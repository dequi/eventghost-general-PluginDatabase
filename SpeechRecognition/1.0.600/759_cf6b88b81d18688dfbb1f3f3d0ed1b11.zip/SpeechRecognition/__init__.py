#
# Plugins/SpeechRecognition/__init__.py
#
# Copyright (C) 2006 MonsterMagnet + BitMonster + Peter
#
# This file is a plugin for EventGhost.
#
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USAfrom win32com.client import constants

eg.RegisterPlugin(
    name = "SpeechRecognition",
    author = "MonsterMagnet + BitMonster + Peter",
    version = "1.0." + "$LastChangedRevision: 600 $".split()[1],
    description = (
        "Uses the Speech-To-Text service of the Microsoft Speech API (SAPI)."
    ),
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAA7DAAAOwwHH"
        "b6hkAAADh0lEQVR4nIXSW0yTBxgG4P/GxRkZ2+gWtR2YCBoOlsL/87fQg4WldkLHqQZo"
        "RcbBUBDCYFxsukaJqyLdAgw3p1AcOhHXNhzaIWLXtVSoWNx0LMsssspGUMYWMB3URVre"
        "XSxpRnaxL/nu3u+5ePMRxP+Mt2MDZ9EqsT0YSsfceBXmxkrhMXFXvR0bOP8JT0zckV3t"
        "6S9pP9fdpL8ybNJ/aR+93x8H/3IPfDN1WPlJhUVnFvx3y3FDw5rPktB56wDL1w6YrLdx"
        "wzWFaxNuWIc/x/y4GoE/NPC5D2PlXjEWbW/A55DDdjxsUZCS/Nk6oNtyZ61x7Fe0P/Bi"
        "6CngnL2FeXs5ArPvwzdZhqWRDPgccgRM6WgrY3roJK5uHWAcm5pvdK+hdRboWgC6Zpcx"
        "Y5EiMFUPTFYDrkN4ZpKiXbX10SsRlDkjjT5OEARB9LzHUDnO8Zt6de/MHbV58O5dH05O"
        "A1oPoB7/DceOFcH7TQa8w/tBJSZ4GBFJ118X0lqapsMJff3GhokOGeZGTmHaVIkOjQQH"
        "TD+j8tYyau4BFc4/MXhJiZUBCQ7lcv+KiBZOCvl8BYdDsQQCcjNhOvLyQ/eZFPx4Vojv"
        "Wnm4dnQ79taewpum3yG/CWSNAGr9ZSjrNYhPzvMKxfvMu0kpWygkNxEEQRDu1q1LGMwE"
        "LPv/2cFM0NkF4Hfex96vVnFkYAEntHa/PLNiYUfsnpuxvILT8XQuK1jc9x+81IfuPYBB"
        "Ahgk8F3kIz69GLUtvbjc6UJBzlUIBE2+SPY+ZyyZ17IroTA2OkEZEgQuqJ4TP26Ng/88"
        "Cf95EjMfRkOWrULnp3q0tdmQmnoG2Tk6lJWffSySVh2MTJS/xk45+HwQiFJHcTTtioDl"
        "JAn7iV0o0eUgtyEPo85R9Pa5UF19BYWFnWhutq4dKG60JQoKKVJQtDkIKA0ZS3Xf1mH8"
        "l4d4ugrUjLyNktslyGlQwNjnwEfNZpSXd0Grve7niUsdtPgtFZtf+GIQoMwUSl2lOGyv"
        "wrTvCZQ2JaRWKajKNNSqm9DysRk1de1PRJKKSWZUmoESFuWSKfkvBAGGjgF2PxuSIQnS"
        "umQQfSEKJJ8WPQvdkfBoy27uD6HhlCmUlaTfHiO9wOblqzjc/HBSrNi47oVDtpGGkG2k"
        "MYRJGkNZ1MCWmGQji+J98mpckiQskophhPMimDtTmTtjZWFxXMWmf9/+DRM268fQlSoX"
        "AAAAAElFTkSuQmCC"
    ),
)


from win32com.client import constants
import win32com.client
import voice
import eg
import wx

class SpeechRecognition(eg.PluginClass):
   
    def __init__(self):        
        try:
            self.listener = win32com.client.Dispatch("SAPI.SpSharedRecognizer")
        except:
            eg.PrintError ("Cannot create SpeechRecognition object")
            return
  
        self.AddAction(SpeechRules)
        
        self.context = self.listener.CreateRecoContext()
        self.grammar = self.context.CreateGrammar()

        self.grammar.DictationSetState(0) 
        self.eventHandler = ContextEvents(self.context, self)
        self.wordsRule = self.grammar.Rules.Add("wordsRule", constants.SRATopLevel + constants.SRADynamic, 0)

        self.myWordsRuleCommands=[]
   
    def __start__(self):        
        try:
            self.grammar.CmdSetRuleState("wordsRule", 1)
        except:
            pass
                
    def __stop__(self):        
        self.grammar.CmdSetRuleState("wordsRule", 0)
        
    def __close__(self):        
        self.listener = None
        self.eventHandler = None
        self.grammar = None
        self.wordsRule = None
        self.myWordsRuleCommands = None


class Text:
    label = "SpeechRecognitionRule: %s"
    button1Label = "Add Command"
    button2Label = "Delete Command"
    rulenameLabel = "Rule Name:"
        
class SpeechRules(eg.ActionClass):
    text = Text

    def __call__(self, Commands= ["hello"], Rule="Rule1"):
        wordsRule = self.plugin.wordsRule
        grammar = self.plugin.grammar            
        wordsRule.Clear()
        [wordsRule.InitialState.AddWordTransition(None, word)for word in Commands ]
        self.plugin.myWordsRuleCommands = Commands     
        grammar.Rules.Commit()        
        grammar.CmdSetRuleState("wordsRule", 1)
        grammar.Rules.Commit()        
           
    def GetLabel(self, Commands= ["hello"], Rule="Rule1"):
        return self.text.label % Rule
    
    def GetCommands(self):
        return self.plugin.myWordsRuleCommands
       
    def Configure(self, Commands= ["hello"], Rule="Rule1"):

        text=self.text

        dialog = eg.ConfigPanel(self)
        sizer = dialog.sizer
        mySizer = wx.FlexGridSizer(cols=2)
                        
        desc1 = wx.StaticText(dialog, -1, text.rulenameLabel)
        mySizer.Add(desc1, 0,  wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5)
            
        Name = wx.TextCtrl(dialog, -1,Rule)
        mySizer.Add(Name, 0, wx.EXPAND|wx.ALL, 5)
            
        Edit = wx.TextCtrl(dialog, -1,)
        mySizer.Add(Edit, 0, wx.EXPAND|wx.ALL, 5)
        
        CommandsEdit = wx.ListBox(dialog, -1, choices=Commands, style=wx.LB_SINGLE)
        mySizer.Add(CommandsEdit, 0, wx.EXPAND|wx.ALL, 5)

        button1 = wx.Button(dialog, -1, label= text.button1Label)
        def OnButton1(event):
            newcommand = Edit.GetValue()
            if len(newcommand)> 0:               
                CommandsEdit.Append(newcommand)
                Edit.Clear()
        button1.Bind(wx.EVT_BUTTON, OnButton1)
        mySizer.Add(button1, 0, wx.EXPAND|wx.ALL, 5)

        button2 = wx.Button(dialog, -1, label= text.button2Label)
        def OnButton2(event):
            try:
                CommandsEdit.Delete(CommandsEdit.GetSelection())
            except:
                pass
        button2.Bind(wx.EVT_BUTTON, OnButton2)
        mySizer.Add(button2, 0, wx.EXPAND|wx.ALL, 5)
        
        sizer.Add(mySizer, 1, wx.EXPAND)
            
        while dialog.Affirmed():           
            Commands =[]
            for i in range (CommandsEdit.GetCount()):
                Commands.append(CommandsEdit.GetString(i))
            dialog.SetResult(Commands, Name.GetValue())
	    #self.__call__(Commands, Name.GetValue())
	       

        
class ContextEventsBase(win32com.client.getevents("SAPI.SpSharedRecoContext")):
    
    pass

class ContextEvents(ContextEventsBase):

    def __init__(self, context, plugin):
        self.plugin = plugin
        ContextEventsBase.__init__(self, context)
   
    def OnRecognition(self, StreamNumber, StreamPosition, RecognitionType, Result):
        newResult = win32com.client.Dispatch(Result)
        self.plugin.TriggerEvent(newResult.PhraseInfo.GetText())
