# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


import wx
import eg

#local imports
import panels
from settings import *
from copy import deepcopy as dc


class ColorPage(panels.Scroll):

    def __init__(self, parent, labels):
        panels.Scroll.__init__(self, parent)
        self.colorbuttons = ()
        for key in sorted(list(ColorSettings.__dict__.keys())):
            if not key.startswith('__') and key != 'globalbackground':
                colorbutton = panels.FontAndColor(self, labels, key)
                colorbutton.UpdateUI()
                self.colorbuttons += (colorbutton,)

        globalback = panels.FontAndColor(self, labels, 'globalbackground')

        globalback.OnGlobalBack = self.OnGlobalBack
        globalback.UpdateUI()
        self.colorbuttons += (globalback,)

        self.AddMany(self.colorbuttons)

    def OnGlobalBack(self, color):
        for key in ColorSettings.__dict__.keys():
            try:
                ColorSettings.__dict__[key].back = color
            except AttributeError:
                pass

        for button in self.colorbuttons:
            button.UpdateUI()

    def OnPageChange(self):
        return dict(colors=True)


class OptionPage(panels.Scroll):

    def __init__(self, parent, labels):
        panels.Scroll.__init__(self, parent)

        antialiasing = wx.CheckBox(self, -1)
        leftright = eg.SpinIntCtrl(self, -1, OptionSettings.leftrightmargin)
        topbottom = eg.SpinIntCtrl(self, -1, OptionSettings.topbottommargin)
        whitespace = wx.CheckBox(self, -1)
        zoomin = wx.TextCtrl(self, -1, OptionSettings.zoomin)
        zoomout = wx.TextCtrl(self, -1, OptionSettings.zoomout)
        setsize = wx.Button(self, -1, labels.dialogsize, size=(120, 30))
        setpos = wx.Button(self, -1, labels.dialogpos, size=(120, 30))

        antialiasing.SetValue(OptionSettings.antialiasing)
        whitespace.SetValue(OptionSettings.whitespacemarker)

        st1 = wx.StaticText(self, -1, labels.antialiasing)
        st2 = wx.StaticText(self, -1, labels.leftrightmargin)
        st3 = wx.StaticText(self, -1, labels.topbottommargin)
        st4 = wx.StaticText(self, -1, labels.whitespacemarker)
        st5 = wx.StaticText(self, -1, labels.zoomin + '     Ctrl+')
        st6 = wx.StaticText(self, -1, labels.zoomout + '   Ctrl+')

        buttonsizer = wx.BoxSizer(wx.HORIZONTAL)

        buttonsizer.Add(setsize, 0, wx.LEFT | wx.TOP, 5)
        buttonsizer.Add(setpos, 0, wx.LEFT | wx.TOP, 5)

        self.AddMany([(st1, antialiasing),
                      (st4, whitespace),
                      (st2, leftright),
                      (st3, topbottom),
                      (st5, zoomin),
                      (st6, zoomout),
                      buttonsizer
                      ])

        eg.EqualizeWidths(self.GetColumn(0))
        eg.EqualizeWidths(self.GetColumn(1))

        self.setsize = setsize

        zoomin.Bind(wx.EVT_CHAR, self.OnZoom)
        zoomout.Bind(wx.EVT_CHAR, self.OnZoom)
        setsize.Bind(wx.EVT_BUTTON, self.OnButton)
        setpos.Bind(wx.EVT_BUTTON, self.OnButton)

    def OnButton(self, evt):
        button = evt.GetEventObject()
        label = button.GetLabel()
        if label != 'Done':
            if button == self.setsize:
                OptionSettings.dialogsize = tuple(button.GetParent().GetParent().GetParent().GetSize())
            else:
                OptionSettings.dialogpos = tuple(button.GetParent().GetParent().GetParent().GetPosition())
            button.SetLabel('Done')
            wx.CallLater(4000, button.SetLabel, label)
        evt.Skip()

    def OnZoom(self, evt):
        def validate(text):
            if len(text) > 1:
                text = text[-1:]
            return text

        zin, zout = self.GetColumn(1)[-2:]
        zin.SetValue(validate(zin.GetValue()))
        zout.SetValue(validate(zout.GetValue()))
        evt.Skip()

    def OnPageChange(self):
        antialiasing, whitespace, leftright, topbottom, zoomin, zoomout = self.GetColumn(1)

        OptionSettings.antialiasing = antialiasing.GetValue()
        OptionSettings.leftrightmargin = leftright.GetValue()
        OptionSettings.topbottommargin = topbottom.GetValue()
        OptionSettings.whitespacemarker = whitespace.GetValue()
        OptionSettings.zoomin = zoomin.GetValue()
        OptionSettings.zoomout = zoomout.GetValue()
        return dict(options=True)


class IndentPage(panels.Scroll):

    def __init__(self, parent, labels):
        panels.Scroll.__init__(self, parent)

        indenterror = wx.Choice(self, -1, choices=labels.indenterrorchoice)
        indentguide = wx.CheckBox(self, -1)
        indentspace = eg.SpinIntCtrl(self, -1, value=IndentSettings.indentspace)
        indentbackspace = wx.CheckBox(self, -1)
        indenttab = wx.CheckBox(self, -1)

        indenterror.SetSelection(IndentSettings.indenterror)
        indentguide.SetValue(IndentSettings.indentguide)
        indentbackspace.SetValue(IndentSettings.indentbackspace)
        indenttab.SetValue(IndentSettings.indenttab)

        st1 = wx.StaticText(self, -1, labels.indenterror)
        st2 = wx.StaticText(self, -1, labels.indentguide)
        st3 = wx.StaticText(self, -1, labels.indentspace)
        st4 = wx.StaticText(self, -1, labels.indentbackspace)
        st5 = wx.StaticText(self, -1, labels.indenttab)

        self.AddMany([(st2, indentguide),
                      (st4, indentbackspace),
                      (st5, indenttab),
                      (st3, indentspace),
                      (st1, indenterror)
                      ])

        eg.EqualizeWidths(self.GetColumn(0))
        eg.EqualizeWidths(self.GetColumn(1))


    def OnPageChange(self):
        indentguide, indentbackspace, indenttab, indentspace, indenterror = self.GetColumn(1)
        IndentSettings.indenterror = indenterror.GetSelection()
        IndentSettings.indentguide = indentguide.GetValue()
        IndentSettings.indentspace = indentspace.GetValue()
        IndentSettings.indentbackspace = indentbackspace.GetValue()
        IndentSettings.indenttab = indenttab.GetValue()
        
        return dict(indent=True)


class FoldingPage(panels.Scroll):

    def __init__(self, parent, labels):
        panels.Scroll.__init__(self, parent)

        foldingicon = wx.Choice(self, -1, choices=labels.foldingiconchoice)
        foldingcomments = wx.CheckBox(self, -1)
        foldingquotes =wx.CheckBox(self,  -1)

        foldingicon.SetSelection(FoldingSettings.foldingicon)
        foldingcomments.SetValue(FoldingSettings.foldingcomments)
        foldingquotes.SetValue(FoldingSettings.foldingquotes)

        st1 = wx.StaticText(self, -1, labels.foldingicon)
        st2 = wx.StaticText(self, -1, labels.foldingcomments)
        st3 = wx.StaticText(self, -1, labels.foldingquotes)

        self.AddMany([(st2, foldingcomments),
                      (st3, foldingquotes),
                      (st1, foldingicon)
                      ])

        eg.EqualizeWidths(self.GetColumn(0))
        eg.EqualizeWidths(self.GetColumn(1))

    def OnPageChange(self):    
        foldingcomments, foldingquotes, foldingicon = self.GetColumn(1)
        FoldingSettings.foldingicon = foldingicon.GetSelection()
        FoldingSettings.foldingcomments = foldingcomments.GetValue()
        FoldingSettings.foldingquotes = foldingquotes.GetValue()
        return dict(folding=True, colors=True)