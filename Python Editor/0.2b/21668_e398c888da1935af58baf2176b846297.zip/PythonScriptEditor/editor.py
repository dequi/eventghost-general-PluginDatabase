# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import wx
import re
import styles
import panels
import keyword
from  wx import stc
from settings import *
from copy import deepcopy as dc
from colorconversion import RGB_to_HEX


class PythonCodeEditor(stc.StyledTextCtrl):

    def __init__(self, parent, ID,
                 pos=wx.DefaultPosition, size=wx.DefaultSize,
                 style=0):

        stc.StyledTextCtrl.__init__(self, parent, ID, pos, size, style)

        self.SetCodePage(stc.STC_CP_UTF8)
        self.SetLexer(stc.STC_LEX_PYTHON)
        self.SetKeyWords(0, " ".join(keyword.kwlist))
        self.popupMenu = self.NewPopupMenu()
        self.rekeyword = re.compile(
            r"(\sreturn\b)|(\sbreak\b)|(\spass\b)|(\scontinue\b)|(\sraise\b)",
            re.MULTILINE
        )
        self.reslash = re.compile(r"\\\Z")
        self.renonwhitespace = re.compile('\S', re.M)
        self.tabwidth = 4
        self.pagenum = 0

    def SetBindings(self):
        self.Bind(stc.EVT_STC_UPDATEUI, self.OnUpdateUI)
        self.Bind(stc.EVT_STC_MARGINCLICK, self.OnMarginClick)
        self.Bind(wx.EVT_KEY_DOWN, self.OnKeyPressed)
        self.Bind(wx.EVT_RIGHT_UP, self.OnRightClick)

    def NewPopupMenu(self):
        menu = wx.Menu()
        text = eg.text.MainFrame.Menu
        def AddMenuItem(ident, menuId):
            self.Bind(wx.EVT_MENU, getattr(self, "OnCmd" + ident), id=menuId)
            return menu.Append(menuId, getattr(text, ident, ident))

        AddMenuItem("Undo", wx.ID_UNDO)
        AddMenuItem("Redo", wx.ID_REDO)
        menu.AppendSeparator()
        AddMenuItem("Cut", wx.ID_CUT)
        AddMenuItem("Copy", wx.ID_COPY)
        AddMenuItem("Paste", wx.ID_PASTE)
        AddMenuItem("Delete", wx.ID_DELETE)
        menu.AppendSeparator()
        AddMenuItem("SelectAll", wx.ID_SELECTALL)
        return menu

    def OnRightClick(self, dummyEvent):
        menu = self.popupMenu
        first, last = self.GetSelection()
        menu.Enable(wx.ID_UNDO, self.CanUndo())
        menu.Enable(wx.ID_REDO, self.CanUndo())
        menu.Enable(wx.ID_CUT, first != last)
        menu.Enable(wx.ID_COPY, first != last)
        menu.Enable(wx.ID_PASTE, self.CanPaste())
        menu.Enable(wx.ID_DELETE, first != last)
        menu.Enable(wx.ID_SELECTALL, True)
        self.PopupMenu(menu)

    def OnCmdUndo(self, dummyEvent=None):
        self.Undo()

    def OnCmdRedo(self, dummyEvent=None):
        self.Redo()

    def OnCmdCut(self, dummyEvent=None):
        self.Cut()

    def OnCmdCopy(self, dummyEvent=None):
        self.Copy()

    def OnCmdPaste(self, dummyEvent=None):
        self.Paste()

    def OnCmdDelete(self, dummyEvent=None):
        self.Delete()

    def OnCmdSelectAll(self, dummyEvent=None):
        self.SelectAll()

    def Delete(self):
        self.CmdKeyExecute(stc.STC_CMD_CLEAR)

    def OnKeyPressed(self, event):
        if self.CallTipActive():
            self.CallTipCancel()

        key = event.GetKeyCode()

        if (key == wx.WXK_RETURN) or (key == 372):
            self.CmdKeyExecute(stc.STC_CMD_NEWLINE)
            self.AutoIndent()
        #elif key == wx.WXK_TAB and event.GetModifiers() == wx.MOD_CONTROL:
        #    self.Navigate()

        elif key == 32 and event.ControlDown():
            pos = self.GetCurrentPos()

            # Tips
            if event.ShiftDown():
                self.CallTipSetBackground("yellow")
                self.CallTipShow(pos, 'lots of of text: blah, blah, blah\n\n'
                                 'show some suff, maybe parameters..\n\n'
                                 'fubar(param1, param2)')
            # Code completion
            else:
                kw = keyword.kwlist[:]
                kw.append("zzzzzz?2")
                kw.append("aaaaa?2")
                kw.append("__init__?3")
                kw.append("zzaaaaa?2")
                kw.append("zzbaaaa?2")
                kw.append("this_is_a_longer_value")

                kw.sort()
                self.AutoCompSetIgnoreCase(False)

                for i in range(len(kw)):
                    if kw[i] in keyword.kwlist:
                        kw[i] = kw[i] + "?1"

                self.AutoCompShow(0, " ".join(kw))
        else:
            event.Skip()

    def OnUpdateUI(self, evt):
        braceAtCaret = -1
        braceOpposite = -1
        charBefore = None
        caretPos = self.GetCurrentPos()

        if caretPos > 0:
            charBefore = self.GetCharAt(caretPos - 1)
            styleBefore = self.GetStyleAt(caretPos - 1)

        if charBefore and chr(charBefore) in "[]{}()" and styleBefore == stc.STC_P_OPERATOR:
            braceAtCaret = caretPos - 1

        if braceAtCaret < 0:
            charAfter = self.GetCharAt(caretPos)
            styleAfter = self.GetStyleAt(caretPos)

            if charAfter and chr(charAfter) in "[]{}()" and styleAfter == stc.STC_P_OPERATOR:
                braceAtCaret = caretPos

        if braceAtCaret >= 0:
            braceOpposite = self.BraceMatch(braceAtCaret)

        if braceAtCaret != -1  and braceOpposite == -1:
            self.BraceBadLight(braceAtCaret)
        else:
            self.BraceHighlight(braceAtCaret, braceOpposite)

    def OnMarginClick(self, evt):
        if evt.GetMargin() == 2:
            if evt.GetShift() and evt.GetControl():
                self.FoldAll()
            else:
                lineClicked = self.LineFromPosition(evt.GetPosition())

                if self.GetFoldLevel(lineClicked) & stc.STC_FOLDLEVELHEADERFLAG:
                    if evt.GetShift():
                        self.SetFoldExpanded(lineClicked, True)
                        self.Expand(lineClicked, True, True, 1)
                    elif evt.GetControl():
                        if self.GetFoldExpanded(lineClicked):
                            self.SetFoldExpanded(lineClicked, False)
                            self.Expand(lineClicked, False, True, 0)
                        else:
                            self.SetFoldExpanded(lineClicked, True)
                            self.Expand(lineClicked, True, True, 100)
                    else:
                        self.ToggleFold(lineClicked)

    def SetPage(self, page):
        print page
        self.pagenum = page

    def GetPage(self):
        return self.pagenum

    def FoldAll(self):
        lineCount = self.GetLineCount()
        expanding = True

        for lineNum in range(lineCount):
            if self.GetFoldLevel(lineNum) & stc.STC_FOLDLEVELHEADERFLAG:
                expanding = not self.GetFoldExpanded(lineNum)
                break
        lineNum = 0

        while lineNum < lineCount:
            level = self.GetFoldLevel(lineNum)
            if level & stc.STC_FOLDLEVELHEADERFLAG and \
               (level & stc.STC_FOLDLEVELNUMBERMASK) == stc.STC_FOLDLEVELBASE:
                if expanding:
                    self.SetFoldExpanded(lineNum, True)
                    lineNum = self.Expand(lineNum, True)
                    lineNum = lineNum - 1
                else:
                    lastChild = self.GetLastChild(lineNum, -1)
                    self.SetFoldExpanded(lineNum, False)
                    if lastChild > lineNum:
                        self.HideLines(lineNum+1, lastChild)
            lineNum = lineNum + 1

    def Expand(self, line, doExpand, force=False, visLevels=0, level=-1):
        lastChild = self.GetLastChild(line, level)
        line = line + 1

        while line <= lastChild:
            if force:
                if visLevels > 0:
                    self.ShowLines(line, line)
                else:
                    self.HideLines(line, line)
            else:
                if doExpand:
                    self.ShowLines(line, line)

            if level == -1:
                level = self.GetFoldLevel(line)

            if level & stc.STC_FOLDLEVELHEADERFLAG:
                if force:
                    if visLevels > 1:
                        self.SetFoldExpanded(line, True)
                    else:
                        self.SetFoldExpanded(line, False)

                    line = self.Expand(line, doExpand, force, visLevels-1)

                else:
                    if doExpand and self.GetFoldExpanded(line):
                        line = self.Expand(line, True, force, visLevels-1)
                    else:
                        line = self.Expand(line, False, force, visLevels-1)
            else:
                line = line + 1

        return line

    def AutoIndent(self):
        pos = self.GetCurrentPos()
        #Strip trailing whitespace first.
        currentline = self.LineFromPosition(pos)
        lineendpos = self.GetLineEndPosition(currentline)
        if lineendpos > pos:
            self.SetTargetStart(pos)
            self.SetTargetEnd(lineendpos)
            textRange = self.GetTextRange(pos, lineendpos)
            self.ReplaceTarget(textRange.rstrip())

        #Look at last line
        pos = pos - 1
        clinenumber = self.LineFromPosition(pos)
        linenumber = clinenumber

        self.GotoPos(pos)
        self.GotoLine(clinenumber)

        numtabs = self.GetLineIndentation(clinenumber+1) / self.tabwidth
        search = self.renonwhitespace.search
        if (
            search(self.GetLine(clinenumber+1)) is not None
            and search(self.GetLine(clinenumber)) is None
        ):
            numtabs += self.GetLineIndentation(clinenumber) / self.tabwidth

        if numtabs == 0:
            numtabs = self.GetLineIndentation(linenumber) / self.tabwidth

        if True:
            checkat = self.GetLineEndPosition(linenumber) - 1
            if self.GetCharAt(checkat) == ord(':'):
                numtabs = numtabs + 1
            else:
                lastline = self.GetLine(linenumber)
                #Remove Comment:
                comment = lastline.find('#')
                if comment > -1:
                    lastline = lastline[:comment]
                if self.reslash.search(lastline.rstrip()) is None:
                    if self.rekeyword.search(lastline) is not None:
                        numtabs = numtabs - 1
        #Go to current line to add tabs

        self.SetTargetStart(pos+1)
        end = self.GetLineEndPosition(clinenumber+1)
        self.SetTargetEnd(end)


        self.ReplaceTarget(self.GetTextRange(pos+1, end).lstrip())

        pos = pos + 1
        self.GotoPos(pos)
        x = 0
        while (x < numtabs):
            self.AddText(' ' * self.tabwidth)
            x = x + 1
        #/Auto Indent Code

        #Ensure proper keyboard navigation:
        self.CmdKeyExecute(stc.STC_CMD_CHARLEFT)
        self.CmdKeyExecute(stc.STC_CMD_CHARRIGHT)

    def GetPythonCode(self):
        return self.GetTextUTF8().replace('\r\n', '\n')

    def ReloadSettings(self, **kwargs):
        self.Finalize(**kwargs)

    def Finalize(self, sourceCode=None, options=False, colors=False, indent=False,  folding=False):
        if sourceCode is not None or options:
            self.SetOtherOptions()
        if sourceCode is not None or folding:
            self.SetFoldingOptions()
        if sourceCode is not None or indent:
            self.SetIndentOptions()
        if sourceCode is not None or colors:
            self.SetColors()

        if sourceCode is not None:
            self.SetTextUTF8(sourceCode)

            self.EmptyUndoBuffer()
            self.Colourise(0, -1)

            self.SetMarginType(1, stc.STC_MARGIN_NUMBER)
            self.SetMarginWidth(1, 25)
            self.SetBindings()

    def SetColors(self):
        colors = ColorSettings
        colordict = ColorSettings.__dict__
        fontdict = FontSettings.__dict__
        stylesdict = styles.EditorStyles.__dict__

        chosenfoldingicon = FoldingSettings.foldingicon
        foldingstyles = stylesdict['foldingicon']
        foldingiconstyles = stylesdict['foldingiconchoice'][chosenfoldingicon]
        forecolor = RGB_to_HEX(colors.folding.fore)
        backcolor = RGB_to_HEX(colors.folding.back)

        self.SetCaretForeground(RGB_to_HEX(colors.caret.fore))
        self.SetFoldMarginColour(True, backcolor)

        formatstring = 'fore:{fore},back:{back},{weight},{underline},{style},{eol},face:{face},size:{pointSize}'

        for key in colordict.keys():
            if key not in stylesdict or key.startswith('__'):
                continue
            styleparams = dc(colordict[key].__dict__)
            styleparams.update(dc(fontdict[key].__dict__))
            colorstyle = stylesdict[key]

            styleparams['fore'] = RGB_to_HEX(styleparams['fore'])
            styleparams['back'] = RGB_to_HEX(styleparams['back'])
            stylestring = formatstring.format(**styleparams).replace('normal,', '')
            self.StyleSetSpec(colorstyle, stylestring)
            if key == 'whitespace':
                self.StyleSetSpec(stylesdict['default'], stylestring)

        for i, style in enumerate(foldingstyles):
            self.MarkerDefine(style, foldingiconstyles[i], forecolor, backcolor)


    def SetFoldingOptions(self):
        folding = FoldingSettings
        self.SetProperty("fold", str(int(bool(folding.foldingicon))))
        self.SetEdgeMode(stc.STC_EDGE_BACKGROUND)
        self.SetEdgeColumn(78)
        self.SetMarginType(2, stc.STC_MARGIN_SYMBOL)
        self.SetMarginMask(2, stc.STC_MASK_FOLDERS)
        self.SetMarginSensitive(2, True)
        self.SetMarginWidth(2, 12)
        self.SetProperty("fold.comment.python", str(int(folding.foldingcomments)))
        self.SetProperty("fold.quotes.python", str(int(folding.foldingquotes)))

    def SetIndentOptions(self):
        indent = IndentSettings
        self.SetProperty("tab.timmy.whinge.level", str(indent.indenterror))
        self.SetIndentationGuides(indent.indentguide)
        self.SetBackSpaceUnIndents(indent.indentbackspace)
        self.SetIndent(indent.indentspace)
        self.SetTabIndents(indent.indenttab)

    def SetOtherOptions(self):
        options = OptionSettings
        self.CmdKeyAssign(ord(options.zoomin), stc.STC_SCMOD_CTRL, stc.STC_CMD_ZOOMIN)
        self.CmdKeyAssign(ord(options.zoomout), stc.STC_SCMOD_CTRL, stc.STC_CMD_ZOOMOUT)

        self.SetMargins(options.leftrightmargin, options.topbottommargin)
        self.SetUseAntiAliasing(options.antialiasing)
        self.SetViewWhiteSpace(options.whitespacemarker)
