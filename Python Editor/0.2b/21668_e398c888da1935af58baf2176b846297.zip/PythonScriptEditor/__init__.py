# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import eg

eg.RegisterPlugin(
    name = 'Python Editor',
    author = 'K',
    version = '0.2b',
    kind = 'other',
    canMultiLoad = False,
    description = ('This is a replacement python script editor. '
                   'When installing this editor it will override '
                   'the existing EventGhost Editor.\n'
                   'Fetures:\n'
                   '\tColor Support\n'
                   '\tSaved Dialog Size\n'
                   '\tShows errors in editor\n'
                   '\tChanging tab amount\n'
                   '\tZooming in and out\n'
                   '\tCode Folding\n'
                   '\tThreading support\n'
                   ),
    guid='{13049FCC-4EA9-4666-A4DF-EA601E0CA0CE}'
    )

import wx
import sys
import editor
import weakref
import notebook
import threading
import scripterror
import scriptthread
from settings import *
from types import ModuleType
from text import Text

class CompileCode:

    idCounter = 0
    scriptDict = None
    threadDict = {}    

    def __init__(self, sourceCode=""):
        idCounter = self.__class__.idCounter
        self.mod = ModuleType(str(idCounter))

        code = sourceCode.splitlines()
        try:
            runinthread = eval(code.pop(0).split(':')[1])
        except:
            runinthread = False
        sourceCode = '\n'.join(code)

        self.sourceCode = sourceCode

        self.__class__.idCounter += 1
        self.scriptDict[idCounter] = self

        try:
            compiledcode = compile(sourceCode + "\n", str(idCounter), "exec", 0, 1)
            self.Script = scriptthread.Thread(self, idCounter, runinthread, self.mod, compiledcode)
        except:
            self.Script = None
            scripterror.PrintTraceback(sourceCode, self.scriptDict)

    def __call__(self):

        if self.Script is None:
            self.__init__(self.sourceCode)
            if self.code is None:
                return

        self.Script.start()

    @eg.LogIt
    def __del__(self):
        pass

class RunCode:

    def __init__(self, sourceCode):
        compiledcode = CompileCode(sourceCode)
        compiledcode()

class Script(eg.ActionBase):

    text = Text
    
    def __init__(self, plugin=None, override=False):

        self.codeerror = None

        if plugin is not None:
            self.plugin = plugin

        if override:
            self.Compile = CompileCode
        else:
            self.__call__ = RunCode

    def GetLabel(self, dummySourceCode=""):
        return self.name

    def Configure(self, sourceCode=""):

        text = self.text
        panel = eg.ConfigPanel()
        dialog = panel.dialog
        dialognotebook = dialog.notebook
        buttonrow = dialog.buttonRow
        
        editCtrl = editor.PythonCodeEditor(panel, -1)
        threadbutton = wx.Button(dialog, -1, text.threadoffbutton)

        if not sourceCode.startswith('# runinthread:'):
            sourceCode = '# runinthread:False\n' + sourceCode

        sourceCode = sourceCode.splitlines()
        self.runinthread = eval(sourceCode.pop(0).split(':')[1])
        sourceCode = '\n'.join(sourceCode)

        if self.runinthread:
            threadbutton.SetLabel(text.threadonbutton)
            threadbutton.SetBackgroundColour(wx.RED)

        optionpage = notebook.OptionPage(dialognotebook, text)
        colorpage = notebook.ColorPage(dialognotebook, text)
        indentpage = notebook.IndentPage(dialognotebook, text)
        foldingpage = notebook.FoldingPage(dialognotebook, text)

        dialognotebook.SetPageText (0, text.editorpage)
        dialognotebook.AddPage(optionpage, text.optionpage)
        dialognotebook.AddPage(colorpage, text.colorpage)
        dialognotebook.AddPage(indentpage, text.indentpage)
        dialognotebook.AddPage(foldingpage, text.foldingpage)
        
        panel.sizer.Add(editCtrl, 1, wx.EXPAND)

        editCtrl.Finalize(sourceCode)

        buttonrow.Add(threadbutton)

        dialog.FinishSetup()
        threadbutton.MoveAfterInTabOrder(dialognotebook)
        dialog.SetPosition(OptionSettings.dialogpos)
        dialog.SetSize(OptionSettings.dialogsize)

        buttonrow.testButton.Unbind(wx.EVT_BUTTON, handler=dialog.OnTestButton)
        buttonrow.applyButton.Unbind(wx.EVT_BUTTON, handler=buttonrow.OnApply)
        buttonrow.testButton.Bind(wx.EVT_BUTTON, self.OnTest)
        buttonrow.applyButton.Bind(wx.EVT_BUTTON, self.OnApply)
        threadbutton.Bind(wx.EVT_BUTTON, self.OnThread)

        dialognotebook.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGING, self.OnPageChanging)
        editCtrl.Bind(wx.EVT_KEY_DOWN, self.OnKeyDown)

        self.panel = panel
        self.editCtrl = editCtrl

        while panel.Affirmed():
            panel.SetResult('# runinthread:' + str(self.runinthread) + '\n' + self.editCtrl.GetPythonCode())

    def EnableButtons(self, flag):
        self.panel.EnableButtons(flag)
        self.panel.dialog.buttonRow.cancelButton.Enable(flag)

    def NotebookPageChange(self):
        currentpage = self.panel.dialog.notebook.GetCurrentPage()
        self.EnableButtons(not hasattr(currentpage,  'OnPageChange'))

    def OnPageChanging(self, evt):
        currentpage = self.panel.dialog.notebook.GetCurrentPage()
        if hasattr(currentpage,  'OnPageChange'):
            self.editCtrl.ReloadSettings(**currentpage.OnPageChange())

        wx.CallAfter(self.NotebookPageChange)
        evt.Skip()

    def OnKeyDown(self, evt):
        if self.codeerror is not None:
            errline, errlinenum, errlinestart, errlineend= self.codeerror
            currlinepos = self.editCtrl.GetCurrentPos()
            currlinenum = self.editCtrl.LineFromPosition(currlinepos)
            if currlinenum == errlinenum:
                self.editCtrl.SetTargetStart(errlinestart)
                self.editCtrl.SetTargetEnd(errlineend)
                self.editCtrl.ReplaceTarget(errline)

                if currlinepos > errlinestart + len(errline):
                    self.editCtrl.GotoPos(errlinestart + len(errline))
                else:
                    self.editCtrl.GotoPos(currlinepos)

                self.codeerror = None

        self.panel.SetIsDirty(True)
        evt.Skip()

    def OnTest(self, evt):
        if self.OnApply():
            self.panel.dialog.DispatchEvent(evt, eg.ID_TEST)
            evt.Skip()
 
    def OnApply(self, evt=None):
        
        sourceCode = self.editCtrl.GetPythonCode()

        try:
            compile(sourceCode + '\n', '', 'exec')
            if evt is None:
                return True
            else:
                self.panel.dialog.DispatchEvent(evt, wx.ID_APPLY)
        except:
            self.codeerror = scripterror.PrintTraceback(sourceCode, editCtrl=self.editCtrl)
        if evt is None:
            return False  
        else:
            evt.Skip()

    def OnThread(self, evt):
        button = evt.GetEventObject()
        if button.GetBackgroundColour() == wx.RED:
            self.runinthread = True
            button.SetLabel(self.text.threadoffbutton)
            button.SetBackgroundColour(wx.SystemSettings_GetColour(wx.SYS_COLOUR_BTNFACE).Get())
        else:
            self.runinthread = False
            button.SetLabel(self.text.threadonbutton)
            button.SetBackgroundColour(wx.RED)
        self.panel.SetIsDirty(True)
        evt.Skip()


class PythonScriptEditor(eg.PluginBase):

    def __init__(self):
        self.savedexit = eg.Exit
        self.savedconfigure = eg.plugins.EventGhost.PythonScript.Configure
        self.savedcall = eg.plugins.EventGhost.PythonScript.Compile
        self.threaddict = {}
        self.override = False
        self.AddAction(Script)


    # def Configure(self, override=False):

    #     panel = eg.ConfigPanel()

    #     overrideCtrl = panel.CheckBox(override)

    #     panel.AddLine("Override Stock EG Script Editor", overrideCtrl)

    #     while panel.Affirmed():
    #         panel.SetResult(overrideCtrl.GetValue())

    # def __start__(self, override=False):
    #     eg.Exit = scriptthread.Exit()

    #     if override:
    #         self.info.actions['Script'] = Script(self, override)
    #         for pluginInfo in eg.actionThread.corePluginInfos:
    #             if pluginInfo.guid == '{9D499A2C-72B6-40B0-8C8C-995831B10BB4}':
    #                 pluginInfo.actions['PythonScript'] = self.info.actions['Script']
    #                 print pluginInfo.actions['PythonScript']

    def __start__(self):
        eg.Exit = scriptthread.Exit()


    def __close__(self):
        pass
        #eg.Exit.Close()

    def __stop__(self):
        #eg.Exit.Close()
        try:
            eg.Exit = self.savedexit
        except:
            pass
        # try:
        #     eg.plugins.EventGhost.PythonScript = self.savedpythonscript
        # except:
        #     pass