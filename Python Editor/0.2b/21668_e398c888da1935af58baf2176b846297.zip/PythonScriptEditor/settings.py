# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


import eg
import wx

winback = wx.SystemSettings_GetColour(wx.SYS_COLOUR_WINDOW).Get()
winfore = wx.SystemSettings_GetColour(wx.SYS_COLOUR_WINDOWTEXT).Get()

class Settings(eg.PersistentData):
    class ColorSettings:
        class bracecorrect:
            fore = (82, 155, 117)
            back = winback
            
        class braceincorrect:
            fore = (255, 8, 0)
            back = winback
    
        class caret:
            fore = (216, 216, 216)
                
        class classnames:
            fore = (0, 0, 255)
            back = winback
     
        class commentblock:
            fore = (125, 125, 125)
            back = winback
    
        class comments:
            fore = (125, 125, 125)
            back = winback
     
        class controlchar:
            fore = (51, 0, 153)
            back = winback
     
        class decorators:
            fore = (78, 255, 34)
            back = winback
    
        class defnames:
            fore = (0, 102, 204)
            back = winback
    
        class double:
            fore = (51, 153, 255)
            back = winback
    
        class folding:
            fore = (137, 3, 27)
            back = winback
    
        class identifiers:
            fore = winfore
            back = winback
    
        class keywords:
            fore = (51, 153, 0)
            back = winback
    
        class keywords2:
            fore = (51, 153, 0)
            back = winback
    
        class linenumbers:
            fore = (51, 0, 153)
            back = winback
    
        class missingquotes:
            fore = (0, 0, 255)
            back = winback
    
        class numbers:
            fore = (0, 204, 0)
            back = winback
    
        class operators:
            fore = (0, 0, 255)
            back = winback
    
        class single:
            fore = (196, 0, 196)
            back = winback
    
        class tripledouble:
            fore = (121, 0, 0)
            back = winback
    
        class triplesingle:
            fore = (255, 154, 3)
            back = winback
    
        class whitespace:
            fore = winfore
            back = winback
    
        class globalbackground:
            back = winback
    
    class FoldingSettings:
        foldingcomments = True
        foldingicon = 4
        foldingquotes = True
    
    class IndentSettings:
        indentbackspace = True
        indenterror = 4
        indentguide = True
        indentspace = 4
        indenttab = True
    
    class OptionSettings:
        antialiasing = True
        dialogsize = (635, 439)
        dialogpos = (635, 439)
        leftrightmargin = 8
        topbottommargin = 6
        whitespacemarker = True
        zoomin = "B"
        zoomout = "N"
    
    class FontSettings:
        class bracecorrect:
            weight = "normal"
            eol =  "normal"
            face =  "Arial"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class braceincorrect:
            weight = "normal"
            eol =  "normal"
            face =  "Arial"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
                
        class classnames:
            weight = "bold"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "underline"
    
        class commentblock:
            weight = "normal"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "italic"
            underline = "normal"
    
        class comments:
            weight = "normal"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "italic"
            underline = "normal"
    
        class controlchar:
            weight = "normal"
            eol =  "normal"
            face =  "Comic Sans MS"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
     
        class decorators:
            weight = "bold"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class defnames:
            weight = "bold"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class double:
            weight = "normal"
            eol =  "normal"
            face =  "Arial"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class identifiers:
            weight = "normal"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class keywords:
            weight = "normal"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
     
        class keywords2:
            weight = "normal"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class linenumbers:
            weight = "normal"
            eol =  "normal"
            face =  "Arial"
            family = "swiss"
            pointSize = 8
            style = "normal"
            underline = "normal"
     
        class missingquotes:
            weight = "normal"
            eol =  "eol"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
     
        class numbers:
            weight = "normal"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class operators:
            weight = "bold"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class single:
            weight = "normal"
            eol =  "normal"
            face =  "Arial"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal" 

        class triplesingle:
            weight = "normal"
            eol =  "normal"
            face =  "Arial"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"
    
        class whitespace:
            weight = "normal"
            eol =  "normal"
            face =  "Courier New"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"

        class tripledouble:
            weight = "normal"
            eol =  "normal"
            face =  "Arial"
            family = "swiss"
            pointSize = 10
            style = "normal"
            underline = "normal"

ColorSettings = Settings.ColorSettings
FontSettings = Settings.FontSettings
IndentSettings = Settings.IndentSettings
OptionSettings = Settings.OptionSettings
FoldingSettings = Settings.FoldingSettings