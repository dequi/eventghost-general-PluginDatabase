# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import wx
from  wx.lib import scrolledpanel
import buttons
from settings import ColorSettings, FontSettings

class Scroll(scrolledpanel.ScrolledPanel):

    def __init__(self, parent):
        scrolledpanel.ScrolledPanel.__init__(self, parent)
        self.SetupScrolling(scroll_x = False)
        try:
            self.sizer = wx.WrapSizer()
        except AttributeError:
            self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.SetSizer(self.sizer)
        self.items = ()
        self.Bind(wx.EVT_SIZE, self.OnSize)

    def OnSize(self, evt):
        size = self.GetSize()
        vsize = self.GetVirtualSize()
        self.SetVirtualSize((size[0], vsize[1]))

    def Add(self, item):
        self.sizer.Add(item)

    def AddMany(self, items):
        for i, item in enumerate(items):
            try:
                self.sizer.Add(*item)
            except:
                if isinstance(item, tuple):
                    widget1, widget2 = item
                    tmpsizer = wx.BoxSizer(wx.HORIZONTAL)
                    if i == len(items) - 1:
                        style1 = wx.ALIGN_BOTTOM|wx.TOP|wx.LEFT|wx.BOTTOM
                        style2 = wx.ALIGN_BOTTOM|wx.ALL

                    else:
                        style1 = wx.ALIGN_BOTTOM|wx.TOP|wx.LEFT
                        style2 = wx.ALIGN_BOTTOM|wx.TOP|wx.LEFT|wx.RIGHT

                    tmpsizer.Add(widget1, 0, style1, 5)
                    tmpsizer.Add(widget2, 0, style2, 5)
                    self.sizer.Add(tmpsizer)
                    self.items += (item,)
                else:
                    self.sizer.Add(item)

    def GetColumn(self, colnum):
        return tuple(item[colnum] for item in self.items)


class FontAndColor(wx.Panel):

    def __init__(self, parent, labels, key):
        self.key = key

        wx.Panel.__init__(self, parent, -1)

        sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.samplepanel = wx.Panel(self, -1)
        self.samplepanel.SetMinSize((200, 40))
        samplesizer = wx.BoxSizer(wx.VERTICAL)
        self.sampletext = wx.StaticText(self.samplepanel, -1, labels.__dict__[key], size=(200, 30))

        samplesizer.Add(self.sampletext, 0, wx.EXPAND |  wx.TOP | wx.LEFT, 8)
        self.samplepanel.SetSizer(samplesizer)

        sizer.Add(self.samplepanel, 1, wx.EXPAND)

        fontcontrol = buttons.Font(self, labels, key)
        colorcontrol = buttons.ColorChooser(self, labels, key)

        if hasattr(fontcontrol, 'fontbutton'):
            sizer.Add(fontcontrol.fontbutton, 0, wx.TOP | wx.LEFT, 5)

        if hasattr(colorcontrol, 'forebutton'):
            sizer.Add(colorcontrol.forebutton, 0, wx.TOP | wx.LEFT, 5)

        if hasattr(colorcontrol, 'backbutton'):
            sizer.Add(colorcontrol.backbutton, 0, wx.TOP | wx.LEFT, 5)

        self.SetSizer(sizer)

    def UpdateUI(self):
        if hasattr(FontSettings, self.key):
            font = buttons.CreateFont(FontSettings.__dict__[self.key])
            self.sampletext.SetFont(font)

        if hasattr(ColorSettings, self.key):
            if hasattr(ColorSettings.__dict__[self.key], 'fore'):
                fore = ColorSettings.__dict__[self.key].fore
                self.sampletext.SetForegroundColour(wx.Colour(*fore))

            if hasattr(ColorSettings.__dict__[self.key], 'back'):
                back = ColorSettings.__dict__[self.key].back
                self.samplepanel.SetBackgroundColour(wx.Colour(*back))
                self.sampletext.SetBackgroundColour(wx.Colour(*back))
                self.samplepanel.Refresh()
