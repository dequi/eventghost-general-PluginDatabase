# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


import eg
from wx.stc import *

class EditorStyles:
    bracecorrect = STC_STYLE_BRACELIGHT
    braceincorrect = STC_STYLE_BRACEBAD
    classnames = STC_P_CLASSNAME
    commentblock = STC_P_COMMENTBLOCK
    comments = STC_P_COMMENTLINE
    controlchar = STC_STYLE_CONTROLCHAR
    decorators = STC_P_DECORATOR
    default = STC_STYLE_DEFAULT
    defnames = STC_P_DEFNAME
    double = STC_P_STRING
    identifiers = STC_P_IDENTIFIER
    keywords = STC_P_WORD
    keywords2 = STC_P_WORD2
    linenumbers = STC_STYLE_LINENUMBER
    missingquotes = STC_P_STRINGEOL
    numbers = STC_P_NUMBER
    operators = STC_P_OPERATOR
    single = STC_P_CHARACTER
    tripledouble = STC_P_TRIPLEDOUBLE
    triplesingle = STC_P_TRIPLE
    whitespace = STC_P_DEFAULT

    foldingiconchoice = [[STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY
                          ],
                         [STC_MARK_ARROWDOWN,
                          STC_MARK_ARROW,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY
                          ],
                         [STC_MARK_BOXMINUS,
                          STC_MARK_BOXPLUS,
                          STC_MARK_VLINE,
                          STC_MARK_LCORNER,
                          STC_MARK_BOXPLUSCONNECTED,
                          STC_MARK_BOXMINUSCONNECTED,
                          STC_MARK_TCORNER
                          ],
                         [STC_MARK_CIRCLEMINUS,
                          STC_MARK_CIRCLEPLUS,
                          STC_MARK_VLINE,
                          STC_MARK_LCORNERCURVE,
                          STC_MARK_CIRCLEPLUSCONNECTED,
                          STC_MARK_CIRCLEMINUSCONNECTED,
                          STC_MARK_TCORNERCURVE
                          ],
                         [STC_MARK_MINUS,
                          STC_MARK_PLUS,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY,
                          STC_MARK_EMPTY
                          ]
                        ]
    foldingicon = [STC_MARKNUM_FOLDEROPEN,
                   STC_MARKNUM_FOLDER,
                   STC_MARKNUM_FOLDERSUB,
                   STC_MARKNUM_FOLDERTAIL,
                   STC_MARKNUM_FOLDEREND,
                   STC_MARKNUM_FOLDEROPENMID,
                   STC_MARKNUM_FOLDERMIDTAIL
                   ]
