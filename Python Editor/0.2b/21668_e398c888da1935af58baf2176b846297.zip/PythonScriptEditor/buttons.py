# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import wx
from  wx.lib.agw import cubecolourdialog
from settings import ColorSettings, FontSettings


def CreateFont(font):
    def convert(value):
        return eval('wx.' + value.upper())

    newfont = wx.Font(pointSize=font.pointSize,
                      family=convert(font.family),
                      style=convert(font.style),
                      weight=convert(font.weight),
                      underline=True if font.underline == 'underline' else False,
                      face=font.face
                      )

    return newfont

class Font:

    def __init__(self, parent, labels, key):
        self.parent = parent

        if hasattr(FontSettings, key):
            self.font = FontSettings.__dict__[key]
            self.fontbutton = wx.Button(parent, -1, labels.fontbuttonlbl, size=(105, 30))
            self.fontbutton.Bind(wx.EVT_BUTTON, self.OnFont)

    def FontDialog(self, parent, font):
        font = CreateFont(font)

        data = wx.FontData()
        data.EnableEffects(True)
        data.SetInitialFont(font)

        dlg = wx.FontDialog(parent, data)
        if dlg.ShowModal() == wx.ID_OK:
            font = dlg.GetFontData()
            font = font.GetChosenFont()

        res = (font.GetPointSize(),
               font.GetFaceName(),
               'underline' if font.GetUnderlined() else 'normal',
               font.GetStyleString()[2:].lower(),
               font.GetWeightString()[2:].lower(),
               font.GetFamilyString()[2:].lower(),
               )
        return res       

    def OnFont(self, evt):
        parent = evt.GetEventObject().GetParent()
        font = self.FontDialog(parent, self.font)
        self.font.pointSize, self.font.face, self.font.underline = font[:3]
        self.font.style, self.font.weight, self.font.family = font[3:]

        parent.UpdateUI()

    

class ColorChooser:

    def __init__(self, parent, labels, key):
        self.key = key
        self.colors = ColorSettings.__dict__[key]

        if hasattr(self.colors, 'fore'):
            self.forebutton = wx.Button(parent, -1, labels.forebuttonlbl, size=(105, 30))
            self.forebutton.Bind(wx.EVT_BUTTON, self.OnForeColor)

        if hasattr(self.colors, 'back'):
            self.backbutton = wx.Button(parent, -1, labels.backbuttonlbl, size=(105, 30))
            self.backbutton.Bind(wx.EVT_BUTTON, self.OnBackColor)

    def OnForeColor(self, evt):
        parent = evt.GetEventObject().GetParent()
        self.colors.fore = self.ColorDialog(parent, self.colors.fore)
        ColorSettings.__dict__[self.key].fore = self.colors.fore
        parent.UpdateUI()
        evt.Skip()

    def OnBackColor(self, evt):
        parent = evt.GetEventObject().GetParent()
        self.colors.back = self.ColorDialog(parent, self.colors.back)
        ColorSettings.__dict__[self.key].back = self.colors.back
        parent.UpdateUI()
        if hasattr(parent, 'OnGlobalBack'):
            parent.OnGlobalBack(self.colors.back)
        evt.Skip()

    def ColorDialog(self, parent, color):
        colordata = wx.ColourData()
        colordata.SetColour(color)
        dlg = cubecolourdialog.CubeColourDialog(parent, colordata)
        if dlg.ShowModal() == wx.ID_OK:
            color = dlg.GetColourData()
            color = tuple(color.GetColour())
        dlg.Destroy()
        return color