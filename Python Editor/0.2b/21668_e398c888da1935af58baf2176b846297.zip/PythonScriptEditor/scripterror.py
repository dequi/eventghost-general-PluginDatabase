# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import eg
import sys
import traceback


def PrintTraceback(code, scriptDict=None, editCtrl=None):
    treeItem = eg if eg.currentItem is None else eg.currentItem
    treeItem.PrintError("Traceback (most recent call last):")

    lines = code.splitlines()
    sys_execinfo = sys.exc_info()
    tbType, tbValue, tbTraceback = sys_execinfo

    name = tbType if type(tbType) == type("") else tbType.__name__

    if editCtrl is not None:
        linenum = int(tbValue[1][1]) -1
        if linenum > 0:
            linestartpos = editCtrl.GetLineEndPosition(linenum - 1) + 1
        else:
            linestartpos = 0

        lineendpos = editCtrl.GetLineEndPosition(linenum)
        textRange = editCtrl.GetTextRange(linestartpos, lineendpos)

        if textRange.find('\t\t< ') == -1:

            tracebackerr = traceback.format_exc().split('\n')[-3:]
            tracebackerr[0] = tracebackerr[0][4:].replace(' ', '.')
            errortext = '\t\t< ' + tracebackerr[1] + ' >\n'

            errorline = lines[linenum]
            if errorline[-1:] == '\n':
                errortext = errorline[:-1] + errortext
            else:
                errortext = errorline + errortext

            indent = editCtrl.GetIndent()
            editCtrl.SetIndent(0)

            editCtrl.SetTargetStart(linestartpos)
            editCtrl.SetTargetEnd(lineendpos)
            editCtrl.ReplaceTarget(errortext)

            editCtrl.SetIndent(indent)
            codeerror = [errorline, linenum, linestartpos, linestartpos + len(errortext)]

        editCtrl.ScrollToLine(linenum)
        editCtrl.GotoLine(linenum)
        return codeerror

    eg.PrintError("Error compiling script.")
    if not traceback.extract_tb(tbTraceback)[1:]:
        linenum = int(sys_execinfo[1][1][1])
        err = traceback.format_exc() + '\n'
        spaces = ' ' * (8 - len(str(linenum)))
        err += '*' + str(linenum) + spaces + lines[linenum-1] + '\n'
        eg.PrintError(err)
        return
    
    for entry in traceback.extract_tb(tbTraceback)[1:]:
        filename, linenum, funcname, source = entry
        filename = filename.decode('mbcs')
        try:
            filenum = int(filename)
        except:
            filenum = None
        if source is None and filenum is not None:
            treeItem.PrintError('  Python script "%s", line %d, in %s' % (filename, linenum, funcname))
            lines = scriptDict[filenum].sourceCode.splitlines()
            treeItem.PrintError('    ' + lines[linenum-1].lstrip())
        else:
            treeItem.PrintError('  File "%s", line %d, in %s' % (filename, linenum, funcname))
        if source is not None:
            treeItem.PrintError('    ' + source.lstrip())
    treeItem.PrintError(str(name) + ': ' + str(tbValue))
