# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.



import sys
import threading
import traceback
import inspect

# import locals
import eg

class Exit:

    def __init__(self):
        self.threadevent = []

    def __call__(self):
        sys.exit()

    def Thread(self, currthread=None):
        if currthread is None:
            currthread = threading.current_thread()
        try:
            index = list(i for i, item in enumerate(self.threadevent) if item[0] == currthread)[0]
            thread, event = self.threadevent.pop(index)
        except:
            thread, event = None, None
        if thread is not None:
            event.set()
            try:
                thread.join(1.0)
            except:
                pass
        else:
            sys.exit()

    def Event(self, thread=None, event=None):

        if thread is not None:
            self.threadevent += [(thread, event)]
            return (thread, event)

        else:
            currentthread = threading.current_thread()
            try:
                thread, event = list(item for item  in self.threadevent if item[0] == currentthread)[0]
            except:
                return True
            else:
                if event.isSet():
                    self.threadevent.remove((thread, event))
                    return True
    def Close(self):
        if self.threadevent:
            for t, e in self.threadevent:
                e.set()
                try:
                    t.join()
                except:
                    pass

class Thread(threading.Thread):

    def __init__(self, plugin, counter, runinthread, mod, compiledcode):
        self.plugin = plugin
        self.counter = counter
        self.mod = mod
        self.compiledcode = compiledcode
        self.runinthread = runinthread

        if runinthread:
            threading.Thread.__init__(self)
        else:
            self.start = self.run

    def run(self):
        counter = self.counter
        mod = self.mod
        oldResult = eg.result
        mod.result = oldResult

        if self.runinthread:
            event = threading.Event()
            self.plugin.threadDict[counter] = eg.Exit.Event(self, event)
        else:
            self.plugin.threadDict[counter] = None

        try:
            exec(self.compiledcode, mod.__dict__) # pylint: disable-msg=W0122
        except SystemExit:
            pass
        except:
            traceback.print_exc()

        return self.Results(self.plugin.threadDict.pop(counter), mod, oldResult)


    def Results(self, eventdict, mod, oldResult):
        if eventdict is None:
            if eg.result is not oldResult:
                return eg.result
            else:
                return mod.result