# power save

try:
    from powersave_widcomm import PowerSave

except:

    class PowerSave:

        @staticmethod
        def enable(bdAddr):
            return False

        @staticmethod
        def disable(bdAddr):
            return False

        @staticmethod
        def linkMode(bdAddr):
            return False