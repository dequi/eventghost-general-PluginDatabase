# power save for widcomm stack v5

from ctypes import byref
from ctypes import c_ubyte
from ctypes.wintypes import BOOLEAN, BOOL
import ctypes
import struct

wcdll = ctypes.cdll.widcommsdk

# XXX: check if widcomm stack is running?
isStackServerUp = getattr(wcdll, '?IsStackServerUp@CBtIf@@QAEHXZ')
isStackServerUp.restype = BOOL
if not isStackServerUp():
    raise Exception("isStackServerUp() returned False")
 
setSniffMode = getattr(wcdll, '?SetSniffMode@CBtIf@@SAHQAE@Z')
setSniffMode.restype = BOOL
cancelSniffMode = getattr(wcdll, '?CancelSniffMode@CBtIf@@SAHQAE@Z')
cancelSniffMode.restype = BOOL
readLinkMode = getattr(wcdll, '?ReadLinkMode@CBtIf@@SAHQAEPAE@Z')
readLinkMode.restype = BOOLEAN


class PowerSave:

    @staticmethod
    def enable(bdAddr=None, **kw):
        return bool(setSniffMode(strToBdAddr(bdAddr)))

    @staticmethod
    def disable(bdAddr=None, **kw):
        return bool(cancelSniffMode(strToBdAddr(bdAddr)))
 
    @staticmethod
    def linkMode(bdAddr=None, **kw):
        mode = c_ubyte(0)
        result = readLinkMode(strToBdAddr(bdAddr), byref(mode))
 
        if result:
            return mode.value
 
        return None

# from pybluez:
# http://code.google.com/p/pybluez/source/browse/trunk/bluetooth/widcomm.py
def bdAddrToStr(bda):
    return "%02X:%02X:%02X:%02X:%02X:%02X" % \
            (ord(bda[0]), ord(bda[1]), ord(bda[2]), 
             ord(bda[3]), ord(bda[4]), ord(bda[5])) 

def strToBdAddr(s):
    digits = [ int (c, 16) for c in s.split(":") ]
    return struct.pack("6B", *digits)

