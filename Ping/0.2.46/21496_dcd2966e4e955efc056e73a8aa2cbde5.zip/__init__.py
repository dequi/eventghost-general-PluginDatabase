# -*- coding: utf-8 -*-
#
# plugins/Ping/__init__.py
#
# This file is a plugin for EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
# Revision history:
#
# 2015-03-30  First Version
##############################################################################
#
# $LastChangedDate: 2015-05-26 10:48:12 -7200 (Tue, 26 May 2015) $
# $LastChangedRevision: 46 $
# $LastChangedBy: lms0815 $


PLUGIN_NAME = 'Ping'
IS_ALIVE = 'alive'
IS_DEAD = 'dead'

from threading import Event, Thread, Lock

eg.RegisterPlugin(
    name=PLUGIN_NAME,
    author="miljbee & Sem;colon",
    version="0.2." + '$LastChangedRevision: 46 $'.split()[1],
    kind="other",
    description=("This plugin generates events when an host become available or unavailable on your LAN.\n" +
                 "It uses the ping commands of windows. Please, have a look at the readme file !"
                 ),
    icon=(
        'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAFo9M/3AAAABmJLR0QAAAD/AABH'
        '24+SAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3wQNCRERHu5CKgAAAxRJ'
        'REFUOMuNkV1IZHUAxX//690d5+tepp2vK+oG4wgxuEEoBD4EsYLgCgNi2CL24EZC'
        've1LlOtD+BK+FUFv0YM9R+xCUGAgAxK0tJXpoLPOOovOpOaMc2fu3K/592BEX0QH'
        'ztOBw+F3AMjn8xXGx8cr6XRainw+XxFCNNVGpNFf/LoIExMTFSTy1uu3ZDablapp'
        'mqamaxSUAufn54ilpaXVarX6GsDy8vLzIpPJyMH4ILtf7RJ+IYxipA12nuzQu9dL'
        's9lEaJomVVUldT3F0/2niMXFxdWtra13ZVfS/3I/Vw+vcnBwABKklPTouv5pb65X'
        'C/4apPR9iVqthrqq0vmyQ8fqoHQ6Hba/2Kb8TZnA+wHUz1V2X9klqAUxTRNRKBSe'
        'mZycPONflMlkjoRpmpGFhYVvu91u9M9hLBb7ZGRkZEUdGxtrKopCVEYJz4Y5Wj9C'
        'CSgA90KhUEZks1mp39EJjga5uHNB5bsKxosGjnTQNE2KwcFBWXlSYeD6AACe49H4'
        'ocG10Wvoui5Vx3GQSBzbAQFe20O70HAcB9d1UWzbJjuWpVVtEX0nymnjFCthYVkW'
        'nuddogVAghpQcW2XKxdXSMwlCBaDUuRyuV8ODw8Tf2cgpcQ0TSHq9Xpkfn6+WS6X'
        'EULwf9Ttdkkmkydra2spMTU19XOpVHoOoMftIfxGmJ27O7SUFhoadepkf8oSuxuj'
        'cdhAIP5YYBgGqmVZUdu20dB4vP+YGxs3SAwliBO/fIQYkWCE4naR3IMcx28d83sH'
        'jUZDqq7r4tgOodshUOBs4Qxb2H+ZfGwdk/4ozcPbD0mSxHd8pJTYto3i+z62Y1P8'
        'uEjqUYrqj1WigSitZgvLsmjX2xhvGxTfLHJz5SbtZhvbtnEcB8/zLgs8z6Ordjl5'
        '6YTAcID4B3HcPRdr3yL0KMTAwQCxVoz7H97HP/XRkzqu6+L7PmJ6evq9jY2Ne4qi'
        '/Cd53/cxnjVQR1RqD2q40mVubm5dGR0dXdnc3FRmZmY+GxoaIplMylQq9Q/39fVJ'
        '4QgZ3gvL2Vdn103TFMPDw/O/ASlFdcONHsjVAAAAAElFTkSuQmCC'
    ),
)

import os
import socket
import eg
import wx
import subprocess


class PingPlugin(eg.PluginBase):

    def __init__(self):
        self.hosts = {}
        self.AddAction(OnePing)
        self.AddAction(AddHost)
        self.AddAction(RemoveHost)
        self.AddAction(GetHostsStatus)

    def __start__(self, pingString):
        self.pingString = str(pingString)
        print "Ping is started with parameter: " + pingString
        for host in self.hosts:
            print "Starting thread " + self.hosts[host].name
            self.hosts[host].StartThread()

    def __stop__(self):
        print "Ping is stopped."
        for host in self.hosts:
            print "Stopping thread " + self.hosts[host].name
            self.hosts[host].StopThread()
        for host in self.hosts:
            print "Joining thread " + self.hosts[host].name
            self.hosts[host].pingThread.join()

    def __close__(self):
        print "Ping is closed."
        while len(self.hosts) > 0:
            for host in self.hosts:
                print "Removing " + self.hosts[host].name
                self.RemoveMyHost(host)
                break

    def Configure(self, pingString="=32"):
        helpString = (	"This plugin launch ping commands to know if hosts are alive or dead.\n\n" +
                       "Ping commands are the same you would use in the command line interpreter:\n" +
                       "ping 192.168.0.1 -w 500 as an exemple.\n\n" +
                       "Unfortunately, the output of the ping command is not the same depending on " +
                       "the version of windows and its localization.\n" +
                       "Thus, you should provide here a string, that may be found in the output of the ping " +
                       "command when a host respond to the request.\n" +
                       "This string will be compared against the output of the ping command.\n\n" +
                       "If it is found, the host is considered to be 'alive'.\n" +
                       "If it is not found, then the host is considered to be 'dead'.\n\n" +
                       "You should test some ping commands in your command prompt to determine " +
                       "which string best fits with your os.\n")

        panel = eg.ConfigPanel(self)
        helpLabel = panel.StaticText(helpString)
        pingStringEdit = panel.TextCtrl(pingString)
        panel.AddLine(helpLabel)
        panel.AddLine("String to match : ", pingStringEdit)

        while panel.Affirmed():
            panel.SetResult(pingStringEdit.GetValue())

    def IsValideHost(self, hostName):
        try:
            ip = socket.gethostbyname(hostName)
            if not ip == hostName:
                print hostName, ': ', ip
                socket.inet_aton(ip)
        except:
            self.PrintError('Invalide host name: ' + str(hostName))
            return False
        return True

    def RemoveMyHost(self, hostName=''):
        hostToDel = self.hosts.get(hostName, None)
        if hostToDel:
            # print "--- " + hostToDel.GetThreadState()
            if hostToDel.GetThreadState() == "Thread is running":
                hostToDel.StopThread()
                hostToDel.pingThread.join()
            elif hostToDel.GetThreadState() == "Thread is finishing his job":
                hostToDel.pingThread.join()
            elif hostToDel.GetThreadState() == "Problem !":
                print "Oups !"
            else:
                print "--- " + hostToDel.GetThreadState()
            del self.hosts[hostName]
            del hostToDel
        else:
            self.PrintError(hostName + ' is not in my list !')
        if len(self.hosts) == 0:
            print "Ping Plugin : the list of watched hosts is now empty !"


class OnePing(eg.ActionBase):
    name = "One Ping Now"
    description = "Send one only ping command to the specified host. The state of the hosts is returned in eg.result. Optionnaly, you can generate an event."
    iconFile = "get"

    def __call__(self, hostFriendlyName, hostName, pingDelay, sendEvent, eventAlive, eventDead):
        #global PLUGIN_NAME
        if self.plugin.IsValideHost(hostName):
            try:
                pingCmd = os.popen("ping " + hostName +
                                   " -w " + str(pingDelay) + " -4 -n 1", "r")
                # print pingCmd.read()
                hostStatus = pingCmd.read().find(self.plugin.pingString) > -1
                eg.TriggerEvent(	prefix=PLUGIN_NAME,
                                 suffix=(hostName if hostFriendlyName == '' else hostFriendlyName) + ': ' + {
                                     True: IS_ALIVE, False: IS_DEAD}.get(hostStatus)
                                 )
                # self.TriggerEvent(eventDead)
                return hostStatus
            except:
                self.PrintError('Invalide hostname: ' +
                                hostFriendlyName + ' (' + str(hostName) + ')')

    def Configure(self, hostFriendlyName='', hostName='', pingDelay=200, sendEvent=False, eventAlive='', eventDead=''):
        panel = eg.ConfigPanel()
        hostFriendlyNameEdit = panel.TextCtrl(hostFriendlyName)
        hostNameEdit = panel.TextCtrl(hostName)
        pingDelayEdit = panel.SpinIntCtrl(pingDelay, max=5000)
        sendEventEdit = panel.CheckBox(sendEvent)
        eventAliveEdit = panel.TextCtrl(eventAlive)
        eventDeadEdit = panel.TextCtrl(eventDead)
        panel.AddLine("Friendly name: ", hostFriendlyNameEdit)
        panel.AddLine("Host name: ", hostNameEdit)
        panel.AddLine(
            "Time to wait for the host response to the ping (milliseconds): ", pingDelayEdit)
        panel.AddLine()
        panel.AddLine("Generate an event ", sendEventEdit)
        panel.AddLine(
            "if checked will generate an event corresponding to the host response, otherwise, eg.result will be set to true/false")
        panel.AddLine()
        panel.AddLine(
            "Event string to fire if the host responds: ", eventAliveEdit)
        panel.AddLine(
            "Event string to fire if the host doesn't responds:", eventDeadEdit)
        while panel.Affirmed():
            panel.SetResult(
                hostFriendlyNameEdit.GetValue(),
                hostNameEdit.GetValue(),
                pingDelayEdit.GetValue(),
                sendEventEdit.GetValue(),
                eventAliveEdit.GetValue(),
                eventDeadEdit.GetValue()
            )


class AddHost(eg.ActionBase):
    name = "Add Host"
    description = "Adds a host to the list of watched host. Once done, you'll get an event when the state of the host changes."

    def __call__(self, hostFriendlyName, hostName, pingDelay, eventAlive, eventDead, delayEventAlive, delayEventDead):
        if self.plugin.IsValideHost(hostName):
            print 'Ping Plugin : Adding host [' + hostFriendlyName + '] to the list of managed hosts.'
            hostToDel = self.plugin.hosts.get(hostName, None)
            if hostToDel:
                self.PrintError('Host already exists, it will be replaced')
                self.plugin.RemoveMyHost(hostName)
            self.plugin.hosts[hostName] = HostType(
                friendlyName=hostFriendlyName,
                name=hostName,
                pingDelay=pingDelay,
                eventAlive=eventAlive,
                eventDead=eventDead,
                delayEventAlive=delayEventAlive,
                delayEventDead=delayEventDead,
                pingString=self.plugin.pingString
            )
            self.plugin.hosts[hostName].StartThread()

    def Configure(
            self, hostFriendlyName='',
            hostName='',
            pingDelay=200,
            eventAlive='',
            eventDead='',
            delayEventAlive=1,
            delayEventDead=1):
        panel = eg.ConfigPanel()
        hostFriendlyNameEdit = panel.TextCtrl(hostFriendlyName)
        hostNameEdit = panel.TextCtrl(hostName)
        pingDelayEdit = panel.SpinIntCtrl(pingDelay, max=5000)
        eventAliveEdit = panel.TextCtrl(eventAlive)
        eventDeadEdit = panel.TextCtrl(eventDead)
        delayEventAliveEdit = panel.SpinIntCtrl(delayEventAlive, min=1)
        delayEventDeadEdit = panel.SpinIntCtrl(delayEventDead, min=1)

        panel.AddLine("Friendly Name: ", hostFriendlyNameEdit)
        panel.AddLine("Host Name: ", hostNameEdit)
        panel.AddLine("Ping delay (ms): ", pingDelayEdit)
        panel.AddLine(
            "Name of the event to fire when host become alive: ", eventAliveEdit)
        panel.AddLine(
            "Name of the event to fire when host become dead: ", eventDeadEdit)
        panel.AddLine("The next two settings will delay the events. As an exemple, if you set the first one to 5,\nyou will get the alive event only when five successive ping commands will be successfull")
        panel.AddLine(
            "Number of successive successfull ping to fire the alive event: ", delayEventAliveEdit)
        panel.AddLine(
            "Number of successive unsuccessfull ping to fire the dead event: ", delayEventDeadEdit)
        while panel.Affirmed():
            panel.SetResult(	hostFriendlyNameEdit.GetValue(),
                             hostNameEdit.GetValue(),
                             pingDelayEdit.GetValue(),
                             eventAliveEdit.GetValue(),
                             eventDeadEdit.GetValue(),
                             delayEventAliveEdit.GetValue(),
                             delayEventDeadEdit.GetValue(),
                             )


class RemoveHost(eg.ActionBase):
    name = "Remove Host"
    description = "Removes a host from the list of watched hosts. Once done, you won't receive any more event from this host."
    iconFile = "remove"

    def __call__(self, hostFriendlyName, hostName):
        if self.plugin.IsValideHost(hostName):
            self.plugin.RemoveMyHost(hostName)

    # Get the choice from dropdown and perform some action
    def OnDeviceChoice(self, event):
        choice = event.GetSelection()
        event.Skip()
        return choice

    def Configure(self, hostFriendlyName='', hostName='',):
        panel = eg.ConfigPanel()
        names = []
        hosts = []
        hostlist = []
        for host in self.plugin.hosts:
            hostlist.append([self.plugin.hosts[host].friendlyName, host])
        hostlist.sort(key=lambda x: x[0])
        for name, host in hostlist:
            names.append(name)
            hosts.append(host)

        # hostNameEdit=panel.TextCtrl(hostName)
        hostNameEdit = wx.ComboBox(parent=panel, pos=(10, 10))
        try:
            idx = hosts.index(hostName)
        except:
            names.append(hostName)
            hosts.append(hostName)
            idx = hosts.index(hostName)
        hostNameEdit.AppendItems(strings=names)
        hostNameEdit.Select(n=idx)
        hostNameEdit.Bind(wx.EVT_CHOICE, self.OnDeviceChoice)
        panel.AddLine(
            "Enter the name of the host you wish to remove, not the friendly name !")
        panel.AddLine("Host name: ", hostNameEdit)
        while panel.Affirmed():
            hostFriendlyName = hostNameEdit.GetValue()
            try:
                hostName = hosts[names.index(hostFriendlyName)]
            except:
                hostName = hostFriendlyName
            panel.SetResult(hostFriendlyName, hostName)


class GetHostsStatus(eg.ActionBase):
    name = "Get Hosts Status"
    description = "Set eg.result with a python dict containing the config and status of all watched hosts. The key of the dict is the host name.\n"
    description += "Each dict entry is a string where values are separated by a coma.\n the values are :\n"
    description += "hostName,hostFriendlyName,pingDelay,eventAlive,eventDead,delayEventAlive,delayEventDead, status,lastPingResult.\n"
    description += "Here is an exemple of a python script you could run jus after this action :\n"
    description += "hosts=eg.result\n"
    description += "for host in hosts:\n"
    description += "    print host + \" : \" + hosts[host]\n"
    description += "    hostData=hosts[host].split(\",\")\n"
    description += "    for idx in range(0,len(hostData)):\n"
    description += "        print hostData[idx]\n"
    iconFile = "get"

    def __call__(self):
        res = {}
        for hostName in self.plugin.hosts:
            host = self.plugin.hosts[hostName]
            res[hostName] = ''
            res[hostName] += host.name + ","
            res[hostName] += host.friendlyName + ","
            res[hostName] += str(host.pingDelay) + ","
            res[hostName] += host.eventAlive + ","
            res[hostName] += host.eventDead + ","
            res[hostName] += str(host.delayEventAlive) + ","
            res[hostName] += str(host.delayEventDead) + ","
            res[hostName] += host.GetStatus() + ","
            res[hostName] += host.GetLastPingResult()
        return res


class HostType:

    def __init__(self, name, friendlyName, pingDelay, eventAlive, eventDead, delayEventAlive, delayEventDead, pingString):
        self.name = name
        self.friendlyName = friendlyName
        self.pingDelay = pingDelay
        self.status = "unknown"
        self.lastPingResult = "unknown"
        #global PLUGIN_NAME

        self.eventAlive = (name if friendlyName ==
                           '' else friendlyName) + ': ' + IS_ALIVE
        self.eventDead = (name if friendlyName ==
                          '' else friendlyName) + ': ' + IS_DEAD

        self.delayEventAlive = delayEventAlive
        self.delayEventDead = delayEventDead
        self.pingString = str(pingString)

        self.pingThread = None
        self.stopThreadEvent = Event()
        self.lock = Lock()

    def ThreadWorker(self, stopThreadEvent):
        print "Ping Plugin : Thread " + self.name + " is starting ! "
        eventsAlive = 0
        eventsDead = 0
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        pingCmd = subprocess.Popen(["ping", self.name, "-4", "-t", "-w", str(
            self.pingDelay)], stdout=subprocess.PIPE, stderr=None, startupinfo=startupinfo)
        for output in range(1, 3):
            pingCmd.stdout.readline()
        pingCmd.wShowWindow = 0
        while not stopThreadEvent.isSet():
            output = pingCmd.stdout.readline()
            # print output
            if output.find(self.pingString) > -1:
                #print (self.name,self.friendlyName,self.pingDelay,self.eventAlive,self.eventDead,self.delayEventAlive,self.delayEventDead,self.pingString)
                eventsAlive += 1
                eventsDead = 0
                self.lock.acquire()
                try:
                    self.lastPingResult = "alive"
                    if eventsAlive >= self.delayEventAlive:
                                # print self.friendlyName,self.status
                        if self.status != "alive":
                            self.status = "alive"
                            eg.TriggerEvent(prefix=PLUGIN_NAME,
                                            suffix=self.eventAlive)
                finally:
                    self.lock.release()
            else:
                #print (self.name,self.friendlyName,self.pingDelay,self.eventAlive,self.eventDead,self.delayEventAlive,self.delayEventDead,self.pingString)
                eventsAlive = 0
                eventsDead += 1
                self.lock.acquire()
                try:
                    self.lastPingResult = "dead"
                    if eventsDead >= self.delayEventDead:
                        # print self.friendlyName,self.status
                        if self.status != "dead":
                            self.status = "dead"
                            eg.TriggerEvent(prefix=PLUGIN_NAME,
                                            suffix=self.eventDead)
                finally:
                    self.lock.release()
        print "Ping Plugin : Thread " + self.name + " is ending ! "
        pingCmd.terminate()
        self.stopThreadEvent.clear()
        # print "Thread " + self.name + " has finished his job !"

    def GetStatus(self):
        self.lock.acquire()
        try:
            status = self.status
        finally:
            self.lock.release()
        return status

    def GetLastPingResult(self):
        self.lock.acquire()
        try:
            res = self.lastPingResult
        finally:
            self.lock.release()
        return res

    def GetThreadState(self):
        if self.pingThread.isAlive() and not self.stopThreadEvent.isSet():
            return "Thread is running"
        elif self.pingThread.isAlive() and self.stopThreadEvent.isSet():
            return "Thread is finishing his job"
        elif (not self.pingThread.isAlive()) and (not self.stopThreadEvent.isSet()):
            return "Thread is ready to be started"
        else:
            return "Problem !"

    def StopThread(self):
        self.stopThreadEvent.set()

    def StartThread(self):
        if self.stopThreadEvent.isSet():
            #self.PrintError ('Problem : stopThreadEvent Is Set ...')
            self.stopThreadEvent.clear()
        self.pingThread = Thread(
            target=self.ThreadWorker, args=(self.stopThreadEvent,))
        self.pingThread.start()
