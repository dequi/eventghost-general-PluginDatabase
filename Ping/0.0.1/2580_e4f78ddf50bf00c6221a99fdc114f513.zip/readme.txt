Ping Plugin for eventghost
author : miljbee+egPing@gmail.com

usual warning :
This plugin is provided as is, it is not sure it will work, perhaps it will destroy your computer, or even your house, but I can not be held responsible for this.
You are supposed to be clever enougth to fully understand what this code do before using it.
You have been warned !

sharing, modifying, distributing this code ...
You can do whatever you want with this code, but please, be kind enough to remember that I am the author of it. I would be very happy to know what you are doing with it.

What is it for ?

This plugin is to get events when a host become available or unavailable on the network.
You can use it for many things, here are a few exemples :

Get an event when you loose your internet connection
Get an event when you turn on or off your TV (if it has TCP/IP connectivity of course)
Get an event when you arrive at home (yes you can do this ! if you have a wifi smartphone in your pocket that automatically connects to your wlan)
Get an event when someone connects to you wlan (if you know his ip adress, which may be the case, if you know the first available address of your dhcp)

How does it work ?
1 - Add the plugin in you eg tree
2 - Add a new action in a macro : Ping\AddHost
2a - Fill in the params, the only important one is the hostname. It can be an ip, or anything that windows can resolve into an ip address.
	valid exemples are 192.168.0.62, www.google.com
3 - Run this macro
4 - If the host respond to ping, you will immediately get the Alive Event, else the Dead Event.
5 - let's say your host is alive, let eg run
6 - turn off your host
7 - it won't last long before you get the dead event for this host
8 - Add the other hosts you wish to manage

How does it work internally ?
When you add a host, the plugin creates a host object. the host object has a thread. The thread is started as soon as you add the host.
The thread is launching the good old windows ping command at specified interval, and reads the result. If it finds some string in it, 
the host is considered to alive, else dead ! So you have as many thread as hosts ...

What is the parameter required by the plugin ?
I can't tell you more than what is written in the plugin conf dialog ....

What can I do with the "number of successive successfull/unsuccessfull ping to fire event" ?
This param is usefull for me, I hope it will be for you ! Here is how I use it :
I have an iPhone which automatically connects to my wlan to retrieve my mails every 15 Minutes.
When it connects, it lasts just a few seconds, and I don't wan't to get event alive/dead each time.
I just want to know if my iPhone is in my house (so if I am in my house ...)
So I set up the host to : 
ping every 10s
wait 500ms for the ping response
fire the alive event after the first successfull ping
fire the dead event, only after 90 unsuccessfull ping (90*10=900s=15min).

This way, I get an alive event 15min max after I arrives at home, and a dead event 15min max after I left my house ...
And thus can automatically turn off my heaters after the dead event...

You said that the only important param is the hostname, what about the others ?
the friendlyName is used to compute the events names if you don't set them. 
If friendly name and events names are not set, the events names are built from the host name !
The ping delay is the time the ping command will wait for the host to respond (-w param, see ping -?)
The delay between pings is the time the host thread will wait between two ping commands.
Other params have already been explained !

Final warning ....
be carefull with the ping delay (corresponding to the -w param of the ping command). Let's say you set it 10000, and the ping interval to 1.
if the host is dead, it will be pinged every 11s. In this 11s, 10 of them are spent by the ping program which is out of control of the python code.
it means that if you close eg while the ping commands runs, you could have to wait 10s before eg gets really closed. It you restart eg
before it is really closed, you will get to instance of eg running at the sametime, and that's not good ... trust me !


To coders :
There is two things I would like to do in this plugin, but I don't know how !

1-being able to interrupt/kill the ping command if the thread is being stopped ....
2-implement the ping command in python !




