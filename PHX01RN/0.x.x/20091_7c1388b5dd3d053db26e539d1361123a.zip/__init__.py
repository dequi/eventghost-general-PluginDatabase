# -*- coding: utf-8 -*-

import eg

eg.RegisterPlugin(
    name="PHX01RN",
    description= '''<div align="center"><img src="PHX01RN.png"/></div>''',
    author="WharfRat",
    version="0.x.x",
    kind="remote",
    url="http://www.eventghost.net/forum/viewtopic.php?f=9&t=5927",
    guid="{0B5511F9-6E8D-447D-9BD7-340E2C3548DD}",
    hardwareId = "USB\\VID_0755&PID_2626",
)

class PHX01RN(eg.PluginBase):

    def __start__(self):
        self.winUsb = eg.WinUsb(self)
        # create the 8 byte button handler
        self.winUsb.Device(self.Callback1, 8).AddHardwareId(
            "PHX01RN W-01RN MI_00", "USB\\VID_0755&PID_2626&MI_00"
        )
        # create the 6 byte button handler
        self.winUsb.Device(self.Callback2, 6).AddHardwareId(
            "PHX01RN W-01RN MI_01", "USB\\VID_0755&PID_2626&MI_01"
        )
        self.winUsb.Start()
        self.inCursorMode = 1
        self.buttonNotPressed = 1
        

    def __stop__(self):
        self.winUsb.Stop()


    def Callback1(self, data):
        print data


    def Callback2(self, data):
        print data
