// EndPointController.cpp : Defines the entry point for the console application.
//
#include <stdio.h>
#include <wchar.h>
#include <tchar.h>
#include <string>
#include "windows.h"
#include "Mmdeviceapi.h"
#include "PolicyConfig.h"
#include "Propidl.h"
#include "Functiondiscoverykeys_devpkey.h"

// Format default string for outputing a device entry. The following parameters will be used in the following order:
// Index, Device Friendly Name
#define DEVICE_OUTPUT_FORMAT "%ws;;%d;;%d;;%ws"

typedef struct TGlobalState
{
	HRESULT hr;
	LPCWSTR option;
	IMMDeviceEnumerator *pEnum;
	IMMDeviceCollection *pDevices;
	LPWSTR strDefaultDeviceID;
	IMMDevice *pCurrentDevice;
	LPCWSTR pDeviceFormatStr;
	int deviceStateFilter;
} TGlobalState;

void createDeviceEnumerator(TGlobalState* state);
void prepareDeviceEnumerator(TGlobalState* state);
void enumerateOutputDevices(TGlobalState* state);
HRESULT printDeviceInfo(IMMDevice* pDevice, int index, LPCWSTR outFormat, LPWSTR strDefaultDeviceID);
std::wstring getDeviceProperty(IPropertyStore* pStore, const PROPERTYKEY key);
HRESULT SetDefaultAudioPlaybackDevice(LPCWSTR devID);
void invalidParameterHandler(const wchar_t* expression, const wchar_t* function, const wchar_t* file, 
	unsigned int line, uintptr_t pReserved);

// EndPointController.exe [NewDefaultDeviceID]
int _tmain(int argc, LPCWSTR argv[])
{

	TGlobalState state;

	// Process command line arguments
	state.option = L"get"; // get indicates list devices.
	state.strDefaultDeviceID = '\0';
	state.pDeviceFormatStr = _T(DEVICE_OUTPUT_FORMAT);
	state.deviceStateFilter = DEVICE_STATE_ACTIVE;
	if (argc > 1)
	{
		if (wcscmp(argv[1], _T("-g")) == 0)
		{
			state.deviceStateFilter = DEVICE_STATEMASK_ALL;
			state.option = L"get";
		}
		else if (wcscmp(argv[1], _T("-s")) == 0)
		{
			argc--;
			state.option = argv[2];
		}
		else
		{
			goto helpe;
		}
		if (argc == 2)
		{
			state.hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
			if (SUCCEEDED(state.hr))
			{
				createDeviceEnumerator(&state);
			}
			return state.hr;
		}
	}
	
	helpe:
	wprintf_s(_T("\nLists audio end-point playback devices or sets default audio end-point playback\n"));
	wprintf_s(_T("device.\n\n"));
	wprintf_s(_T("Commandline options:\n\n"));
	wprintf_s(_T("  -g             Lists audio end-point playback devices.\n"));
	wprintf_s(_T("  OUTPUT:device_name;;device_state;;default(1=yes);;device_id\n\n"));
	wprintf_s(_T("  -s device_id   Sets the default playback device with the given id.\n"));
	exit(0);
}

// Create a multimedia device enumerator.
void createDeviceEnumerator(TGlobalState* state)
{
	state->pEnum = NULL;
	state->hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), NULL, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator),
		(void**)&state->pEnum);
	if (SUCCEEDED(state->hr))
	{
		prepareDeviceEnumerator(state);
	}
}

// Prepare the device enumerator
void prepareDeviceEnumerator(TGlobalState* state)
{
	state->hr = state->pEnum->EnumAudioEndpoints(eRender, state->deviceStateFilter, &state->pDevices);
	if SUCCEEDED(state->hr)
	{
		enumerateOutputDevices(state);
	}
	state->pEnum->Release();
}

// Enumerate the output devices
void enumerateOutputDevices(TGlobalState* state)
{
	UINT count;
	state->pDevices->GetCount(&count);

	// If option is get, list devices
	if (state->option == L"get") 
	{
		// Get default device
		IMMDevice* pDefaultDevice;
		state->hr = state->pEnum->GetDefaultAudioEndpoint(eRender, eMultimedia, &pDefaultDevice);
		if (SUCCEEDED(state->hr))
		{
			
			state->hr = pDefaultDevice->GetId(&state->strDefaultDeviceID);

			// Iterate all devices
			for (int i = 1; i <= (int)count; i++)
			{
				state->hr = state->pDevices->Item(i - 1, &state->pCurrentDevice);
				
				if (SUCCEEDED(state->hr))
				{
					state->hr = printDeviceInfo(state->pCurrentDevice, i, state->pDeviceFormatStr,state->strDefaultDeviceID);
					state->pCurrentDevice->Release();
				}
			}
		}
	}
	// set device to default
	else
	{
		state->hr = SetDefaultAudioPlaybackDevice(state->option);
	}
	state->pDevices->Release();
}

HRESULT printDeviceInfo(IMMDevice* pDevice, int index, LPCWSTR outFormat, LPWSTR strDefaultDeviceID)
{
	// Device ID
	LPWSTR strID = NULL;
	HRESULT hr = pDevice->GetId(&strID);
	if (!SUCCEEDED(hr))
	{
		return hr;
	}
	
	int deviceDefault = (strDefaultDeviceID != '\0' && (wcscmp(strDefaultDeviceID, strID) == 0));
	
	// Device state
	DWORD dwState;
	hr = pDevice->GetState(&dwState);
	if (!SUCCEEDED(hr))
	{
		return hr;
	}
		
	IPropertyStore *pStore;
	hr = pDevice->OpenPropertyStore(STGM_READ, &pStore);
	if (SUCCEEDED(hr))
	{
		std::wstring friendlyName = getDeviceProperty(pStore, PKEY_Device_FriendlyName);
		//std::wstring Desc = getDeviceProperty(pStore, PKEY_Device_DeviceDesc);
		//std::wstring interfaceFriendlyName = getDeviceProperty(pStore, PKEY_DeviceInterface_FriendlyName);
		
		if (SUCCEEDED(hr))
		{
			wprintf_s(outFormat,
				friendlyName.c_str(),
				dwState,
				deviceDefault,
				strID
				//Desc.c_str(),
				//interfaceFriendlyName.c_str()
			);
			wprintf_s(_T("\n"));
		}

		pStore->Release();
	}
	return hr;
}

std::wstring getDeviceProperty(IPropertyStore* pStore, const PROPERTYKEY key)
{
	PROPVARIANT prop;
	PropVariantInit(&prop);
	HRESULT hr = pStore->GetValue(key, &prop);
	if (SUCCEEDED(hr))
	{
		std::wstring result (prop.pwszVal);
		PropVariantClear(&prop);
		return result;
	}
	else
	{
		return std::wstring (L"");
	}
}

HRESULT SetDefaultAudioPlaybackDevice(LPCWSTR devID)
{	
	IPolicyConfigVista *pPolicyConfig;
	ERole reserved = eConsole;

    HRESULT hr = CoCreateInstance(__uuidof(CPolicyConfigVistaClient), 
		NULL, CLSCTX_ALL, __uuidof(IPolicyConfigVista), (LPVOID *)&pPolicyConfig);
	if (SUCCEEDED(hr))
	{
		hr = pPolicyConfig->SetDefaultEndpoint(devID, reserved);
		pPolicyConfig->Release();
	}
	return hr;
}