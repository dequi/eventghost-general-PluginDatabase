# -*- coding: utf-8 -*-
#
# plugins/AudioEndpoint/__init__.py
# 
# This file is a plugin for EventGhost.

import eg

eg.RegisterPlugin(
    name = "AudioEndpoint",
    guid = "{31DE576B-5938-4C0B-A0E2-64F9ADF02BF8}",
    author = "Sem;colon",
    version = "2.0",
    kind = "other",
    canMultiLoad = False,
    description = "This plugin can set the default audio render device and generates events when an audio endpoint changes!",
    url = "http://www.eventghost.net/forum/viewtopic.php?f=9&t=6213",
)

import AudioEndpointControl


class CMMNotificationClient(AudioEndpointControl.COMObject):
    _com_interfaces_=[AudioEndpointControl.IMMNotificationClient]
    
    def __init__(self, plugin):
        self.plugin=plugin
    
    def OnDeviceStateChanged(self, this, pwstrDeviceId, dwNewState):
        device=self.plugin.audioEndpoints(pwstrDeviceId)
        state=AudioEndpointControl.DEVICE_STATE[dwNewState].replace("DEVICE_STATE_","")
        self.plugin.TriggerEvent("State."+state+"."+device.getName(),[device.getId()])

    def OnDeviceRemoved(self, this, pwstrDeviceId):
        device=self.plugin.audioEndpoints(pwstrDeviceId)
        self.plugin.TriggerEvent("DeviceRemoved."+device.getName(),[device.getId()])

    def OnDeviceAdded(self, this, pwstrDeviceId):
        device=self.plugin.audioEndpoints(pwstrDeviceId)
        self.plugin.TriggerEvent("DeviceAdded."+device.getName(),[device.getId()])

    def OnDefaultDeviceChanged(self, this, flow, role, pwstrDeviceId):
        flow2=AudioEndpointControl.EDataFlow[flow][1:]
        role2=AudioEndpointControl.ERole[role][1:]
        device=self.plugin.audioEndpoints(pwstrDeviceId)
        self.plugin.TriggerEvent("Default."+flow2+"."+role2+"."+device.getName(),[device.getId()])

    def OnPropertyValueChanged(self, this, pwstrDeviceId, key):
        property=u"{%8.08x-%4.04x-%4.04x-%2.02x%2.02x-%2.02x%2.02x%2.02x%2.02x%2.02x%2.02x}" % (key.fmtid.Data1, key.fmtid.Data2, key.fmtid.Data3,	2**8+key.fmtid.Data4[0], 2**8+key.fmtid.Data4[1],	2**8+key.fmtid.Data4[2], 2**8+key.fmtid.Data4[3],	2**8+key.fmtid.Data4[4], 2**8+key.fmtid.Data4[5],	2**8+key.fmtid.Data4[6], 2**8+key.fmtid.Data4[7])
        device=self.plugin.audioEndpoints(pwstrDeviceId)
        #self.plugin.TriggerEvent("Property."+device.getName(),[device.getId(),property,int(key.pid)])


class AudioEndpoint(eg.PluginBase):
  
    def __init__(self):
        self.AddAction(SetRender, "SetRender", "Set Default Audio Render", "Sets the default audio render device.(by id)")
        self.AddAction(GetRender, "GetRender", "Get Default Audio Render", "Returns the ID of the current Default Audio Render", hidden=True)
        self.AddAction(GetDefaultDevice, "GetDefaultDevice", "Get Default Audio Device", "Returns the ID and the name of the current Default Audio Device")
        self.AddAction(NextRender, "NextRender", "Next Default Audio Render", "Selects the next available Default Audio Render")
        self.AddAction(PreviousRender, "PreviousRender", "Previous Default Audio Render", "Selects previous available Default Audio Render")

        
    def __start__(self):
        self.activeAudioEndpoint=""
        if self.init():
            print "Audio Endpoint plugin started."
            for flow in [0,1]:
                for role in [0,1,2]:
                    try:
                        device=self.audioEndpoints.GetDefault(role,flow)
                        flow2=AudioEndpointControl.EDataFlow[flow][1:]
                        role2=AudioEndpointControl.ERole[role][1:]
                        self.TriggerEvent("Default."+flow2+"."+role2+"."+device.getName(),[device.getId()])
                    except:
                        pass
                        

    def __stop__(self):
        self.audioEndpoints.UnregisterCallback()
        print "Audio Endpoint plugin stopped."

        
    def __close__(self):
        print "Audio Endpoint plugin closed."

    
    def init(self):
        self.audioEndpoints=AudioEndpointControl.AudioEndpoints()
        self.reinit()
        self.audioEndpoints.RegisterCallback(CMMNotificationClient(self))
        return True
        
        
    def reinit(self):
        self.audioEndpointIDs=[]
        self.audioEndpointNames=[]
        for endpiont in self.audioEndpoints:
            self.audioEndpointIDs.append(endpiont.getId())
            self.audioEndpointNames.append(endpiont.getName())
        return True
            
            
class SetRender(eg.ActionBase):
    
    role = "Role:"
    setTo = "Set default to:"
    
    def __call__(self,target,role=0):
        if self.plugin.audioEndpoints(target):
            self.plugin.audioEndpoints.SetDefault(self.plugin.audioEndpoints(target),role)
            return True
        else:
            eg.PrintError("AudioEndpoint SetRender: Device not found! "+str(target))
            return False
    
    def GetLabel(self, target="",role=0):
        if self.plugin.audioEndpoints(target):
            target = self.plugin.audioEndpoints(target).getName()
        else:
            target = "???"
        return target
        
    def Configure(self,target="",role=0):
        self.plugin.reinit()
        roles=["Console","Multimedia","Communications"]
        panel = eg.ConfigPanel(self)
        
        wx_role = wx.Choice(panel, -1, choices=roles)
        wx_role.SetSelection(role)
        st_role = panel.StaticText(self.role)
        
        if target in self.plugin.audioEndpointIDs:
            target = self.plugin.audioEndpointIDs.index(target)
        else:
            target = 0
        wx_setTo = wx.Choice(panel, -1, choices=self.plugin.audioEndpointNames)
        wx_setTo.SetSelection(target)
        st_setTo = panel.StaticText(self.setTo)
        
        panel.AddLine(st_role,wx_role)
        panel.AddLine(st_setTo,wx_setTo)

        while panel.Affirmed():
            panel.SetResult(self.plugin.audioEndpointIDs[wx_setTo.GetCurrentSelection()],wx_role.GetCurrentSelection())    
    

class GetRender(eg.ActionBase):
    
    def __call__(self):
        return self.plugin.audioEndpoints.GetDefault(0,0).getId() 
    
    
class GetDefaultDevice(eg.ActionBase):
    
    flow = "Flow:"
    role = "Role:"
    
    def __call__(self,role=0,flow=0):
        try:
            device = self.plugin.audioEndpoints.GetDefault(role,flow)
            return {"id":device.getId(),"name":device.getName()}
        except:
            eg.PrintError("AudioEndpoint GetDefaultDevice: Default device not found!")
            return False
        
    def Configure(self,role=0,flow=0):
        flows=["Render","Capture"]
        roles=["Console","Multimedia","Communications"]
        panel = eg.ConfigPanel(self)
        
        wx_role = wx.Choice(panel, -1, choices=roles)
        wx_role.SetSelection(role)
        st_role = panel.StaticText(self.role)
        
        wx_flow = wx.Choice(panel, -1, choices=flows)
        wx_flow.SetSelection(flow)
        st_flow = panel.StaticText(self.flow)
        
        panel.AddLine(st_role,wx_role)
        panel.AddLine(st_flow,wx_flow)

        while panel.Affirmed():
            panel.SetResult(wx_role.GetCurrentSelection(),wx_flow.GetCurrentSelection())    
        

        
class NextRender(eg.ActionBase):
    
    role = "Role:"
    
    def __call__(self,role=0):
        self.plugin.reinit()
        oldIndex = self.plugin.audioEndpointIDs.index(self.plugin.audioEndpoints.GetDefault(role,0).getId())
        i=oldIndex+1
        while i!=oldIndex:
            if i<len(self.plugin.audioEndpointIDs):
                target = self.plugin.audioEndpointIDs[i]
                self.plugin.audioEndpoints.SetDefault(self.plugin.audioEndpoints(target),role)
                return True
            if i>=len(self.plugin.audioEndpointIDs):
                i=0
            else:
                i+=1
        eg.PrintError("AudioEndpoint NextRender: No (other) selectable Render!")
        return False

    def Configure(self,role=0):
        roles=["Console","Multimedia","Communications"]
        panel = eg.ConfigPanel(self)
        
        wx_role = wx.Choice(panel, -1, choices=roles)
        wx_role.SetSelection(role)
        st_role = panel.StaticText(self.role)
        
        panel.AddLine(st_role,wx_role)

        while panel.Affirmed():
            panel.SetResult(wx_role.GetCurrentSelection())    
    
    
    
class PreviousRender(eg.ActionBase):
        
    role = "Role:"
    
    def __call__(self,role=0):
        self.plugin.reinit()
        oldIndex = self.plugin.audioEndpointIDs.index(self.plugin.audioEndpoints.GetDefault(role,0).getId())
        i=oldIndex-1
        while i!=oldIndex:
            if i>=0:
                target = self.plugin.audioEndpointIDs[i]
                self.plugin.audioEndpoints.SetDefault(self.plugin.audioEndpoints(target),role)
                return True
            if i<=0:
                i=len(self.plugin.audioEndpointIDs)-1
            else:
                i-=1
        eg.PrintError("AudioEndpoint PreviousRender: No (other) selectable Render!")
        return False

    def Configure(self,role=0):
        roles=["Console","Multimedia","Communications"]
        panel = eg.ConfigPanel(self)
        
        wx_role = wx.Choice(panel, -1, choices=roles)
        wx_role.SetSelection(role)
        st_role = panel.StaticText(self.role)
        
        panel.AddLine(st_role,wx_role)

        while panel.Affirmed():
            panel.SetResult(wx_role.GetCurrentSelection())
