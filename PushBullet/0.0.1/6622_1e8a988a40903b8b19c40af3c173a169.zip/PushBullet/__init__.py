# -*- coding: utf-8 -*-

import eg
import wx
import sys
import threading
import json
from pushbullet import pyPushBullet
from urllib2 import URLError, HTTPError

eg.RegisterPlugin(
    name = "PushBullet",
    author = "sfalkman",
    version = "0.0.1",
    kind = "other",
    guid = "{9214697C-458C-49B9-963D-77C0869F7B5E}",
    description = u'''<rst>This plugin lets you send push notifications to your Android device that has the PushBullet app installed.
https://www.pushbullet.com/.

|

.. image:: pushbullet.png
   :align: center
   :target: https://www.pushbullet.com/
'''
)

class Text:
    # Types
    pb_note = "Note"
    pb_file = "File"
    
    # Labels
    lb_apikey = "API key"

def GetDeviceById(devices = [], id = 0):
    for device in devices:
        if device["id"] == id:
            return device
            
def GetDeviceName(device = []):
    if "nickname" in device["extras"]:
        return device["extras"]["nickname"]
    elif "model" in device["extras"]:
        return device["extras"]["model"]
    else:
        return str(device["id"]) # Is this even possible?
            
    
##########################################################################
###
### Plugin
###
##########################################################################
class PushBullet(eg.PluginBase):
    text = Text
    apikey = ""
    devices = []
    
    def __init__(self):
        self.AddAction(Push)
        self.types = [
            self.text.pb_note,
            self.text.pb_file
        ]
        
    def __start__(self, apikey=""):
        self.apikey = apikey
        
        # Start new thread to fetch devices
        deviceEvent = threading.Event()
        self.thread = threading.Thread(
            target=self.GetDevicesThread,
            name="RetrievePBDeviceThread",
            args=(deviceEvent,)
        )
        self.thread.start()
            
    def GetDevicesThread(self, deviceEvent):
        try:
            if len(self.devices) < 1:
                try:
                    p = pyPushBullet(self.apikey)
                    self.devices = p.getDevices()
                    print "%s: %s devices fetched" % (self.name, len(self.devices))
                    
                except HTTPError:
                    _, e, _ = sys.exc_info()
                    eg.PrintError("The server couldn\'t fulfill the request.")
                    eg.PrintError("Error code: %s" % (e.code))
                    return
                    
                except URLError:
                    _, e, _ = sys.exc_info()
                    eg.PrintError("We failed to reach the server.")
                    eg.PrintError("Reason: %s" % (e.reason))
                    return
                    
                except Exception, exc:
                    eg.PrintError("Error while fetching devices")
                    eg.PrintError("Exception: %s" % unicode(exc))
                    eg.PrintTraceback()
                    return  
        except:
            self.thread = None
            raise
            
    def Configure(self, apikey=""):
        text = self.text
        panel = eg.ConfigPanel(self)
        txtAPI = panel.TextCtrl(apikey)
        
        panel.AddLine(text.lb_apikey, txtAPI)
        
        while panel.Affirmed():
            panel.SetResult(txtAPI.GetValue())
           
##########################################################################
###
### Push action
###
##########################################################################
class Push(eg.ActionBase):
    description = "Push something to your Android device"

    class text:
        # Types
        pb_note = "Note"
        pb_file = "File"
        
        # Labels
        lb_device = "Push to"
        lb_type = "Push type"
        lb_title = "Title"
        lb_body = "Body"
        lb_file = "File"
        
    def __call__(
        self, 
        device = None, 
        type = None, 
        title = u"{eg.event.string}", 
        body = u"{eg.event.payload}",
        file = u"{eg.event.payload}"
        ):
        
        text = self.text
        
        if device is None:
            eg.PrintError("No device to push to")
            return
        
        elif type is None:
            eg.PrintError("Not a valid push type")
            return
        
        file = eg.ParseString(file)
        title = eg.ParseString(title)
        body = eg.ParseString(body)
        
        # Initialize PushBullet API
        p = pyPushBullet(self.plugin.apikey)
        
        try:
            if type == self.text.pb_note:
                ret = p.pushNote(device, title, body)
                
            elif type == self.text.pb_file:
                if not file is None:
                    ret = p.pushFile(device, file)
                else:
                    eg.PrintError("No file to push")
                
            else:
                eg.PrintError("Not a valid push type")
                return
        
            if "created" in ret:
                print "Push sent to device %s" % str(device)
            else:
                eg.PrintError("ERROR %s" % (address))
                
        except HTTPError:
            _, e, _ = sys.exc_info()
            eg.PrintError("The server couldn\'t fulfill the request.")
            eg.PrintError("Error code: %s" % (e.code))
            return
            
        except URLError:
            _, e, _ = sys.exc_info()
            eg.PrintError("We failed to reach a server.")
            eg.PrintError("Reason: %s" % (e.reason))
            return
            
        except Exception, exc:
            eg.PrintError("Error while pushing to device %s" % str(device))
            eg.PrintError("Exception: %s" % unicode(exc))
            #eg.PrintTraceback()
            return
        
    def GetLabel(
        self, 
        device,
        type,
        title,
        body,
        file,
        ):
        thisDevice = GetDeviceById(self.plugin.devices, device)
        thisDeviceName = GetDeviceName(thisDevice)        
        return "Push %s to device %s" % (type, thisDeviceName)
        
    def Configure(
        self, 
        defDevice = "", 
        defType = "", 
        title = u"{eg.event.string}", 
        body = u"{eg.event.payload}",
        file = u"{eg.event.payload}"
        ):
        
        text = self.text
        
        devices = self.plugin.devices
        dspDevices = []
        indDevices = []
        
        # Get device names and id's
        for device in devices:
            dspDevices.append(GetDeviceName(device))
            indDevices.append(device["id"])
        
        # Get selected device
        try:
            deviceindex = indDevices.index(defDevice)
        except ValueError:
            deviceindex = 0
        
        # Get selected type
        try:
            typeindex = self.plugin.types.index(defType)
        except ValueError:
            typeindex = 0
            
        # Define form controls
        panel = eg.ConfigPanel(self)
        dropDevices = panel.Choice(deviceindex, dspDevices)
        dropTypes = panel.Choice(typeindex, self.plugin.types) 
        txtTitle = panel.TextCtrl(title)
        txtBody = panel.TextCtrl(body)
        txtFile = panel.TextCtrl(file)
                
        def enableNote(enable):
            txtTitle.Enable(enable)
            txtBody.Enable(enable)
            
        def enableFile(enable):
            txtFile.Enable(enable)
        
        def enableButtons(enable):
            panel.dialog.buttonRow.applyButton.Enable(enable)
            panel.dialog.buttonRow.okButton.Enable(enable)
        
        def enableDrops(enable):
            dropDevices.Enable(enable)
            dropTypes.Enable(enable)
        
        def updateForm():
            type = self.plugin.types[dropTypes.GetValue()]
            
            # Check devices
            if len(devices) == 0:
                enableNote(False)
                enableFile(False)
                enableDrops(False)
                enableButtons(False)
                
            else:
                # Check type
                if type == text.pb_note:
                    enableNote(True)
                    enableFile(False)
                
                elif type == text.pb_file:
                    enableNote(False)
                    enableFile(True)
                
        def TypeSelection(event):
            updateForm()
            event.Skip()
        dropTypes.Bind(wx.EVT_CHOICE, TypeSelection)
        
        # Perform updateForm to enable/disable controls
        updateForm()
        
        # Add form controls
        panel.AddLine(text.lb_device, dropDevices)
        panel.AddLine(text.lb_type, dropTypes)
        panel.AddLine(text.lb_title, txtTitle)
        panel.AddLine(text.lb_body, txtBody)
        panel.AddLine(text.lb_file, txtFile)
        
        while panel.Affirmed():
            panel.SetResult(
                indDevices[dropDevices.GetValue()],
                self.plugin.types[dropTypes.GetValue()],
                txtTitle.GetValue(), 
                txtBody.GetValue(),
                txtFile.GetValue()
            )
    