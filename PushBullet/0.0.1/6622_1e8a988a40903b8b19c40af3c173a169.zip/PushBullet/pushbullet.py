# -*- coding: utf-8 -*-

'''
pushbullet.py by Azelphur
https://github.com/Azelphur/pyPushBullet
with some modifications
'''
try:
    from urllib.request import Request, urlopen
except:
    from urllib2 import Request, urlopen

from base64 import encodestring, b64encode
from cStringIO import StringIO
import json
import mimetypes
import os

HOST = "https://www.pushbullet.com/api";

class pyPushBullet():
    def __init__(self, apiKey):
        self.apiKey = apiKey

    def _request(self, url, postdata=None):
        request = Request(url)
        request.add_header("Accept", "application/json")
        request.add_header("Content-type","application/json");
        auth = "%s:" % (self.apiKey)
        auth = auth.encode('ascii')
        auth = b64encode(auth)
        auth = b"Basic "+auth
        request.add_header("Authorization", auth)
        request.add_header("User-Agent", "pyPushBullet")
        if postdata:
            postdata = json.dumps(postdata)
            postdata = postdata.encode('utf-8')
        response = urlopen(request, postdata)
        data = response.read()
        data = data.decode("utf-8")
        j = json.loads(data)
        return j
        
    def _request_multiform(self, url, postdata, files):
        request = Request(url)
        content_type, body = self._encode_multipart_formdata(postdata, files)
        request.add_header("Accept", "application/json")
        request.add_header("Content-type", content_type);
        auth = "%s:" % (self.apiKey)
        auth = auth.encode('ascii')
        auth = b64encode(auth)
        auth = b"Basic "+auth
        request.add_header("Authorization", auth)
        request.add_header("User-Agent", "pyPushBullet")
        response = urlopen(request, body)
        data = response.read()
        data = data.decode("utf-8")
        j = json.loads(data)
        return j
        
    def _encode_multipart_formdata(self, fields, files):
        '''
        from http://mattshaw.org/news/multi-part-form-post-with-files-in-python/
        Replaced array with StringIO. Was causing unicode problems.
        '''
        def guess_type(filename):
            return mimetypes.guess_type(filename)[0] or 'application/octet-stream'
        
        BOUNDARY = '----------bound@ry_$'
        body = ''
        
        buf = StringIO()
        for key,value in fields.iteritems():
            buf.write('--'+BOUNDARY+'\r\n')
            buf.write('Content-Disposition: form-data; name="%s"'%(key)+'\r\n')
            buf.write(''+'\r\n')
            buf.write(str(value)+'\r\n')
            
        for (key, filename, value) in files:
            buf.write('--'+BOUNDARY+'\r\n')
            buf.write('Content-Disposition: form-data; name="%s"; filename="%s"'%(key, filename)+'\r\n')
            buf.write('Content-Type: %s'%(guess_type(filename))+'\r\n')
            buf.write(''+'\r\n')
            buf.write(value+'\r\n')
            
        buf.write('--'+BOUNDARY+'--'+'\r\n')
        buf.write(''+'\r\n')
        
        body = buf.getvalue()
        content_type = 'multipart/form-data; boundary=%s' % BOUNDARY
        
        return content_type, body

    def getDevices(self):
        return self._request(HOST + "/devices")["devices"]

    def pushNote(self, device, title, body):
        data = {'type'      : 'note',
                'device_id' : device,
                'title'     : title,
                'body'      : body}
        return self._request(HOST + "/pushes", data)

    def pushAddress(self, device, name, address):
        data = {'type'      : 'address',
                'device_id' : device,
                'name'      : name,
                'address'   : address}
        return self._request(HOST + "/pushes", data)

    def pushList(self, device, title, items):
        data = {'type'      : 'list',
                'device_id' : device,
                'title'     : title,
                'items'     : items}
        return self._request(HOST + "/pushes", data)


    def pushLink(self, device, title, url):
        data = {'type'      : 'link',
                'device_id' : device,
                'title'     : title,
                'url'     : url}
        return self._request(HOST + "/pushes", data)
        
    def pushFile(self, device, file):
        data = {'type'      : 'file',
                'device_id' : device}
        filedata = ''
        with open(file, "rb") as f:
            filedata = f.read()
        
        return self._request_multiform(HOST + "/pushes", data, [('file', os.path.basename(file), filedata)])