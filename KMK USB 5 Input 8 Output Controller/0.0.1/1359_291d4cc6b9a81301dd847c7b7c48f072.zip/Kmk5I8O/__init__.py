import eg

eg.RegisterPlugin(
    name = "KMK USB 5 Input 8 Output Controller",
    author = "Me",
    version = "0.0.1",
    kind = "external",
    url = "http://www.kmk.com.hk/ProductShop/USB5I8O.htm",
    description = (
        '<p>Plugin to control KMK USB I/O Board</p>'
        '\n\n<p><a href="http://www.kmk.com.hk/ProductShop/USB5I8O.htm">Info</a></p>'
        '<center><img src="USB5I8O.png" /></center>'
    ),
)

from threading import Event, Thread
import time

class KMKIO(eg.PluginBase):

    def __init__(self):
        self.out1 = 0
        self.out2 = 0
        self.out3 = 0
        self.out4 = 0
        self.out5 = 0
        self.out6 = 0
        self.out7 = 0
        self.out8 = 0
        self.AddAction(ReadValue)
        self.AddAction(TurnOn1)
        self.AddAction(TurnOff1)
        self.AddAction(TurnOn2)
        self.AddAction(TurnOff2)
        self.AddAction(TurnOn3)
        self.AddAction(TurnOff3)
        self.AddAction(TurnOn4)
        self.AddAction(TurnOff4)
        self.AddAction(TurnOn5)
        self.AddAction(TurnOff5)
        self.AddAction(TurnOn6)
        self.AddAction(TurnOff6)
        self.AddAction(TurnOn7)
        self.AddAction(TurnOff7)
        self.AddAction(TurnOn8)
        self.AddAction(TurnOff8)
        self.serialnr = "KMSHF43V"

        
#Input Read and split.

class ReadValue(eg.ActionBase):
    name = "Read The Input Value"
    description = "Reads the input Value."

    def __call__(self):
        self.plugin.out1 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        Axkmkusb1.out = self.plugin.out1
        time.sleep(0.1)
        self.plugin.input = Axkmkusb1.binary
        print "Input Value: ", self.plugin.input
        inputs = str(self.plugin.input)
        inputList = []
        for i in range(0,len(inputs)):
        	inputList.insert(i, inputs[i])
        self.plugin.in1 = inputList[0]
        self.plugin.in2 = inputList[1]
        self.plugin.in3 = inputList[2]
        self.plugin.in4 = inputList[3]
        self.plugin.in5 = inputList[4]
        print "Input Value port 1: ", self.plugin.in1
        print "Input Value port 2: ", self.plugin.in2
        print "Input Value port 3: ", self.plugin.in3
        print "Input Value port 4: ", self.plugin.in4
        print "Input Value port 5: ", self.plugin.in5
        Axkmkusb1.port_open_close = 0


#Output port 1

class TurnOn1(eg.ActionBase):
    name = "Turn On 1"
    description = "Turns on the device connected to Output 1."

    def __call__(self):
        self.plugin.out1 = 1
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
class TurnOff1(eg.ActionBase):
    name = "Turn Off 1"
    description = "Turns off the device connected to Output 1."

    def __call__(self):
        self.plugin.out1 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0

#Output port 2

class TurnOn2(eg.ActionBase):
    name = "Turn On 2"
    description = "Turns on the device connected to Output 2."

    def __call__(self):
        self.plugin.out2 = 2
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
class TurnOff2(eg.ActionBase):
    name = "Turn Off 2"
    description = "Turns off the device connected to Output 2."

    def __call__(self):
        self.plugin.out2 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
#Output port 3

class TurnOn3(eg.ActionBase):
    name = "Turn On 3"
    description = "Turns on the device connected to Output 3."

    def __call__(self):
        self.plugin.out3 = 4
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
class TurnOff3(eg.ActionBase):
    name = "Turn Off 3"
    description = "Turns off the device connected to Output 3."

    def __call__(self):
        self.plugin.out3 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
#Output port 4

class TurnOn4(eg.ActionBase):
    name = "Turn On 4"
    description = "Turns on the device connected to Output 4."

    def __call__(self):
        self.plugin.out4 = 8
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
class TurnOff4(eg.ActionBase):
    name = "Turn Off 4"
    description = "Turns off the device connected to Output 4."

    def __call__(self):
        self.plugin.out3 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
#Output port 5

class TurnOn5(eg.ActionBase):
    name = "Turn On 5"
    description = "Turns on the device connected to Output 5."

    def __call__(self):
        self.plugin.out5 = 16
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
class TurnOff5(eg.ActionBase):
    name = "Turn Off 5"
    description = "Turns off the device connected to Output 5."

    def __call__(self):
        self.plugin.out5 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
#Output port 6

class TurnOn6(eg.ActionBase):
    name = "Turn On 6"
    description = "Turns on the device connected to Output 6."

    def __call__(self):
        self.plugin.out6 = 32
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
class TurnOff6(eg.ActionBase):
    name = "Turn Off 6"
    description = "Turns off the device connected to Output 6."

    def __call__(self):
        self.plugin.out6 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
#Output port 7

class TurnOn7(eg.ActionBase):
    name = "Turn On 7"
    description = "Turns on the device connected to Output 7."

    def __call__(self):
        self.plugin.out7 = 64
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
class TurnOff7(eg.ActionBase):
    name = "Turn Off 7"
    description = "Turns off the device connected to Output 7."

    def __call__(self):
        self.plugin.out7 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
#Output port 8

class TurnOn8(eg.ActionBase):
    name = "Turn On 8"
    description = "Turns on the device connected to Output 8."

    def __call__(self):
        self.plugin.out8 = 128
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
class TurnOff8(eg.ActionBase):
    name = "Turn Off 8"
    description = "Turns off the device connected to Output 8."

    def __call__(self):
        self.plugin.out8 = 0
        import win32com.client
        Axkmkusb1 = win32com.client.Dispatch("KMKUSB5I8OOCX.KMKUSB")
        Axkmkusb1.device = self.plugin.serialnr
        Axkmkusb1.port_open_close = 1
        self.plugin.outsum = self.plugin.out1 + self.plugin.out2 + self.plugin.out3 + self.plugin.out4 + self.plugin.out5 + self.plugin.out6 + self.plugin.out7 + self.plugin.out8 
        Axkmkusb1.out = self.plugin.outsum
        time.sleep(0.1)
        Axkmkusb1.port_open_close = 0
        
