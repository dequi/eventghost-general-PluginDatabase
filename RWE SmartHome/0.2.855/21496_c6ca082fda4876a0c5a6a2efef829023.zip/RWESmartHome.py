# -*- coding: UTF-8 -*-
#!/usr/bin/python
#
# plugins/RWE_SmartHome/__init__.py
#
# Copyright (c) 2015, Heiko Steinwender
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. Neither the name of Heiko Steinwender nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
##############################################################################
# Revision history:
#
# 2015-03-30  First Version
##############################################################################
#
# $LastChangedDate: 2015-09-16 12:44:47 -7200 (Wed, 16 Sep 2015) $
# $LastChangedRevision: 877 $
# $LastChangedBy: lms0815 $
#
# http://python.net/~goodger/projects/pycon/2007/idiomatic/handout.html
#

import requests
import ssl
import sslfix
import uuid
import inspect
import hashlib
import base64
import os
import datetime
import time
from myudf import *
# https://docs.python.org/3.1/library/xml.etree.elementtree.html

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

if 'PLUGIN_NAME' not in locals():
    PLUGIN_NAME = ''

if 'DEBUG' not in locals():
    DEBUG = False

NAMESPACES = {'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
              'xsd': 'http://www.w3.org/2001/XMLSchema'}
XSI_NS_TYPE = '{' + NAMESPACES['xsi'] + '}' + 'type'
XSD_NS_TYPE = '{' + NAMESPACES['xsd'] + '}' + 'type'

ShcDevices = {}  # LD
ShcPhyBdId = {}  # BDId

##########################################################################
# Smart Home Center - Device Definition
##########################################################################


class ShcBaseDevice(object):

    class text:
        JOINER = '.'

    def __init__(self, XmlTree=None):
        if XmlTree is None:
            PrintError('wrong initialization')
        self['DeviceType'] = 'Basic'
        try:
            self['Name'] = self.propername(
                XmlTree.attrib.get('Name', 'noNAME'))
        except:
            self['Name'] = None
        try:
            self['RoomId'] = str(XmlTree.attrib.get('LCID', None))
        except:
            self['RoomId'] = None
        try:
            self['BDId'] = str(XmlTree.findtext('./BDId'))
        except:
            self['BDId'] = None

    def __repr__(self):
        return self.GetLongName()

    def __getitem__(self, attrib_name=None):
        if attrib_name == '' or attrib_name is None:
            attributes = {}
            for s in dir(self):
                if s[0:2] != '__' and type(getattr(self, s)).__name__ \
                        in ['str', 'dic', 'unicode', 'float', 'int', 'bool']:
                    attributes[s] = getattr(self, s)
            return attributes
        return getattr(self, attrib_name, None)

    def __setitem__(self, attrib_name=None, value=None):
        if attrib_name is not None:
            setattr(self, attrib_name, value)

    def unicoder(self, ToUniCode=u''):
        return (ToUniCode if type(ToUniCode).__name__ == 'unicode'
                else unicode(ToUniCode))

    def propername(self, string):
        return self.unicoder(
            string.replace(self.text.JOINER, ' ').title().replace(' ', '')
        )

    def GetRoom(self):
        try:
            return ShcDevices[self['RoomId']].Name
        except:
            return 'noRoom'

    def GetName(self):
        return self['Name']

    def GetLongName(self):
        return self.GetRoom() + self.text.JOINER + self['Name']

    def GetFullName(self):
        return self['DeviceType'] + self.text.JOINER + self.GetLongName()

    def XmlToEvent(self, XmlTree):
        PrintInfo('\n' + self['DeviceType'] + ':\n',
                  ET.tostring(XmlTree).replace('\n', ''))

    def XmlSetStateCommand(self, XmlSubTree, **kwargs):
        PrintInfo('\n' + self['DeviceType'] + ':\n', kwargs, '\n',
                  ET.tostring(XmlSubTree).replace('\n', ''))
        return False  # No change


class ShcRouter(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcRouter, self).__init__(XmlTree)
        self['DeviceType'] = 'Router'


class ShcRoom(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcRoom, self).__init__(XmlTree)
        # PrintInfo (ET.tostring(XmlTree).replace("\n",''))
        self['DeviceType'] = 'Room'
        try:
            self['Name'] = self.propername(XmlTree.findtext('./Name'))
        except:
            self['Name'] = None
        try:
            self['Position'] = XmlTree.findtext('./Position')
        except:
            self['Position'] = None
        try:
            self['RoomType'] = XmlTree.findtext('./Rtype')
        except:
            self['RoomType'] = None


class ShcDimmerActuator(ShcBaseDevice):
    """
    <LD LCID="416d04a2-ac72-4c71-a6da-614c8a1a7ad5" Name="Dimmer-Unterputz 1" ns0:type="DimmerActuator" xmlns:ns0="http://www.w3.org/2001/XMLSchema-instance">
        <Id>2381de77-bd2b-45a8-8306-d668e482f047</Id>
        <BDId>761d12e8-c716-4077-9d07-4b473e81a80d</BDId>
        <ActCls>DimmableLight</ActCls>
        <DOfStgs ns0:type="DimmerActuatorSettings">
            <Id>934cbd2e-a757-40d5-9d04-5be71fc805c8</Id>
            <AcId>2381de77-bd2b-45a8-8306-d668e482f047</AcId>
            <DmLvl>0</DmLvl>
        </DOfStgs>
        <TMxV>100</TMxV>
        <TMnV>30</TMnV>
    </LD>
    """

    def __init__(self, XmlTree):
        super(ShcDimmerActuator, self).__init__(XmlTree)
        self['DeviceType'] = 'DimmerActuator'
        # PrintInfo(XmlTree.findtext('./DOfStgs/DmLvl').replace("\n",''))
        try:
            self['DmLvl'] = int(XmlTree.findtext('./DOfStgs/DmLvl'))
        except:
            self['DmLvl'] = None
            PrintInfo('\n' + self['DeviceType'] + ':\n',
                      ET.tostring(XmlTree).replace('\n', ''))

    # <LogicalDeviceState DmLvl="0" LID="2381de77-bd2b-45a8-8306-d668e482f047" ns0:type="DimmerActuatorState" xmlns:ns0="http://www.w3.org/2001/XMLSchema-instance" />
    def XmlToEvent(self, XmlTree):
        state = XmlTree.attrib.get('DmLvl', None)
        if state is not None:
            try:
                self['DmLvl'] = int(state)
                return {'payload': str(self['DmLvl'])}
            except:
                pass
        self['DmLvl'] = None
        PrintError(self['DeviceType'], ET.tostring(XmlTree).replace('\n', ''))
        return {'payload': 'error'}

    def XmlSetStateCommand(
        self,
        XmlSubTree,
        DmLvl=None,
        **kwargs
    ):
        """
        <BaseRequest xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="SetActuatorStatesRequest" Version="1.70" RequestId="a2e824c6-f840-4c13-af81-81dfbde6ac88" SessionId="702390ac-3daf-4073-9999-bf17dc5b0b9b" BasedOnConfigVersion="1065">
            <ActuatorStates>
                <LogicalDeviceState xsi:type="DimmerActuatorState" LID="2381de77-bd2b-45a8-8306-d668e482f047" DmLvl="49" />
            </ActuatorStates>
        </BaseRequest>
        """
        DmLvl = int(DmLvl)
        if DmLvl < 0:
            DmLvl = 0
        if DmLvl > 100:
            DmLvl = 100
        if self['DmLvl'] == DmLvl:
            return False  # no change
        self['DmLvl'] = DmLvl
        XmlSubTree.set('xsi:type', 'DimmerActuatorState')
        XmlSubTree.set('DmLvl', str(DmLvl))
        XmlState = ET.SubElement(XmlSubTree, 'DmLvl')
        XmlState.text = str(DmLvl)
        return True


class ShcSwitchActuator(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcSwitchActuator, self).__init__(XmlTree)
        self['DeviceType'] = 'SwitchActuator'
        # PrintInfo(XmlTree.findtext('./DOfStgs/IsOn').replace("\n",''))
        try:
            self['IsOn'] = str_to_bool(XmlTree.findtext('./DOfStgs/IsOn'))
        except:
            self['IsOn'] = None
            PrintInfo('\n' + self['DeviceType'] + ':\n',
                      ET.tostring(XmlTree).replace('\n', ''))

    def XmlToEvent(self, XmlTree):
        state = XmlTree.attrib.get('IsOn', None)
        if state is not None:
            self['IsOn'] = str_to_bool(state)
            return {'state': bool_to_str(self['IsOn'], True)}
        PrintError(self['DeviceType'], ET.tostring(XmlTree).replace('\n', ''))
        return {'state': 'error'}

    def XmlSetStateCommand(
        self,
        XmlSubTree,
        IsOn=None,
        **kwargs
    ):
        if self['IsOn'] == IsOn:
            return False  # no change
        self['IsOn'] = IsOn
        IsOnText = bool_to_str(IsOn)
        XmlSubTree.set('xsi:type', 'SwitchActuatorState')
        XmlSubTree.set('IsOn', IsOnText)
        XmlState = ET.SubElement(XmlSubTree, 'IsOn')
        XmlState.text = IsOnText
        return True


class ShcValveActuator(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcValveActuator, self).__init__(XmlTree)
        self['DeviceType'] = 'ValveActuator'


class ShcLuminanceSensor(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcLuminanceSensor, self).__init__(XmlTree)
        self['DeviceType'] = 'LuminanceSensor'
        self['Luminance'] = None

    def XmlToEvent(self, XmlTree):
        payload = XmlTree.findtext('./Luminance')
        if payload:
            self['Luminance'] = float(payload)
            return {'payload': '%.1f' % self['Luminance']}
        PrintError(self['DeviceType'], ET.tostring(XmlTree).replace('\n', ''))
        return {'payload': 'error'}


class ShcPushButtonSensor(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcPushButtonSensor, self).__init__(XmlTree)
        self['DeviceType'] = 'PushButtonSensor'


class ShcAlarmActuator(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcAlarmActuator, self).__init__(XmlTree)
        self['DeviceType'] = 'AlarmActuator'
        try:
            # PrintInfo(XmlTree.findtext('./DOfStgs/IsOn'))
            self['IsOn'] = str_to_bool(XmlTree.findtext('./DOfStgs/IsOn'))
        except:
            self['IsOn'] = None
            PrintInfo('\n' + self['DeviceType'] + ':\n',
                      ET.tostring(XmlTree).replace('\n', ''))

    def XmlToEvent(self, XmlTree):
        # PrintInfo(XmlTree.findtext('./IsOn').lower())
        try:
            self['IsOn'] = str_to_bool(XmlTree.findtext('./IsOn'))
            return {'state': bool_to_str(self['IsOn'], True)}
        except:
            PrintError(
                self['DeviceType'],
                ET.tostring(XmlTree).replace(
                    '\n',
                    ''))
            return {'state': 'error'}

    def XmlSetStateCommand(
        self,
        XmlSubTree,
        IsOn=None,
        **kwargs
    ):
        if self['IsOn'] == IsOn:
            return False  # no change
        self['IsOn'] = IsOn
        IsOnText = bool_to_str(IsOn)
        XmlSubTree.set('xsi:type', 'AlarmActuatorState')
        XmlSubTree.set('IsOn', IsOnText)
        state = ET.SubElement(XmlSubTree, 'IsOn')
        state.text = IsOnText
        return True


class ShcSmokeDetectorSensor(ShcBaseDevice):  # SmokeDetectionSensor

    def __init__(self, XmlTree):
        super(ShcSmokeDetectorSensor, self).__init__(XmlTree)
        self['DeviceType'] = 'SmokeDetectorSensor'
        self['IsSmokeAlarm'] = None

    def XmlToEvent(self, XmlTree):
        # PrintInfo(XmlTree.findtext('./IsSmokeAlarm').lower())
        try:
            self['IsSmokeAlarm'] = str_to_bool(
                XmlTree.findtext('./IsSmokeAlarm'))
            return {'state': bool_to_str(self['IsSmokeAlarm'], True)}
        except:
            PrintError(
                self['DeviceType'],
                ET.tostring(XmlTree).replace(
                    '\n',
                    ''))
            return {'state': 'error'}


class ShcRoomTemperatureActuator(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcRoomTemperatureActuator, self).__init__(XmlTree)
        self['DeviceType'] = 'RoomTemperatureActuator'
        # PrintInfo XmlTree.findtext('./DOfStgs/PtTmp')
        try:
            self['Temperature'] = float(XmlTree.findtext('./DOfStgs/PtTmp'))
        except:
            self['Temperature'] = None
            PrintInfo('\n' + self['DeviceType'] + ':\n',
                      ET.tostring(XmlTree).replace('\n', ''))
        try:
            self['Automatic'] = str_to_bool(
                XmlTree.findtext('./DOfStgs/WndRd'))
        except:
            self['Automatic'] = None
            PrintInfo('\n' + self['DeviceType'] + ':\n',
                      ET.tostring(XmlTree).replace('\n', ''))

    def XmlToEvent(self, XmlTree):
        payload = XmlTree.attrib.get('PtTmp', '')
        if payload:
            self['Temperature'] = float(payload)
            return {'payload': '%.1f' % self['Temperature']}
        PrintError(self['DeviceType'], ET.tostring(XmlTree).replace('\n', ''))
        return {'payload': 'error'}

    def XmlSetStateCommand(
        self,
        XmlSubTree,
        Temperature=0,
        Automatic=None,
        **kwargs
    ):
        Temperature = round(float(Temperature) * 2) / 2
        if Temperature < 6.0:
            Temperature = 6.0
        if Temperature > 30.0:
            Temperature = 30.0
        if self['Temperature'] == Temperature and self[
                'Automatic'] == Automatic:
            return False
        self['Temperature'] = Temperature
        self['Automatic'] = Automatic
        XmlSubTree.set('xsi:type', 'RoomTemperatureActuatorState')
        XmlSubTree.set('PtTmp', str(Temperature))
        XmlSubTree.set('OpnMd', {True: 'Auto', False: 'Manu'
                                 }.get(Automatic, True))
        XmlSubTree.set('WRAc', bool_to_str(False))
        return True


class ShcThermostatActuator(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcThermostatActuator, self).__init__(XmlTree)
        self['DeviceType'] = 'ThermostatActuator'
        self['IsOn'] = False


class ShcWindowDoorSensor(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcWindowDoorSensor, self).__init__(XmlTree)
        self['DeviceType'] = 'WindowDoorSensor'
        self['IsOpen'] = False

    def XmlToEvent(self, XmlTree):
        state = XmlTree.findtext('IsOpen')
        if state is not None:
            self['IsOpen'] = str_to_bool(state)
            return {'state': bool_to_str(self['IsOpen'])}
        PrintError(self['DeviceType'], ET.tostring(XmlTree).replace('\n', ''))
        return {'state': 'error'}


class ShcMotionDetectionSensor(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcMotionDetectionSensor, self).__init__(XmlTree)
        self['DeviceType'] = 'MotionDetectionSensor'
        self['IsOn'] = False


class ShcRoomHumiditySensor(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcRoomHumiditySensor, self).__init__(XmlTree)
        self['DeviceType'] = 'RoomHumiditySensor'
        self['Humidity'] = None

    def XmlToEvent(self, XmlTree):
        payload = XmlTree.attrib.get('Humidity', None)
        if payload:
            self['Humidity'] = float(payload)
            return {'payload': '%.1f' % self['Humidity']}
        PrintError(self['DeviceType'], ET.tostring(XmlTree).replace('\n', ''))
        return {'payload': 'error'}


class ShcHumiditySensor(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcHumiditySensor, self).__init__(XmlTree)
        self['DeviceType'] = 'HumiditySensor'
        self['Humidity'] = None


class ShcTemperatureSensor(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcTemperatureSensor, self).__init__(XmlTree)
        self['DeviceType'] = 'TemperatureSensor'
        self['Temperature'] = None


class ShcRoomTemperatureSensor(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcRoomTemperatureSensor, self).__init__(XmlTree)
        self['DeviceType'] = 'RoomTemperatureSensor'
        self['Temperature'] = None

    def XmlToEvent(self, XmlTree):
        payload = XmlTree.attrib.get('Temperature', '')
        if payload:
            self['Temperature'] = float(payload)
            return {'payload': '%.1f' % self['Temperature']}
        PrintError(self['DeviceType'], ET.tostring(XmlTree).replace('\n', ''))
        return {'payload': 'error'}


class ShcRollerShutterActuator(ShcBaseDevice):

    def __init__(self, XmlTree):
        super(ShcRollerShutterActuator, self).__init__(XmlTree)
        self['DeviceType'] = 'RollerShutterActuator'
        self['Position'] = None

    def XmlSetStateCommand(self, XmlSubTree, Position=50, **kwargs):
        # @param string $logicalDeviceId the logical device id
        # state integer $shutterLevel the new shutter level of the device in
        # percent (0 - 100)
        try:
            Position = int(Position)
            if Position < 0:
                Position = 0
            if Position > 100:
                Position = 100
        except:
            PrintError('Wrong position (should be like 15.5, 22.75): ' +
                       str(Position))
            Position = 50
        if self['Position'] == Position:
            return False
        self['Position'] == Position
        XmlSubTree.set('xsi:type', 'RollerShutterActuatorState')
        ShutterLevel = ET.SubElement(XmlSubTree, 'ShutterLevel')
        ShutterLevel.text = str(Position)
        return True


class ShcGenericActuator(ShcBaseDevice):  # also ShcGenericDevice

    def __init__(self, XmlTree):
        super(ShcGenericActuator, self).__init__(XmlTree)
        self['DeviceType'] = 'GenericDevice'  # GenericActuator
        try:
            for state in XmlTree.findall('./DOfStgs/Ppts/Ppt'):
                attrib_name = state.attrib.get('Name', None)
                if attrib_name is not None:
                    setattr(
                        self,
                        attrib_name,
                        convert_property(
                            state.attrib.get(attrib_name, ''),
                            state.attrib.get(XSI_NS_TYPE, 'no_property')
                        )
                    )
        except:
            self['Value'] = None

    def XmlToEvent(self, XmlTree):
        state = XmlTree.find('./Ppts/Ppt')
        attrib_name = state.attrib.get('Name', None)
        if attrib_name is None:
            PrintError(self['DeviceType'],
                       ET.tostring(XmlTree).replace('\n', ''))
            return {'state': 'error'}
        else:
            setattr(
                self,
                attrib_name,
                convert_property(
                    state.attrib.get(attrib_name, ''),
                    state.attrib.get(XSI_NS_TYPE, 'no_property')
                )
            )
            return {'state': bool_to_str(
                    getattr(
                        self,
                        attrib_name,
                        'unknown'),
                    True)}

    def XmlSetStateCommand(
            self,
            XmlSubTree,
            IsOn=None,
            Payload=None,
            **kwargs):
        if self['Value'] == IsOn and self['Payload'] == Payload:
            return False
        self['Value'] = IsOn
        self['Payload'] = Payload
        XmlSubTree.set('xsi:type', 'GenericDeviceState')
        Ppts = ET.SubElement(XmlSubTree, 'Ppts')
        Ppt = ET.SubElement(Ppts,
                            'Ppt',
                            **{'xsi:type': 'BooleanProperty',
                               'Name': 'Value',
                               'Value': bool_to_str(IsOn)})
        return True


class ShcGenericSensor(ShcBaseDevice):  # also ShcGenericDevice

    def __init__(self, XmlTree):
        super(ShcGenericSensor, self).__init__(XmlTree)
        self['DeviceType'] = 'GenericSensor'  # GenericActuator
        try:
            for state in XmlTree.findall('./Pmts/Ppt'):
                attrib_name = state.attrib.get('Name', None)
                if attrib_name is not None:
                    setattr(
                        self, attrib_name, convert_property(
                            state.attrib.get(
                                'Value', ''), state.get(
                                XSI_NS_TYPE, 'no_property')))
        except:
            pass

    def XmlToEvent(self, XmlTree):
        """
        <LogicalDeviceState LID="87561af5-5db7-4cf9-aa90-ddfe1f94c389" ns0:type="GenericDeviceState" xmlns:ns0="http://www.w3.org/2001/XMLSchema-instance">
              <Ppts>
                <Ppt Name="NextSunrise" Value="2015-06-14T05:20:06.4680000+02:00" ns0:type="DateTimeProperty" />
                <Ppt Name="NextSunset" Value="2015-06-14T21:49:17.6240000+02:00" ns0:type="DateTimeProperty" />
                <Ppt Name="NextTimeEvent" Value="2015-06-14T05:20:06.4680000+02:00" ns0:type="DateTimeProperty" />
              </Ppts>
        </LogicalDeviceState>
        """
        try:
            for state in XmlTree.findall('./Ppts/Ppt'):
                attrib_name = state.attrib.get('Name', None)
                if attrib_name is not None:
                    setattr(
                        self, attrib_name, convert_property(
                            state.attrib.get(
                                'Value', ''), state.get(
                                XSI_NS_TYPE, 'no_property')))
            if self['NextTimeEvent'] is not None:
                return {
                    'state': 'NextTimeEvent',
                    'payload': self['NextTimeEvent']}
            else:
                return {'state': 'error'}

        except:
            PrintError(self['DeviceType'],
                       ET.tostring(XmlTree).replace('\n', ''))
            return {'state': 'error'}


ShcDeviceDefinitions = [s.__name__ for s in
                        ShcBaseDevice.__subclasses__()]


##########################################################################
# Smart Home Center - Communication
##########################################################################
# Low Level
##########################################################################

class SmartHomeCenter(object):

    def __init__(
        self,
        hostname,
        username,
        password,
        bDoEvents=True,
        clientid='',
    ):
        self.hostname = hostname
        self.username = username
        self.password = base64.b64encode(hashlib.sha256(password).digest())
        self.version = '1.70'
        self.clientid = (clientid if clientid != ''
                         else str(uuid.uuid1()))
        self.sessionid = None
        self.confversion = None
        self.notificationid = None
        self.bDoEvents = bDoEvents
        self.initialized = False

        self.bMultipleRequest = False
        self.CommandLinesQueue = []

        # global ShcRooms
        # RWE Smart Home Center NS
        # PrintInfo(ET.VERSION)
        try:  # ElementTree 1.3
            register_namespace = ET.register_namespace
        except:

                # ElementTree 1.2 (Python 2.5)

            def register_namespace(prefix, uri):
                try:
                    ET._namespace_map[uri] = prefix
                except:
                    pass

            for (prefix, uri) in NAMESPACES.items():
                register_namespace(prefix, uri)

        # self.Logon(hostname, username, password, bDoEvents)

    def BaseRequest(
        self,
        RequestType,
        *args,
        **kwargs
    ):
        #kwargs.update({'RequestId': str(uuid.uuid4())})
        #kwargs.update({'xsi:type': RequestType})
        XmlTree = ET.Element('BaseRequest', *args, **kwargs)
        XmlTree.set('RequestId', str(uuid.uuid4()))
        XmlTree.set('xsi:type', RequestType)
        if self.version is not None:
            XmlTree.set('Version', self.version)
        if self.confversion is not None:
            XmlTree.set('BasedOnConfigVersion', self.confversion)
        if not self.bMultipleRequest:
            XmlTree.set('xmlns:xsi', NAMESPACES['xsi'])
            XmlTree.set('xmlns:xsd', NAMESPACES['xsd'])
            if self.sessionid is not None:
                XmlTree.set('SessionId', self.sessionid)
            # PrintInfo(ET.tostring(XmlTree).replace('\n',''))
        #XmlTree.set('timeout', '30000')
        #XmlTimeout = ET.SubElement(XmlTree, 'timeout')
        #XmlTimeout.text = '30000'

        return XmlTree

    def MultipleCollect(self):
        PrintInfo()
        self.bMultipleRequest = True
        del self.CommandLinesQueue[:]

    def MultipleClear(self):
        PrintInfo()
        self.bMultipleRequest = False
        del self.CommandLinesQueue[:]

    def MultipleCommit(self):
        # PrintInfo()
        self.MultipleRequest(*self.CommandLinesQueue)
        self.bMultipleRequest = False
        del self.CommandLinesQueue[:]

    def MultipleRequest(self, *CommandLines):
        PrintInfo()
        if not self.IsConnected():
            return
        if not self.bMultipleRequest:
            PrintError(
                ('"MultipleRequest: MultipleCollect()" '
                 'neest to be issued first.'))
            return
        if len(CommandLines) == 0:
            PrintError('MultipleRequest: empty command queue.')
            return
        self.bMultipleRequest = False
        BaseRequest = self.BaseRequest('MultipleRequest')
        RequestList = ET.SubElement(BaseRequest, 'RequestList')
        for CommandLine in CommandLines:
            RequestList.append(CommandLine)
        del self.CommandLinesQueue[:]
        return self.SmartHomeRequest(ET.tostring(BaseRequest),
                                     expectedResponse='MultipleResponse')

    def SmartHomeRequest(
        self,
        CommandString,
        page='cmd',
        bCheckCfg=True,
        expectedResponse=None,
        expectedErrorResponse=None,
        tries=1,
    ):
        # Base request function
        # PrintInfo()
        if self.bMultipleRequest and page == 'cmd':
            # Workaround for jouning namespaced subelements
            XML_Command = ET.fromstring(
                CommandString.replace('xsi:type', 'xsi_type'))

            def IterateMe(XML_Tree):
                for XML_Sub in XML_Tree:
                    IterateMe(XML_Sub)
                if XML_Tree.attrib.get('xsi_type', None) is not None:
                    XML_Tree.attrib['xsi:type'] = XML_Tree.attrib['xsi_type']
                    del XML_Tree.attrib['xsi_type']

            IterateMe(XML_Command)
            self.CommandLinesQueue.append(XML_Command)
            return XML_Command

        url_string = 'https://' + self.hostname + '/' + page

        # url_string = 'http://smarthome.store.local/cmd.php'
        # params={'file': filepath}
        # auth=(self.username, self.password)

        if DEBUG:
            try:
                XML_Command = ET.fromstring(CommandString).attrib.get(
                    XSI_NS_TYPE, 'RWESmartHome')
                WriteInfo(CommandString, 'Request_' + XML_Command + '.xml')
            except:
                pass
        if bCheckCfg:
            self.GetConfiguration()
        Response = None
        try:
            s = requests.Session()
            s.mount('https://', sslfix.MyAdapter(max_retries=tries))

            # Response = requests.request(method='post',url=url_string,

            Response = s.request(
                method='post',
                url=url_string,
                headers={
                    'Host': self.hostname,
                    'Referer': 'https://smarthome.blob.core.windows.net' +
                    '/silverlight/latest/application/' +
                    'RWE.SmartHome.UI.Shell.xap?ignore=1.70.916.0',
                    'ClientId': self.clientid,
                    'Proxy-Connection': 'keep-alive',
                    'Accept-Encoding': 'identity',
                    'Content-Type': 'text/xml',
                    'Content-Length': str(len(CommandString)),
                    'Connection': 'keep-alive',
                    'Accept': '*/*',
                    'Accept-Language': 'de-de',
                },
                data=CommandString,
                verify=False,
                allow_redirects=False,
                stream=False,
                timeout=67,
            )
        except Exception as e:

            # max_retries=tries,
            # delay_between_retries=5

            PrintError(e)
            self.sessionid = None
        try:
            XmlTree = ET.fromstring(Response.text.encode('utf-8'))
            DeviceType = XmlTree.attrib.get(XSI_NS_TYPE, None)
            if DeviceType != expectedResponse and DeviceType \
                    != expectedErrorResponse:
                XML_Command = ET.fromstring(
                    CommandString).attrib.get(XSI_NS_TYPE, None)
                PrintError('Unexpecred response ' + XML_Command,
                           ' (', DeviceType, '): ',
                           ET.tostring(XmlTree).replace('\n', ''))
            else:
                if bCheckCfg:
                    self.GetConfiguration(XmlTree)
                if DEBUG:
                    WriteInfo(
                        Response.text.encode('utf-8'),
                        'Response_' +
                        XmlTree.attrib.get(
                            XSI_NS_TYPE,
                            'RWESmartHome') +
                        '.xml')
                return XmlTree
        except:
            try:
                PrintError(Response.status_code + ': ' + Response.text)
                return None
            except:
                PrintError('unknown reason')
        return None

    def Logon(
        self,
        hostname,
        username,
        password,
        bDoEvents,
        clientid,
    ):
        PrintInfo()
        if self.hostname != hostname:
            self.sessionid = None
            self.hostname = hostname
        if self.username != username:
            self.sessionid = None
            self.username = username
        if self.password \
                != base64.b64encode(hashlib.sha256(password).digest()):
            self.sessionid = None
            self.password = base64.b64encode(hashlib.sha256(password).digest())
        if self.clientid != clientid:
            self.clientid = (clientid if clientid != ''
                             else str(uuid.uuid1()))
        if self.bDoEvents != bDoEvents:
            self.sessionid = None
            self.bDoEvents = bDoEvents
        self.IsConnected()

    def LoginRequest(self):
        PrintInfo()
        self.sessionid = None
        XmlTree = self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest(
                    'LoginRequest',
                    **{
                        'UserName': self.username,
                        'Password': self.password})),
            bCheckCfg=False,
            expectedResponse='LoginResponse',
            expectedErrorResponse='AuthenticationErrorResponse',
            tries=3)

        if XmlTree is not None:
            AuthenticationError = XmlTree.attrib.get('Error', None)
            if AuthenticationError is not None:
                PrintError(AuthenticationError)
                return
            if XmlTree.attrib.get(XSI_NS_TYPE, None) == 'LoginResponse':
                self.sessionid = XmlTree.attrib.get('SessionId', None)
                if IsUUID(self.sessionid):
                    PrintInfo('login successful:', self.clientid)
                else:
                    self.sessionid = None
                    PrintError('no login')
                    PrintError(ET.tostring(XmlTree).replace('\n', ''))
                    return
            else:
                PrintError('no https BaseRequest')
        else:
            PrintError('no Tree')

    def LogoutRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('LogoutRequest')),
            expectedResponse='AcknowledgeResponse')

    def SHCRestartRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        BaseRequest = self.BaseRequest('SHCRestartRequest')
        Child = ET.SubElement(BaseRequest, 'Reason')
        Child.text = 'EventGhost'
        Child = ET.SubElement(BaseRequest, 'Requester')
        Child.text = self.username
        return self.SmartHomeRequest(
            ET.tostring(BaseRequest),
            bCheckCfg=False,
            expectedResponse='AcknowledgeResponse')

    def GetEntitiesRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        BaseRequest = self.BaseRequest('GetEntitiesRequest')
        Child = ET.SubElement(BaseRequest, 'EntityType')
        Child.text = 'Configuration'
        return self.SmartHomeRequest(
            ET.tostring(BaseRequest),
            bCheckCfg=False,
            expectedResponse='GetEntitiesResponse')

    def AcquireConfigurationLockRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        BaseRequest = self.BaseRequest('AcquireConfigurationLockRequest'
                                       )
        Child = ET.SubElement(BaseRequest, 'OverrideLock')
        Child.text = bool_to_str(False)
        return self.SmartHomeRequest(
            ET.tostring(BaseRequest),
            expectedResponse='AcknowledgeResponse',
            expectedErrorResponse='ConfigurationLockErrorResponse')

    def ReleaseConfigurationLockRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('ReleaseConfigurationLockRequest')),
            expectedResponse='AcknowledgeResponse',
            expectedErrorResponse='ModifyEntitiesErrorResponse')

    def GetApplicationTokenRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetApplicationTokenRequest')),
            expectedResponse='GetApplicationTokenResponse')

    def GetUserEmailConfirmationState(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetUserEmailConfirmationState')),
            expectedResponse='GetUserEmailConfirmationStateResponse')

    def GetAllLogicalDeviceStatesRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetAllLogicalDeviceStatesRequest')),
            expectedResponse='GetAllLogicalDeviceStatesResponse')

    def GetAllPhysicalDeviceStatesRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetAllPhysicalDeviceStatesRequest')),
            expectedResponse='GetAllPhysicalDeviceStatesResponse')

    def GetMessageListRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetMessageListRequest')),
            expectedResponse='MessageListResponse')

    def GetShcInformationRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetShcInformationRequest')),
            expectedResponse='ShcInformationResponse')

    def GetShcTypeRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetShcTypeRequest')),
            expectedResponse='GetShcTypeResponse')

    def GetCmsAddress(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetCmsAddress')),
            expectedResponse='GetCmsAddressResponse')

    def InitializeEndpoint(self):
        PrintInfo()
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest(
                    'InitializeEndpoint',
                    **{
                        'UserName': self.username,
                        'Password': self.password})),
            bCheckCfg=False,
            expectedResponse='InitializeEndpointResponse',
            tries=3)

    def SendMessage(self):
        PrintInfo()
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest(
                    'SendMessage',
                    **{
                        'UserName': self.username,
                        'Password': self.password})),
            bCheckCfg=False,
            expectedResponse='SendMessageResponse',
            tries=3)

    def GetMessages(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetMessages')),
            expectedResponse='GetMessagesResponse')

    def GetUserShcs(self):
        PrintInfo()

        # Username / Pasword should be included within the header

        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest('GetUserShcs')),
            expectedResponse='GetUserShcsResponse')

    def NotificationRequest(self, SetNotificationType='',
                            bSubscribe=True):
        if SetNotificationType not in [
            'Calibration',
            'ConfigurationChanges',
            'CustomApplication',
            'DeviceStateChanges',
            'DeploymentChanges',
            'MessageUpdate',
        ]:
            SetNotificationType = 'DeviceStateChanges'
        if not self.IsConnected():
            return
        # PrintInfo()
        BaseRequest = self.BaseRequest('NotificationRequest')
        Action = ET.SubElement(BaseRequest, 'Action')
        Action.text = ('Subscribe' if bSubscribe else 'Unsubscribe')
        NotificationType = ET.SubElement(BaseRequest, 'NotificationType'
                                         )
        NotificationType.text = SetNotificationType
        return self.SmartHomeRequest(
            ET.tostring(BaseRequest),
            expectedResponse='AcknowledgeResponse',
            tries=3)

    def SoftwareUpdateRequest(self):
        PrintInfo()
        if not self.IsConnected():
            return
        return self.SmartHomeRequest(
            ET.tostring(
                self.BaseRequest(
                    'SoftwareUpdateRequest',
                    **{'Action': 'Update'})),
            expectedResponse='AcknowledgeResponse')

    def GetUpdatesRequest(self):
        # PrintInfo()
        if self.sessionid is not None:
            return self.SmartHomeRequest('upd', 'upd')

    def SetActuatorStatesRequest(self, SetLogicalDeviceId, **kwargs):
        # PrintInfo()
        if not self.IsConnected():
            return
        if ShcDevices.get(SetLogicalDeviceId, None) is not None:
            BaseRequest = self.BaseRequest('SetActuatorStatesRequest')
            ActuatorStates = ET.SubElement(BaseRequest, 'ActuatorStates')
            LogicalDeviceState = ET.SubElement(
                ActuatorStates, 'LogicalDeviceState',
                **{'LID': SetLogicalDeviceId})
            if ShcDevices[SetLogicalDeviceId].XmlSetStateCommand(
                    LogicalDeviceState, **kwargs):
                XmlTree = self.SmartHomeRequest(
                    ET.tostring(BaseRequest),
                    expectedResponse='ControlResultResponse',
                    expectedErrorResponse='GenericSHCErrorResponse')
                if self.bMultipleRequest:
                    return XmlTree
                try:
                    result = XmlTree.attrib.get(
                        'Result', 'ErrorCode: ' +
                        str(XmlTree.attrib.get('Code', 'n/a')))
                    if result.lower() == 'ok':
                        return True
                    else:
                        PrintError(result)
                        if result.lower() == 'configurationoutofdate':
                            self.confversion = None
                        return False
                except:
                    PrintError('ERROR')
            else:
                PrintInfo('desired state is same as current state')
        else:
            PrintError('UnknownDevice:', SetLogicalDeviceId)
            # PrintInfo(ET.tostring(XmlTree).replace("\n",''))
        return False

##########################################################################

    def IsConnected(self):
        if self.sessionid is not None:
            return True
        self.LoginRequest()
        if self.sessionid is not None:
            if self.bDoEvents:
                # self.NotificationRequest('Calibration')
                # self.NotificationRequest('ConfigurationChanges')
                # self.NotificationRequest('CustomApplication')
                # self.NotificationRequest('DeploymentChanges')
                # self.NotificationRequest('DeviceStateChanges')
                # self.NotificationRequest('MessageUpdate')
                self.MultipleCollect()
                self.MultipleRequest(
                    self.NotificationRequest('Calibration'),
                    self.NotificationRequest('ConfigurationChanges'),
                    self.NotificationRequest('CustomApplication'),
                    self.NotificationRequest('DeploymentChanges'),
                    self.NotificationRequest('DeviceStateChanges'),
                    self.NotificationRequest('MessageUpdate'),
                )
            return True
        return False

    def GetConfiguration(self, XmlTree=None):
        if not self.IsConnected():
            return
        if XmlTree is not None:
            confversion = XmlTree.attrib.get(
                'CurrentConfigurationVersion', XmlTree.attrib.get(
                    'ConfigurationVersion', None))
            if not confversion or confversion == self.confversion:
                return
        else:
            if self.confversion:
                return
        # PrintInfo()
        ShcDevices.clear()  # Clear current Device Configuration
        XmlTree = self.GetEntitiesRequest()
        if XmlTree is not None:
            self.confversion = XmlTree.attrib.get(
                'ConfigurationVersion', None)
            PrintInfo('loading rooms...')
            for item in XmlTree.findall('./LCs/LC'):  # './LCs/LC[Id]'
                ShcDevices[item.findtext(
                    './Id')] = globals()['ShcRoom'](item)
            PrintInfo('loading devices...')
            for item in XmlTree.findall('./LDs/LD'):  # './LDs/LD[Id]'
                DeviceType = item.attrib.get(XSI_NS_TYPE, None)
                if 'Shc' + DeviceType in ShcDeviceDefinitions:
                    ShcDevices[item.find('Id').text] = globals()[
                        'Shc' + DeviceType](item)
                else:
                    PrintError('Missing type definition: ' +
                               DeviceType +
                               '\n' +
                               ET.tostring(item).replace("\n", ''))
                    ShcDevices[item.find('Id').text] = ShcBaseDevice(item)

            # Get All Logical Device States
            PrintInfo('loading devices states...')
            XmlTree = self.GetAllLogicalDeviceStatesRequest()
            for item in XmlTree.findall('./States/LogicalDeviceState'):
                ShcDevices[item.attrib.get('LID', None)].XmlToEvent(item)

            # Get All Physical Device States Request
            if not self.initialized:
                self.initialized = True
                try:
                    eg.TriggerEvent(prefix=PLUGIN_NAME,
                                    suffix='initialized',
                                    payload=self.sessionid)
                except:
                    PrintInfo('initialized')

            # create BDID translate
            ShcPhyBdId.clear()  # Clear current Device Configuration
            for key in ShcDevices:
                if ShcDevices[key].BDId is not None:
                    ShcPhyBdId[ShcDevices[key].BDId] = key

    def GetEvents(self):
        egEvent = []
        if not self.IsConnected():
            return egEvent
        # PrintInfo(self.sessionid)
        XmlTree = self.GetUpdatesRequest()

        if XmlTree is None:
            self.sessionid = None
            PrintError('No request response')
            return egEvent

        # PrintInfo(ET.tostring(XmlTree).replace("\n",''))
        # and self.notificationid !=
        # XmlTree.attrib.get('NotificationListId',None):

        for notification in XmlTree.findall('./Notifications/*'):
            if notification.tag == 'LogoutNotification':
                PrintInfo(notification.tag)
                self.sessionid = None
                break

            if notification.tag == 'ConfigurationChangedNotification':
                PrintInfo(notification.tag)
                self.confversion = None
                break

            if notification.tag == 'NewMessageNotification':
                """
                <NewMessageNotification NotificationId="7eae1e84-fa51-4185-83b6-0b2354b56022" Version="1.70">
                    <Message Class="Alert" Id="040be059-22c2-458c-9456-11ceec13e5a3" TimeStamp="2015-06-15T13:42:59.058Z" Type="DeviceUnreachable">
                        <Parameters>
                            <MessageParameter Key="DeviceId" Value="3877f91f-07fc-44bd-a76f-e04c3af69adc" />
                        </Parameters>
                    </Message>
                </NewMessageNotification>
                """
                for XmlState in notification.findall('./Message'):
                    if XmlState.attrib.get('Class', None) != 'Alert':
                        PrintInfo(notification.tag + '\n' +
                                  ET.tostring(notification).replace('\n', ''))
                        try:
                            PrintInfo(ET.tostring(
                                self.GetMessageListRequest()).replace(
                                '\n', ''))
                        except Exception as e:
                            PrintError(e)
                continue

            if notification.tag == 'MessageStateChangedNotification':
                for XmlState in notification.findall('./Message'):
                    if XmlState .attrib.get('State', 'Deleted') != 'Deleted':
                        PrintInfo(notification.tag + '\n' +
                                  ET.tostring(notification).replace('\n', ''))
                continue

            if notification.tag == 'PhysicalDeviceStateChangedNotification':
                """
                <PhysicalDeviceStateChangedNotification NotificationId="4f0df33b-f991-40a6-bf47-075ebdd49d02" Version="1.70">
                    <DeviceState DeviceConfigurationState="Complete" DeviceInclusionState="Included" FirmwareVersion="22" IsReachable="false" PhysicalDeviceId="3877f91f-07fc-44bd-a76f-e04c3af69adc" UpdateState="UpToDate" />
                </PhysicalDeviceStateChangedNotification>
                """
                for XmlState in notification.findall('./DeviceState/'):
                    # PrintInfo(ET.tostring(XmlState))
                    LID = ShcPhyBdId.get(
                        XmlState.attrib.get(
                            'PhysicalDeviceId', None), None)
                    event = str_to_bool(XmlState.attrib.get('IsReachable', ''))
                    state = XmlState.attrib.get('DeviceConfigurationState', '')
                    if LID is None:
                        PrintError('PhysicalDeviceId not found.')
                    else:
                        if ShcDevices.get(LID, None) is None:
                            PrintError('PhysicalDeviceId not found: ' + LID)
                        else:
                            if state == 'Complete':
                                state = {True: 'IsReachable',
                                         False: 'NotReachable'}.get(
                                    event,
                                    'unknown')

                            event_joined = ShcDevices[LID]['DeviceType'] + \
                                '.' + ShcDevices[LID].GetLongName() + \
                                ': ' + state
                            egEvent.append([event_joined, None])
                continue

            if notification.tag == 'LogicalDeviceStatesChangedNotification':
                for XmlState in notification.findall(
                        './LogicalDeviceStates/LogicalDeviceState/'):
                    # PrintInfo(ET.tostring(XmlState))
                    LID = XmlState.attrib.get('LID', None)
                    DeviceType = XmlState.attrib.get(
                        XSI_NS_TYPE, '').replace('State', '')
                    if LID is None:
                        PrintInfo('Missing device (' + DeviceType + '):\n' +
                                  ET.tostring(XmlState).replace('\n', ''))
                    else:
                        if ShcDevices.get(LID, None) is not None:
                            """
                            if ShcDevices[LID]['DeviceType'] != DeviceType:
                                PrintInfo(
                                    'Typemismatch:\n' +
                                    ShcDevices[LID].GetLongName() + ': ' +
                                    ShcDevices[LID]['DeviceType'] + '|' +
                                    DeviceType + '\n' +
                                    ET.tostring(XmlState).replace('\n', ''))
                            """
                            try:
                                event = ShcDevices[LID].XmlToEvent(XmlState)
                            except:
                                PrintError(ET.tostring(XmlState))
                            event_joined = (
                                ShcDevices[LID]['DeviceType'] +
                                '.' +
                                ShcDevices[LID].GetLongName())
                            if event is not None:
                                state = event.get('state', None)
                                payload = event.get('payload', None)
                                if state is not None:
                                    event_joined += (
                                        (': ' if payload is None else '.') +
                                        state)
                                egEvent.append([event_joined, payload])
                continue

            if notification.tag == 'InvalidateTokenCacheNotification':
                """
                <InvalidateTokenCacheNotification NotificationId="ae5221a6-29c7-4e4e-a405-481a5a392570" Version="1.70" />
                """
                egEvent.append([
                    'Shc.InvalidateTokenCache',
                    notification.attrib.get('NotificationId', None)])
                continue

            PrintError('Unknown Notificatin Type:' +
                       notification.tag +
                       '\n' +
                       ET.tostring(notification).replace('\n', ''))
        return egEvent

    def BuidNamesID(self, deviceid, DeviceType):
        try:
            (names, myids) = zip(*sorted([[v.GetLongName(), k]
                                          for (k, v) in ShcDevices.iteritems()
                                          if v.DeviceType == DeviceType]))
        except:
            (names, myids) = ((), ())
        if len(myids) == 0:
            PrintError('no devices for "' + DeviceType + '"avaylable')
            return ([deviceid], [deviceid], 0)
        try:
            idx = myids.index(deviceid)
        except:
            idx = -1
        return (names, myids, idx)

##########################################################################
# Helper Functions
##########################################################################


def IsUUID(uuid=None):
    if uuid is None or len(uuid) < 36:
        return False
    try:
        int(uuid.replace('-', ''), 16)
        return True
    except:
        return False


def str_to_bool(value):
    return {'true': True,
            'false': False,
            'on': True,
            'off': False
            }.get(value.lower(), None)


def bool_to_str(value, switch=False):
    if switch:
        return {True: 'on', False: 'off'}.get(value, None)
    else:
        return {True: 'True', False: 'False'}.get(value, None)


def strtime_to_localtime(timestring):
    """
    NextSunrise =   "2015-06-14T05:20:06.4680000+02:00"
    NextSunset =    "2015-06-14T21:49:17.6240000+02:00"
    NextTimeEvent = "2015-06-14T05:20:06.4680000+02:00"

    timestring[0:4]  # year
    timestring[5:7]  # month
    timestring[8:10]  # day
    timestring[10:11]  # Z
    timestring[11:13]  # hour
    timestring[14:16]  # minute
    timestring[17:19]  # second
    # timestring[19:27]  # microsecond
    timestring[20:23]  # microsecond
    timestring[27:28]  # +- tzinfo
    timestring[28:30]  # offset hour
    timestring[31:33]  # offset minutes
    """

    # dt = datetime.tzinfo()
    # dt = datetime.datetime.now().timetuple()
    # print time.timezone
    # print time.localtime().tm_isdst

    # time zime correction
    # offset correction
    """
    dt += datetime.timedelta(
        hours=int(timestring[28:30]),  # offset hours
        minutes=int(timestring[31:33])  # offset minutes
    ) * (1 if timestring[27:28] != '-' else -1)
    """
    # time
    try:
        dt = datetime.datetime(
            int(timestring[0:4]),  # year
            int(timestring[5:7]),  # month
            int(timestring[8:10]),  # day
            int(timestring[11:13]),  # hour
            int(timestring[14:16]),  # minute
            int(timestring[17:19]),  # second
            int(timestring[20:23]),  # microsecond
        )
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return timestring[0:23]


def convert_property(value, property):

    if property == 'BooleanProperty':
        return str_to_bool(value)

    if property == 'NumericProperty':
        try:
            return float(value)
        except:
            PrintError('float property:' + value)
            return value

    if property == 'DateTimeProperty':
        return strtime_to_localtime(value)

    PrintError('unknown property:' + property)
    return value
