from requests.adapters import HTTPAdapter
from requests.packages.urllib3.poolmanager import PoolManager
import ssl


class MyAdapter(HTTPAdapter):

    def init_poolmanager(self, pool_connections=1,  pool_maxsize=1, max_retries=5, block=False):
        self.poolmanager = PoolManager(	num_pools=pool_connections,
                                        maxsize=pool_maxsize,
                                        block=block,
                                        # retries=max_retries,
                                        ssl_version=ssl.PROTOCOL_TLSv1)
