#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# plugins/RWE_SmartHome/__init__.py
#
# Copyright (c) 2015, Heiko Steinwender
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. Neither the name of Heiko Steinwender nor the names of its contributors may
#    be used to endorse or promote products derived from this software without
#    specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# $LastChangedDate: 2015-07-07 17:56:16 -7200 (Tue, 07 Jul 2015) $
# $LastChangedRevision: 15 $
# $LastChangedBy: lms0815 $
#
#
##########################################################################
# Helper Functions
##########################################################################

import os
import inspect
import imp


PLUGIN_NAME = ' '.join((__name__ + '.myudf').split('.myudf', 1)
                       [0].split('.')[-1].replace('_', ' ').split())

try:
    imp.find_module('eg')
    EGLOADED = True

except ImportError:
    EGLOADED = False

DEBUG = os.path.isfile(
    os.path.normpath(
        os.path.join(
            os.path.dirname(__file__),
            '~push.cmd')))


def _BuildInfo(*args):
    comment = u' '.join(i if type(i).__name__ ==
                        'unicode' else unicode(str(i)) for i in args)
    if DEBUG:
        i = 2
        if EGLOADED:
            comment = ('%s%s' % (
                inspect.stack()[i][3],
                (': ' + comment if comment.strip() != '' else ''))
            )
        else:
            comment = ('  File "%s", line %i, in %s%s' % (
                inspect.stack()[i][1],
                inspect.stack()[i][2],
                inspect.stack()[i][3],
                ('\n' + comment if comment.strip() != '' else ''))
            )
    if comment.strip() != '':
        return PLUGIN_NAME + ': ' + comment
    return ''


def PrintInfo(*args):
    c = _BuildInfo(*args)
    if c != '':
        print (c)


def PrintError(*args):
    c = _BuildInfo(*args)
    if c != '':
        try:
            eg.PrintError(c)
        except:
            print ('ERROR: ' + c)


def WriteInfo(info='', filename=__file__ + '.xml'):
    path = os.path.normpath(os.path.join(os.path.dirname(__file__),
                                         'Logs', filename))
    if not os.path.isfile(path):
        try:
            PrintInfo('Writing: ' + path)

            # http://www.freeformatter.com/xml-formatter.html#ad-output

            with open(path, 'w') as stream:
                stream.write(info.replace('><', '>\n<'))
                stream.close()
        except:
            PrintError('Writing: ' + path)

#############################################################################
if __name__ == '__main__':
    PrintInfo('IsDebug:', DEBUG)
    PrintInfo()
    PrintInfo('PlugInName:' + PLUGIN_NAME)
