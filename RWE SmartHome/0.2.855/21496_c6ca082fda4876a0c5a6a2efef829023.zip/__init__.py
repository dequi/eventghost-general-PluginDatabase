# -*- coding: UTF-8 -*-
#!/usr/bin/python
#
# plugins/RWE_SmartHome/__init__.py
#
# Copyright (c) 2015, Heiko Steinwender
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. Neither the name of Heiko Steinwender nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
##############################################################################
# Revision history:
#
# 2015-03-30  First Version
##############################################################################
#
# $LastChangedDate: 2015-07-06 16:50:02 -7200 (Mon, 06 Jul 2015) $
# $LastChangedRevision: 855 $
# $LastChangedBy: lms0815 $
#
# http://python.net/~goodger/projects/pycon/2007/idiomatic/handout.html
#


import eg
import hashlib
import base64
import uuid


from RWESmartHome import SmartHomeCenter, IsUUID
from threading import Event, Thread
from myudf import *

if 'PLUGIN_NAME' not in locals():
    PLUGIN_NAME = ''

THREAD_DELAY = 2  # Original SHC delay 2 sec

eg.RegisterPlugin(
    name=PLUGIN_NAME,
    guid='{f418c7e7-3d1c-4d5d-bd67-8ced72401c53}',
    author='Heiko Steinwender',
    version='0.2.' + '$LastChangedRevision: 855 $'.split()[1],
    kind='external',
    # kind = 'program',
    canMultiLoad=True,
    createMacrosOnAdd=True,
    url=('http://www.eventghost.net/forum/viewtopic.php?'
         'f=9&t=6882&sid=0caf179a29daab775b7302a8e6aaab4f'),
    description=(
        u'<p>Plugin to control '
        u'<a href="http://www.rwe-smarthome.de/">RWE SmartHome</a></p>'
        u'<center><img src="RWESmartHome.jpg" /></center>'
    ),
    help=(
        '<b>Home automation with RWE SmartHome</b><br><br>'
        'The convenient solution for your home.<br><br>'
        'Customised home automation is no longer a pipe-dream or an '
        'unaffordable luxury &#45 thanks to RWE SmartHome, '
        'the user-friendly home automation system for every home, '
        'which delivers contemporary home automation of electrical devices '
        'and heating.'),
    icon=(
        'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAFo9M/3AAAABmJLR0QA/wD/AP+g'
        'vaeTAAAAB3RJTUUH3wQECAUIKOEYAgAABClJREFUOBEBHgTh+wPC3O3/K0lbBQMR'
        'N1MFCQtKewGiyN3d6u/0pwDM47X/6vb9/wGXv9jdCwkKIk0xHQDs9foAAqzJ4ac2'
        'IRIA7fP4APz7+gABqMrf/+Tt8oUAAAAA1OLv9ADp9vz/cq7U/wBorP/q9/3/BP//'
        '/wAWC0MAg071AP//UQAB1Ofz////7ADz+eQADggwAACuzuL/2+/6/97x+v/m9vz/'
        'Z6DM/97w+v/c8Pr/3fD7/wLS4euFbZjAAAYCAQAHAgMANiZ8AAoFAgBTjLsACwYD'
        'AATd6fUAo3BDAAMBAACVvg0ABAMKAAYCAAC+e0gAAAIAAAS60+b0tdLkAAQCAgAj'
        'FtcAAQAAALjV5wD9/v8A6PD4AAGVwNv/FQsEAOjv88L6/f/DAAAAAAAAAAABAAAB'
        'c0kvfQHd8Pv//wD/AAIBAACBqs4AiVs1APv+/wD4+/4AoLC9mQINBwIAFQoFACJy'
        'sACRXzcAgbLUAB15tgAOBwIA+v3+AADp9/7/NoC3/+j1/P+Ywzz/7Pf//+Hx+v9T'
        'j7//cJizmAHp9v3/AgAAAJjADwAFAwsAAAAAAEgspQAYED8Ae5u0mQIEAwEAAgEA'
        'AGY/5QD/AP4A+v3zAB4TQQADAgIA7vX6AATn7vUAAwIAAOz0zABVM+IA9PniAOvy'
        '9wD7/f8A6fL4AAS31OcAGA8IAAMCJgDk7+wA/wAKAP//7wD7/v8A2uXu9QGXwNr/'
        'RjEgAPz+AQABAQAAAAAAAAEAAAD/AQAABAICAP///wD9//8AAQAAAP//AAAAAAAA'
        '//8AAAQCAAB2l7CHBAoEAQAGAgMABQH/AAIBAAACAQEA7/f7AEmWxQAUCQUA+Pz+'
        'APv/AAC9bjwAYZ/LAJteMwAEAwIAAgIBACUVCxIC1ePtwgwGAQAJBQEAcaLIABpu'
        'qgDj7fMAzHZAAJpa+QCmYAUAxnI9AM/g7QC/0uEAfanNAAsHAgAMBQEA+v3+AAQE'
        'AwPD+P3/PgIAAACaZTsAhFbWAO71vgDH284A1eWaAP8A/wAvHW8AFg0rANiILwAV'
        'DSgA+v7+APr/AAD4+v0AAu71+gAEAQAAAP8AAPz9/QAUDCkACgYWANTlmgACAgYA'
        'AwIHANLkkwAPCR8AEwsnAPz9/QAB/gAABAEAAPH2+wAC5/H4AAUDAQAEAgAAAwEB'
        'AAIB/wAEAgQA/v/7ADUgdQAyHm4A+/33AAUCBQACAv8AAwEBAAMCAAAFAwEA6vP5'
        'AATn7/cBvtbnAAIBAQAEAgEAAgIAAAIBJQA0H9IA/P0IAAAA/wA2IFoA3esJANvq'
        '6wD+/v8A/P7/AP7//wDq8vgAAQAAAAIOXJOECAICEv8AAAAAAP8AAAAAAAAAAAAA'
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAAA9/r49fOoc4HeS5o151U92wAAAABJ'
        'RU5ErkJggg=='),
)


class RWESmartHome(eg.PluginClass):

    class text:
        infoStartup = 'plugin started'
        infoStopped = 'plugin stopped'
        infoClosed = 'plugin closed'
        infoStatus = 'not yet started'
        infoStartThread = 'monitor thread is started'
        infoStopThread = 'monitor thread has stopped'
        infoEvent = 'unknown event'

        hostname = 'RWE SmartHomeCenter IP-address or host name: '
        username = 'User name (leave empty if not defined): '
        password = 'Password (leave empty if not defined): '
        clientid = 'unique id'

        infobDoEvents = 'Check to log device events'

    def __init__(self):
        self.RWE_SHC = None
        self.AddAction(RoomTemperatureActuatorSet)
        self.AddAction(RollerShutterActuatorSet)
        self.AddAction(DimmerActuatorSet)
        self.AddAction(RestartRequest)

        group1 = self.AddGroup('Switch Actuatos', 'Switch Actuator on/off')
        group1.AddAction(SwitchActuatorOn)
        group1.AddAction(SwitchActuatorOff)

        group2 = self.AddGroup('Generic Actuatos', 'Generic Actuatos on/off')
        group2.AddAction(GenericActuatorOn)
        group2.AddAction(GenericActuatorOff)

        group3 = self.AddGroup('Alarm Actuatos', 'Generic Actuatos on/off')
        group3.AddAction(AlarmActuatorOn)
        group3.AddAction(AlarmActuatorOff)

        group4 = self.AddGroup('Multiple Commands',
                               'Collect commands and commit at once')
        group4.AddAction(MultipleCollect)
        group4.AddAction(MultipleClear)
        group4.AddAction(MultipleCommit)

############################################################

    def __start__(self,
                  hostname,
                  username,
                  password,
                  bDoEvents,
                  clientid):
        self.info.eventPrefix = PLUGIN_NAME

        self.hostname = hostname
        self.username = username
        self.password = password
        self.bDoEvents = bDoEvents
        self.clientid = clientid

        self.bPluginIsInitialized = False
        self.sq = None
        self.wifi = 0

        self.stopThreadEvent = Event()
        Thread(target=self.ThreadWorker,
               args=(self.stopThreadEvent,)
               ).start()
        PrintInfo(self.text.infoStartup)
        self.RWE_SHC = SmartHomeCenter(hostname=str(self.hostname),
                                       username=str(self.username),
                                       password=str(self.password),
                                       bDoEvents=self.bDoEvents,
                                       clientid=str(clientid)
                                       )

        while not self.bPluginIsInitialized:
            try:
                self.bPluginIsInitialized = self.RWE_SHC.sessionid is None
            except:
                pass

    def __stop__(self):
        if self.stopThreadEvent:
            self.stopThreadEvent.set()
            PrintInfo(self.text.infoStopped)

    def __close__(self):
        if self.bPluginIsInitialized:
            self.RWE_SHC.MultipleCollect()
            self.RWE_SHC.MultipleRequest(
                self.RWE_SHC.NotificationRequest('Calibration', False),
                self.RWE_SHC.NotificationRequest('ConfigurationChanges', False),
                self.RWE_SHC.NotificationRequest('CustomApplication', False),
                self.RWE_SHC.NotificationRequest('DeploymentChanges', False),
                self.RWE_SHC.NotificationRequest('DeviceStateChanges', False),
                self.RWE_SHC.NotificationRequest('MessageUpdate', False),
            )
            self.RWE_SHC.LogoutRequest()
            PrintInfo(self.text.infoClosed)

    def IsConnected(self):
        if not self.bPluginIsInitialized:
            return False
        return self.RWE_SHC.IsConnected()

    def ThreadWorker(self, stopThreadEvent):
        while not stopThreadEvent.isSet():
            if self.IsConnected():
                for SHC_Event in self.RWE_SHC.GetEvents():
                    eg.TriggerEvent(prefix=self.info.eventPrefix,
                                    suffix=SHC_Event[0],
                                    payload=SHC_Event[1])
                    # self.TriggerEvent( SHC_Event[0],payload=SHC_Event[1])
            else:
                if self.bPluginIsInitialized:
                    self.RWE_SHC.Logon(hostname=str(self.hostname),
                                       username=str(self.username),
                                       password=str(self.password),
                                       bDoEvents=self.bDoEvents,
                                       clientid=str(self.clientid)
                                       )
            stopThreadEvent.wait(THREAD_DELAY)

    def Configure(
        self,
        hostname='',
        username='',
        password='',
        bDoEvents=True,
        clientid='',
        *args
    ):

        panel = eg.ConfigPanel(self, resizable=False)

        hostnameCtrl = panel.TextCtrl(hostname)
        panel.AddLine('Host name or IP address: ', hostnameCtrl)

        usernameCtrl = panel.TextCtrl(str(username))
        panel.AddLine('User name: ', usernameCtrl)

        passwordCtrl = panel.TextCtrl(str(password))
        panel.AddLine('Password: ', passwordCtrl)

        clientid = str(clientid)
        if not IsUUID(clientid):
            clientid = str(uuid.uuid1())
        bDoEventsCtrl = panel.CheckBox(bDoEvents)
        panel.AddLine('Enable events: ', bDoEventsCtrl)

        while panel.Affirmed():
            hostname = hostnameCtrl.GetValue()
            username = usernameCtrl.GetValue()
            password = passwordCtrl.GetValue()
            bDoEvents = bDoEventsCtrl.GetValue()
            # clientid = clientidCtrl.GetValue()

            panel.SetResult(
                hostname,
                username,
                password,
                bDoEvents,
                clientid,
                *args
            )

    # Get the choice from dropdown and perform some action
    # def OnDeviceChoice(self, event):
    # choice = event.GetSelection()
    # event.Skip()
    # return choice

    def BuidNamesID(self, deviceid, type):
        try:
            names, myids, idx = self.RWE_SHC.BuidNamesID(deviceid, type)
            return names, myids, idx
        except:
            PrintError('please retry,'
                       ' configuration is currently not loaded...')
            return [deviceid], [deviceid], 0

    def GetConfigure(self, devicename='', deviceid='', type='', **kwargs):
        names, myids, idx = self.BuidNamesID(deviceid, type)
        panel = eg.ConfigPanel(self, resizable=False)
        deviceCtrl = panel.Choice(idx, names)
        panel.AddLine('Device name: ', deviceCtrl)

        while panel.Affirmed():
            if deviceCtrl.GetValue() >= 0:
                devicename = names[deviceCtrl.GetValue()]
                deviceid = myids[deviceCtrl.GetValue()]
            else:
                devicename = ''
                deviceid = ''
            panel.SetResult(devicename, deviceid)


class SwitchActuatorOn(eg.ActionClass):
    name = 'SwitchActuator on'
    description = 'Set Switch Actuator on'
    iconFile = 'RWESmartHome_on'

    def __call__(self, devicename, deviceid):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), IsOn=True)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid=''):
        self.plugin.GetConfigure(devicename, deviceid, 'SwitchActuator')


class SwitchActuatorOff(eg.ActionClass):
    name = 'SwitchActuator off'
    description = 'Set Switch Actuator off'
    iconFile = 'RWESmartHome_off'

    def __call__(self, devicename, deviceid):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), IsOn=False)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid=''):
        self.plugin.GetConfigure(devicename, deviceid, 'SwitchActuator')


class GenericActuatorOn(eg.ActionClass):
    name = 'GenericActuator on'
    description = 'Set Generic Actuator on'
    iconFile = 'RWESmartHome_on'

    def __call__(self, devicename, deviceid):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), IsOn=True)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid=''):
        self.plugin.GetConfigure(devicename, deviceid,
                                 'GenericDevice')  # GenericActuator


class GenericActuatorOff(eg.ActionClass):
    name = 'GenericActuator off'
    description = 'Set Generic Actuator off'
    iconFile = 'RWESmartHome_off'

    def __call__(self, devicename, deviceid):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), IsOn=False)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid=''):
        self.plugin.GetConfigure(devicename, deviceid,
                                 'GenericDevice')  # GenericDevice


class AlarmActuatorOn(eg.ActionClass):
    name = 'AlarmActuator on'
    description = 'Set Alarm Actuator on'
    iconFile = 'RWESmartHome_on'

    def __call__(self, devicename, deviceid):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), IsOn=True)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid=''):
        self.plugin.GetConfigure(devicename, deviceid,
                                 'AlarmActuator')


class AlarmActuatorOff(eg.ActionClass):
    name = 'AlarmActuator off'
    description = 'Set Alarm Actuator off'
    iconFile = 'RWESmartHome_off'

    def __call__(self, devicename, deviceid):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), IsOn=False)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid=''):
        self.plugin.GetConfigure(devicename, deviceid,
                                 'AlarmActuator')


class RoomTemperatureActuatorSet(eg.ActionClass):
    name = 'RoomTemperatureActuator set'
    description = 'Set Room Temperature Actuator value'
    # iconFile = 'RWESmartHome_off'

    def __call__(self, devicename, deviceid, state, mode):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), Temperature=state, Automatic=mode)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid='', state='18.0', mode=True):
        names, myids, idx = self.plugin.BuidNamesID(
            deviceid, 'RoomTemperatureActuator')
        panel = eg.ConfigPanel(self, resizable=False)
        deviceCtrl = panel.Choice(idx, names)
        panel.AddLine('Device name: ', deviceCtrl)
        stateCtrl = panel.TextCtrl(str(state))
        panel.AddLine('Temperature: ', stateCtrl)
        modeCtrl = panel.CheckBox(mode)
        panel.AddLine('Automatic mode: ', modeCtrl)

        while panel.Affirmed():
            if deviceCtrl.GetValue() > -1 and names[0] != myids[0]:
                devicename = names[deviceCtrl.GetValue()]
                deviceid = myids[deviceCtrl.GetValue()]
            state = "%.1f" % (round(float(stateCtrl.GetValue()) * 2) / 2)
            mode = modeCtrl.GetValue()
            panel.SetResult(devicename, deviceid, state, mode)


class DimmerActuatorSet(eg.ActionClass):
    name = 'DimmerActuatorState set'
    description = 'Set Dimmer Actuator value'
    # iconFile = 'RWESmartHome_off'

    def __call__(self, devicename, deviceid, state):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), DmLvl=state)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid='', state='50'):
        names, myids, idx = self.plugin.BuidNamesID(
            deviceid, 'DimmerActuator')
        panel = eg.ConfigPanel(self, resizable=False)
        deviceCtrl = panel.Choice(idx, names)
        panel.AddLine('Device name: ', deviceCtrl)
        stateCtrl = panel.SpinIntCtrl(int(state), min=0, max=100)
        panel.AddLine('Dim level: ', stateCtrl)

        while panel.Affirmed():
            if deviceCtrl.GetValue() > -1 and names[0] != myids[0]:
                devicename = names[deviceCtrl.GetValue()]
                deviceid = myids[deviceCtrl.GetValue()]
            state = int(stateCtrl.GetValue())
            panel.SetResult(devicename, deviceid, state)


class RollerShutterActuatorSet(eg.ActionClass):
    name = 'RollerShutterActuatorState set'
    description = 'Set Roller Shutter Actuator value'
    # iconFile = 'RWESmartHome_off'

    def __call__(self, devicename, deviceid, state):
        try:
            return self.plugin.RWE_SHC.SetActuatorStatesRequest(
                str(deviceid), Position=state)
        except:
            PrintError('currentlly not initialized')

    def Configure(self, devicename='', deviceid='', state='50'):
        names, myids, idx = self.plugin.BuidNamesID(
            deviceid, 'RollerShutterActuator')
        panel = eg.ConfigPanel(self, resizable=False)
        deviceCtrl = panel.Choice(idx, names)
        panel.AddLine('Device name: ', deviceCtrl)
        stateCtrl = panel.SpinIntCtrl(int(state), min=0, max=100)
        panel.AddLine('Position: ', stateCtrl)

        while panel.Affirmed():
            if deviceCtrl.GetValue() > -1 and names[0] != myids[0]:
                devicename = names[deviceCtrl.GetValue()]
                deviceid = myids[deviceCtrl.GetValue()]
            state = int(stateCtrl.GetValue())
            panel.SetResult(devicename, deviceid, state)


class MultipleCollect(eg.ActionClass):
    name = 'MultipleCollect'
    description = 'Start collecting commands'
    # iconFile = 'RWESmartHome_off'

    def __call__(self):
        try:
            return self.plugin.RWE_SHC.MultipleCollect()
        except:
            PrintError('currentlly not initialized')

    def Configure(self):
        panel = eg.ConfigPanel(self, resizable=False)
        while panel.Affirmed():
            panel.SetResult()


class MultipleClear(eg.ActionClass):
    name = 'MultipleClear'
    description = 'Abbort collecting commands'
    iconFile = 'RWESmartHome_off'

    def __call__(self):
        try:
            return self.plugin.RWE_SHC.MultipleClear()
        except:
            PrintError('currentlly not initialized')

    def Configure(self):
        panel = eg.ConfigPanel(self, resizable=False)
        while panel.Affirmed():
            panel.SetResult()


class MultipleCommit(eg.ActionClass):
    name = 'MultipleCommit'
    description = 'Commit collected commands'
    iconFile = 'RWESmartHome_on'

    def __call__(self):
        try:
            return self.plugin.RWE_SHC.MultipleCommit()
        except:
            PrintError('currentlly not initialized')

    def Configure(self):
        panel = eg.ConfigPanel(self, resizable=False)
        while panel.Affirmed():
            panel.SetResult()


class RestartRequest(eg.ActionClass):
    name = 'SmartHomeCenter RestartRequest'
    description = 'SmartHomeCenter restart request'
    iconFile = 'RWESmartHome_on'

    def __call__(self):
        try:
            return self.plugin.RWE_SHC.SHCRestartRequest()
        except:
            PrintError('currentlly not initialized')

    def Configure(self):
        panel = eg.ConfigPanel(self, resizable=False)
        while panel.Affirmed():
            panel.SetResult()
