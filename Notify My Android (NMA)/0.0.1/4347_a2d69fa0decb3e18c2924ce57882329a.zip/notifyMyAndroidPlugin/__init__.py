import eg
import httplib
import os

eg.RegisterPlugin()
eg.RegisterPlugin(
    name = "notify my android",
    author = "Community",
    version = "0.0.1",
    kind = "other",
    description = "Notify My android plugin for eventghost."
)

class MyNewPlugin(eg.PluginBase):

    def __init__(self):
        self.AddAction(HelloWorld)
    #actie als de plugin start
    def __start__(self, myString):
        print "MyNewPlugin is started with parameter: " + myString
    #actie als de plugin stopt
    def __stop__(self):
        print "MyNewPlugin is stopped."
	#actie als de plugin word afgesloten
    def __close__(self):
        print "MyNewPlugin is closed."
	#dit stukje niet aanpassen
    def Configure(self, myString=""):
        panel = eg.ConfigPanel()

        api = panel.TextCtrl()
        url = panel.TextCtrl()
        programTitle = panel.TextCtrl()
		
        panel.AddLine("Server URL", url)
        panel.AddLine("Api key", api)
        panel.AddLine("Program Title", programTitle)
        while panel.Affirmed():
            panel.SetResult(
			    api.GetValue()
			)	

class HelloWorld(eg.ActionBase):

    def __call__(self):
        print "Hello World!"
        httpServ = httplib.HTTPConnection("nma.usk.bz", 80)
        httpServ.connect()
        httpServ.request('GET', "/publicapi/notify?apikey=EXAMPLE API KEY WITCH DOES NOT WORK&application=Eventghost&event=HELLOWORLD&description")

        response = httpServ.getresponse()
        if response.status == httplib.OK:
            print "Messege send succesfully"
  
        httpServ.close()
    def Configure(self, myString=""):
        panel = eg.ConfigPanel()
        textControl = wx.TextCtrl(panel, -1, myString)
        panel.sizer.Add(textControl, 1, wx.EXPAND)
        while panel.Affirmed():
            panel.SetResult(textControl.GetValue())