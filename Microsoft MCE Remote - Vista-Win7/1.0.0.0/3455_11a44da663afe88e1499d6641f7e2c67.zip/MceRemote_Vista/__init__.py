#
# plugins/MceRemote/__init__.py
#
# Copyright (C) 2005 Lars-Peter Voss
#
# This file is part of EventGhost.
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#
# $LastChangedDate: 2009-04-23 18:49:25 +0200 (Thu, 23 Apr 2009) $
# $LastChangedRevision: 911 $
# $LastChangedBy: Bitmonster $

import eg
import time

eg.RegisterPlugin(
    name = "Microsoft MCE Remote - Vista/Win7",
    author = "Brett Stottlemyer",
    version = "1.0.0.0",
    kind = "remote",
    description = 'Plugin for the Microsoft MCE remote.  Requires installation of AlternateMceIrService.',
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACfklEQVR42q2TS2gTQRyH"
        "f5N9NNlts20abYyxVirWShGLUh8XoSpUUBEVUU+5CXoQr+LNm14UtRCpRcGLHnqoiooN"
        "VO1FRWrTaKgmqdJqGuwj3TTZ947bbLV37cAMM8zMx39+fEPwn42sGKD7zk3aeWg3TEut"
        "rC3bdrpZmZuWBlVXYFgGKKEQOAHDg+M4f/YCqQBuxa7T7XtaEWloRkkrwDQt6KZzwdZR"
        "VGSU1DmoRgm6pUBWC1DUMoK1q2BmQ24F77/G6ZfvI2isb0FRnYVYZtAe8aCUkzGSyuCj"
        "tADFLsEwNOi0CM1QYDnVrNcOuICHQzfoWCaJoD8MWZnGfoPB1k0BpN/k8DKbxvAGE1JA"
        "QHidF9lMHvnChPMuii3sCRdwre8czUykwDAMuLKKU1oV2CCL7Itx9LMycmtqsa2jAY1N"
        "EgaepWBxc2A5Dq30mAu40neGpr59AKUUliHB5z8KUwxi5vUDWCQNW2TRvrOpknkykYRQ"
        "7wXr4bFRO+ICrj6J0tHcq0ris3MHwbdcgiaX8XMohl2B+xAF4jyhBsqCgqQTsOhnwXNe"
        "NM4fdgG3By7S4amnoBaHT4m9gP84ivkUquf7cTL8Fh1tPjSv9eHxqIw48YL3MfBWiQj/"
        "6nIBzxN3afxHDJYTzLvBOvBMGfMFPyLcZ3QFCtixWcCiET1pFVpIAiE2aqrrEM4vAZIT"
        "Q/RR6jKo1zmgOrLYtAIzphSEZ2cQ8gGTio0E5SGFa6BrBiJSKxqm97mAWE83VUJjSEzG"
        "nXT5v34ugkqKDkPW4OEZCCIH4iEg1IPOttPQ0quXVe6910vh6EuX/F5U1hmWZV/a+LP0"
        "EBbRaJSs3Gf61/YbN1kg0OJlna4AAAAASUVORK5CYII="
    ),
)

import wx
from threading import Timer
import win32file
import win32pipe
import win32api
import win32event
from struct import unpack_from

class MceMessageReceiver(eg.ThreadWorker):
    """
    A thread with a hidden window to receive win32 messages from the driver
    """
    def Setup(self, plugin, waitTime):
        """
        This will be called inside the thread at the beginning.
        """
        self.plugin = plugin
        self.file = None
        self.keepRunning = True
          
    @eg.LogIt
    def Finish(self):
        """
        This will be called inside the thread when it finishes. It will even
        be called if the thread exits through an exception.
        """
        self.keepRunning = False
        eg.PrintNotice("MCE_Vista: keepRunning set to False")
        if self.file:
            win32file.CloseHandle(self.file)

    def Connect(self):
        eg.PrintNotice("MCE_Vista: Connect started")
        self.sentMessageOnce = False
        while self.file is None and self.keepRunning:
            try:
                self.file = win32file.CreateFile(r'\\.\pipe\MceIr',win32file.GENERIC_READ
                                        |win32file.GENERIC_WRITE,0,None,
                                        win32file.OPEN_EXISTING,win32file.FILE_ATTRIBUTE_NORMAL
                                        |win32file.FILE_FLAG_OVERLAPPED,None)
            except:
                if not self.sentMessageOnce:
                    eg.PrintNotice("MCE_Vista: MceIr pipe is not available, app doesn't seem to be running")
                    eg.PrintNotice("    Will continue to try to connect to MceIr")
                    eg.PrintNotice("    Message = %s"%win32api.FormatMessage(win32api.GetLastError()))
                    self.sentMessageOnce = True
                time.sleep(.25)
        return

    def HandleData(self):
        if self.sentMessageOnce:
            eg.PrintNotice("MCE_Vista: Connected to MceIr pipe, started handling IR events")
        nMax = 2048;
        self.result = []
        self.readOvlap = win32file.OVERLAPPED()
        self.readOvlap.hEvent = win32event.CreateEvent(None, 0, 0, None)
        handles = [self.plugin.hFinishedEvent,self.readOvlap.hEvent]
        while self.keepRunning:
            try:
                (hr,data) = win32file.ReadFile(self.file,nMax,self.readOvlap)
            except:
                win32file.CloseHandle(self.file)
                self.file = None
                return
            rc = win32event.WaitForMultipleObjects(handles, False, win32event.INFINITE)
            if rc == win32event.WAIT_OBJECT_0: #Finished event
                self.keepRunning = False
                win32file.CloseHandle(self.file)
                self.file = None
                break
            try:
                nGot = self.readOvlap.InternalHigh
                vals = unpack_from((nGot/4)*"i",data)
                #eg.PrintNotice("vals = %s"%str(vals))
                for v in vals:
                    a = abs(v)
                    self.result.append(a)                   
                    if a > 6500: #button held?
                        #eg.PrintNotice("Sending ir code %s"%str(self.result))
                        self.plugin.irDecoder.Decode(self.result, len(self.result))
                        self.result = []
            except:
                pass
        eg.PrintNotice("MCE_Vista: Handle Data finished")
                
    def Run(self):
        eg.PrintNotice("MCE_Vista: Run started")
        while self.keepRunning:
            self.Connect()
            if self.keepRunning:
                self.HandleData()
                
class MCE_Vista(eg.IrDecoderPlugin):
    
    def __init__(self):
        eg.IrDecoderPlugin.__init__(self,1.0)
        
    def __close__(self):
        self.irDecoder.Close()          
        
    @eg.LogIt
    def __start__(self, waitTime=0.15):
        self.hFinishedEvent = win32event.CreateEvent(None, 0, 0, None)
        try:
            self.remoteList = self.irDecoder.SetKeyMappingFromFile(self.__class__.__name__)
        except:
            pass
        self.msgThread = MceMessageReceiver(self, waitTime)
        self.msgThread.Start()
        self.msgThread.Call(self.msgThread.Run)
              
    def __stop__(self):
        eg.PrintNotice("MCE_Vista: Stopping Mce Vista plugin")
        win32event.SetEvent(self.hFinishedEvent)
        self.msgThread.keepRunning = False
        self.msgThread.Stop()