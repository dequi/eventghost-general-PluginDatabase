# This file is part of EventGhost.
# Copyright (C) 2005 Lars-Peter Voss <bitmonster@eventghost.org>
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#
# $LastChangedDate: 2010-01-07 23:37:23 -0500 (Th, 07 Jan 2010) $
# $LastChangedRevision: 1000 $
# $LastChangedBy: Rovaals $

import eg

eg.RegisterPlugin(
    name = "Remote Touch DS (Buttons)",
    description = "Receives events from Remote Touch DS.",
    version = "1.0." + "$LastChangedRevision: 1000 $".split()[1],
    author = "Network Receiver by Bitmonster. Modified for RTDS by Rovaals.",
    canMultiLoad = False,
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QAAAAAAAD5Q7t/"
        "AAAACXBIWXMAAAsSAAALEgHS3X78AAAAB3RJTUUH1gIQFgQb1MiCRwAAAVVJREFUOMud"
        "kjFLw2AQhp8vif0fUlPoIgVx6+AgopNI3fwBViiIoOAgFaugIDhUtP4BxWDs4CI4d3MR"
        "cSyIQ1tDbcHWtjFI4tAWG5pE8ca7997vnrtP4BOZvW0dSBAcZ0pAMTEzPUs4GvMsVkvP"
        "6HktGWRAOBpjIXVNKOSWWdYXN7lFAAINhBCEQgqxyTHAAQQAD/dFbLurUYJYT7P7TI2C"
        "VavwIiZodyyaH6ZLo/RZVTXiOYVhGOh5jcpbq5eRAXAc5wdBVSPMLR16GtxdbgJgN95d"
        "OxicACG6bPH4uIu1UHjE7sFqR/NDVxhaoixLvFYbtDufNFtu1tzxgdeAaZfBU7ECTvd1"
        "WRlxsa4sp1ydkiRxkstmlEFRrWT4nrRer3vmlf6mb883fK8AoF1d+Bqc6Xkt+cufT6e3"
        "dnb9DJJrq+uYpunZ2WcFfA0ol8v8N5Qgvr/EN8Lzfbs+L0goAAAAAElFTkSuQmCC"
    ),
)

import wx
import asynchat
import asyncore
import random
import socket


class Text:
    port = "TCP/IP Port:"
    eventPrefix = "Event Prefix:"
    tcpBox = "TCP/IP Settings"
    eventGenerationBox = "Event generation"
    
    
DEBUG = False
if DEBUG:
    log = eg.Print
else:
    def log(dummyMesg):
        pass
    

class ServerHandler(asynchat.async_chat):
    """Telnet engine class. Implements command line user interface."""
    
    def __init__(self, sock, addr, plugin, server):
        log("Server Handler inited")
        self.plugin = plugin
        
        # Call constructor of the parent class
        asynchat.async_chat.__init__(self, sock)

        # Set up input line terminator
        self.set_terminator('\x00')

        # Initialize input data buffer
        self.data = ''
        self.ip = addr[0]
        self.payload = [self.ip]
	self.rtds_mapping = {
            'ADOWN000G': 'A_Touch', 'RETURNDNK': 'A_Media',
            'BDOWN000G': 'B_Touch', 'BACK0000K': 'B_Media',
	    'YDOWN000G': 'Y_Touch',
            'XDOWN000G': 'X_Touch',
            'LEFTDOWNG': 'Left_Touch', 'LEFT0000K': 'Left_Media',
            'RGHTDOWNG': 'Right_Touch', 'RIGHT000K': 'Right_Media',
            'UPDOWN00G': 'Up_Touch', 'UPDOWN00K': 'Up_Media',
            'DOWNDOWNG': 'Down_Touch', 'DOWNDOWNK': 'Down_Media',
            'LDOWN000G': 'L_Touch',
            'RDOWN000G': 'R_Touch',
            'PLAYPAUSK': 'Play/Pause', 'STOP0000K': 'Stop', 'PREV0000K': 'Previous', 'NEXT0000K': 'Next',
            'VOLDOWN0K': 'Volume_Down', 'VOLUP000K': 'Volume_Up', 'VOLMUTE0K': 'Volume_Mute',
            'RESTART0S': 'Restart', 'SHUTDOWNS': 'Shutdown',
            'SPACE000K': 'Space',
            'A0000000K': 'A', 'B0000000K': 'B', 'C0000000K': 'C', 'D0000000K': 'D', 'E0000000K': 'E', 
            'F0000000K': 'F', 'G0000000K': 'G', 'H0000000K': 'H', 'I0000000K': 'I', 'J0000000K': 'J', 
            'K0000000K': 'K', 'L0000000K': 'L', 'M0000000K': 'M', 'N0000000K': 'N', 'O0000000K': 'O', 
            'P0000000K': 'P', 'Q0000000K': 'Q', 'R0000000K': 'R', 'S0000000K': 'S', 'T0000000K': 'T', 
            'U0000000K': 'U', 'V0000000K': 'V', 'W0000000K': 'W', 'X0000000K': 'X', 'Y0000000K': 'Y', 
            'Z0000000K': 'Z',
            '10000000K': '1', '20000000K': '2', '30000000K': '3', '40000000K': '4', '50000000K': '5', 
            '60000000K': '6', '70000000K': '7', '80000000K': '8', '90000000K': '9', '00000000K': '0', 
            '-0000000K': 'Minus', '/0000000K': 'Slash', ':0000000K': 'Colon', ';0000000K': 'Semicolon', '(0000000K': 'Left_Bracket', 
            ')0000000K': 'Right_Bracket', '$0000000K': 'Dollar', '&0000000K': 'And', '@0000000K': 'At', '"0000000K': 'Quote', 
            '.0000000K': 'Period', ',0000000K': 'Comma', '?0000000K': 'Question', '!0000000K': 'Exclamation', "'0000000K": 'Apostraphe'
 
        }
                
    def handle_close(self):
        self.plugin.EndLastEvent()
        asynchat.async_chat.handle_close(self)
    
    
    def collect_incoming_data(self, data):
        """Put data read from socket to a buffer
        """
        # Collect data in input buffer
        log("<<" + repr(data))
        self.data = self.data + data


    if DEBUG:
        def push(self, data):
            log(">>", repr(data))
            asynchat.async_chat.push(self, data)
    
    
    def found_terminator(self):
        """
        This method is called by asynchronous engine when it finds
        command terminator in the input stream
        """   
        # Take the complete line
        line = self.data

        # Reset input buffer
        self.data = ''
	try:
            line = self.rtds_mapping[line]
        except:
            line = "invalid"

	if line != "invalid":
            self.plugin.TriggerEvent(line)

class Server(asyncore.dispatcher):
    
    def __init__ (self, port, handler):
        self.handler = handler

        # Call parent class constructor explicitly
        asyncore.dispatcher.__init__(self)
        
        # Create socket of requested type
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # restart the asyncore loop, so it notices the new socket
        eg.RestartAsyncore()

        # Set it to re-use address
        #self.set_reuse_addr()
        
        # Bind to all interfaces of this host at specified port
        self.bind(('', port))

        # Start listening for incoming requests
        #self.listen (1024)
        self.listen(5)


    def handle_accept (self):
        """Called by asyncore engine when new connection arrives"""
        # Accept new connection
        log("handle_accept")
        (sock, addr) = self.accept()
        ServerHandler(
            sock, 
            addr, 
            self.handler, 
            self
        )



class RTDS(eg.PluginBase):
    text = Text
    
    def __init__(self):
        self.AddEvents()
    
    def __start__(self, port, prefix):
        self.port = port
        self.info.eventPrefix = prefix
        try:
            self.server = Server(self.port, self)
        except socket.error, exc:
            raise self.Exception(exc[1])
        
        
    def __stop__(self):
        if self.server:
            self.server.close()
        self.server = None


    def Configure(self, port=7777, prefix="RTDS"):
        text = self.text
        panel = eg.ConfigPanel()
        
        portCtrl = panel.SpinIntCtrl(port, max=65535)
        eventPrefixCtrl = panel.TextCtrl(prefix)
        st1 = panel.StaticText(text.port)
        st2 = panel.StaticText(text.eventPrefix)
        eg.EqualizeWidths((st1, st2))
        box1 = panel.BoxedGroup(text.tcpBox, (st1, portCtrl))
        box2 = panel.BoxedGroup(
            text.eventGenerationBox, (st2, eventPrefixCtrl)
        )
        panel.sizer.AddMany([
            (box1, 0, wx.EXPAND),
            (box2, 0, wx.EXPAND|wx.TOP, 10),
        ])
        
        while panel.Affirmed():
            panel.SetResult(
                portCtrl.GetValue(), 
                eventPrefixCtrl.GetValue()
            )

