import eg
import time
from threading import Thread
from SimpleXMLRPCServer import SimpleXMLRPCServer
from xmlrpclib import ServerProxy

eg.RegisterPlugin(
    name = "HomeMatic",
    author = "Topfi",
    version = "0.0.1",
    kind = "remote",
    description = "Interact with Homematic home automation system."
)

global HMP

class HomeMatic(eg.PluginBase):
    
    radioSrv   = None
    server     = None
    srvThread  = None
    pingThread = None
    
    def __start__(self, aliveTimeoutInS="60", hmAddr="homematic-ccu2", srvAddr="", srvPort="8000"):
        
        hmPort = 2001
        
        global HMP
        HMP = self 
        print "Timeout in s  :", str(aliveTimeoutInS)
        print "HM address    :", str(hmAddr)+":"+str(hmPort)
        print "Server address:", str(srvAddr)+":"+str(srvPort)

        self.aliveTimeoutInS=int(aliveTimeoutInS)
        self.hmAddr  = hmAddr
        self.hmPort  = int(hmPort)
        self.srvAddr = srvAddr
        self.srvPort = int(srvPort)
        
        self.waitForPong = 0
 
 
        if self.srvAddr != "":       
            self.server = SimpleXMLRPCServer(("0.0.0.0", self.srvPort), logRequests=False)
            self.server.register_introspection_functions()
            self.server.register_instance(HomeFunctions())
            self.server.register_multicall_functions()
    
            self.srvThread = Thread(
                target=self.SrvThreadLoop
            )
            self.srvThread.start()
            
            if self.radioSrv is None: 
                self.radioSrv = ServerProxy('http://'+self.hmAddr+':'+str(self.hmPort))
            self.connectRadioSrv()
    
            self.running = True
            self.pingThread = Thread(
                target=self.PingThreadLoop
            )
            self.pingThread.start()

    def connectRadioSrv(self):
        if self.radioSrv is not None:
            print "Initializing radio modules"
            try:
                self.radioSrv.init('http://'+self.srvAddr+':'+str(self.srvPort),'RD')
            except Exception as ex:
                print "Init raised exception:", ex
            print "Initializing radio modules ... completed"
        else:
            print "connectRadioSrv: radioSrv not started"

    def disconnectRadioSrv(self):
        if self.radioSrv is not None:
            print "Stopping radio modules"
            try:
                self.radioSrv.init('http://'+self.srvAddr+':'+str(self.srvPort),'')
            except Exception as ex:
                print "Init raised exception:", ex
            print "Stopping radio modules ... completed"
        else:
            print "disconnectRadioSrv: radioSrv not started"

    def __stop__(self):

        self.disconnectRadioSrv()
        
        if self.server is not None:
            self.server.shutdown()
            
        if self.srvThread is not None:
            self.srvThread.join()
            print "Server thread joined!"
        
        self.running = False
        
        if self.pingThread is not None:
            self.pingThread.join()
            print "Ping thread joined!"
        
        self.waitForPong = 0
        

    def SrvThreadLoop(self):
        print "Server thread started!"
        self.server.serve_forever()
        print "Server thread stopped!"

    def PingThreadLoop(self):
        print "Ping thread started!"
        i=self.aliveTimeoutInS
        self.waitForPong = 0
        while self.running:
            if i >= self.aliveTimeoutInS:
                self.waitForPong = 10 # Antwort muss in spaetestens 10 Sekunden da sein 
                #print "Ping sent!"
                try:
                    self.radioSrv.ping('HMPTEST')
                    i = 1
                except:
                    print "Ping could not be sent!"
            else:
                i = i + 1
            time.sleep(1)    
            
            if self.waitForPong > 0:
                print "Waiting for Pong.", self.waitForPong
                self.waitForPong = self.waitForPong -1
                if self.waitForPong == 0:
                    i = 1
                    print "No Pong received! Try to establish new connection!"
                    self.disconnectRadioSrv()
                    self.connectRadioSrv()
            
        print "Ping thread stopped!"
            

    def Configure(self, aliveTimeoutInS="60", hmAddr="homematic-ccu2", srvAddr="", srvPort="8000"):
        print "Configure (1)"
        print str(aliveTimeoutInS)
        print str(hmAddr)
        print str(srvAddr)+":"+str(srvPort)
        panel = eg.ConfigPanel()
        txt1 = wx.StaticText(panel, label="\nPing Timeout [s]:")
        panel.sizer.Add(txt1, 1, wx.EXPAND)
        aliveTimeoutInSCtrl = wx.TextCtrl(panel, -1, aliveTimeoutInS)
        panel.sizer.Add(aliveTimeoutInSCtrl, 1, wx.EXPAND)
        txt2 = wx.StaticText(panel, label="\nHomeMatic address:")
        panel.sizer.Add(txt2, 1, wx.EXPAND)
        hmAddrCtrl = wx.TextCtrl(panel, -1, hmAddr)
        panel.sizer.Add(hmAddrCtrl, 1, wx.EXPAND)
        txt3 = wx.StaticText(panel, label="\nXML RPC Server address (this PC):")
        panel.sizer.Add(txt3, 1, wx.EXPAND)
        srvAddrCtrl = wx.TextCtrl(panel, -1, srvAddr)
        panel.sizer.Add(srvAddrCtrl, 1, wx.EXPAND)
        txt4 = wx.StaticText(panel, label="\nXML RPC Server port:")
        panel.sizer.Add(txt4, 1, wx.EXPAND)
        srvPortCtrl = wx.TextCtrl(panel, -1, srvPort)
        panel.sizer.Add(srvPortCtrl, 1, wx.EXPAND)
        while panel.Affirmed():
                print "Configure (2)"
                print str(aliveTimeoutInS)
                print str(hmAddr)
                print str(srvAddr)+":"+str(srvPort)
                panel.SetResult(aliveTimeoutInSCtrl.GetValue(), hmAddrCtrl.GetValue(), srvAddrCtrl.GetValue(), srvPortCtrl.GetValue() )

    def pongReceived(self):
        #print "Pong received!"
        self.waitForPong = 0


class HomeFunctions:
    def event(self, *args):
        global HMP
        txt=""
        dot=''
        for arg in args:
            txt=txt+dot+str(arg)
            if not dot:
                dot='.'
        if arg and str(arg) == "HMPTEST":
            HMP.pongReceived()
        else:
            HMP.TriggerEvent(txt)
        return ''
