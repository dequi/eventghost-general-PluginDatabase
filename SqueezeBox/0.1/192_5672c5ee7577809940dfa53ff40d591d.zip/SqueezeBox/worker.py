﻿# -*- coding: utf-8 -*-

# Changelog (in reverse chronological order):
# -------------------------------------------
# 0.1 (17.02.2012)  first released version


import telnetlib
import socket
import time

from threading import *

class WorkerThread(Thread):
    def __init__(self, parent, host="localhost", port=9090, notifications="mixer,playlist,play,stop,pause,jump"):
        Thread.__init__(self)
        self.parent      = parent
        self.host        = host
        self.port        = port
        self.keep_alive  = True
        self.isconnected = False
        self.squeezebox  = None
        #self.host        = host
        #self.port        = port

    def run(self):
        while self.keep_alive:
            if self.isconnected:
                self.get_events()
            #time.sleep( 0.5 )

    def abort(self):
        self.keep_alive = False

    def connect(self):
        if not self.isconnected:
            try:
                self.squeezebox = telnetlib.Telnet(self.host, self.port, 5)
            except socket.error, e:
                self.disconnect(repr(e))
            else:
                self.isconnected = True

    def disconnect(self, err=False):
        if self.isconnected:
            self.isconnected = False
            time.sleep( 1 )
            self.squeezebox.close()
            if err: self.parent.TriggerEvent('ERROR', err)

    def isConnected(self):
        return self.isconnected

    def get_events(self):
        if not self.isconnected: return
        try:
            rc = self.squeezebox.read_until('\n',3).strip('\r\n')
        except socket.error, e:
            self.disconnect(repr(e))
        else:
            if rc:
                event = (rc.replace('%3A',':')).split(' ')
                evt = event[1].title()
                if evt == "Pause":
                    if event[2] == "1": evt = "Paused"
                    elif event[2] == "0": evt = "Unpaused"
                    else: evt = ""
                if evt == "Mixer":
                    if event[2] == "muting":
                        if event[3] == "1": evt = "Muted"
                        elif event[3] == "0": evt = "Unmuted"
                if evt == "Power":
                    if event[2] == "1": evt = "Power_On"
                    elif event[2] == "0": evt = "Power_Off"
                if evt == "0" or evt == "1":
                    evt = event[0].title()
                    
                self.parent.TriggerEvent(evt,event)

    def TurnNotificationsOn(self):
        if not self.isConnected():
            self.connect()
        self.Notify("1") #  "mixer,playlist,play,stop,pause,jump"
        
    def TurnNotificationsOff(self):
        if self.isConnected():
            self.Notify("0")
            self.disconnect()
        
    def Notify(self, notify):
        if self.isconnected:
            self.squeezebox.write("listen "+notify+"\n")
            #self.squeezebox.write("subscribe "+notify+"\n")
