﻿# -*- coding: utf-8 -*-

# This file is a plugin for EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# Changelog (in reverse chronological order):
# -------------------------------------------
# 0.1 (17.02.2012)  first released version


import eg
from pysqueezecenter.server import Server
from pysqueezecenter.player import Player
from worker import WorkerThread

import logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
'''
CRITICAL = 50
FATAL = CRITICAL
ERROR = 40
WARNING = 30
WARN = WARNING
INFO = 20
DEBUG = 10
NOTSET = 0
'''

eg.RegisterPlugin(
    name = "SqueezeBox",
    author = "topix",
    version = "0.1",
    kind = "program",
    description = ('Control your SqueezeCenter/SqueezeBoxes with EventGhost.'),
    guid = "{A80E3CC3-9A1E-4476-9C28-7343C9D5F09A}"
)

class SqueezeBox(eg.PluginClass):
    
    def __init__(self):
        self.server = None
        self.player = None
        self.worker = None
        self.notify = False
        self.playernames = []
        self.AddAction(SetPlayer)
        self.AddAction(TurnNotificationsOn)
        self.AddAction(TurnNotificationsOff)
        self.AddAction(Play)
        self.AddAction(Pause)
        self.AddAction(BassDown)
        self.AddAction(BassUp)
        self.AddAction(SetBass)
        self.AddAction(DisplayText)
        #self.AddAction(ShowText)  # EG hängt bei Benutzung
        self.AddAction(Forward)
        self.AddAction(Rewind)
        self.AddAction(ToggleMute)
        self.AddAction(Mute)
        self.AddAction(Unmute)
        self.AddAction(PlayPause)
        self.AddAction(Stop)
        self.AddAction(VolumeUp)
        self.AddAction(VolumeDown)
        self.AddAction(Next)
        self.AddAction(Prev)
        self.AddAction(Random)
        self.AddAction(Unpause)
        self.AddAction(SetVolume)
        self.AddAction(GetMuting)
        self.AddAction(GetBass)
        self.AddAction(GetMode)
        self.AddAction(GetPowerState)
        self.AddAction(GetVolume)
        self.AddAction(GetTrackAlbum)
        self.AddAction(GetTrackArtist)
        self.AddAction(GetTrackCurrentTitle)
        self.AddAction(GetTrackTitle)
        self.AddAction(GetTrackDuration)
        self.AddAction(GetTrackGenre)
        self.AddAction(GetTrackPath)
        self.AddAction(GetTrackRemote)
        self.AddAction(SetPowerState)
        
    def __start__(self, hostname, port, username, password):
        self.hostname = hostname
        self.port     = port
        self.username = username
        self.password = password
        self.ConnectServer()
        self.worker = WorkerThread(self, self.hostname, self.port)
        self.worker.start()
        if self.notify: self.worker.TurnNotificationsOn()
        
    def __stop__(self):
        self.StopWorker()
    
    def __close__(self):
        self.StopWorker()

    def StopWorker(self):
        if self.worker.isAlive():
            self.worker.abort()

    def Configure(self, hostname="localhost", port=9090, username="", password=""):
        panel = eg.ConfigPanel()
        #ntypes=["Hinweis","Alarm"]
        #lst_ntypes  = wx.gizmos.EditableListBox(panel, -1) #style=wx.EL_ALLOW_NEW|wx.EL_ALLOW_EDIT|wx.EL_ALLOW_DELETE)
        #lst_ntypes.SetStrings(ntypes)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Host")
        host = wx.TextCtrl(panel, -1, hostname)
        panel.AddLine(txt, host)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Port")
        port = wx.SpinCtrl(panel, -1, min=0, max=65535, initial=port)
        panel.AddLine(txt, port)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Username")
        user = wx.TextCtrl(panel, -1, username)
        panel.AddLine(txt, user)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Password")
        pwd = wx.TextCtrl(panel, -1, password, style=wx.TE_PASSWORD)
        panel.AddLine(txt, pwd)
        
        while panel.Affirmed():
            panel.SetResult(
                host.GetValue(),
                port.GetValue(),
                user.GetValue(),
                pwd.GetValue()
            )
    
    def ConnectServer(self):
        self.server = Server(self.hostname)
        self.server.connect(update=True)
        self.playernames = [i.name for i in self.server.players]

class SetPlayer(eg.ActionClass):
    name = "Set Player"
    description = "Set the Player you want to control."
    def __call__(self, player):
        self.plugin.player = self.plugin.server.get_player(player)
        
    def Configure(self, player=None):
        panel = eg.ConfigPanel()
        ctrl = wx.Choice(panel, -1, choices=self.plugin.playernames)
        ctrl.SetStringSelection(player)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Password")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetStringSelection() )
        
class Play(eg.ActionClass):
    name = "Play"
    description = "Put the current selected SqueezeBox into play mode."

    def __call__(self):
        if self.plugin.player: self.plugin.player.play()

class Pause(eg.ActionClass):
    name = "Pause"
    description = "Put the current selected SqueezeBox into pause mode."

    def __call__(self):
        if self.plugin.player: self.plugin.player.pause()

class BassDown(eg.ActionClass):
    name = "Bass Down"
    description = "Decrease Player Bass."

    def __call__(self, amount):
        if self.plugin.player: self.plugin.player.bass_down(amount)
        
    def Configure(self, amount=5):
        panel = eg.ConfigPanel()
        ctrl = wx.SpinCtrl(panel, -1, min=1, max=100, initial=amount)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Amount to change bass level")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetValue() )

class BassUp(eg.ActionClass):
    name = "Bass Up"
    description = "Increase Player Bass."

    def __call__(self, amount):
        if self.plugin.player: self.plugin.player.bass_up(amount)
        
    def Configure(self, amount=5):
        panel = eg.ConfigPanel()
        ctrl = wx.SpinCtrl(panel, -1, min=1, max=100, initial=amount)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Amount to change bass level")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetValue() )

class SetBass(eg.ActionClass):
    name = "Set Bass"
    description = "Set Player Bass Level (min -100, max 100)."

    def __call__(self, bass):
        if self.plugin.player: self.plugin.player.set_bass(bass)

    def Configure(self, bass=0):
        panel = eg.ConfigPanel()
        ctrl = wx.SpinCtrl(panel, -1, min=-100, max=100, initial=bass)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Set bass level to")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetValue() )

class DisplayText(eg.ActionClass):
    name = "Display Text"
    description = "Display some text."

    def __call__(self, line1, line2, duration):
        if self.plugin.player: self.plugin.player.display(line1, line2, duration)

    def Configure(self, line1='', line2='', duration=3):
        panel = eg.ConfigPanel()
        txt_l1 = wx.TextCtrl(panel, -1, value=line1)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Line 1")
        panel.AddLine(txt, txt_l1)
        txt_l2 = wx.TextCtrl(panel, -1, value=line2)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Line 2")
        panel.AddLine(txt, txt_l2)
        ctrl = wx.SpinCtrl(panel, -1, min=1, max=30, initial=duration)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Duration (seconds)")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( txt_l1.GetValue(), txt_l2.GetValue(), ctrl.GetValue() )
        
class ShowText(eg.ActionClass):
    name = "Show Text"
    description = "Display some text."

    def __call__(self, line1, line2, duration, brightness, font, centered):
        if self.plugin.player: self.plugin.player.show(line1, line2, duration, brightness, font, centered)

    def Configure(self, line1='', line2='', duration=3, brightness=4, font='standard', centered=False):
        panel = eg.ConfigPanel()
        txt_l1 = wx.TextCtrl(panel, -1, value=line1)
        txt = wx.StaticText(panel,wx.ID_ANY,"Line 1")
        panel.AddLine(txt, txt_l1)
        txt_l2 = wx.TextCtrl(panel, -1, value=line2)
        txt = wx.StaticText(panel,wx.ID_ANY,"Line 2")
        panel.AddLine(txt, txt_l2)
        ctrl1 = wx.SpinCtrl(panel, -1, min=1, max=30, initial=duration)
        txt = wx.StaticText(panel,wx.ID_ANY,"Duration (seconds)")
        panel.AddLine(txt, ctrl1)
        ctrl2 = wx.SpinCtrl(panel, -1, min=1, max=100, initial=brightness)
        txt = wx.StaticText(panel,wx.ID_ANY,"Brightness")
        panel.AddLine(txt, ctrl2)
        fnt = wx.Choice(panel, -1, choices=["standard"])
        fnt.SetStringSelection(font)
        txt = wx.StaticText(panel,wx.ID_ANY,"Font")
        panel.AddLine(txt, fnt)
        cntr = wx.CheckBox(panel, -1, "Centered: ", style=wx.ALIGN_RIGHT)
        cntr.SetValue(centered)
        txt = wx.StaticText(panel,wx.ID_ANY,"Centered")
        panel.AddLine(txt, cntr)
        while panel.Affirmed():
            panel.SetResult( txt_l1.GetValue(),
                             txt_l2.GetValue(),
                             ctrl1.GetValue(),
                             ctrl2.GetValue(),
                             fnt.GetStringSelection(),
                             cntr.GetValue()
                            )

class Forward(eg.ActionClass):
    name = "Forward"
    description = ""

    def __call__(self, seconds):
        if self.plugin.player: self.plugin.player.forward(seconds)

    def Configure(self, seconds=10):
        panel = eg.ConfigPanel()
        ctrl = wx.SpinCtrl(panel, -1, min=0, initial=seconds)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Seconds")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetValue() )

class Rewind(eg.ActionClass):
    name = "Rewind"
    description = "Seek Player Backwards."

    def __call__(self, seconds):
        if self.plugin.player: self.plugin.player.rewind(seconds)
    
    def Configure(self, seconds=10):
        panel = eg.ConfigPanel()
        ctrl = wx.SpinCtrl(panel, -1, min=0, initial=seconds)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Seconds")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetValue() )

class ToggleMute(eg.ActionClass):
    name = "Toggle Mute"
    description = ""

    def __call__(self):
        if self.plugin.player: self.plugin.player.set_muting( not(self.plugin.player.get_muting()) )

class Mute(eg.ActionClass):
    name = "Mute"
    description = ""

    def __call__(self):
        if self.plugin.player: self.plugin.player.mute()

class Unmute(eg.ActionClass):
    name = "Unmute"
    description = ""

    def __call__(self):
        if self.plugin.player: self.plugin.player.unmute()

class PlayPause(eg.ActionClass):
    name = "Play/Pause"
    description = ""

    def __call__(self):
        if self.plugin.player: self.plugin.player.toggle()

class Stop(eg.ActionClass):
    name = "Stop"
    description = ""

    def __call__(self):
        if self.plugin.player: self.plugin.player.stop()

class VolumeUp(eg.ActionClass):
    name = "Volume Up"
    description = ""

    def __call__(self, amount):
        if self.plugin.player: self.plugin.player.volume_up(amount)
    
    def Configure(self, amount=5):
        panel = eg.ConfigPanel()
        ctrl = wx.SpinCtrl(panel, -1, min=0, max=100, initial=amount)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Amount to change volume")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetValue() )

class VolumeDown(eg.ActionClass):
    name = "Volume Down"
    description = ""

    def __call__(self, amount):
        if self.plugin.player: self.plugin.player.volume_down(amount)
    
    def Configure(self, amount=5):
        panel = eg.ConfigPanel()
        ctrl = wx.SpinCtrl(panel, -1, min=0, max=100, initial=amount)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Amount to change volume")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetValue() )

class Next(eg.ActionClass):
    name = "Next"
    description = ""

    def __call__(self):
        if self.plugin.player: self.plugin.player.next()

class Prev(eg.ActionClass):
    name = "Previous"
    description = ""

    def __call__(self):
        if self.plugin.player: self.plugin.player.prev()

class Random(eg.ActionClass):
    name = "Random Play"
    description = ""
    def __call__(self, randommode):
        if self.plugin.player: self.plugin.player.randomplay(randommode.lower())
        
    def Configure(self, randommode="Tracks"):
        panel = eg.ConfigPanel()
        ctrl = wx.Choice(panel, -1, choices=["Tracks","Albums","Contributors","Year"])
        ctrl.SetStringSelection(randommode)
        txt = wx.StaticText(panel,wx.ID_ANY,"Random mode")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetStringSelection() )
        
class Unpause(eg.ActionClass):
    name = "Unpause"
    description = ""

    def __call__(self):
        if self.plugin.player: self.plugin.player.unpause()

class SetVolume(eg.ActionClass):
    name = "Set Volume"
    description = ""

    def __call__(self, volume):
        if self.plugin.player: self.plugin.player.set_volume(volume)

    def Configure(self, volume=0):
        panel = eg.ConfigPanel()
        ctrl = wx.SpinCtrl(panel, -1, min=0, max=100, initial=volume)
        txt  = wx.StaticText(panel,wx.ID_ANY,"Set volume to")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetValue() )

class GetMuting(eg.ActionClass):
    name = "Get Muting"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_muting()

class GetBass(eg.ActionClass):
    name = "Get Bass"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_bass()

class GetMode(eg.ActionClass):
    name = "Get Mode"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_mode().upper()

class GetPowerState(eg.ActionClass):
    name = "Get Powerstate"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_power_state()

class GetVolume(eg.ActionClass):
    name = "Get Volume"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_volume()

class GetTrackAlbum(eg.ActionClass):
    name = "Get Track Album"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_track_album()

class GetTrackArtist(eg.ActionClass):
    name = "Get Track Artist"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_track_artist()

class GetTrackCurrentTitle(eg.ActionClass):
    name = "Get Track Current Title"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_track_current_title()

class GetTrackTitle(eg.ActionClass):
    name = "Get Track Title"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_track_title()

class GetTrackDuration(eg.ActionClass):
    name = "Get Track Duration"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_track_duration()

class GetTrackGenre(eg.ActionClass):
    name = "Get Track Genre"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_track_genre()

class GetTrackPath(eg.ActionClass):
    name = "Get Track Path"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_track_path()

class GetTrackRemote(eg.ActionClass):
    name = "Get Track Remote"
    description = ""

    def __call__(self):
        if self.plugin.player: return self.plugin.player.get_track_remote()

class SetPowerState(eg.ActionClass):
    name = "Set Power State"
    description = ""
    
    def __call__(self, powerstate):
        if self.plugin.player:
            if powerstate == 2:
                self.plugin.player.set_power_state( not(self.plugin.player.get_power_state()) )
            else:
                self.plugin.player.set_power_state( powerstate)
                
    def Configure(self, powerstate=True):
        panel = eg.ConfigPanel()
        ctrl = wx.Choice(panel, -1, choices=["Off","On","Toggle On/Off"])
        ctrl.SetSelection(powerstate)
        txt = wx.StaticText(panel,wx.ID_ANY,"Power")
        panel.AddLine(txt, ctrl)
        while panel.Affirmed():
            panel.SetResult( ctrl.GetSelection() )
        
class TurnNotificationsOn(eg.ActionClass):
    name = "Turn Notification On"
    description = "Get Notifications from Squeezebox"
    def __call__(self):
        self.plugin.worker.TurnNotificationsOn()
        self.plugin.notify = True

        
class TurnNotificationsOff(eg.ActionClass):
    name = "Turn Notification Off"
    description = "Turn Notifications from Squeezebox off"
    def __call__(self):
        self.plugin.worker.TurnNotificationsOff()
        self.plugin.notify = False

'''

get_display_type()

    Get Player Display Type String

get_ip_address()

    Get Player IP Address

get_ir_state()

    Get Player Infrared State

get_model()

    Get Player Model String

get_name()

    Get Player Name

get_pitch()

    Get Player Pitch

get_pref_value(name, namespace=None)

    Get Player Preference Value

get_rate()

    Get Player Rate

get_ref()

    Get Player Ref

get_time_elapsed()

    Get Player Time Elapsed

get_time_remaining()

    Get Player Time Remaining

get_treble()

    Get Player Treble

get_uuid()

    Get Player UUID

get_wifi_signal_strength()

    Get Player WiFi Signal Strength

has_permission(request_terms)

    Check Player User Permissions

ir_button(button)

    Simulate IR Button Press

pitch_down(amount=5)

    Decrease Player Pitch

pitch_up(amount=5)

    Increase Player Pitch

playlist_add(item)

    Add Item To Playlist

playlist_clear()

    Clear the entire playlist. Will stop the player.

playlist_delete(item)

    Delete Item From Playlist By Name

playlist_erase(index)

    Erase Item From Playlist

playlist_get_info()

    Get info about the tracks in the current playlist

playlist_insert(item)

    Insert Item Into Playlist (After Current Track)

playlist_move(from_index, to_index)

    Move Item In Playlist

playlist_play(item)

    Play Item Immediately

playlist_play_index(index)

    Play track at a certain position in the current playlist (index is zero-based)

playlist_track_count()

    Get the amount of tracks in the current playlist

rate_down(amount=1)

    Decrease Player Rate

rate_up(amount=1)

    Increase Player Rate

request(command_string, preserve_encoding=False)

    Executes Telnet Request via SqueezeCenter

seek_to(seconds)

    Seek Player

set_ir_state(state)

    Set Player Power State

set_name(name)

    Set Player Name

set_pitch(pitch)

    Set Player Pitch

set_pref_value(name, value, namespace=None)

    Set Player Preference Value

set_rate(rate)

    Set Player Rate

set_treble(treble)

    Set Player Treble

treble_down(amount=5)

    Decrease Player Treble

treble_up(amount=5)

    Increase Player Treble

update(index, update=True)

    Update Player Properties from SqueezeCenter

'''        