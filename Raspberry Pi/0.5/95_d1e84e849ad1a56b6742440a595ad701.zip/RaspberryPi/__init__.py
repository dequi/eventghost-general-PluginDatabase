# -*- coding: utf-8 -*-
#
# plugins/RaspberryPi/__init__.py
#
# Copyright (C) 2013 Pako
#
# This file is a plugin for EventGhost.
# Copyright (C) 2005-2012 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it undervcg
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

# Changelog (in reverse chronological order):
# -------------------------------------------
# 0.5 by Pako 2015-04-24 21:47 UTC+1
#     - bugfix - when RPi list ist empty ...
# 0.4 by Pako 2015-04-24 20:19 UTC+1
#     - bugfix - update - according to new paramiko library
# 0.3 by Pako 2013-09-30 20:10 UTC+1
#     - small string correction
# 0.2 by Pako 2013-09-29 10:55 UTC+1
#     - bug fix (Show info button pressed immediately after RPi adding)
# 0.1 by Pako 2013-09-21 17:38 UTC+1
#     - attempts choice added
#     - Show info: now all informations are collected during a single connection
# 0.0 by Pako 2013-09-14 10:29 UTC+1
#     - initial version
#===============================================================================

eg.RegisterPlugin(
    name = "Raspberry Pi",
    author = "Pako",
    version = "0.5",
    kind = "external",
    guid = "{CFBE7669-2571-4873-B828-2937638B6517}",
    canMultiLoad = False,
    createMacrosOnAdd = True,
    description = ur"""<rst>
Adds actions to watch and control  `Raspberry Pi`__.

| **Notice:**
| This plugin communicates with RPi via **SSH**.
| For proper operation of the plugin is therefore necessary to enable 
 SSH communication in the **RPi** settings.

__ http://www.raspberrypi.org
""",
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAB3RJTUUH3QkFDCU55laW"
        "mQAAAvFJREFUOMtlkj1sm1UUhp977/fjz/Vf3JA0aZOoIFw1KZQfgSoVQiToQIcywFDE"
        "AhMrA2Jhgg0GBpjYAQkRsXQCilqkgJSKIpQ2CVQmSuK4JCWOncT293u/y9DaJOKs533P"
        "Oe95X8V/VVIu50oj9kuZjJp08tIN2+ndB72nRyuZadsR51KTlnVMF+gAiAcANXba++js"
        "hdLbhUE7l6YmaW3Gu+tL3c+am1Eweb7w7sijXknHxgq7aXvhWmu2eqP9FoDVW+9kZXls"
        "8khOWYI4SK2HxjNHg45+Pz9ghWdmSrlOK8HNSixH5pbmdr0eTwIcGZB6c8W/Wr25H3h5"
        "hZBwby2ktuTbW6thrrbYBSBbsKj+up9sLHd+6A1QAHFgOF7xbu3UIyvsptP5giWqN9us"
        "Xevib2m0axgey7Cy0GZ90f+4vhx8CuhDEhoLAcDq89WhVjeny4Mtlw9yj6EQzP/SQC+A"
        "21F7i/7uGhAekgCwTzrxijv+zhNyoLza7ACQGoNC4CJJ9lMuWqOFi/bIe8BUj2cdsPGp"
        "Rb17sk3CBWeEsnT4MdxEY7jkniBAs5C0uGv8Y8B5YLH/A+DhNzITH3pCTVZUgRfdYwzL"
        "DDsmwhGKF5whhmUG32gU0p6Q2RN/6v3PAaxRPIAzU6o4U0t9CsLun1TTXXZNRGxSbCFR"
        "CCZUliHpPklUvy+hQQTQuZeGyR29Z91OWjRNRGRSPKHwhMf30d/smYQ7yR7jKouLSvo2"
        "agwas94wYeWUVXi8KG2+DTY4bRV53ZvgrD3AP2nIlbDOtDNESTjMBrXvOiRf9p84iKub"
        "Or4+lSleftYZtDxhkRWqL8UVkkvucV52R/kj2cMV8ifMARe279s6t6Lbc4+k+ZmKyjMb"
        "1IhNihSC20mLV91xfJNwK24ur6fd64eS2MvSb0nzry0d5OeTxqmisOVJlSMrLOqpz8/x"
        "Nr/HO1e+iTY+Aa72SIL/VxF47bI7/uYz9tHnBIL5ePvG1+H6F8BXQOMg+F8Qkj5x353x"
        "lAAAAABJRU5ErkJggg=="
    ),
    url = "http://www.eventghost.net/forum/viewtopic.php?f=9&t=5704"
)
#===============================================================================
import os
import sys
import paramiko
import eg
import wx
import wx.animate
import socket
from os.path import abspath, split
from wx.lib.mixins.listctrl import CheckListCtrlMixin
from copy import deepcopy as cpy
from datetime import timedelta
from time import time as timetime

SYS_VSCROLL_X = wx.SystemSettings.GetMetric(wx.SYS_VSCROLL_X)
nbytes = 4096
VALUES=[
    [True,
    u'Temperature',
    u'temp',
    u'>70.0F',
    u'\xb0C',
    u'/opt/vc/bin/vcgencmd measure_temp',
    u'''#data to be processed will be stored in the variable INPUT
OUTPUT = INPUT.split("=")[1].split("\'C")[0]
eg.plugins.RaspberryPi.plugin.result = OUTPUT
'''
    ],
    [True,
    u'Memory usage 90%',
    u'memUsage90',
    u'>90.0F',
    u'%',
    u'free',
    u'''#data to be processed will be stored in the variable INPUT
INPUT = INPUT.split(chr(10))[1]
total, used, free = INPUT.split()[1:4]
OUTPUT = 100 * float(used) / float(total)
eg.plugins.RaspberryPi.plugin.result = OUTPUT
'''
    ],
    [True,
    u'Disk usage 90%',
    u'diskUsage90',
    u'>90I',
    u'%',
    u'df -h /',
    u'''#data to be processed will be stored in the variable INPUT
OUTPUT = INPUT.split(chr(10))[1].split()[4][:-1]
eg.plugins.RaspberryPi.plugin.result = OUTPUT
'''
    ]
]
#===============================================================================

class myCheckListBox(wx.CheckListBox):
    def __init__(self, parent, id=-1, choices = []):
        wx.CheckListBox.__init__(
            self,
            parent,
            id,
            wx.DefaultPosition,
            wx.DefaultSize,
            choices,
        )
        self.Bind(wx.EVT_CHECKLISTBOX, self.onCheck)


    def onCheck(evt):
        index = evt.GetSelection()
        evt.Skip()
        self.SetSelection(index) # now (un)checking also selects (moves the highlight)


    def SetValue(self, data):
        for i in range(len(data)):
            self.Check(i, int(data[i]))

    def GetValue(self):
        data = []
        for i in range(len(self.GetStrings())):
            data.Append(self.IsChecked(i))
        return data
#===============================================================================

class CheckListCtrl(wx.ListCtrl, CheckListCtrlMixin):
    def __init__(self, parent, header, rows, hidden = 0, passw = 0):
        wx.ListCtrl.__init__(
            self,
            parent,
            -1,
            style = wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL
        )
        self.rows = rows
        self.hidden = hidden
        self.passw = passw
        if passw:
            self.psswds = []
        self.selRow = -1
        self.back = self.GetBackgroundColour()
        self.fore = self.GetForegroundColour()
        self.selBack = wx.SystemSettings.GetColour(wx.SYS_COLOUR_HIGHLIGHT)
        self.selFore = wx.SystemSettings.GetColour(wx.SYS_COLOUR_HIGHLIGHTTEXT)
        self.wk = SYS_VSCROLL_X+self.GetWindowBorderSize()[0]
        self.collens = []
        hc = len(header)
        for i in range(hc):
            self.InsertColumn(i, header[i])
        for i in range(hc-hidden):
            self.SetColumnWidth(i, wx.LIST_AUTOSIZE_USEHEADER)
            w = self.GetColumnWidth(i)
            self.collens.append(w)
            self.wk += w
        if self.hidden:
            for i in range(hc - self.hidden, hc):
                self.SetColumnWidth(i, 0)
        self.InsertStringItem(0, "dummy")
        rect = self.GetItemRect(0, wx.LIST_RECT_BOUNDS)
        hh = rect[1] #header height
        hi = rect[3] #item height
        self.DeleteAllItems()
        self.SetMinSize((self.wk, 5 + hh + rows * hi))
        self.SetSize((self.wk, 5 + hh + rows * hi))
        self.Layout()
        CheckListCtrlMixin.__init__(self)
        self.Bind(wx.EVT_LIST_ITEM_SELECTED, self.OnItemSelected)
        self.Bind(wx.EVT_SIZE, self.OnSize)


    def SetWidth(self):
        newW = self.GetSize().width
        p = newW/float(self.wk)
        col = self.GetColumnCount()-self.hidden
        w = SYS_VSCROLL_X + self.GetWindowBorderSize()[0]+self.GetColumnWidth(0)
        for c in range(1, col-1):
            self.SetColumnWidth(c, p*self.collens[c])
            w += self.GetColumnWidth(c)
        self.SetColumnWidth(col-1, newW-w)


    def OnSize(self, event):
        wx.CallAfter(self.SetWidth)
        event.Skip()


    def OnItemSelected(self, evt):
        self.SelRow(evt.m_itemIndex)
        evt.Skip()


    # this is called by the base class when an item is checked/unchecked !!!!!!!
    def OnCheckItem(self, index, flag):
        evt = eg.ValueChangedEvent(self.GetId(), value = (index, flag))
        wx.PostEvent(self, evt)


    def SelRow(self, row):
        if row != self.selRow:
            if self.selRow in range(self.GetItemCount()):
                item = self.GetItem(self.selRow)
                item.SetTextColour(self.fore)
                item.SetBackgroundColour(self.back)
                self.SetItem(item)
            self.selRow = row
        if self.GetItemBackgroundColour(row) != self.selBack:
            item = self.GetItem(row)
            item.SetTextColour(self.selFore)
            item.SetBackgroundColour(self.selBack)
            self.SetItem(item)
            self.SetItemState(row, 0, wx.LIST_STATE_SELECTED)


    def DeleteRow(self):
        row = self.selRow
        if row > -1:
            if hasattr(self, "psswds"):
                self.psswds.pop(row)
            self.DeleteItem(row)
            row = row if row < self.GetItemCount() else self.GetItemCount() - 1
            if row > -1:
                self.SelRow(row)
            else:
                self.selRow = -1
                evt = eg.ValueChangedEvent(self.GetId(), value="Empty")
                wx.PostEvent(self, evt)


    def AppendRow(self):
        ix = self.GetItemCount()
        self.InsertStringItem(ix, "")
        self.CheckItem(ix)
        self.EnsureVisible(ix)
        self.SelRow(ix)
        if hasattr(self, "psswds"):
            self.psswds.append("")
        if ix == 0:
            evt = eg.ValueChangedEvent(self.GetId(), value="One")
            wx.PostEvent(self, evt)


    def SetRow(self, rowData, row = None):
        row = self.selRow if row is None else row
        if rowData[0]:
            self.CheckItem(row)
        elif self.IsChecked(row):
            self.ToggleItem(row)
        for i in range(1, len(rowData)):
            if i != self.passw:
                self.SetStringItem(row, i, rowData[i])
            else:
                self.psswds[row]=rowData[i]
                self.SetStringItem(row, i, 7 * u"\u2022")


    def GetSelectedItemIx(self):
        return self.selRow


    def GetRow(self, row = None):
        row = self.selRow if row is None else row
        rowData=[]
        rowData.append(self.IsChecked(row))
        for i in range(1, self.GetColumnCount()):
            if i != self.passw:
                rowData.append(self.GetItem(row, i).GetText())
            else:
                rowData.append(self.psswds[row])
        return rowData


    def GetData(self):
        data = []
        for row in range(self.GetItemCount()):
            rowData = self.GetRow(row)
            data.append(rowData)
        return data


    def SetData(self, data):
        if data:
            for row in range(len(data)):
                self.AppendRow()
                self.SetRow(data[row])
            self.SelRow(0)
            self.EnsureVisible(0)
            if hasattr(self, "psswds"):
                self.psswds = [i[6] for i in data]
            
#===============================================================================

class profDialog(wx.Frame):
    def __init__(self, parent, plugin):
        wx.Frame.__init__(
            self,
            parent,
            -1,
            style = wx.DEFAULT_DIALOG_STYLE | wx.TAB_TRAVERSAL|wx.RESIZE_BORDER,
            name="RPiPluginProfDialog"
        )
        self.SetBackgroundColour(wx.NullColour)
        self.panel = parent
        self.plugin = plugin
        self.profiles = cpy(self.panel.profiles)
        self.SetIcon(self.plugin.info.icon.GetWxIcon())
        self.flag = True
        self.oldSel = -1


    def ShowProfDialog(self):
        text = self.plugin.text
        self.panel.Enable(False)
        self.panel.dialog.buttonRow.cancelButton.Enable(False)
        self.panel.EnableButtons(False)
        self.SetTitle(text.title3)
        panel = wx.Panel(self)
        line = wx.StaticLine(
            panel,
            -1,
            style = wx.LI_HORIZONTAL
        )
        btnsizer = wx.BoxSizer(wx.HORIZONTAL)
        btn3 = wx.Button(panel, wx.ID_ADD,text.add)
        btnsizer.Add(btn3)
        btnsizer.Add((5,-1))
        btn4 = wx.Button(panel, wx.ID_DELETE,text.delete)
        btnsizer.Add(btn4)
        btnsizer.Add((10,-1),1,wx.EXPAND)
        btn1 = wx.Button(panel, wx.ID_OK,text.ok)
        btnsizer.Add(btn1)
        btnsizer.Add((5,-1))
        btn2 = wx.Button(panel, wx.ID_CANCEL,text.cancel)
        btnsizer.Add(btn2)
        lbl1 = wx.StaticText(panel, -1, text.profLbl1)
        lbl2 = wx.StaticText(panel, -1, text.profLbl2)
        lbl3 = wx.StaticText(panel, -1, "")
        listBoxCtrl=wx.ListBox(
            panel,-1,
            style=wx.LB_SINGLE|wx.LB_NEEDED_SB
        )
        profNameCtrl = wx.TextCtrl(panel,-1)
        choices = [i[1] for i in self.panel.val_grid.GetData()]
        profilesCtrl = myCheckListBox(
            panel,
            -1,
            choices = choices,
        )


        def setValue(item):
            profNameCtrl.ChangeValue(item[0])
            profilesCtrl.SetValue(item[1])
            lbl3.SetLabel(text.profLbl3 % item[0])


        def enableCtrl(enable):
            profNameCtrl.Enable(enable)
            btn4.Enable(enable)
            profilesCtrl.Enable(enable)


        def readListBox(ix):
            self.profiles[self.oldSel][1][ix] = profilesCtrl.IsChecked(ix)


        def onCheckListBox(evt):
            index = evt.GetSelection()
            wx.CallAfter(readListBox, index)
            evt.Skip()
        profilesCtrl.Bind(wx.EVT_CHECKLISTBOX, onCheckListBox)


        def OnNameChange(evt):
            if self.profiles<>[] and self.flag:
                flag = False
                sel = self.oldSel
                label = profNameCtrl.GetValue()
                self.profiles[sel][0]=label
                listBoxCtrl.Set([n[0] for n in self.profiles])
                listBoxCtrl.SetSelection(sel)
                if label.strip()<>"":
                    if [n[0] for n in self.profiles].count(label) == 1:
                        flag = True
                btn3.Enable(flag)
            evt.Skip()
        profNameCtrl.Bind(wx.EVT_TEXT, OnNameChange)


        def onAdd(evt):
            self.flag = False
            enableCtrl(True)
            sel = listBoxCtrl.GetSelection() + 1
            self.oldSel=sel
            item = ['', cpy(self.profiles[0][1])]
            self.profiles.insert(sel, item)
            listBoxCtrl.Set([n[0] for n in self.profiles])
            listBoxCtrl.SetSelection(sel)
            setValue(item)
            profNameCtrl.SetFocus()
            btn3.Enable(False)
            self.flag = True
            evt.Skip()
        btn3.Bind(wx.EVT_BUTTON, onAdd)


        def OnButtonDelete(evt):
            lngth = len(self.profiles)
            sel = listBoxCtrl.GetSelection()
            sel = self.oldSel if self.oldSel < lngth-2 else lngth-2
            self.oldSel = sel
            tmp = self.profiles.pop(listBoxCtrl.GetSelection())
            listBoxCtrl.Set([i[0] for i in self.profiles])
            listBoxCtrl.SetSelection(sel)
            item = self.profiles[sel]
            setValue(item)
            if lngth == 2:
                enableCtrl(False)
            evt.Skip()
        btn4.Bind(wx.EVT_BUTTON, OnButtonDelete)


        def OnClick(evt):
            sel =  evt.GetSelection()
            self.oldSel = sel
            enableCtrl(sel != 0)
            setValue(self.profiles[sel])
            evt.Skip()
        listBoxCtrl.Bind(wx.EVT_LISTBOX, OnClick)

        enableCtrl(False)
        leftSizer = wx.BoxSizer(wx.VERTICAL)
        leftSizer.Add(lbl1)
        leftSizer.Add(listBoxCtrl,1,wx.EXPAND)
        leftSizer.Add(lbl2,0,wx.TOP,5)
        leftSizer.Add(profNameCtrl,0,wx.EXPAND)
        rightSizer = wx.BoxSizer(wx.VERTICAL)
        rightSizer.Add(lbl3)
        rightSizer.Add(profilesCtrl,1,wx.EXPAND)
        topSizer = wx.BoxSizer(wx.HORIZONTAL)
        topSizer.Add(leftSizer,1,wx.ALL|wx.EXPAND,5)
        topSizer.Add(rightSizer,1,wx.ALL|wx.EXPAND,5)
        mainSizer = wx.BoxSizer(wx.VERTICAL)
        mainSizer.Add(topSizer,1,wx.ALL|wx.EXPAND,5)
        mainSizer.Add(line, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.BOTTOM,5)
        mainSizer.Add(btnsizer, 0, wx.EXPAND|wx.LEFT|wx.RIGHT, 10)
        mainSizer.Add((1,6))
        panel.SetSizer(mainSizer)

        def onClose(evt):
            self.MakeModal(False)
            self.panel.Enable(True)
            self.panel.dialog.buttonRow.cancelButton.Enable(True)
            self.panel.EnableButtons(True)
            self.GetParent().GetParent().Raise()
            self.Destroy()
        self.Bind(wx.EVT_CLOSE, onClose)


        def onOk(evt):
            self.panel.profiles = self.profiles
            self.Close()
        btn1.Bind(wx.EVT_BUTTON, onOk)


        def onCancel(evt):
            self.Close()
        btn2.Bind(wx.EVT_BUTTON, onCancel)

        if not self.profiles[0][1]:
            self.profiles[0] = [
                "default",
                [i[0] for i in self.panel.val_grid.GetData()]
            ]
        data = self.profiles[0]
        setValue(data)
        listBoxCtrl.Set([i[0] for i in self.profiles])
        listBoxCtrl.SetSelection(0)
        mainSizer.Fit(self)
        mainSizer.Layout()
        self.Raise()
        self.MakeModal(True)
        self.Show()
#===============================================================================

class extDialog(wx.Frame):
    def __init__(
        self,
        parent,
        plugin,
        labels,
        data,
        grid,
        add=False,
        multi = [],
        combo=(0,)
    ):
        wx.Frame.__init__(
            self,
            parent,
            -1,
            style = wx.DEFAULT_DIALOG_STYLE | wx.TAB_TRAVERSAL|wx.RESIZE_BORDER,
            name="RPiPluginExtDialog"
        )
        self.panel = parent
        self.plugin = plugin
        self.text = plugin.text
        self.SetIcon(self.plugin.info.icon.GetWxIcon())
        self.labels = labels
        self.data = data
        self.grid = grid
        self.add = add
        self.multi = multi
        self.combo = combo
        self.passRow = 6 if combo != (0,) else 0


    def ShowExtDialog(self, title):
        self.panel.Enable(False)
        self.panel.dialog.buttonRow.cancelButton.Enable(False)
        self.panel.EnableButtons(False)
        self.SetTitle(title)
        text = self.plugin.text
        panel = wx.Panel(self)

        def wxst(label):
            return wx.StaticText(panel, -1, label)

        labels = self.labels
        data = self.data
        rows = len(labels)
        acv = wx.ALIGN_CENTER_VERTICAL
        sizer = wx.FlexGridSizer(rows-1, 2, 5, 5)
        sizer.AddGrowableCol(1)
        for r in self.multi:
            sizer.AddGrowableRow(r-1)
        for row in range(1, rows):
            sizer.Add(wxst(labels[row]), 0, acv)
            if row not in self.multi and row != self.combo[0] and row != self.passRow:
                txtCtrl = wx.TextCtrl(panel, -1, data[row])
            elif row == self.combo[0]:
                txtCtrl=wx.ComboBox(
                    panel,
                    -1,
                    choices=self.combo[1],
                    style=wx.CB_DROPDOWN
                )
                txtCtrl.SetValue(data[row])
            elif row == self.passRow:
                self.password = eg.Password(data[row])
                txtCtrl = wx.TextCtrl(
                    panel,
                    -1,
                    self.password.Get(),
                    style = wx.TE_PASSWORD
                )
            else:
                txtCtrl = wx.TextCtrl(
                    panel,
                    -1,
                    data[row],
                    style = wx.TE_MULTILINE
                )
            sizer.Add(txtCtrl,0,wx.EXPAND)

        line = wx.StaticLine(
            panel,
            -1,
            style = wx.LI_HORIZONTAL
        )
        btn1 = wx.Button(panel, wx.ID_OK)
        btn1.SetLabel(text.ok)
        btn2 = wx.Button(panel, wx.ID_CANCEL)
        btn2.SetLabel(text.cancel)
        btnsizer = wx.StdDialogButtonSizer()
        btnsizer.AddButton(btn1)
        btnsizer.AddButton(btn2)
        btnsizer.Realize()
        mainSizer = wx.BoxSizer(wx.VERTICAL)
        mainSizer.Add(sizer,1,wx.ALL|wx.EXPAND,5)
        mainSizer.Add(line, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.TOP|wx.BOTTOM,5)
        mainSizer.Add(btnsizer, 0, wx.EXPAND|wx.RIGHT, 10)
        mainSizer.Add((1,6))
        panel.SetSizer(mainSizer)
        mainSizer.Fit(self)


        def onClose(evt):
            self.MakeModal(False)
            self.panel.Enable(True)
            self.panel.dialog.buttonRow.cancelButton.Enable(True)
            self.panel.EnableButtons(True)
            self.GetParent().GetParent().Raise()
            self.Destroy()
        self.Bind(wx.EVT_CLOSE, onClose)


        def onOk(evt):
            if self.add:
                self.grid.AppendRow()
                if title==self.text.title2: # var_grid
                    for prof in self.panel.profiles:
                        prof[1].append(True)
            data=[self.data[0]]
            children = sizer.GetChildren()
            for child in range(1,len(children),2):
                ctrl=children[child].GetWindow()
                if child != 2 * self.passRow - 1:
                    data.append(ctrl.GetValue())
                else:
                    self.password.Set(ctrl.GetValue())
                    data.append(self.password)
            self.grid.SetRow(data)
            self.Close()
        btn1.Bind(wx.EVT_BUTTON, onOk)


        def onCancel(evt):
            self.Close()
        btn2.Bind(wx.EVT_BUTTON, onCancel)

        mainSizer.Layout()
        w, h = self.GetSize()
        self.SetSize((max(w, 400), h))
        self.SetMinSize((max(w, 400), h))
        self.Raise()
        self.MakeModal(True)
        self.Show()
#===============================================================================

class infDialog(wx.Frame):
    def __init__(
        self,
        plugin,
        parent,
        ix,
        grid
    ):
        wx.Frame.__init__(
            self,
            parent,
            -1,
            style = wx.DEFAULT_DIALOG_STYLE | wx.TAB_TRAVERSAL|wx.RESIZE_BORDER,
            name="RPiPluginInfDialog",
        )
        self.SetBackgroundColour(wx.BLACK)
        self.parent = parent
        self.plugin = plugin
        self.text = plugin.text
        self.SetIcon(self.plugin.info.icon.GetWxIcon())
        self.ix = ix
        self.SetTitle(self.text.title4 % grid.GetRow(ix)[1])


        demoData = (
            "",
            "",
            28*"_",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
        )
        self.ShowInfo(demoData)
        mainSizer = self.panel.GetSizer()
        mainSizer.Fit(self)
        size = self.GetSize()
        self.SetMinSize(size)
        self.SetSize(size)
        self.onRefresh()


    def ShowInfo(self, data):
        text = self.text
        if hasattr(self, "panel"):
            self.ag.Destroy()
            mainSizer = self.panel.GetSizer()
            mainSizer.Clear(True)
            panel = self.panel
            panel.Bind(wx.EVT_RIGHT_UP, self.OnRightClick)
            flag = True
        else:
            panel = wx.Panel(self)
            self.panel = panel
            panel.SetBackgroundColour(wx.BLACK)
            panel.SetForegroundColour(wx.Colour(255,255,0))
            mainSizer = wx.BoxSizer(wx.VERTICAL)
            panel.SetSizer(mainSizer)
            flag =False


        def StaticText(txt, sz = None, clr = None):
            st = wx.StaticText(panel, -1, txt, pos = ((0,-50)))
            if flag:
                st.Bind(wx.EVT_RIGHT_UP, self.OnRightClick)
            font = st.GetFont()
            os = font.GetPointSize()
            ns = int(os * 1.45 if sz else os * 1.35)
            font.SetPointSize(ns)
            ul = True if sz else False
            font.SetUnderlined(ul)
            st.SetFont(font)
            if clr:
                st.SetForegroundColour(wx.RED)
            return st

        intSizer = wx.GridBagSizer(8, 20)
        mainSizer.Add(intSizer,1,wx.ALL|wx.EXPAND,5)
        labels = text.labels
        for i in range(18):
            if i == 0:
                intSizer.Add(StaticText(labels[i], 1, 1), (i, 0), (1, 2))
            elif i in (5, 9, 13):
                intSizer.Add(StaticText(labels[i],1,1),(i,0),(1,2),flag = wx.TOP, border = 8)
            else:
                intSizer.Add(StaticText(labels[i]),(i,0))
                intSizer.Add(StaticText(data[i]),(i,1))
        mainSizer.Layout()


    def onOK(self, evt):
        self.Close()
        evt.Skip()


    def onRefresh(self, evt = None):
        self.panel.GetSizer().Clear(True)
        self.PlayRPiGif(evt is None)
        eg.scheduler.AddTask(0.01, self.plugin.GetData, self.ix)
        if evt:
            evt.Skip()


    def onCopy(self, evt):
        eg.scheduler.AddTask(0.01, self.plugin.onCopy)
        evt.Skip()


    def OnRightClick(self, event):
        if not hasattr(self, "popupID1"):
            self.popupID1 = wx.NewId()
            self.popupID2 = wx.NewId()
            self.popupID3 = wx.NewId()
            self.Bind(wx.EVT_MENU, self.onOK, id=self.popupID1)
            self.Bind(wx.EVT_MENU, self.onRefresh, id=self.popupID2)
            self.Bind(wx.EVT_MENU, self.onCopy, id=self.popupID3)
        menu = wx.Menu()
        menu.Append(self.popupID1, self.text.popup[0])
        menu.Append(self.popupID2, self.text.popup[1])
        menu.Append(self.popupID3, self.text.popup[2])
        self.PopupMenu(menu)
        menu.Destroy()


    def PlayRPiGif(self, flag):
        self.parent.Enable(False)
        self.parent.dialog.buttonRow.cancelButton.Enable(False)
        self.parent.EnableButtons(False)
        text = self.text
        panel = self.panel
        mainSizer = self.panel.GetSizer()
        waitLabel=wx.StaticText(panel, -1, text.collect)
        ag_fname = abspath(split(__file__)[0]) + r"\Spec-RaspberryPi-GIF-256-Transp.gif"
        sw, sh = self.GetClientSize()
        agw, agh = (256, 256)
        pos = (((sw - agw) / 2, (sh - agh) / 2))
        ag = wx.animate.GIFAnimationCtrl(panel, -1, ag_fname, pos = pos)
        self.ag = ag
        ag.Play()
        mainSizer.Add(waitLabel,0,wx.LEFT|wx.TOP,5)
        mainSizer.Layout()
        if flag:
            self.Raise()
            self.MakeModal(True)
            self.Show()

        def onClose(evt):
            self.MakeModal(False)
            self.parent.Enable(True)
            self.parent.dialog.buttonRow.cancelButton.Enable(True)
            self.parent.EnableButtons(True)
            self.GetParent().GetParent().Raise()
            self.Destroy()
        self.Bind(wx.EVT_CLOSE, onClose)
#===============================================================================

class Text:
    label1="List of observed RPi's:"
    label2="List of observed values:"
    header1 = (
        "Enabled",
        "RPi name",
        "Event name",
        "Hostname/IP address",
        "Port",
        "Username",
        "Password",
        "Value profile",
    )
    header2 = (
        "Enabled",
        "Value name",
        "Event suffix",
        "Limit",
        "Unit",
        "Command",
        "Script",
    )
    buttons1 = (
        "Add new",
        "Duplicate",
        "Edit",
        "Delete",
        "Show info",
        "Reboot",
        "Power off"
    )
    buttons2 = (
        "Add new",
        "Duplicate",
        "Edit",
        "Delete",
        "Test event",
        "Profiles ...",
    )
    title1 = "RPi details"
    title2 = "Value details"
    title3 = "Value profiles"
    title4 = 'Raspberry Pi "%s" details'
    profLbl1 = "List:"
    profLbl2 = "Name:"
    profLbl3 = "Profile %s:"
    cancel = "Cancel"
    ok = "OK"
    add = "Add"
    delete = "Delete"
    period = "Polling period [s]:"
    attempts = "Maximum number of attempts to obtain a value:"
    prefix = "Event prefix:"
    no_prof = 'The "%s" profile does not exist.\The default profile will be used instead.'
    no_cmd = 'The Command is undefined.\nThe value "%s" can not be found.'
    no_script = ('The script for processing the result is undefined.\n'
                'The result can not be processed.')
    notAcc = 'Raspberry Pi "%s" is not accessible !'
    warn = "Warning"
    no_acc = "notAccessible"
    no_conn = ('The connection with RPi "%s" failed.'
              '\nMaybe we have the wrong credentials?')
    un_res = 'Unexpected result from "%s" for "%s"'
    err = 'error'
    collect = "Data collection in progress. Please wait ..."
    labels = (
        "System",
        "Serial number",
        "Distribution",
        "Uptime",
        "Aver. load (1 min.)",
        "Memory usage",
        "Total memory",
        "Used",
        "Free",
        "Disk usage",
        "Disk size",
        "Used",
        "Free",
        "Physical parameters",
        "ARM frequency",
        "CORE frequency",
        "CORE voltage",
        "CORE temperature",
    )
    popup = (
        "Close",
        "Refresh",
        "Copy to clipboard"
    )
    defScript =(
        '#data to be processed will be stored in the variable '
        'INPUT\neg.plugins.RaspberryPi.plugin.result = INPUT'
    )
#===============================================================================

def isAlive(host, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.2)
        sock.connect((host,port))
        sock.close()
        return True
    except:
        return False
#===============================================================================

class RaspberryPi(eg.PluginBase):

    text = Text
    result = None
    dialog = None
    poll = None

    def __init__(self):
        self.AddActionsFromList(ACTIONS)


    def __start__(
        self,
        rpis=[],
        values=[],
        profiles = [["default",[]]],
        prefix="RPi",
        period = 300,
        attempts = 3,
        ):
        self.info.eventPrefix = prefix
        self.rpis = rpis
        self.values = values
        self.profiles = profiles
        self.period = period
        self.attempts = attempts
        t = int(timetime())
        ct = 10-t%10
        t = t + ct
        self.poll = eg.scheduler.AddTask(ct, self.polling, t)


    def __stop__(self):
        if self.poll:
            try:
                eg.scheduler.CancelTask(self.poll)
            except:
                pass


    def procScript(self, script):
        eg.plugins.RaspberryPi.plugin.result = None
        eg.plugins.EventGhost.PythonScript(script)
        return eg.plugins.RaspberryPi.plugin.result


    def cmd_session(self, client, cmd, ign = False):
        stdout_data = []
        stderr_data = []
        session = client.open_channel(kind='session')
        session.exec_command(cmd)
        while True:
            if session.recv_ready():
                stdout_data.append(session.recv(nbytes))
            if session.recv_stderr_ready():
                stderr_data.append(session.recv_stderr(nbytes))
            if session.exit_status_ready():
                break
        if session.recv_exit_status() == 0:
            res = ''.join(stdout_data)
        else:
            if not ign:
                eg.PrintError(''.join(stderr_data))
            res = None
        session.close()
        return res.decode("utf-8")


    def polling(self, oldT):
        per = self.period
        newT = oldT + per if timetime() - oldT < per / 2 else oldT + 2 * per
        self.poll = eg.scheduler.AddTaskAbsolute(newT, self.polling, newT)
        for rpi in self.rpis:
            if not rpi[0]:
                continue
            if not isAlive(rpi[3], int(rpi[4])):
                self.TriggerEvent(self.text.no_acc, payload=rpi[2])
                continue
            try:
                client = paramiko.Transport((rpi[3],int(rpi[4])))
                client.connect(username=rpi[5], password=rpi[6].Get())
            except:
                eg.PrintNotice(self.text.no_conn % rpi[1])
            else:
                prof = rpi[7]
                tmp = [i[0] for i in self.profiles]
                if prof in tmp:
                    prof = self.profiles[tmp.index(prof)][1]
                else:
                    eg.PrintNotice(self.text.no_prof % prof)
                    prof = self.profiles[0][1]
                for i, val in enumerate(self.values):
                    if not prof[i]:
                        continue
                    if val[5]:
                        if val[6]:
                            for a in range(self.attempts):
                                cmd = val[5].replace("/opt/vc/bin/vcgencmd ","vcgencmd ")
                                cmd = cmd.replace("vcgencmd ","/opt/vc/bin/vcgencmd ")
                                res = self.cmd_session(client, cmd)
                                if res:
                                    tp = val[3][-1]
                                    lmt = val[3][1:-1]
                                    lmt = int(lmt) if tp == "I" else float(lmt)
                                    op = val[3][0]
                                    script = u'INPUT = """' + res + '"""\n' + val[6]
                                    try:
                                        res = self.procScript(script)
                                        res = int(res) if tp=="I" else float(res)
                                        if (op =="<" and res<lmt) or (op==">"and res>lmt):
                                            self.TriggerEvent(val[2],payload=[rpi[2], res])
                                        flag = False
                                        break
                                    except:
                                        flag = True
                            if flag:
                                    self.TriggerEvent(self.text.err,payload=[rpi[2], val[2]])
                        else:
                            eg.PrintNotice(self.text.no_script)
                    else:
                        eg.PrintNotice(self.text.no_cmd % val[1])
                client.close()


    def enableRPi(self, ix, enable):
        self.rpis[ix][0] = enable


    def rpiCommand(self, ix, cmd, dis = 0, ign = False):
        rpi = self.rpis[ix]
        if not isAlive(rpi[3], int(rpi[4])):
            eg.PrintNotice(self.text.notAcc % rpi[1])
            return
        client = paramiko.Transport((rpi[3],int(rpi[4])))
        client.connect(username=rpi[5], password=rpi[6].Get())
        res = self.cmd_session(client, cmd, ign)
        client.close()
        if dis:
            self.enableRPi(ix, False)
            if dis == 1:
                eg.scheduler.AddTask(120, self.enableRPi, ix, True)
        return res


    def GetValues(self, ix):
        atts = self.attCtrl.GetValue()
        data = 18 * ["???"]
        rpi = self.rpi_grid.GetData()[ix]
        
        def Notice(txt):
            eg.PrintNotice(self.text.un_res % (rpi[1], txt))

        if not isAlive(rpi[3], int(rpi[4])):
            eg.PrintNotice(self.text.notAcc % rpi[1])
            return data
        client = paramiko.Transport((rpi[3], int(rpi[4])))
        client.connect(username = rpi[5], password = rpi[6].Get())

        #Serial number
        for a in range(atts):
            try:
                res = self.cmd_session(client, "cat /proc/cpuinfo")
                data[1] = res.split("\n")[-2].split(": ")[-1]
                break
            except:
                Notice(self.text.labels[1])
        #Distribution
        for a in range(atts):
            try:
                res = self.cmd_session(client, "cat /etc/*-release")
                data[2] = res.split("\n")[0].split("=")[-1][1:-1]
                break
            except:
                Notice(self.text.labels[2])
        #Uptime
        for a in range(atts):
            try:
                res = self.cmd_session(client, "cat /proc/uptime")
                uptime_seconds = int(float(res.split("\n")[0].split()[0]))
                data[3] = str(timedelta(seconds = uptime_seconds))
                break
            except:
                Notice(self.text.labels[3])
        #Average load
        for a in range(atts):
            try:
                res = self.cmd_session(client, "cat /proc/loadavg")
                data[4] = res.split("\n")[0].split()[0]
            except:
                Notice(self.text.labels[4])
        #Memory usage
        for a in range(atts):
            try:
                res = self.cmd_session(client, "free")
                res = res.split("\n")[1].split()[1:4]
                for i in range(len(res)):
                    data[i + 6] = "%s KiB" % res[i]
                break
            except:
                Notice(self.text.labels[5])
        #Disk usage
        for a in range(atts):
            try:
                res = self.cmd_session(client, "df -h /")
                res = res.split("\n")[1].split()[1:4]
                for i in range(len(res)):
                    data[i+10] = res[i].replace("G"," GiB").replace("M"," MiB")
                break
            except:
                Notice(self.text.labels[9])
        #ARM frequency
        for a in range(atts):
            try:
                res = self.cmd_session(client, "cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
                data[14] = str(int(res)/1000)+" MHz"
                break
            except:
                Notice(self.text.labels[14])
        #CORE frequency
        for a in range(atts):
            try:
                res = self.cmd_session(client, "/opt/vc/bin/vcgencmd measure_clock core")
                res = res.split("\n")[0].split("=")[1]
                data[15] = str(float(res)/1000000)+" MHz"
                break
            except:
                Notice(self.text.labels[15])
        #CORE voltage
        for a in range(atts):
            try:
                res = self.cmd_session(client, "/opt/vc/bin/vcgencmd measure_volts core")
                data[16] = res.split("\n")[0].split("=")[1].replace("V", " V")
                break
            except:
                Notice(self.text.labels[16])
        #CORE temperature
        for a in range(atts):
            try:
                res = self.cmd_session(client, "/opt/vc/bin/vcgencmd measure_temp")
                data[17] = res.split("\n")[0].split("=")[1].replace(u"'C", u" \u00B0C")
                break
            except:
                Notice(self.text.labels[17])

        client.close()
        return data
   

    def GetData(self, ix):
        data = self.GetValues(ix)
        self.data = data
        eg.scheduler.AddTask(0.01, self.dataReady, data)


    def dataReady(self, data):
        wx.CallAfter(self.dialog.ShowInfo, data)
        return True


    def onCopy(self):
        clipData = ""
        for i in range(18):
            if i in (0, 5, 9, 13):
                clipData += "\n%s\n" % self.text.labels[i]
            else:
                clipData+="%s\t%s\n" %(self.text.labels[i],self.data[i])
        eg.plugins.System.SetClipboard(clipData[1:])


    def Configure(
        self,
        rpis=[],
        values=[],
        profiles = [["default",[True, True, True]]],
        prefix="RPi",
        period = 300,
        attempts = 3,
        ):
        panel = eg.ConfigPanel()
        panel.GetParent().GetParent().SetIcon(self.info.icon.GetWxIcon())
        label1 = wx.StaticText(panel, -1, self.text.label1)
        label2 = wx.StaticText(panel, -1, self.text.label2)
        rpi_grid = CheckListCtrl(panel, self.text.header1, 3, passw = 6)
        self.rpi_grid = rpi_grid
        rpi_grid.SetData(self.rpis if hasattr(self, 'rpis') else rpis)
        val_grid = CheckListCtrl(panel, self.text.header2, 5, 2)
        self.val_grid = val_grid
        panel.val_grid = val_grid
        values = values if values else VALUES
        val_grid.SetData(values)
        panel.profiles = cpy(profiles)

        def enableButtons1(enable):
            for b in range(1, 7):
                wx.FindWindowById(bttns[b]).Enable(enable)


        def enableButtons2(enable):
            for b in range(8, 11):
                wx.FindWindowById(bttns[b]).Enable(enable)


        def OnGridChange1(evt):
            value = evt.GetValue()
            if value == "Empty":
                enableButtons1(False)
            elif value == "One":
                enableButtons1(True)
            evt.Skip()
        rpi_grid.Bind(eg.EVT_VALUE_CHANGED, OnGridChange1)


        def OnGridChange2(evt):
            value = evt.GetValue()
            if value == "Empty":
                enableButtons2(False)
            elif value == "One":
                enableButtons2(True)
            else:
                if value[0] < len(panel.profiles[0][1]):
                    panel.profiles[0][1][value[0]] = value[1]
            evt.Skip()
        val_grid.Bind(eg.EVT_VALUE_CHANGED, OnGridChange2)


        def OnDeleteVal(evt):
            ix = evt.m_itemIndex
            for prof in panel.profiles:
                prof[1].pop(ix)
            evt.Skip()
        val_grid.Bind(wx.EVT_LIST_DELETE_ITEM, OnDeleteVal)


        def edit1():
            dlg = extDialog(
                parent = panel,
                plugin = self,
                labels = self.text.header1,
                data=rpi_grid.GetRow(),
                grid=rpi_grid,
                combo=(7,[i[0] for i in panel.profiles])
            )
            dlg.Centre()
            wx.CallAfter(
                dlg.ShowExtDialog,
                self.text.title1,
            )


        def edit2():
            dlg = extDialog(
                parent = panel,
                plugin = self,
                labels = self.text.header2,
                data=val_grid.GetRow(),
                grid=val_grid,
                multi = [6],
            )
            dlg.Centre()
            wx.CallAfter(
                dlg.ShowExtDialog,
                self.text.title2,
            )


        def OnActivated1(evt):
            edit1()
            evt.Skip()
        rpi_grid.Bind(wx.EVT_LIST_ITEM_ACTIVATED, OnActivated1)


        def OnActivated2(evt):
            edit2()
            evt.Skip()
        val_grid.Bind(wx.EVT_LIST_ITEM_ACTIVATED, OnActivated2)


        def testEvent():
            data=val_grid.GetRow()
            rpi = rpi_grid.GetRow()
            eg.TriggerEvent(
                data[2],
                prefix = prefCtrl.GetValue(),
                payload = [rpi[2], data[3][1:]]
            )
            eg.TriggerEvent(
                self.text.err,
                prefix = prefCtrl.GetValue(),
                payload = [rpi[2], data[2]]
            )


        def onButton(evt):
            if rpi_grid.selRow > -1:
                rpi = rpi_grid.GetRow()
            id = evt.GetId()
            if id == bttns[0]: #Add
                dlg = extDialog(
                    parent = panel,
                    plugin = self,
                    labels = self.text.header1,
                    data=[True, "", "", "", "22", "pi", eg.Password(None), "default"],
                    grid=rpi_grid,
                    add=True,
                    combo=(7,[i[0] for i in panel.profiles])
                )
                dlg.Centre()
                wx.CallAfter(
                    dlg.ShowExtDialog,
                    self.text.title1,
                )
            elif id == bttns[1]: #Duplicate
                dlg = extDialog(
                    parent = panel,
                    plugin = self,
                    labels = self.text.header1,
                    data=rpi_grid.GetRow(),
                    grid=rpi_grid,
                    add=True,
                    combo=(7,[i[0] for i in panel.profiles])
                )
                dlg.Centre()
                wx.CallAfter(
                    dlg.ShowExtDialog,
                    self.text.title1,
                )
            elif id == bttns[2]: # Edit
                edit1()
            elif id == bttns[3]: # Delete
                rpi_grid.DeleteRow()
            elif id == bttns[4]: # Show info
                if isAlive(rpi[3], int(rpi[4])):
                    self.dialog = infDialog(
                        self,
                        parent = panel,
                        ix = rpi_grid.GetSelectedItemIx(),
                        grid = rpi_grid
                    )
                    self.dialog.Centre()
                else:
                    messDial = eg.MessageDialog(
                        panel,
                        self.text.notAcc % rpi[1],
                        self.text.warn,
                        wx.OK|wx.ICON_EXCLAMATION|wx.STAY_ON_TOP
                    )
                    messDial.ShowModal()
                    messDial.Destroy()
            elif id == bttns[5]: # Reboot
                ix = rpi_grid.GetSelectedItemIx()
                self.rpiCommand(
                    ix,
                    "echo '%s' | sudo -S shutdown -r now" % rpi[6],
                    1,
                    True
                )
            elif id == bttns[6]: # Poweroff
                ix = rpi_grid.GetSelectedItemIx()
                self.rpiCommand(
                    ix,
                    "echo '%s' | sudo -S shutdown -h now" % rpi[6],
                    2,
                    True
                )
            elif id == bttns[7]: #Add value
                dlg = extDialog(
                    parent = panel,
                    plugin = self,
                    labels = self.text.header2,
                    data=[
                        True,
                        "",
                        "",
                        "",
                        "",
                        "",
                        self.text.defScript
                    ],
                    grid=val_grid,
                    add=True,
                    multi = [6]
                )
                dlg.Centre()
                wx.CallAfter(
                    dlg.ShowExtDialog,
                    self.text.title2,
                )
            elif id == bttns[8]: #Value duplicate
                dlg = extDialog(
                    parent = panel,
                    plugin = self,
                    labels = self.text.header2,
                    data=val_grid.GetRow(),
                    grid=val_grid,
                    add=True,
                    multi = [6]
                )
                dlg.Centre()
                wx.CallAfter(
                    dlg.ShowExtDialog,
                    self.text.title2,
                )
            elif id == bttns[9]: # Value edit
                edit2()
            elif id == bttns[10]: # Delete
                val_grid.DeleteRow()
            elif id == bttns[11]: # Test event
                testEvent()
            elif id == bttns[12]: # Profiles
                dlg = profDialog(
                    parent = panel,
                    plugin = self,
                )
                dlg.Centre()
                wx.CallAfter(
                    dlg.ShowProfDialog,
                )
            evt.Skip()

        panel.sizer.Add(label1, 0, wx.TOP|wx.LEFT, 5)
        panel.sizer.Add(rpi_grid, 0, wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.EXPAND, 5)
        bttnSizer1 = wx.BoxSizer(wx.HORIZONTAL)
        bttnSizer1.Add((5, -1))
        i = 0
        bttns = []
        for bttn in self.text.buttons1:
            id = wx.NewId()
            bttns.append(id)
            b = wx.Button(panel, id, bttn)
            bttnSizer1.Add(b,1)
            if not len(rpis) and i not in (0,):
                b.Enable(False)
            if i == 0:
                b.SetDefault()
            b.Bind(wx.EVT_BUTTON, onButton, id = id)
            bttnSizer1.Add((5, -1))
            i += 1
        panel.sizer.Add(bttnSizer1,0,wx.EXPAND)
        panel.sizer.Add(label2, 0, wx.TOP|wx.LEFT, 5)
        panel.sizer.Add(val_grid, 0, wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.EXPAND, 5)
        bttnSizer2 = wx.BoxSizer(wx.HORIZONTAL)
        bttnSizer2.Add((5, -1))
        i = 0
        for bttn in self.text.buttons2:
            id = wx.NewId()
            bttns.append(id)
            b = wx.Button(panel, id, bttn)
            bttnSizer2.Add(b,1)
            if not len(values) and i not in (0,):
                b.Enable(False)
            if i == 0:
                b.SetDefault()
            b.Bind(wx.EVT_BUTTON, onButton, id = id)
            bttnSizer2.Add((5, -1))
            i += 1
        panel.sizer.Add(bttnSizer2,0,wx.EXPAND)
        bottomSizer = wx.FlexGridSizer(2, 2, 5, 5)
        panel.sizer.Add(bottomSizer,0,wx.ALL,5)
        prefLbl = wx.StaticText(panel, -1, self.text.prefix)
        prefCtrl = wx.TextCtrl(panel, -1, prefix)
        periLbl = wx.StaticText(panel, -1, self.text.period)
        attLbl = wx.StaticText(panel, -1, self.text.attempts)
        periCtrl = eg.SpinIntCtrl(
            panel,
            -1,
            period,
            min=30,
            max=9990,
        )
        periCtrl.increment = 10
        attCtrl = eg.SpinIntCtrl(
            panel,
            -1,
            attempts,
            min=1,
            max=99,
        )
        self.attCtrl = attCtrl
        bottomSizer.Add(periLbl,0,wx.TOP,3)
        bottomSizer.Add(periCtrl,0,wx.EXPAND)
        bottomSizer.Add(attLbl,0,wx.TOP,3)
        bottomSizer.Add(attCtrl,0,wx.EXPAND)
        bottomSizer.Add(prefLbl,0,wx.TOP,3)
        bottomSizer.Add(prefCtrl,0,wx.EXPAND)

        while panel.Affirmed():
            panel.SetResult(
                rpi_grid.GetData(),
                val_grid.GetData(),
                panel.profiles,
                prefCtrl.GetValue(),
                periCtrl.GetValue(),
                attCtrl.GetValue(),
            )
#===============================================================================

class SendCommand(eg.ActionBase):

    class text:
        chooseLbl = "Select RPi by:"
        chooses = ("RPi name", "Event name")
        rpiLbl = "Raspberry Pi:"
        command = "Command:"
        dis2min = "Disable RPi for two minutes after the command execution"
        disPerm = "Disable RPi permanently after the command execution"
        unknown = 'Unknown RPi: "%s"'

    def __call__(self, choose=1,rpi="",cmd="",dis=0):
        cmd = eg.ParseString(cmd) if cmd[0]!="@" else cmd[1:]
        rpi = eg.ParseString(rpi)
        tmp = [rp[choose+1] for rp in self.plugin.rpis]
        if rpi in tmp:
            ix = tmp.index(rpi)
            return self.plugin.rpiCommand(ix, cmd, dis)
        else:
            eg.PrintNotice(self.text.unknown % rpi)


    def GetLabel(self, choose, rpi, cmd, dis):
        return "%s: %s: %s" % (self.name, rpi, cmd)


    def Configure(self, choose=1,rpi="",cmd="",dis=0):
        panel = eg.ConfigPanel(self)
        text = self.text
        chooseSizer = wx.BoxSizer(wx.HORIZONTAL)
        chooseLbl=wx.StaticText(panel,-1,text.chooseLbl)
        rpiLbl=wx.StaticText(panel,-1,text.rpiLbl)
        cmdLbl=wx.StaticText(panel,-1,text.command)
        rb0=panel.RadioButton(choose==0,self.text.chooses[0], style=wx.RB_GROUP)
        rb1 = panel.RadioButton(choose==1, self.text.chooses[1])
        choices = [rp[choose+1] for rp in self.plugin.rpis]
        rpiCtrl = wx.ComboBox(panel, -1, choices = choices,style=wx.CB_DROPDOWN)
        rpiCtrl.SetValue(rpi)
        cmdCtrl = wx.TextCtrl(panel, -1, cmd)
        twoCtrl = wx.CheckBox(panel, label = self.text.dis2min)
        perCtrl = wx.CheckBox(panel, label = self.text.disPerm)
        twoCtrl.SetValue(dis==1)
        perCtrl.SetValue(dis==2)
        chooseSizer.Add(rb0)
        chooseSizer.Add(rb1, 0, wx.LEFT, 10)
        topSizer = wx.FlexGridSizer(3, 2, 10, 20)
        topSizer.AddGrowableCol(1)
        topSizer.Add(chooseLbl)
        topSizer.Add(chooseSizer)
        topSizer.Add(rpiLbl,0,wx.TOP,4)
        topSizer.Add(rpiCtrl, 0, wx.EXPAND)
        topSizer.Add(cmdLbl)
        topSizer.Add(cmdCtrl, 0, wx.EXPAND)
        mainSizer= wx.BoxSizer(wx.VERTICAL)
        mainSizer.Add(topSizer, 0, wx.EXPAND)
        mainSizer.Add(twoCtrl, 0, wx.TOP,15)
        mainSizer.Add(perCtrl, 0, wx.TOP,12)
        panel.sizer.Add(mainSizer,1,wx.ALL|wx.EXPAND,10)

        def onCheckbox(evt = None):
            perCtrl.Enable(not twoCtrl.IsChecked())
            twoCtrl.Enable(not perCtrl.IsChecked())
            if evt:
                evt.Skip()
        twoCtrl.Bind(wx.EVT_CHECKBOX, onCheckbox)
        perCtrl.Bind(wx.EVT_CHECKBOX, onCheckbox)
        onCheckbox()


        def onRadioBox(evt):
            ix = 1 + rb1.GetValue()
            tmp = rpiCtrl.GetValue()
            rpiCtrl.Clear()
            rpiCtrl.AppendItems([rp[ix] for rp in self.plugin.rpis])
            rpiCtrl.SetValue(tmp)
            evt.Skip()
        rb0.Bind(wx.EVT_RADIOBUTTON, onRadioBox)
        rb1.Bind(wx.EVT_RADIOBUTTON, onRadioBox)

        while panel.Affirmed():
            panel.SetResult(
                int(rb1.GetValue()),
                rpiCtrl.GetValue(),
                cmdCtrl.GetValue(),
                int(twoCtrl.GetValue()) + 2 * int(perCtrl.GetValue())
            )
#===============================================================================

class enableRPi(eg.ActionBase):

    class text:
        chooseLbl = "Select RPi by:"
        chooses = ("RPi name", "Event name")
        rpiLbl = "Raspberry Pi:"
        unknown = 'Unknown RPi: "%s"'

    def __call__(self, choose=1,rpi=""):
        rpi = eg.ParseString(rpi)
        tmp = [rp[choose+1] for rp in self.plugin.rpis]
        if rpi in tmp:
            ix = tmp.index(rpi)
            return self.plugin.enableRPi(ix, self.value)
        else:
            eg.PrintNotice(self.text.unknown % rpi)


    def GetLabel(self, choose=1,rpi=""):
        return "%s: %s" % (self.name, rpi)


    def Configure(self, choose=1,rpi=""):
        panel = eg.ConfigPanel(self)
        text = self.text
        chooseSizer = wx.BoxSizer(wx.HORIZONTAL)
        chooseLbl=wx.StaticText(panel,-1,text.chooseLbl)
        rpiLbl=wx.StaticText(panel,-1,text.rpiLbl)
        rb0=panel.RadioButton(choose==0,self.text.chooses[0], style=wx.RB_GROUP)
        rb1 = panel.RadioButton(choose==1, self.text.chooses[1])
        choices = [rp[choose+1] for rp in self.plugin.rpis]
        rpiCtrl = wx.ComboBox(panel, -1, choices = choices,style=wx.CB_DROPDOWN)
        rpiCtrl.SetValue(rpi)
        chooseSizer.Add(rb0)
        chooseSizer.Add(rb1, 0, wx.LEFT, 10)
        topSizer = wx.FlexGridSizer(3, 2, 10, 20)
        topSizer.AddGrowableCol(1)
        topSizer.Add(chooseLbl)
        topSizer.Add(chooseSizer)
        topSizer.Add(rpiLbl,0,wx.TOP,4)
        topSizer.Add(rpiCtrl, 0, wx.EXPAND)
        mainSizer= wx.BoxSizer(wx.VERTICAL)
        mainSizer.Add(topSizer, 0, wx.EXPAND)
        panel.sizer.Add(mainSizer,1,wx.ALL|wx.EXPAND,10)

        def onRadioBox(evt):
            ix = 1 + rb1.GetValue()
            tmp = rpiCtrl.GetValue()
            rpiCtrl.Clear()
            choices = [rp[ix] for rp in self.plugin.rpis]
            for ch in choices:
                rpiCtrl.Append(ch)
            rpiCtrl.SetValue(tmp)
            evt.Skip()
        rb0.Bind(wx.EVT_RADIOBUTTON, onRadioBox)
        rb1.Bind(wx.EVT_RADIOBUTTON, onRadioBox)

        while panel.Affirmed():
            panel.SetResult(
                int(rb1.GetValue()),
                rpiCtrl.GetValue(),
            )
#===============================================================================
ACTIONS = (
    (SendCommand, "SendCommand", "Send command", "Sends command to selected RPi.", None),
    (enableRPi, "EnableRPi", "Enable RPi", "Enables selected RPi.", True),
    (enableRPi, "DisableRPi", "Disable RPi", "Disables selected RPi.", False),
)
