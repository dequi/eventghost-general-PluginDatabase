import eg

eg.RegisterPlugin(
    name = "iTunes",
    author = "cpesch based on work from Tosbaa (Bilo)",
    version = "0.0.2",
    kind = "program",
    description = ('Control iTunes via COM'),
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABEAAAARCAIAAAC0D9CtAAAABGdBTUEAALGPC/xhBQAA"
        "AwdJREFUOE9tU0tME0EYnqoHCfGiXjzoSS968KAHL3jxYAwcEOPJg8H4SDTxgQoaUAwa"
        "BRMVDT6wKDXQoOXVQIvlYVtxkYcWl7S0S7sty7J9bakg9AG783C2Gk9+2Ux2JvP938z/"
        "faPDGIMcCCE6nQ5gBNfRlQ0bECbrdIDo6AAIAutVQDYSQCcAUA4Fyo0QQowQIf8+WocC"
        "QoJcvjiEiELT0PbTGV3PIbOaiYdlTki0Dvpq3k4W3/lSUMbsvOTML+wPizIhtCblQEpd"
        "IxivKtA84X5lCjLDktnC5hczB6uFonqxyCDteyKB3W0JeVGrqmg6CoFkLZV+L42eEfl7"
        "H2SbY7nD6t3fGN1azYHzQXBiakelHxxql2MLGkelHKRiTIKy82Givk76WDk7V9shdlkX"
        "95y2PraGx4OxbDpLj3Tqvp3zh+kPgQhQkXQm5Z3Xc1mjVWm5+9N09tvI5df+01fe+UPT"
        "2lkgXCao5PZA3wCb64gCEMFLclzme6NcNx9o9EafvZqo63EtXLjaFpqPWIYYjg8HxcDR"
        "8r7+3h8IqYgo1BYUkcSo5IqEvoneEYm1jQ90Wqbil8tbfy39ZIaGPCOmNG8rudY9bh9e"
        "Xo5gQjQrk8mkfybo4+bcHn7sR4B1T38YTZyraJ2fF8qML52phnDccOS64bO9IZkQMNXR"
        "DIXQO+11i0nPnBzNoGw21cHEjpU+u1nZX2B0XnSMVY3Imw8PDwmvV34J1F9AraVS7BQb"
        "S61Cgq1f2Rt2YW+teKmis9sYfGBR8god+c0QHHfV8GZCL0TWNB0amUCA++5yU/KuYmPe"
        "UwJuxU7WOnu62JaepQM1nk1Vwjb9pGUhoDmJiMZRVXU2GGpqesN8YuwzqS1lzu0Vzkdm"
        "vmvA//ItaxxTSidWmjzuKMfRgGHN05xOJp11h/zNL/TPG2pnfGFmKmob832y821GVt88"
        "aWixMk77ajaDVdpsrN3nT1pp8BRVicXlfvuguddqau82mtraezsdDltEEnJ7aAY0/OVo"
        "ryCHP+n+L7QO5/Ab5KCpr+DlMAIAAAAASUVORK5CYII="
    )
)

import wx
import pythoncom
from win32com.client import Dispatch, DispatchWithEvents
from win32gui import SendMessageTimeout
from win32con import SMTO_BLOCK, SMTO_ABORTIFHUNG
from threading import Event, Thread

   
class EventHandler:
       
    def OnPlayerPlayEvent(self, Track):
       eg.plugins.iTunes.TriggerEvent("TrackPlay")
    
    def OnPlayerPlayingTrackChangedEvent(self, Track):
       eg.plugins.iTunes.TriggerEvent("TrackChanged")

    def OnPlayerStopEvent(self, Track):
       eg.plugins.iTunes.TriggerEvent("TrackStop")

    def OnSoundVolumeChangedEvent(self, NewVolume):
       eg.plugins.iTunes.TriggerEvent("VolumeChanged")

    def OnAboutToPromptUserToQuitEvent(self):
       eg.plugins.iTunes.iTunesApp = None 
       
       
class iTunes(eg.PluginClass):

    def __init__(self):
       self.iTunesApp = DispatchWithEvents("iTunes.Application", EventHandler)
       self.AddAction(Play)
       self.AddAction(Pause)
       self.AddAction(PlayPause)
       self.AddAction(Stop)
       self.AddAction(PreviousTrack)
       self.AddAction(NextTrack)
       self.AddAction(Rewind)
       self.AddAction(FastForward)
       self.AddAction(StartItunes)
       self.AddAction(GetArtistName)
       self.AddAction(GetTrackName)
       self.AddAction(ShowInfoOSD)  
       self.AddAction(ToggleVisuals)  

    def initItunes(self):
       if self.iTunesApp is None:
         self.iTunesApp = DispatchWithEvents("iTunes.Application", EventHandler)
         #comEvents = self.iTunes.Events

    def showOSD(self):
        self.initItunes()  
        track = self.iTunesApp.CurrentTrack
        eg.plugins.EventGhost.ShowOSD(track.Artist + ": " + track.Name, None, (255, 255, 255), (0, 0, 0), 5, (0, 50), 0, 3)       
        #comEvents = self.iTunes.Events

    
    
class Play(eg.ActionClass):

    def __call__(self):
         self.plugin.initItunes()
         return self.plugin.iTunesApp.Play() 

class Pause(eg.ActionClass):

    def __call__(self):
         self.plugin.initItunes()
         return self.plugin.iTunesApp.Pause() 

class PlayPause(eg.ActionClass):

    def __call__(self):
         self.plugin.initItunes()
         return self.plugin.iTunesApp.PlayPause() 

class Stop(eg.ActionClass):
    
    def __call__(self):
        self.plugin.initItunes()  
        return self.plugin.iTunesApp.Stop()        

class NextTrack(eg.ActionClass):

    def __call__(self):
         self.plugin.initItunes()
         return self.plugin.iTunesApp.NextTrack()
         
class PreviousTrack(eg.ActionClass):
    
    def __call__(self):
         self.plugin.initItunes()  
         return self.plugin.iTunesApp.PreviousTrack()        

class Rewind(eg.ActionClass):

    def __call__(self):
         self.plugin.initItunes()
         return self.plugin.iTunesApp.Rewind()

class FastForward(eg.ActionClass):

    def __call__(self):
         self.plugin.initItunes()
         return self.plugin.iTunesApp.FastForward()

class StartItunes(eg.ActionClass):
    
    def __call__(self):
      if self.plugin.iTunesApp is not None:
        self.plugin.iTunesApp = Dispatch("iTunes.Application")   
        
class GetArtistName(eg.ActionClass):
    
    def __call__(self):
        self.plugin.initItunes()  
        return self.plugin.iTunesApp.CurrentTrack.Artist         
        
class GetTrackName(eg.ActionClass):
    
    def __call__(self):
        self.plugin.initItunes()  
        return self.plugin.iTunesApp.CurrentTrack.Name         

class ShowInfoOSD(eg.ActionClass):
    
    def __call__(self):
        self.plugin.showOSD()  

class ToggleVisuals(eg.ActionClass):

    def __call__(self):
         self.plugin.initItunes()
         self.plugin.iTunesApp.VisualsEnabled = 1 - self.plugin.iTunesApp.VisualsEnabled