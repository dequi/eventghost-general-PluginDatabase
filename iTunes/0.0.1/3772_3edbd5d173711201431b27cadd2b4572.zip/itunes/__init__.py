version="0.1.10"

# Plugins/itunes/__init__.py
#
# Copyright (C)  2009 jitterjames  <jitterjames@gmail.com>
#
# This file is part of EventGhost.
#
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#Last change: 

eg.RegisterPlugin(
    name = "iTunes",
    author = "jitterjames",
    version = "0.0.1",
    kind = "program",
    createMacrosOnAdd = True,
    description = (
        'Adds support functions to control '
        '<a href="http://www.apple.com/itunes/">iTunes</a>. \n\n<P>'        
    ),
    url = "http://www.eventghost.org/forum/viewtopic.php?t=noneyet",
        icon = (
        "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEA"
        "mpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iA"
        "lEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKO"
        "g6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEK"
        "JHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThL"
        "CIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCR"
        "ACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUp"
        "AAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2"
        "YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+r"
        "cEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ"
        "2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc"
        "5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+"
        "AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQk"
        "LlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiG"
        "zbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggX"
        "mYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGy"
        "UT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAu"
        "xsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKgg"
        "HCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQ"
        "AkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJA"
        "caT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJ"
        "S6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3"
        "GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XL"
        "VI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGg"
        "sV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H"
        "45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1F"
        "u1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5M"
        "b6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX"
        "4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN"
        "1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l"
        "1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N"
        "/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dn"
        "F2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0"
        "nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5y"
        "n+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8"
        "Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGL"
        "w34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6"
        "P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIs"
        "OpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkk"
        "xTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+"
        "xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zv"
        "n//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0m"
        "ek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3Hjl"
        "G4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7"
        "g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttV"
        "AVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cO"
        "xx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptT"
        "mvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ7"
        "52PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLua"
        "rrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn"
        "7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbr"
        "njg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv"
        "28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMz"
        "LdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAC+JJ"
        "REFUeNqUl3mMXfV1xz93fffty7xl3pvNM4PH47HxFmwCtjEIswQMVAkkiLaotE1RaJWl"
        "SkqIqKyKpaFSFeIkhqQNCqEJlBZcKGDAxIZ4wWDAGOOx8Xg8Hs/25r03b9/u8u7tH35O"
        "7Cp/tEf66ScdXZ3z+Z7f+V2dn2DbNhea4zg4joMgCIiCAIIAwBuv7ySbzfLKa6/7R1au"
        "HM5kckFFkaWA11txTH0yGgnOJJNdrF9/JamePgBsx0E4HxcQEfido23CHwKwbQdZlgAo"
        "l/Ps+u3BVbv2Hbp9bDp9Rbyrb5nj2IlLF/eRjEWpmg6VWq1ZXcge89P8qF6tvaK63S/f"
        "cdsWli4Z+r2o/w+AKIoAfHj0+FUP/eTp7x04NnaDL9xJLBZhIBFhsKuDvniIWDiEFooS"
        "6EjQkezAr8F8ucbR3W+fMnTjqVXLhp9YvniwqLlUbMf5vwEI7ZJvf27HD773yL99s1RW"
        "ifRoLF4UoC8WJOjz4gsG8PuDhIIBouEQiWgHqUSCSDKCV4JgO9b0fC4nS9JDkaBvm6oo"
        "/CG7CKCdXP3WP21/8/F/3L4Jf5z+rhV0RmSUUB3J5cZRPWjeIOFQgEgkgN8XIhT00xWL"
        "MDjQSyrqJaXARelarZeQpC8C9v8GkLZu3XqR8q8/9sT+bQ88tp6+JPHuEG7JpN7UyDeh"
        "io0kq2iKildT8KgiEmBbFtVKhZPpIhmXn1SHRuB86xkGTd0YninXrnxi566ZciGvD/X2"
        "VM4DyBee+c+ef+WpH333ocvpGyQYD9NyTNJGBdmU8ZgeRNHAFHR0u07ZKmHX3Ui2ja3r"
        "eIMBCEWIRl3ku0bAcShaNqcaBp8gMa24r3s13HXdT+KRO4F//x3A+a44NTl99b3fevQe"
        "VB+q14VVN6lJEi5FxLELtBpVRCQsoUW91UC0fBiVAv2XDLDh1usIRDuIBwJ0BgO4ZBlL"
        "EDE1ibwPsgbMGxDq6+eNvbv8f5SKg9eL49jIongO4L5HntxGpoi2fDGtuk6t3MQTCiDL"
        "GorSwC3VcEwfRlNCUFrIZotKucSK5BVs3nglFuek1IBRA45acLDhcKRUZaJcgZYNLYvI"
        "bOY7B36z+6krb73FFgQBGeCtdw+t3/X2R5dKS/pxa25KtoiMhdNq4XIE3F4fTcdCsnUc"
        "3U9LMVHUGn1RP16/hx0tOGHDexU4qTsUdBvyC5Cfh1qRPrcL2eVhPD3P3X9+99DBZ/71"
        "G73jJ3/QPTiEjG3xxPO7/hi3n1TCS7FhoGgCHkUER0ASwNBdCLIP3GXqNZ2RcBcb1l9S"
        "TMGJszrBJ3P20mP5DOtTnayZmyCeO8PKzk5ig2FUK8qKSIgDU0W+dvwE7lCQUvfKB5/9"
        "jxd+/J3vPmDK+/btlV5658PN4c4uPF6BaquB5lLRZAlFsHEE0A0B0VFZqFW57rIlzuN/"
        "d/94f39y1KwZ+54dm1vxw4q+VP7Kff9w46aOVQ9se+y20UM6aZdDuLsb0wBZh2JzHgSR"
        "6bF5lqy7JvLyR/u2YNZ3yKMT03HB7euORXwIErhtAZ8ELklAlhwMS0BxO8xlDHqjnWy9"
        "94vz/f3JCtCheNWRFav6kvXDs6wJLx//+x8//bDlW/bqzd/ecv1b702wzOoioYlYpk6l"
        "XgVFI58vEB9McNb0/unH7727Q+ocGBlOix33JcIeWoKCKEDE78bv0dA0DVl1YYkyTUfh"
        "/rtuKKweTJSqTTsQ8AeS6empk8+88Y75Qeei5T3vTx65I3V99nimeTgW06/XvI4/ky4j"
        "izJ2vcLJSoODhsWIpNAfSPLJ2KT2/LaHtsmFaiNpOiGCgQhWTUeVRUIeGZciASJ6y6FZ"
        "NVnZtcjZfOXaifn50/Lw8sHO3+7dd/ima666v/eWL10T/f61X1m9dli4YyC2wrOoszhZ"
        "mN119Ox7d2cXJlEkN4ajU206oGoUynXmp/L4Ip2pvZNzSbneaIg+Xx/eQICG2ABdwu9X"
        "8agSoijQaNmYbpnBrlgrFYt9ZhTSsVKpEP/rv/rq9wdSycyvf/1c69Ln32Gh+XFl3e1/"
        "O4iA4J3zlLe/8xaYs0TCPTiygiEpEIhRSGfIzpxhNld0bb719kvkUn5hxrfERyAcoCko"
        "WIqEP6jiUUQkUURzRBxDJByLSZLfN9HR1ZP+7737Xel6o7l5oJ8utyQmsIlHvUMILAIW"
        "PG5BsiyNUjbLrH8MMdCD43OD4qJSr5GlRcNo4PaHQnJ+8sSZ4NLrqoFQzGc6JWoyeNwy"
        "AbcLzaViImFXW6zuTwmfFCraZF7f89q+g0mxZ/Hao4X8niee+qVx7edu5KsDG7cAVUCc"
        "K9bC43MFPLUmmekxtISXqhOBloPeaFK0DHKZDCtDUkM2K4UFq1Gb9sVSw6oiky0o+L0C"
        "HQEPAbeCLUp0pHz0DnQRdqpf/tqOt17Kfnb6kGPWl1kDIzcXBG1Lp9eDKohlWqZlmEZs"
        "+7/8onf801GWDvrJTn6KO2dSWb4BDBOaDcp1kUap7FSd7KQ8PjnlrK1mD4SS3cOqJmIr"
        "PjxSnUjEQ9jtxh0M0fT5ySlwhdfX/eBVa7be/sPHHhGs2c4Nl39uxcjIpckPdYsPPjhS"
        "r9iZ5tOvvj58aNYI3//o3xDt6ubI2XHGDh2lWS1BfgGhXqFkSsyNfpK97C83TUkA5cy0"
        "uP5PvnHnopgPj8eL7Qj0RIL4OmOIHo3TE59ijB0iP32WtWvW9Pdetm71fHFBUGvpcn/f"
        "kDTT0b+q9P5rhQ9efzM6qns6v/6j7Vy9fBGqJ4gR72c0sYTRRotWZpZ4bpZivkG5OHdk"
        "6z1bfioDSnVuYvf4+2+PbfyLqxenKm6mFpKYioQnDpOjx5E/O4DfF2A+PkizYnPzDZtW"
        "rL1h04rde94rpptW/XiujG8qPZwfnRBXfPNRfD6F3aNZXpwsMjafx9CbGNU6FPM0KhUm"
        "Jwp8Yd3wi+s2XoMERIF8fvq0c+e999zU44JgUKQuwyUKiLkZzJkJmv2X4R9cxiLZoVrV"
        "qVQs5v3d2rNF1X/49ByJ+VOCWD1DbskGRlsJfvnRGKdOzVDLpmlm0pDPIOkVahNTiLrO"
        "jn/+9t0dkY6aBHQA4dLc2ROLVl99/ReGF8U9AnQrEAPibo1jp47xqZwiFuwgV63xwkSe"
        "X53IsPP4FJOnpyB9lnVBLyEjy/FikUNWJ/r4GDTyUC2eW/UqcqOEWNHZtDj2czs7/uze"
        "AwcRgKF2FcqBROrzH83M/GxQunh2/ezoHh78uIrdvZajU9OMpctQrUC9CPUS1HL82Ugf"
        "Htvk0P6XOJ5cSSN1Ka2FHNQqYBqoHhHj8PvcuGpNs3bi7b69+/ZnACRgoA3Qq9cq+cMf"
        "HjHuuevOVRcCRBO9zOSmePzdNPl0CUrzUJyDwjzUynRYRVYnwlSlMOWFOhzbj5mZQmxV"
        "0GQDdyNP/chBlqW66WjM3r9n15tvOeeH0nYF+oEAED87duLU2cyCfNvNNy3+PYLIkOrw"
        "zt6dzExMgl4BqwnNCqRPssrt0NU3RFk3MSUV1R0gUsgRLuhI+TK5M6dZPrCU5Z3aK2/8"
        "13OP6ZZtAq3zAAYQB7qAEKB9/MH7x46fOm1tueWWIUU6N7NZgsqgU8OeO45YnMFdz+Mv"
        "zTKkwtKRVcjhKJpoEVQFopEgrlQfVZLUGgku3/B5BkONN1995qdPVhqWAVQAE3AEQAUS"
        "wDJgCdDT9pX6Fy+55OGHH1l/15e/1AOQA8ZrBoVPT9Kcn6VpGuAL08SmXipRazbJFuuc"
        "ydWYKdbxaSopQTLyJ3a/vvPlF141YRo4BmSBJmBL5yZjnHb8OWABsIBwMb9gvPifz2d3"
        "vrHLtkUp2DM0pMS8Gr3dccJLBgn3DhEKhYj5NVyqRlXQqKNCyyJolWhNfXzmyG9+9dL+"
        "dw++acMEMAoU2upbtAdZkXMPGQ1wtX0uIAJ0cu42RoGlwUBg6RUbN3avv/aGVDCWUmWX"
        "hoCNpTfILxSYmZ1hburMwtRnx87Onhn/JJMv7QFOAPNt1XY7sdkWfdF1E9s9obR3of2x"
        "0/YFLlih9v/De0EF9XYVM+19ASi3qylfEO+i59n/DABeCGc+Nsi5aAAAAABJRU5ErkJg"
        "gg=="
    ),
)



from win32com.client import Dispatch
from eg.WinApi.Utils import CloseHwnd
import time
import datetime
import wx.lib.masked as masked
from os.path import isfile
import win32com.client
import eg

#====================================================================
class Text:

    
    mainGrpName = "Main control of iTunes"
    mainGrpDescr = "Here you find actions for main control of MediaMonkey."
    levelGrpName = "Another control of iTunes"
    levelGrpDescr = (
        "Here you find further actions for control of iTunes"
        " (volume, balance, seek)."
    )
    
#====================================================================
class iTunes(eg.PluginClass):
	def __init__(self):
		self.AddAction(Play)
		self.AddAction(Pause)
		self.AddAction(Stop)
		self.AddAction(GetAlbum)
		self.AddAction(GetArtist)		
		self.AddAction(GetTitle)		
		self.AddAction(SetVolume)
		self.AddAction(Next)
		self.AddAction(Previous)
		self.AddAction(ToggleMute)		

class Play(eg.ActionBase):
	def __call__(self):
		iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")	
		iTunes.Play()

class Pause(eg.ActionBase):
	def __call__(self):		
		iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
		iTunes.Pause()

class Stop(eg.ActionBase):
	def __call__(self):		
		iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
		iTunes.Stop()


#====================================================================
class GetAlbum(eg.ActionClass):
    name = "Get Album"
    description = "Get Current Playing Album."
    def __call__(self):
	iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
	return iTunes.CurrentTrack.Album

#====================================================================
class GetArtist(eg.ActionClass):
    name = "Get Artist"
    description = "Get Current Playing Artist."
    def __call__(self):
	iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
	return iTunes.CurrentTrack.Artist

#====================================================================
class GetTitle(eg.ActionClass):
    name = "Get Title"
    description = "Get Current Playing Song Title."
    def __call__(self):
	iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
	return iTunes.CurrentTrack.Name


#====================================================================
class SetVolume(eg.ActionClass):
    name = "Set Volume Level"
    description = "Sets the volume to a percentage (%)."
    class text:
        label_tree="Set volume "
        label_conf="Volume Level:"
    def __call__(self, volume):
	iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
	iTunes.SoundVolume = volume;


    def GetLabel(self, volume):
        return self.text.label_tree+str(int(volume))+"%"

    def Configure(self, volume=100.0):
        panel = eg.ConfigPanel(self)
        volumeCtrl = eg.SpinNumCtrl(
            panel,
            -1,
            volume,
            max=100.0,
            fractionWidth=1
        )
        panel.AddLabel(self.text.label_conf)
        panel.AddCtrl(volumeCtrl)
        while panel.Affirmed():
            panel.SetResult(volumeCtrl.GetValue())


#====================================================================
class Next(eg.ActionClass):
    name = "Next"
    description = "Next."

    def __call__(self):
	iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
	iTunes.NextTrack()


#====================================================================
class Previous(eg.ActionClass):
    name = "Previous"
    description = "Previous."

    def __call__(self):
		iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
		iTunes.PreviousTrack()

#====================================================================
class ToggleMute(eg.ActionClass):
	name = "Toggle Mute"
	description = "Toggle Mute."

	def __call__(self):
		iTunes = win32com.client.gencache.EnsureDispatch("iTunes.Application")
		if iTunes.Mute:
			iTunes.Mute = False
		else:
			iTunes.Mute = True