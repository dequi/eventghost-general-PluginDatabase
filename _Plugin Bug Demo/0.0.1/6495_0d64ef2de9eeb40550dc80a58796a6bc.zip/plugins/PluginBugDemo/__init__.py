# -*- coding: utf-8 -*-

#
# plugins/Standby/__init__.py
#
# Copyright (C) 2008 Stefan Gollmer
# v1.0.6 contributions and bug fixes by Daniel Brugger
#
# This file is part of EventGhost.
#
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#

import eg

eg.RegisterPlugin(
    name="_Plugin Bug Demo",
    author="Daniel",
    version="0.0.1",
    kind="other",
    guid="{1FDCD177-6481-46C2-B73F-C41A0F14402F}",
    description=(
        'Demonstrates a plugin bug: '
        'Modify the single value field => __stop__ / __start__ of the plugin is called after configuration (as expected). '
        'Add a new item to the table => __stop__ / __start__ is not called after configuration! '
        '(although the configuration is stored correctly) '
    )
)

from datetime import datetime as dt
import time
import wx


class PluginBugDemo(eg.PluginClass):

    def __init__(self):
        print "PluginBugDemo __init__"

    @eg.LogIt
    def __start__(self, value=0.0, itemList=[]):
        print "PluginBugDemo __start__"
        eg.PrintDebugNotice("PluginBugDemo __start__: value=" + str(value) + ", itemList=" + str(itemList))

    @eg.LogIt
    def __stop__(self):
        print "PluginBugDemo __stop__"

    @eg.LogIt
    def __close__(self):
        print "PluginBugDemo __close__"

    @eg.LogItWithReturn
    def Configure(self, value=50.0, itemList = []):

        def onItemSelection(event):
            enable = itemListCtrl.GetFirstSelected() != -1
            removeButton.Enable(enable)
            event.Skip()

        def onComboChange(event):
            name = itemCombo.GetValue()
            addButton.Enable(name != '')

        def onAddButton(event):
            name = itemCombo.GetValue()
            if name != '' and name not in itemList:
                itemList.append(name)
                itemList.sort()
                onRefreshButton(event)
            event.Skip()

        def onRemoveButton(event):
            item = itemListCtrl.GetFirstSelected()
            while item != -1:
                name = itemListCtrl.GetItemText(item)
                itemList.remove(name)
                item = itemListCtrl.GetNextSelected(item)
            onRefreshButton(event)
            removeButton.Enable(False)
            event.Skip()

        def onRefreshButton(event):
            itemListCtrl.DeleteAllItems()
            row = 0
            for name in itemList:
                itemListCtrl.InsertStringItem(row, name)
                row += 1
            itemCombo.Clear()
            itemCombo.AppendItems(getItemList())
            event.Skip()

        def getItemList():
            itemList = [ "item " + str(dt.now())[11:] + " " + str(c) for c in range(5) ] 
            return itemList

        panel = eg.ConfigPanel(self, resizable=True)
        tableSizer = wx.GridBagSizer(5,5)

        rowCount = 0
        valueCtrl = panel.SpinNumCtrl(value, min=0, max=99999, fractionWidth=0, integerWidth=5)
        tableSizer.Add(wx.StaticText(panel, -1, "Value"), (rowCount, 0), flag=wx.ALIGN_CENTER_VERTICAL)
        tableSizer.Add(valueCtrl, (rowCount, 1), flag=wx.ALIGN_RIGHT)

        rowCount +=1
        itemCombo = wx.ComboBox(panel, -1, value='', choices = [], size=(200,-1) )
        tableSizer.Add(wx.StaticText(panel, -1, "Item"), (rowCount, 0), flag=wx.ALIGN_CENTER_VERTICAL)
        tableSizer.Add(itemCombo, (rowCount, 1), flag=wx.LEFT | wx.ALIGN_CENTER_VERTICAL)

        addButton = wx.Button(panel, -1, "Add item")
        addButton.Enable(False)
        tableSizer.Add(addButton, (rowCount,2), flag=wx.ALIGN_RIGHT)

        itemListCtrl = wx.ListCtrl(panel, -1, style=wx.LC_REPORT | wx.VSCROLL | wx.HSCROLL)
        itemListCtrl.InsertColumn(0, "Item list")
        itemListCtrl.SetColumnWidth(0, 300)
        itemListCtrl.SetMinSize((300, -1))

        tableRows = 6
        rowCount += 1
        tableSizer.Add(itemListCtrl, (rowCount,0), (tableRows, 3), flag=wx.EXPAND)
        rowCount += tableRows

        removeButton = wx.Button(panel, -1, "Remove item")
        removeButton.Enable(False)
        tableSizer.Add(removeButton, (rowCount,0), flag=wx.ALIGN_LEFT)

        refreshButton = wx.Button(panel, -1, "Refresh items")
        tableSizer.Add(refreshButton, (rowCount,2), flag=wx.ALIGN_RIGHT)
        rowCount += 1

        panel.sizer.Add(tableSizer, 1, flag=wx.EXPAND)

        itemCombo.Bind(wx.EVT_TEXT, onComboChange)
        addButton.Bind(wx.EVT_BUTTON, onAddButton)
        itemListCtrl.Bind(wx.EVT_LIST_ITEM_SELECTED, onItemSelection)
        itemListCtrl.Bind(wx.EVT_LIST_ITEM_DESELECTED, onItemSelection)
        refreshButton.Bind(wx.EVT_BUTTON, onRefreshButton)
        removeButton.Bind(wx.EVT_BUTTON, onRemoveButton)
        onRefreshButton(wx.CommandEvent())

        while panel.Affirmed():
            value = valueCtrl.GetValue()
            panel.SetResult(value, itemList)
