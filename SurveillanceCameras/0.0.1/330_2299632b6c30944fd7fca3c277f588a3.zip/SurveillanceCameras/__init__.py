#
# plugins/SurveillanceCameras/__init__.py
#
# Copyright (C) 2013
# Walter Kraembring
#
##############################################################################
# Revision history:
#
# 2013-05-23  The first stumbling version
##############################################################################

eg.RegisterPlugin(
    name = "SurveillanceCameras",
    guid = '{D06E1E7D-9389-46DD-92AE-D9001118F121}',
    author = "Walter Kraembring",
    version = "0.0.1",
    canMultiLoad = False,
    kind = "external",
    url = "http://www.eventghost.org",
    description = (
        "A plugin used to define and configure surveillance cameras"+
        " for taking n numbers of snapshots when triggered"
    )
)

import datetime
import time
import os
import sys
import urllib2
from threading import Event, Thread


class Text:
    started = "Plugin started"



class SurveillanceCameras(eg.PluginClass):
    text = Text
        
    def __init__(self):
        self.AddAction(TakeSnapShots)
        self.started = False


    def __start__(
        self
    ):
        print self.text.started


    def __stop__(self):
        self.started = False


    def __close__(self):
        self.started = False



class TakeSnapShots(eg.ActionClass):

    class text:
        camera_txt = "Enter a name for the camera: "
        site_txt = "Enter the site name: "
        path_txt = "Enter the url to the camera: "
        folder_txt = "Enter the folder name for pictures: "
        nbrs_txt = "Select the number of snapshots to be taken: "

    name = "TakeSnapShots"
    description = "Takes a preconfigured number of snapshots from a camera."
    iconFile = "camera"

    def __call__(
        self,
        cameraName,
        sitename,
        path_to_camera,
        folder_for_images,
        nbr_of_images
    ):
        self.sitename = sitename
        self.path_to_camera = path_to_camera
        self.folder_for_images = folder_for_images
        self.nbr_of_images = nbr_of_images
        
        self.finished = Event()
        self.TakeSnapShot = Thread(
            target=self.TakeSnapShotThread,
            name="TakeSnapShots"
        )
        self.now = datetime.datetime.now()
        self.TakeSnapShot.start()


    def TakeSnapShotThread(self):
        while not self.finished.isSet():
            print "Capturing "+str(self.nbr_of_images)+" images..."
            for item in range(self.nbr_of_images):
                #print item
                image1 = urllib2.urlopen(self.path_to_camera)
                increment = str(item)
                filename = (
                    self.sitename +
                    "_" +
                    self.now.strftime("%y%b%d_%H-%M-%S.%f") +
                    "-" +
                    increment +
                    ".jpg"
                )
                if(
                    not os.path.exists(self.folder_for_images)
                    and
                    not os.path.isdir(self.folder_for_images)
                ):
                    os.makedirs(self.folder_for_images)
                output1 = open(self.folder_for_images + "\\" + filename,'wb')
                output1.write(image1.read())
                output1.close()
                self.finished.wait(0.5)
            print "Captured!"
            self.finished.set()
            time.sleep(0.1)
            print "Snap Shot action finished"


    def Configure(
        self,
        cameraName = 'camera name',
        sitename = 'sitename',
        path_to_camera = 'http://xxx.yyy.zzz.qqq:ppp/cgi-bin/CGIProxy.fcgi?usr=XXX&cmd=snapPicture2',
        folder_for_images = 'rptFolder',
        nbr_of_images = 50
    ):
        text = self.text
        panel = eg.ConfigPanel()

        cameraNameCtrl = wx.TextCtrl(panel, -1, cameraName)
        sitenameCtrl = wx.TextCtrl(panel, -1, sitename)
        path_to_cameraCtrl = wx.TextCtrl(panel, -1, path_to_camera)
        path_to_cameraCtrl.SetInitialSize((500,-1))
        folder_for_imagesCtrl = wx.TextCtrl(panel, -1, folder_for_images)
        snapShotCtrl = panel.SpinIntCtrl(nbr_of_images)
        
        panel.AddLine(text.camera_txt, cameraNameCtrl)
        panel.AddLine(text.site_txt, sitenameCtrl)
        panel.AddLine(text.path_txt, path_to_cameraCtrl)
        panel.AddLine(text.folder_txt, folder_for_imagesCtrl)
        panel.AddLine(text.nbrs_txt, snapShotCtrl)

        while panel.Affirmed():
            panel.SetResult(
                cameraNameCtrl.GetValue(),
                sitenameCtrl.GetValue(),
                path_to_cameraCtrl.GetValue(),
                folder_for_imagesCtrl.GetValue(),
                snapShotCtrl.GetValue()
            )
