# -*- coding: utf-8 -*-
#
# This file is a plugin for EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import eg

eg.RegisterPlugin(
    name = "New Broadcaster",
    author = "K, based on the work by Kingtd/Bitmonster",
    version = "0.01a",
    description = (
                "Listens for and Transmits UDP Broadcasts\n\n"
                "Updates:\n"
                "Changed how the parsing of data took place\n"
                "Changed the asyncore out for threading\n"
                "Other minor code changes\n"
        ),
    guid = "{F35E0C15-F809-403C-96C6-F42AC06D12D5}",
    canMultiLoad = True
)

import wx
import os
import sys
import threading
import socket

class Text:
    eventPrefix = "Event prefix:"
    zone = "Broadcast zone:"
    port = "UDP port:"
    listenAddr = "Listening address:"
    selfBroadcast = "Respond to self broadcast"
    delim = "Payload delimiter"
    message_1 = "Broadcast listener on"
    message_2 = "Self broadcast is"
    sendport = "UDP port: (0 = default)"
    command = "Command:"
    payload = "Payload:"


class Server(threading.Thread):

    text = Text

    def __init__(self, plugin):
        super(Server, self).__init__()

        self.plugin = plugin
        self.running = False
        self.sock = None

    def Start(self, *args):
        try:
            self.t = threading.Thread(name='UDP Server', target=self.RunThread, args=args)
            self.t.start()
        except:
            self.t = False
            eg.PrintError("New Broadcaster: Server: Start: "+str(sys.exc_info()))
        finally:
            return self.t
        
    def RunThread(self, port, listenAddr, selfBroadcast, payDelim):

        self.selfBroadcast = selfBroadcast
        self.addresses = self.plugin.GetAddresses()
        self.port = port
        self.payDelim = payDelim

        if listenAddr in self.addresses:
            self.listenAddr = listenAddr
        else:
            addrs = socket.gethostbyname_ex(socket.gethostname())[2]
            self.listenAddr = addrs[0]

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.bind((self.listenAddr, self.port))
            self.sock = sock
            self.running = True
            eg.PrintNotice("New Broadcaster: Server: UDP Server has Started")
        except:
            eg.PrintError("New Broadcaster: Server: Failed to create socket "+str(sys.exc_info()))

        while self.running:
            data, addr = sock.recvfrom(1024)
            self.IncomingData(data, addr)

        try: self.sock.close()
        except: pass

        eg.PrintNotice("New Broadcaster: Server: UDP Server has Shutdown")

    def HandleConnect(self):

        text = self.text

        print "%s %s:%s. %s %s."  % (
                                    text.message_1,
                                    self.listenAddr,
                                    str(self.port),
                                    text.message_2,
                                    str(self.selfBroadcast)
                                    )
        pass

    def IncomingData(self, data, addr):
        self.HandleConnect()
        # Check if the sending address is any of our interfaces
        my_addr = addr[0] in self.addresses

        if (not my_addr) or self.selfBroadcast:
            bits = data.split(str(self.payDelim))
            kwargs = dict(suffix=bits[0])

            if len(bits) > 1:
                kwargs['payload'] = bits[1] if len(bits) == 2 else bits[1:]

            self.plugin.TriggerEvent(*kwargs)

    def Close(self):
        self.running = False
        return None

class UDPListener(eg.PluginBase):

    text = Text
   
    def __init__(self):
        self.AddAction(Broadcast)
        self.Server = None
  
    def __start__(
                self,
                prefix=None,
                zone="255.255.255.255",
                port=33333,
                selfBroadcast=False,
                payDelim="&&",
                listenAddr=""
                ):

        self.info.eventPrefix = prefix
        self.port = port
        self.payDelim=payDelim
        self.zone = zone
        self.listenAddr = listenAddr
        self.selfBroadcast = selfBroadcast

        server = Server(self)
        self.Server = server.Start(port, listenAddr, selfBroadcast, payDelim)

    def __stop__(self):
        try: self.Server = self.Server.Close()
        except: pass

    def __close__(self):
        try: self.Server = self.Server.Close()
        except: pass

    def GetAddresses(self):
        addresses = socket.gethostbyname_ex(socket.gethostname())[2]
        addresses.sort(key=lambda a: [int(b) for b in a.split('.', 4)])
        return addresses


    def Configure(
                self,
                prefix="Broadcast",
                zone="255.255.255.255",
                port=33333,
                selfBroadcast=False,
                payDelim="&&",
                listenAddr=""
                ):

        text = self.text
        panel = eg.ConfigPanel(self)
        addrs = self.GetAddresses()

        try: addr = addrs.index(listenAddr)
        except ValueError: addr = 0

        editCtrl = panel.TextCtrl(prefix)
        zoneCtrl = panel.TextCtrl(zone)
        portCtrl = panel.SpinIntCtrl(port, min=1, max=65535)
        listenAddrCtrl = panel.Choice(addr, addrs)
        selfBroadcastCtrl=panel.CheckBox(selfBroadcast)
        payDelimCtrl = panel.TextCtrl(payDelim)

        panel.AddLine(text.eventPrefix, editCtrl)
        panel.AddLine(text.zone, zoneCtrl)
        panel.AddLine(text.port, portCtrl)

        panel.AddLine(text.listenAddr, listenAddrCtrl)
        panel.AddLine(text.selfBroadcast,selfBroadcastCtrl)
        panel.AddLine(text.delim, payDelimCtrl)

        while panel.Affirmed():
            panel.SetResult(
                editCtrl.GetValue(),
                zoneCtrl.GetValue(),
                portCtrl.GetValue(),
                selfBroadcastCtrl.GetValue(),
                payDelimCtrl.GetValue(),
                addrs[listenAddrCtrl.GetValue()]
            )


class Broadcast(eg.ActionWithStringParameter):

    text = Text

    def __call__(self, mesg, payload="", port=0):
        res = self.bcastSend(mesg, payload, port)
        return res

    def bcastSend(self, eventString, payload="", port=0):

        def EvalData(data):
            try: return str(eval(data[1:-1])) if data[:4] == '{eg.' else str(data)
            except: return str(data)

        eventString = EvalData(eventString)
        payload = EvalData(payload)

        if port is None:
            sendToPort = self.plugin.port
        else:                
            sendToPort = int(port)
        
        addr = (self.plugin.zone, sendToPort)
        UDPSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # Create socket
        UDPSock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        if  payload == "None":
            UDPSock.sendto(eventString, addr)
        else:
            UDPSock.sendto(eventString+self.plugin.payDelim+payload, addr)
        UDPSock.close()

    def Configure(self, command="", payload="", port=""):

        text = self.text
        panel = eg.ConfigPanel(self)
        
        commandCtrl = panel.TextCtrl(command)
        payloadCtrl = panel.TextCtrl(payload)
        portCtrl = panel.SpinIntCtrl(port, min=0, max=65535)
        commandlabel = panel.StaticText(text.command) 
        payloadlabel = panel.StaticText(text.payload)
        portlabel =panel.StaticText(text.sendport)
        panel.sizer.Add(commandlabel,0,wx.EXPAND) 
        panel.sizer.Add(commandCtrl,0,wx.EXPAND)
        panel.sizer.Add((20, 20))
        panel.sizer.Add(payloadlabel,0,wx.EXPAND) 
        panel.sizer.Add(payloadCtrl,0,wx.EXPAND)
        panel.sizer.Add((20, 20))
        panel.sizer.Add(portlabel,0) 
        panel.sizer.Add(portCtrl,0)
        panel.sizer.Add((20, 20))

        
        while panel.Affirmed():
            panel.SetResult(commandCtrl.GetValue(), payloadCtrl.GetValue(), portCtrl.GetValue())
