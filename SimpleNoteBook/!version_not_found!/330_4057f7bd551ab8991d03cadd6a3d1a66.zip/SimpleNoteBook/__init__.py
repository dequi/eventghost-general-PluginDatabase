import eg
import wx

eg.RegisterPlugin(
        name = "SimpleNoteBook",
)

print "MyNewPlugin module code gets loaded."



class MyNewPlugin(eg.PluginBase):

    def __init__(self):
        print "MyNewPlugin is inited."
        self.AddAction(PrintString)


    def __start__(self, myString):
        print "MyNewPlugin is started with parameter: " + myString


    def __stop__(self):
        print "MyNewPlugin is stopped."


    def __close__(self):
        print "MyNewPlugin is closed."


    def Configure(self, myString=""):
        panel = eg.ConfigPanel()
        textControl = wx.TextCtrl(panel, -1, myString)
        panel.sizer.Add(textControl, 1, wx.EXPAND)
        while panel.Affirmed():
            panel.SetResult(textControl.GetValue())



class PageOne(wx.Panel):

    def __init__(self, parent):
        wx.Panel.__init__(self, parent)
        t = wx.StaticText(self, -1, "This is a PageOne object", (20,20))



class PageTwo(wx.Panel):

    def __init__(self, parent):
        wx.Panel.__init__(self, parent)
        t = wx.StaticText(self, -1, "This is a PageTwo object", (40,40))



class PageThree(wx.Panel):

    def __init__(self, parent):
        wx.Panel.__init__(self, parent)
        t = wx.StaticText(self, -1, "This is a PageThree object", (60,60))



class PageFour(wx.Panel):

    def __init__(self, parent, iMinOnPeriod):
        wx.Panel.__init__(self, parent)
        t = wx.StaticText(self, -1, "This is a PageFour object", (80,80))

        pageSizer = wx.GridBagSizer(5, 5)

        pageSizer.Add(
            wx.StaticText(
                self,
                -1,
                "MinOnPeriod"
            ),
            (0,0)
        )
        
        iMinOnPeriod = wx.SpinCtrl(
                self,
                -1,
                pos=(0,20),
                size=(40,-1),
                style = wx.SP_ARROW_KEYS|wx.SP_WRAP,
                min=0,
                max=9,
                initial=0
        )
        
        pageSizer.Add(
            iMinOnPeriod,
            (5,0)
        )



class PrintString(eg.ActionBase):

    def __call__(self, myString, iMinOnPeriod):
        print myString


    def Configure(self, myString="", iMinOnPeriod = 5):
        panel = eg.ConfigPanel()
        sizer = wx.GridBagSizer(5, 5)

        # Here we create a panel and a notebook on the panel
        nb = wx.Notebook(panel)
        sizer.Add(nb,(0,0))

        textControl = wx.TextCtrl(panel, -1, myString)
        sizer.Add(textControl,(5,0))

        panel.sizer.Add(sizer, 0, wx.EXPAND)

        # create the page windows as children of the notebook
        page1 = PageOne(nb)
        page2 = PageTwo(nb)
        page3 = PageThree(nb)
        page4 = PageFour(nb, iMinOnPeriod)

        # add the pages to the notebook with the label to show on the tab
        nb.AddPage(page1, "Page 1")
        nb.AddPage(page2, "Page 2")
        nb.AddPage(page3, "Page 3")
        nb.AddPage(page4, "Page 4")

        while panel.Affirmed():
            panel.SetResult(
                textControl.GetValue(),
                iMinOnPeriod
            )

