# -*- coding: utf-8 -*-
#
# plugins/xPL/__init__.py
# 
# This file is a plugin for EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

eg.RegisterPlugin(
    name = "xAP",
    author = "K",
    version = "0.1a",
    canMultiLoad = False,
    kind = "external",
    guid = "{26649308-3137-4C33-A5D2-6F50DAE36A65}",
    description = "Send and receive xAP messages.",
    url = "",
)
    
import sys
#import string
#import select
import re
import socket
import wx
import threading
from time import sleep
from copy import deepcopy as dc


DEBUG = False

def log(*args):
    if DEBUG:
        args = list(args)
        data = ""
        for item in args: data += str(item)
        print data
    return DEBUG

class Text:
    textBoxLabel   = "xAP Msg Type: "
    textBoxLabel0  = "xAP Schema: "
    textBoxLabel1  = "xAP Target: "
    textBoxLabel2  = "xAP Message: "
    AddressText    = "Listening Address: "
    HeartBeatText  = "HeartBeat Events: "
    HostPrefixText = "Host Information as Prefix: "
    AllDataText = "Display all xAP Broadcasts: "
    class sendxAP:
        name = "Send xAP message"
        description = "Sends an xAP message"

class Server(threading.Thread):

    text = Text

    def __init__(self, plugin):
        super(Server, self).__init__()
        self.plugin = plugin
        self.UDPSock = False
        self.HBSock = False
        self.HBEvent = threading.Event()
        self.HBEvent.set()
        self.UDPEvent = threading.Event()
        self.UDPEvent.set()

    def Start(self, *args):

        log("Strating Server Thread")

        try:
            threading.Thread(name='xAP Server', target=self.RunListener, args=args).start()
        except:

            if not log("UDP thread wouldn't start: sysexec: ", sys.exc_info()):
                eg.PrintError("xAP: Server: Start: "+str(sys.exc_info()))
        
    def RunListener(self, port, listenAddr, hbeatEvent, hostPrefix):
        while self.UDPSock: sleep(1)

        listenAddr = listenAddr if listenAddr in self.plugin.GetAddresses() else 'localhost'

        log("listenAddr: ", listenAddr, "port: ", port)

        log("UDP server starting")

        try:

            log("opening socket")

            self.UDPSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.UDPSock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            if port is None:
                self.plugin.port = 50000
                while True :
                    try :
                        self.UDPSock.bind((listenAddr, self.plugin.port))

                        log("not allData bind sucess: self.plugin.port: ",  self.plugin.port)

                        break
                    except:

                        log("not allData bind failed: sysexec: ", sys.exc_info())

                        self.plugin.port += 1
            else:
                self.UDPSock.bind((listenAddr, port))

                log("allData bind sucess")

                self.plugin.port = port

            if not log("UDP server has started"):
                eg.PrintNotice("xAP: Server: UDP Server has Started")
        except:

            if not log("opening socket failed: sysexec: ", sys.exc_info()):
                eg.PrintError("xAP: Server: Failed to create socket "+str(sys.exc_info()))

        log("starting heartbeat")

        try:
            threading.Thread(name='xAP HeartBeat', target=self.RunHeartBeat).start()
            self.UDPEvent = threading.Event()
        except:

            if not log("heartbeat thread wouldn't start: sysexec: ", sys.exc_info()):
                eg.PrintError("xAP: HeartBeat: Start: "+str(sys.exc_info()))

        while not self.UDPEvent.isSet():
            data, addr = self.UDPSock.recvfrom(1500)
            if not self.UDPEvent.isSet():
                self.IncomingData(data, addr, hbeatEvent, hostPrefix)

        log("UDP server shutting down")

        try: self.UDPSock.close()

        except: log("UDP server socket close error: sysexec: ", sys.exc_info())

        self.UDPSock = False

        if not log("UDP server has shutdown"):
            eg.PrintNotice("xAP: Server: UDP Server has Shutdown")

    def RunHeartBeat(self):
        while self.HBSock: sleep(1)

        self.HBEvent = threading.Event()
        self.HBSock = True

        if not log("heartbeat has started"):
            eg.PrintNotice("xAP: Server: HeartBeat has Started")

        while not self.HBEvent.isSet():
            msg = self.plugin.Message('xap-hbeat', 'xap-hbeat.alive', '*', xAPinterval='60', xAPport=str(self.plugin.port))

            log("outgoing heartbeat message: ", [msg], ", self.plugin.port: ", self.plugin.port)

            self.Send(msg, 3969)
            self.HBEvent.wait(60)

        log("heartbeat shutting down")

        self.HBSock = False

        if not log("heartbeat has shutdown"):
            eg.PrintNotice("xAP: Server: HeartBeat has Shutdown")
        

    def IncomingData(self, data, addr, hbeatEvent, hostPrefix):
        xAPType = None
        payload = None

        log("<     data: ", [data])

        data = data.split('}\n')
        data.pop()

        log("<     split: ", [data])

        for i in range(len(data)):
            try:
                trim = data[i].find('\n')
                xAPType = data[i][:trim]

                log("<     xAPType: ", xAPType)

                data[i] = data[i][trim+1:].replace('\n', '","').replace('=', '":"')
                data[i] = '{'+data[i][3:-2]+'}'

                log("<     reformatted: ", [data])

                if payload: payload.update(eval(data[i]))
                else: payload = eval(data[i])

                log("<     payload: ", payload)

            except:
                log("<     error: ", [data], ", sysexec: ", sys.exc_info())

                xAPType = None

        if xAPType:
            presuf = [dc(payload['source']) \
                        if 'source' in payload \
                            and (xAPType != 'xap-hbeat' or hbeatEvent) \
                        else None]
            presuf.append(None if 'class' not in payload \
                            else 'xAP'+dc(payload['class'])[3:].title() if payload['class'].find('hbeat') > -1 \
                            else  dc(payload['class']))

            log("<     presuf: ", presuf, ", payload: ", payload)

            prefix = presuf[0]
            suffix = presuf[1]
            if not hostPrefix:

                log("<     not hostPrefix")

                prefix = presuf[1]
                suffix = presuf[0]

            if prefix and suffix:

                log("<     triggering event: prefix: ", prefix, ", suffix: ", suffix, ", payload: ", payload)

                eg.TriggerEvent(prefix=prefix, suffix=suffix, payload=payload)
            else:

                log("<     no event: prefix: ", prefix, ", suffix: ", suffix, ", payload: ", payload)

    def Send(self, msg, port):

        log(">     msg: ", [msg],  ", port: ", port)

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST,1)
        sock.sendto(msg,("255.255.255.255", port))
        self.UDPSock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def Stop(self):

        log("stopping server")

        if self.UDPSock:
            self.HBEvent.set()
            msg = self.plugin.Message('xap-hbeat', 'xap-hbeat.end', '*',  xAPinterval='60', xAPport=str(self.plugin.port))

            log(">     msg: ", [msg], ", self.plugin.port: ", self.plugin.port)

            self.Send(msg, 3969)
            if self.plugin.port != 3969:
                self.Send(msg, self.plugin.port)
            self.UDPEvent.set()

class xAP(eg.PluginBase):

    text = Text

    def __init__(self):
        self.localIP = socket.gethostbyname(socket.gethostname())
        self.hostname = "EventGhost."+str(socket.gethostname())
        self.Server = Server(self)           
        self.AddAction(sendxAP)

    def __start__(
                self,
                listenAddr="All Connections",
                hbeatEvent=False,
                hostPrefix=False,
                allxAPData=True
                ):

        port = 3639 if allxAPData else None
        self.Server.Start(port, listenAddr, hbeatEvent, hostPrefix)

    def __stop__(self):
        self.Server.Stop()

    def __close__(self):
        self.Server.Stop()

    def GetAddresses(self):
        addresses = socket.gethostbyname_ex(socket.gethostname())[2]
        addresses.sort(key=lambda a: [int(b) for b in a.split('.', 4)])
        return addresses

    def Message(self, xAPheader, xAPclass, xAPtarget, xAPinterval=None, xAPport=None, xAPtype=None, xAPmsg=None):     
        msg = xAPheader+"\n"
        msg += "{\n" 
        msg += "v=13\n"
        msg += "hop=1\n"
        msg += "uid=FF999900\n"
        msg += "class="+xAPclass+"\n"
        msg += "source="+self.hostname+"\n"
        msg += "target="+xAPtarget+"\n"
        msg += "interval="+xAPinterval+"\n" if xAPinterval else ''
        msg += "port="+xAPport+"\n" if xAPport else ''
        msg += "}\n"
        msg += xAPtype+"\n" if xAPtype else ''
        if xAPtype is None: return msg
        msg += "{\n"
        msg += xAPmsg+"\n" if xAPmsg else ''
        msg += "}\n"
        return msg

    def Configure(
                self,
                listenAddr="",
                hbeatEvent=False,
                hostPrefix=False,
                allxAPData=True
                ):

        text = self.text
        panel = eg.ConfigPanel(self)

        addrs = self.GetAddresses()
        addrs.insert(0, 'All Connections')

        try: addr = addrs.index(listenAddr)
        except ValueError: addr = 0

        st1 = panel.Choice(addr, addrs)
        st2 = panel.CheckBox(hbeatEvent)
        st3 = panel.CheckBox(hostPrefix)
        st4 = panel.CheckBox(allxAPData)

        panel.AddLine(text.AddressText, st1)
        panel.AddLine(text.HeartBeatText, st2)
        panel.AddLine(text.HostPrefixText, st3)
        panel.AddLine(text.AllDataText, st4)

        while panel.Affirmed():
            panel.SetResult(
                            addrs[st1.GetValue()],
                            st2.GetValue(),
                            st3.GetValue(),
                            st4.GetValue()
                            )

class sendxAP(eg.ActionClass):
    text = Text

    def __call__(self, xAPtype, xAPclass, xAPtarget, xAPmsg):
        xAPMessage=re.compile('\r')
        xAPMessage.sub('',xAPmsg)
        xAPMessage=re.compile('\n ')
        xAPMessage.sub('\n',xAPmsg)
        msg = self.plugin.Message('xap-header', xAPclass, xAPtarget, xAPtype=xAPtype, xAPmsg=xAPmsg)
        self.plugin.Server.Send(msg, 3969)
        
    def Configure(
        self, 
        xAPtype="",
        xAPclass="",
        xAPtarget="",
        xAPmsg=""
        ):

        text = self.text

        panel = eg.ConfigPanel(self)
        plugin = self.plugin
        
        textType = wx.TextCtrl(panel, -1, xAPtype)           
        staticBox = wx.StaticBox(panel, -1, text.textBoxLabel)
        staticBoxSizer = wx.StaticBoxSizer(staticBox, wx.VERTICAL)
        sizerz = wx.BoxSizer(wx.HORIZONTAL)
        sizerz.Add(textType, 1, wx.EXPAND)
        staticBoxSizer.Add(sizerz, 0, wx.EXPAND|wx.ALL, 10)
        panel.sizer.Add(staticBoxSizer, 0, wx.EXPAND)
        
        textClass = wx.TextCtrl(panel, -1, xAPclass)           
        staticBox = wx.StaticBox(panel, -1, text.textBoxLabel0)
        staticBoxSizer = wx.StaticBoxSizer(staticBox, wx.VERTICAL)
        sizer = wx.BoxSizer(wx.HORIZONTAL)
        sizer.Add(textClass, 1, wx.EXPAND)
        staticBoxSizer.Add(sizer, 0, wx.EXPAND|wx.ALL, 10)
        panel.sizer.Add(staticBoxSizer, 0, wx.EXPAND)
        
        textTarget = wx.TextCtrl(panel, -1, xAPtarget)           
        staticBox = wx.StaticBox(panel, -1, text.textBoxLabel1)
        staticBoxSizer = wx.StaticBoxSizer(staticBox, wx.VERTICAL)
        sizer0 = wx.BoxSizer(wx.HORIZONTAL)
        sizer0.Add(textTarget, 1, wx.EXPAND)
        staticBoxSizer.Add(sizer0, 0, wx.EXPAND|wx.ALL, 10)
        panel.sizer.Add(staticBoxSizer, 0, wx.EXPAND)
        
        staticBox = wx.StaticBox(panel, -1, text.textBoxLabel2)
        staticBoxSizer = wx.StaticBoxSizer(staticBox, wx.VERTICAL)
        
        textMsg = wx.TextCtrl(panel, -1, xAPmsg, style=wx.TE_MULTILINE)
        sizer1 = wx.BoxSizer(wx.HORIZONTAL)
        sizer1.Add(textMsg, 1, wx.EXPAND)
        staticBoxSizer.Add(sizer1, 0, wx.EXPAND|wx.ALL, 5)
        
        panel.sizer.Add(staticBoxSizer, 0, wx.EXPAND)
        
        while panel.Affirmed():
            panel.SetResult(
                textType.GetValue(), 
                textClass.GetValue(), 
                textTarget.GetValue(), 
                textMsg.GetValue(), 
            ) 