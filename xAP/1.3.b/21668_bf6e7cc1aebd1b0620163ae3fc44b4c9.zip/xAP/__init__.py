# -*- coding: utf-8 -*-
# 
# This file is a plugin for EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

eg.RegisterPlugin(
    name = "xAP",
    author = "K",
    version = "1.3.b",
    canMultiLoad = False,
    kind = "external",
    guid = "{26649308-3137-4C33-A5D2-6F50DAE36A65}",
    description = "Send and receive xAP messages.",
    url = "",
)
    
import sys
import socket
import wx
import threading
from copy import deepcopy as dc
from eg.WinApi.Utils import GetMonitorDimensions

class PRINT:
    def __init__(self, plugin):
        self.plugin = plugin
     
    def Log(self, logStr, event):
        if event in self.plugin.debuggdEvents: print logStr

    def Notice(self, noticeString):
        eg.PrintNotice(noticeString)

    def Error(self, errorString):
        eg.PrintError(errorString)

class Text:
    textBoxLabel   = "xAP Msg Type: "
    textBoxLabel0  = "xAP Schema: "
    textBoxLabel1  = "xAP Target: "
    textBoxLabel2  = "xAP Message: "
    AddressText    = "Listening Address: "
    HeartBeatText  = "HeartBeat Events: "
    HostPrefixText = "Host Information as Prefix: "
    AllDataText = "xAP DebuggingMode: "
    VenDescText = ('You may leave this as is or if you would like to specify a name you may do so.\n'
                  'The name has to be 2 sections seperated by a "." and the first section of the name\n'
                  'cannot be longer than 8 characters. The second section is the device if you will,\n'
                  'I am not sure if there are any limitations for this. There is a 3rd section that \n'
                  'is automatically added and that is the computers hostname. If you would like to send\n'
                  'a command to EG from an xAP whatever is in this field with a "." and the computers\n'
                  'host name would be the target that would have to be entered into that devices xAP\n'
                  'transmission. If you find this not working then you have a special character that is\n'
                  'not supported.\n')
    VendorText = "Vendor Name: "
    VersDescText = ("Set to 1.2 if you don't know what version of xAP your devices use. If they use 1.3\n"
                   "they will be able to talk to EG because of backwards compatability. 1.2 uses a\n"
                   "identifier (electronic serial number) formatted like FF5AC000 and 1.3 is like\n"
                   "FF.5AC0E811:0000. Not enough room to explain about it.\n")
    VersionText = "xAP Version: "
    SocketErr = "xAP: Hub: Failed to open socket: "
    BindSucess = "xAP: Hub: UDP Hub has Started bound on Port: "
    BindErr = "xAP: Hub: Failed to open port: This plugin acts as a hub also, restarting Hub in 30 seconds"
    SocketClose = "xAP: Hub: UDP Hub has Shutdown"
    HeartOpen = "xAP: Hub: HeartBeat has Started"
    HeartClose = "xAP: Hub: HeartBeat has Shutdown"
    MalformedData = "malformed Data"
    MalformedException = "malformed Data Exception"
    TerminateLease = "Terminating forwarding lease"
    Port = "Port"
    NewLease = "New forwarding lease"
    RenewLease = "Renewing forwarding lease"
    Duration = "Duration"
    Seconds = "seconds"
    Prefix = "Prefix"
    Suffix = "Suffix"
    Payload = "Payload"
    TimeoutLease = "Host timed out removing from lease"
    Host = "Host"
    Data = "Data"
    UID = "UID"
    Message = "Message"
    Network = "Network"
    VersionBox = "Version"
    VendorBox = "Vendor Name"
    DebugFrame = 'xAP Debugging'
    IgnoreFrame = 'xAP Ignore'
    ColumnLabel = ["Source", "Message Type", "Message Schema", "Destination"]
    TableLabels = {
                    'DbgEvt': ["Debug Events Available", "Debug Event", "Debug All"],
                    'IgnEvt': ["Ignore Events Available", "Ignore Event", "Ignore All"],
                    'Dbg': ["Debug Events Selected", "Remove Debug Item", "Remove All Debugs"],
                    'Ign': ["Ignore Events Selected", "Remove Ignore", " Remove All Ignores"],
                    'Pnl': ["Refresh Tables", "OK", "Cancel"],
                    'Box': ['Debug xAP Events', 'Ignore xAP Events']
                    }
    class sendxAP:
        name = "Send xAP message"
        description = "Sends an xAP message"

class Hub:

    text = Text

    def __init__(self, plugin):
        self.plugin = plugin
        self.UDPSock = False
        self.HBEvent = threading.Event()
        self.UDPEvent = threading.Event()
        self.leaseData = []
        self.Print = PRINT(self.plugin)
        self.PN = self.Print.Notice
        self.PE = self.Print.Error
        self.Log = self.Print.Log
        self.port = self.plugin.port
        self.listenAddr = ''

    def Start(self, *args):
        self.startUp = True
        try:
            threading.Thread(target=self.RunListener, args=args).start()
            return True
        except:
            self.PE("xAP: Hub: Start: "+str(sys.exc_info()))
            return False

    def RunListener(self, port, listenAddr, hostPrefix):
        text = self.text

        while self.UDPSock: pass

        while self.startUp:
            try: self.UDPSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            except:
                self.UDPEvent.set()
                self.PE(text.SocketErr+str(sys.exc_info()))
            if self.UDPSock:
                serverMode = 'xAP Hub Mode Running'
                try:
                    self.UDPSock.bind((listenAddr, port))
                    self.startUp = False
                except:
                    listenAddr = '127.0.0.1'
                    port = 50000
                    self.UDPEvent.set()
                    while self.UDPEvent.isSet():
                        try:
                            self.UDPSock.bind((listenAddr, port))
                            self.UDPEvent.clear()
                            serverMode = 'xAP Application Mode Running'
                            self.startUp = False
                        except:
                            port += 1
                            if port > 51000:
                                self.PN('Socket Binding Error')
                                raise
                if not self.startUp:
                    self.port = port
                    self.plugin.serverMode = serverMode
                    self.listenAddr = listenAddr
                    self.PN(serverMode+": "+str(port))
                    threading.Thread(target=self.RunHeartBeat).start()
        while not self.UDPEvent.isSet():
            data, addr = self.UDPSock.recvfrom(1500)
            if not self.UDPEvent.isSet(): self.IncomingData(data, addr, listenAddr, hostPrefix)

        try: self.UDPSock.close()
        except: pass
        try: self.UDPSock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        except: pass
        self.UDPSock = False
        self.UDPEvent.clear()
        self.PN(text.SocketClose)

    def RestartHub(self, *args):
        self.PN("External Hub Offline: Restarting internal Hub")
        self.Stop()
        self.Start(*args)

    def RunHeartBeat(self):
        plg = self.plugin
        text = self.text

        self.PN(text.HeartOpen)
        plg.OUTSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        plg.OUTSock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST,1)

        msg, addr, port, evt = plg.Message('xap-hbeat', 'xap-hbeat.alive', xAPinterval='60', xAPport=self.port)
        while not self.HBEvent.isSet():
            plg.SendData(msg, plg.listenAddr, plg.port, evt)
            self.HBEvent.wait(60)
        try: plg.OUTSock.close()
        except: pass
        plg.OUTSock = False
        self.HBEvent.clear()
        self.PN(text.HeartClose)

    def IncomingData(self, data, addr, listenAddr, hostPrefix):
        plg = self.plugin
        text = self.text
        pData = {}
        payload = {}
        fData = data.split('}\n')
        fData.pop()

        for i in range(len(fData)):
            try:
                trim = fData[i].find('\n')
                pData['type'] = fData[i][:trim]
                fData[i] = fData[i][trim+1:].replace('\n', '","').replace('=', '":"')
                fData[i] = '{'+fData[i][3:-2]+'}'
                if pData: pData.update(eval(fData[i]))
                else: pData = eval(fData[i])
            except:
                self.Log('>     '+txt.MalformedData+": "+data, False)
                self.Log('>     '+txt.MalformedException+": "+str(sys.exc_info()), False)
                return

        for key in pData.keys():
            value = dc(pData[key])
            key = key[:-2].title()+'ID' if key[-2:] in ['id', 'ID'] else key.title()

            if value and value.find(' ') == -1 \
                        and value.find('.') == -1 \
                            and value.find(':') == -1 \
                                and value.find('/') == -1 \
                                    and value.find('-') == -1:
                value = value.capitalize()

            if value.count(':') == 5:
                macValue = [item.upper() for item in value.split(':') if len(item) == 2]
                value = ':'.join(macValue) if len(macValue) == 6 else value
            payload[key] = dc(value)

        Type = dc(payload['Type']) if 'Type' in payload else None
        Port = dc(payload['Port']) if 'Port' in payload else None
        Hbeat = dc(payload['Class']) if Type == 'xap-hbeat' else None
        Class = dc(payload['Class']) if 'Class' in payload else None
        Target = dc(payload['Target']) if 'Target' in payload else None
        Source = dc(payload['Source']) if 'Source' in payload else None
        Interval = int(dc(payload['Interval']))*2 if 'Interval' in payload else 120
        UID = dc(payload['UID']) if 'UID' in payload else None

        Hostname = self.plugin.hostname

        if Type is None: return
        Tar = Target if Target else '**NODATA**'
        Cla = Class if Class else '**NODATA**'
        Sou = Source if Source else '**NODATA**'
        newEvent = plg.CheckEvent([Sou, Type, Cla, Tar])
        self.Log(">     "+text.Data+": "+data, newEvent)

        if Hbeat and UID != plg.UID and addr[0] == listenAddr and listenAddr == plg.listenAddr:
            lease = text.TerminateLease if Hbeat.find('alive') == -1 else text.RenewLease
            try:
                idx = self.leaseData.index(newLease)
                newLease = self.leaseData.pop(idx)
                self.leaseData.pop(idx).cancel()
            except:
                newLease = [UID, Port]
                lease = text.NewLease

            lease += ": "+text.UID+UID+", "+text.Port+": "+Port
            if Port and lease.find(text.TerminateLease) == -1:
                lease += ", "+text.Duration+": "+str(Interval)+" "+text.Seconds
                tmr = threading.Timer(Interval, self.RemoveHost, args=[newLease])
                self.leaseData += [newLease, tmr]
                tmr.start()

            self.leaseData = [[False, False], False] \
                    if not self.leaseData else self.leaseData[2:] \
                    if self.leaseData[0][0] is False else self.leaseData

        elif Hbeat and plg.serverMode.find('Hub') == -1 \
                    and UID == plg.UID and int(Port) == self.port:
            try: self.appModeTimer.cancel()
            except: pass
            self.appModeTimer = threading.Timer(Interval, self.RestartHub, args=[plg.port, plg.listenAddr, hostPrefix])
            self.appModeTimer.start()

        for host in self.leaseData:
            try: plg.SendData(data, '127.0.0.1', int(host[1]), newEvent)
            except: pass

        presuf = [Source]
        presuf += ['xAP'+Class[3:].title() if Hbeat else Class]
        prefix = presuf[0] if hostPrefix else presuf[1]
        suffix = presuf[1] if hostPrefix else presuf[0]

        self.Log(">     "+text.Prefix+": "+prefix, newEvent)
        self.Log(">     "+text.Suffix+": "+suffix, newEvent)
        self.Log(">     "+text.Payload+": "+str(payload), newEvent)

        try:
            if Source[:15] == 'ersp.SlimServer':
                eg.plugins.LMS.Receive(dc(payload))
        except:
            pass

        if newEvent not in self.plugin.ignoredEvents:
            eg.TriggerEvent(prefix=prefix, suffix=suffix, payload=payload)

    def RemoveHost(self, lease):
        text = self.text
        if lease in self.leaseData:
            idx = self.leaseData.index(lease)
            self.leaseData.pop(idx)
            self.leaseData.pop(idx)
            self.Log(text.TimeoutLease+": "+text.UID+": "+lease[0]+", "+text.Port+": "+lease[1], False)

    def Stop(self):
        plg = self.plugin
        self.startUp = False
        while self.leaseData:
            try: self.leaseData.pop(0).cancel()
            except: pass
        try: self.appModeTimer.cancel()
        except: pass
        msg, addr, port, evt = plg.Message('xap-hbeat', 'xap-hbeat.stopped', xAPinterval='60', xAPport=self.port)
        plg.SendData(msg, plg.listenAddr, plg.port, evt)
        if self.listenAddr != plg.listenAddr:
            plg.SendData(msg, self.listenAddr, self.port, evt)
        self.HBEvent.set()
        self.UDPEvent.set()

class xAP(eg.PluginBase):

    text = Text

    def __init__(self): 
        self.AddAction(sendxAP)
        self.eventList = []
        self.debuggdEvents = []
        self.ignoredEvents = []
        self.serverStarted = False
        self.OUTSock = False
        self.port = 3639
        self.serverMode = 'xAP Server Not Running'
        self.Hub = Hub(self)

    def __start__(self, listenAddr="", UID=["FF5AC000", "FF.5BC0D811:0000"], hostPrefix=False, xAPvendor='EvntGhst.Hub',
                    xAPversion='1.3', debuggdEvents=False, ignoredEvents=False):
        self.StartUp(listenAddr, UID, hostPrefix, xAPvendor, xAPversion, debuggdEvents, ignoredEvents)

    def StartUp(self, listenAddr, UID, hostPrefix, xAPvendor, xAPversion, debuggdEvents, ignoredEvents):
        
        UID = ["FF5AC000", "FF.5BC0D811:0000"] if isinstance(UID, bool) else UID
        self.UID = UID[0] if xAPversion == "1.2" else UID[1]

        self.debuggdEvents, self.ignoredEvents = self.CheckOld(debuggdEvents, ignoredEvents)

        self.listenAddr = listenAddr if listenAddr in self.GetAddresses() else '0.0.0.0'
        self.xAPversion = xAPversion
        self.hostname = xAPvendor+"."+str(socket.gethostname())

        self.serverStarted = self.Hub.Start(self.port, self.listenAddr, hostPrefix)

    def CheckOld(self, old1, old2):
        bad = [['**NODATA**']*len(self.text.ColumnLabel)]
        old1 = [] if old1 == bad else old1
        old2 = [] if old2 == bad else old2
        return old1, old2

    def __stop__(self):
        self.Hub.Stop()

    def __close__(self):
        self.Hub.Stop()

    def SendData(self, Message, Address, Port, Event):
        if self.OUTSock:
            self.OUTSock.sendto(Message, (Address, Port))
            
    def DebugedEvt(self, items=False):
        if items: self.debuggdEvents = dc(items)
        elif items is not False: self.debuggdEvents = [['**NODATA**']*len(self.text.ColumnLabel)]
        return dc(self.eventList)

    def IgnoredEvt(self, items=False):
        if items: self.ignoredEvents = dc(items)
        elif items is not False: self.ignoredEvents = [['**NODATA**']*len(self.text.ColumnLabel)]
        return dc(self.eventList)

    def GetAddresses(self):
        addresses = socket.gethostbyname_ex(socket.gethostname())[2]
        addresses.sort(key=lambda a: [int(b) for b in a.split('.', 4)])
        return addresses

    def CheckEvent(self, event):
        if not self.eventList or event not in self.eventList:
            self.eventList += [event]
        return event

    def Message(self, xAPheader, xAPclass, xAPtarget=None, xAPinterval=None, xAPport=None, xAPtype=None, xAPmsg=None):

        msg = xAPheader+"\n"
        msg += "{\n" 
        msg += "v="+self.xAPversion.replace('.', '')+"\n"
        msg += "hop=1\n"
        msg += "uid="+self.UID+"\n"
        msg += "class="+xAPclass+"\n"
        msg += "source="+self.hostname+"\n"
        msg += "target="+xAPtarget+"\n" if xAPtarget else ""
        msg += "interval="+xAPinterval+"\n" if xAPinterval else ""
        msg += "port="+str(xAPport)+"\n" if xAPport else ""
        msg += "}\n"
        msg += xAPtype+"\n" if xAPtype else ""
        msg += "{\n" if xAPtype else ""
        msg += xAPmsg+"\n" if xAPmsg else ""
        msg += "}\n" if xAPtype else ""

        Type = xAPtype if xAPtype else xAPheader
        Target = xAPtarget if xAPtarget else '**NODATA**'
        Class = xAPclass if xAPclass else '**NODATA**'

        newEvent = self.CheckEvent([self.hostname, Type, Class, Target])
        return (msg, self.listenAddr, xAPport, newEvent)

    def Configure(self, listenAddr="", UID=["FF5AC000", "FF.5BC0D811:0000"], hostPrefix=False, xAPvendor='EvntGhst.Hub',
                    xAPversion='1.3', debuggdEvents=False, ignoredEvents=False):

        debuggdEvents, ignoredEvents = self.CheckOld(debuggdEvents, ignoredEvents)

        UID = ["FF5AC000", "FF.5BC0D811:0000"] if isinstance(UID, bool) else UID

        text = self.text
        panel = eg.ConfigPanel(self)
        buttonSizer = wx.BoxSizer(wx.VERTICAL)      

        addrs = self.GetAddresses()
        try: addr = addrs.index(listenAddr)
        except ValueError: addr = 0

        versions = ['1.2', '1.3']
        try: v = versions.index(xAPversion)
        except ValueError: v = 0

        BEG = UID[v][:3] if v else UID[v][:2]
        END = UID[v][-5:] if v else UID[v][-2:]
        NUID = UID[v][3:-5] if v else UID[v][2:-2]

        UIDSizer = wx.BoxSizer(wx.HORIZONTAL)
        BTNSizer = wx.BoxSizer(wx.HORIZONTAL)

        serverMode = panel.StaticText("Server Mode: "+self.serverMode)
        timer = wx.Timer(panel, -1)

        st1 = panel.Choice(addr, addrs)
        self.st2 = panel.TextCtrl(BEG, style=wx.TE_READONLY)
        self.st3 = panel.TextCtrl(NUID)
        self.st4 = panel.TextCtrl(END, style=wx.TE_READONLY)
        st5 = panel.CheckBox(hostPrefix)
        st6 = panel.TextCtrl(xAPvendor)
        st7 = panel.Choice(v, versions)
        st8 = panel.StaticText(text.VenDescText)
        st9 = panel.StaticText(text.VersDescText)
        st10 = wx.Button(panel, -1, "Ignore/Debug Events")
        self.st2.SetBackgroundColour((170, 170, 170))
        self.st4.SetBackgroundColour((170, 170, 170))

        def GetPanelResults():
            return [addrs[st1.GetValue()], UID, st5.GetValue(), st6.GetValue(),
                    versions[st7.GetValue()], self.debuggdEvents, self.ignoredEvents]

        def OnChoice(evt):
            evtObj = evt.GetEventObject()
            v = evtObj.GetValue()

            UID[not v] = self.st2.GetValue() \
                        +self.st3.GetValue() \
                        +self.st4.GetValue()

            self.st3.SetMaxLength(8)

            NUID = UID[v]
            BEG = NUID[:3] if v else NUID[:2]
            END = NUID[-5:] if v else NUID[-2:]
            NUID = NUID[3:-5] if v else NUID[2:-2]

            self.st2.ChangeValue(BEG)
            self.st3.ChangeValue(NUID)
            self.st4.ChangeValue(END)

            if not v: self.st3.SetMaxLength(4)
            self.st2.SetBackgroundColour((170, 170, 170))
            self.st4.SetBackgroundColour((170, 170, 170))

            evt.Skip()
        st7.Bind(wx.EVT_CHOICE, OnChoice)

        def OnIgnoreDebugBtn(evt):
            if not self.serverStarted: self.StartUp(*GetPanelResults())
            dlg = Frame(parent=panel, plugin=self, text=text, title=text.DebugFrame)
            dlg.Centre()
            wx.CallAfter(dlg.ShowDialog, text.ColumnLabel, self.debuggdEvents, self.ignoredEvents)
            evt.Skip()
        st10.Bind(wx.EVT_BUTTON, OnIgnoreDebugBtn)

        def OnTimer(evt):
            serverMode.SetLabel("Server Mode: "+self.serverMode)
            panel.sizer.Layout()
        panel.Bind(wx.EVT_TIMER, OnTimer, timer)

        UIDSizer.Add(self.st2, 0, wx.ALIGN_CENTER)
        UIDSizer.Add(self.st3, 0, wx.ALIGN_CENTER)
        UIDSizer.Add(self.st4, 0, wx.ALIGN_CENTER)

        BTNSizer.Add(st10, 0, wx.ALIGN_CENTER)

        box1 = panel.BoxedGroup('', (text.AddressText, st1), (text.HostPrefixText, st5))
        box2 = panel.BoxedGroup('Unique Identifier', UIDSizer)
        box3 = panel.BoxedGroup(text.VendorBox, st8, (text.VendorText, st6))
        box4 = panel.BoxedGroup(text.VersionBox, st9, (text.VersionText, st7))
        box5 = panel.BoxedGroup('', BTNSizer)

        panel.sizer.AddMany([serverMode, (box1, 0, wx.EXPAND), (box2, 0, wx.EXPAND), (box3, 0, wx.EXPAND), (box4, 0, wx.EXPAND), (box5, 0, wx.EXPAND)])

        timer.Start(2000)

        while panel.Affirmed(): panel.SetResult(*GetPanelResults())

class sendxAP(eg.ActionClass):

    text = Text

    def __call__(self, xAPtype, xAPclass, xAPtarget, xAPmsg):
        plg = self.plugin
        plg.SendData(*plg.Message('xap-header', xAPclass, xAPtarget, xAPtype=xAPtype, xAPmsg=xAPmsg))
        
    def Configure(self, xAPtype="Audio.Transport", xAPclass="xAP-Audio.Transport",
        xAPtarget="ersp.SlimServer.SOMEHOSTNAME:PLAYERNAME", xAPmsg="Command=Play"):
        text = self.text
        panel = eg.ConfigPanel(self)
        plugin = self.plugin

        st1 = panel.TextCtrl(xAPtype, size=(300, 20))
        st2 = panel.TextCtrl(xAPclass, size=(300, 20))
        st3 = panel.TextCtrl(xAPtarget, size=(300, 20))
        st4 = panel.TextCtrl(xAPmsg, style=wx.TE_MULTILINE, size=(300, 200))

        box1 = panel.BoxedGroup(text.textBoxLabel, st1)
        box2 = panel.BoxedGroup(text.textBoxLabel0, st2)
        box3 = panel.BoxedGroup(text.textBoxLabel1, st3)
        box4 = panel.BoxedGroup(text.textBoxLabel2, st4)

        panel.sizer.AddMany([(box1, 0, wx.EXPAND), (box2, 0, wx.EXPAND), (box3, 0, wx.EXPAND), (box4, 0, wx.EXPAND)])
        while panel.Affirmed(): panel.SetResult(st1.GetValue(), st2.GetValue(), st3.GetValue(), st4.GetValue())

class Table(wx.ListCtrl):

    def __init__(self, panel, parent, header):
        style = wx.LC_REPORT|wx.VSCROLL|wx.HSCROLL|wx.LC_HRULES|wx.LC_VRULES
        wx.ListCtrl.__init__(self, parent, -1, style=style)

        nC = len(header)
        self.nC = nC

        def Build(head, testTable, lines):
            cW = []
            self.InsertItems(testTable, head)
            for i in range(nC):
                self.SetColumnWidth(i, wx.LIST_AUTOSIZE)
                cW += [self.GetColumnWidth(i)]
            tW = wx.SYS_VSCROLL_X+self.GetWindowBorderSize()[0]+sum(cW)
            rect = self.GetItemRect(0, wx.LIST_RECT_BOUNDS)
            rect = 2+rect[1]+lines*rect[3]
            return cW, tW, rect

        bData = [['********NODATA********']*nC]
        lines = 10
        monW = 0
        monH = 0
        cW, tW, rect = Build(header, bData, lines)

        for mon in GetMonitorDimensions():
            monW = max(monW, mon[2])
            monH = max(monH, mon[3])

        if monH < rect*2+400:
            lines = 5
            self.DeleteAllItems()
        if monW < tW*2+150:
            bData = [['**NODATA**']*nC]
            self.DeleteAllItems()

        if self.GetItemCount():
            self.DeleteAllItems()
        else:
            cW, tW, rect = Build(False, bData, lines)
            self.DeleteAllItems()

        parent.PanelMin = (tW+75, rect+175)

        self.SetMinSize((tW, rect))
        self.cW = cW
        self.tW = tW

        self.Bind(wx.EVT_SIZE, self.OnSize)
        
    def InsertItems(self, newTable, header=''):
        if not header:
            oldTable = self.GetAll()
            self.DeleteAllItems()
            newTable = [item for item in newTable if item not in oldTable]
            newTable += oldTable
        while header: self.InsertColumn(self.nC-len(header), header.pop(0), format=wx.LIST_FORMAT_LEFT)

        newTable.sort()
        tLen = len(newTable)

        for i in range(tLen):
            items = newTable.pop(0)
            pos = False
            for j, item in enumerate(items):
                if pos is False: pos = self.InsertStringItem(j, item)
                else: self.SetStringItem(pos, j, item)

    def IterColumn(self, row):
        tmpData = [self.GetItemText(row)]
        for i in range(1, self.nC): tmpData += [self.GetItem(row, i).GetText()]
        return tmpData

    def DeleteSelect(self):
        row = self.GetFirstSelected()
        selits = []
        data = []
        while row != -1:
            selits.append(row)
            data += [self.IterColumn(row)]
            row = self.GetNextSelected(row)
        selits.reverse()
        for row in selits: self.DeleteItem(row)
        if self.GetItemCount() < 0: self.DeleteAllItems()
        return data

    def DeleteAll(self):
        tableData = self.GetAll()
        self.DeleteAllItems()
        return tableData

    def GetSelect(self):
        data = []
        row = self.GetFirstSelected()
        while row != -1:
            data += [self.IterColumn(row)]
            row = self.GetNextSelected(row)
        return data

    def GetAll(self):
        data = []
        for row in range(self.GetItemCount()): data += [self.IterColumn(row)]
        return data

    def SetWidth(self):
        for i in range(self.nC):
            self.SetColumnWidth(i, (self.GetSize().width - self.tW)/self.nC + self.cW[i])

    def OnSize(self, event):
        wx.CallAfter(self.SetWidth)
        event.Skip()

class Frame(wx.Frame):

    def __init__(self, parent, plugin, text, title):
        style = wx.DEFAULT_DIALOG_STYLE | wx.TAB_TRAVERSAL| wx.RESIZE_BORDER
        wx.Frame.__init__(self, parent, -1, style=style, name=title)
        
        self.plugin = plugin
        self.text = text
        self.title = title
        self.parent = parent
        self.panel = wx.Panel(self)
        self.SetIcon(self.plugin.info.icon.GetWxIcon())

    def CheckItems(self, sItems, nItems):
        try: nItems = [item for item in nItems if item not in sItems]
        except: pass
        return sItems, nItems

    def ShowDialog(self, header, DbgItems, IgnItems):
        self.SetTitle(self.title)
        lbls = dc(self.text.TableLabels)
        panel = self.panel
        self.header = header
        self.PanelMin = (100, 100)

        self.parent.Enable(False)
        self.parent.dialog.buttonRow.cancelButton.Enable(False)
        self.parent.EnableButtons(False)

        DbgItems, EvtDbgItems = self.CheckItems(DbgItems, self.plugin.DebugedEvt())
        IgnItems, EvtIgnItems = self.CheckItems(IgnItems, self.plugin.IgnoredEvt())
        self.SavedDbg = DbgItems
        self.DavedIgn = IgnItems

        PanelSizer = wx.BoxSizer(wx.VERTICAL)
        panel.SetSizer(PanelSizer)

        TableSizer = wx.BoxSizer(wx.HORIZONTAL)
        PnlBtnSizer = wx.BoxSizer(wx.HORIZONTAL)
        DbgBoxLbl = wx.StaticBox(panel, -1, lbls['Box'][0])
        DbgBox = wx.StaticBoxSizer(DbgBoxLbl, wx.VERTICAL)
        IgnBoxLbl = wx.StaticBox(panel, -1, lbls['Box'][1])
        IgnBox = wx.StaticBoxSizer(IgnBoxLbl, wx.VERTICAL)

        def TblSizer(items, tableLbl, btn1Lbl, btn2Lbl, lastLine=True):
            tmpSizer = wx.BoxSizer(wx.VERTICAL)
            tmpBtnSizer = wx.BoxSizer(wx.HORIZONTAL)

            tableLbl = wx.StaticText(panel, -1, tableLbl)
            line1 = wx.StaticLine(panel, -1, size=(20,-1), style=wx.LI_HORIZONTAL)
            line2 = wx.StaticLine(panel, -1, size=(20,-1), style=wx.LI_HORIZONTAL)
            btn1Lbl = wx.Button(panel, -1, btn1Lbl)
            btn2Lbl = wx.Button(panel, -1, btn2Lbl)
            table = Table(self, panel, dc(header))
            if items: table.InsertItems(items)
            tmpBtnSizer.Add(btn1Lbl, 0, wx.EXPAND|wx.ALIGN_RIGHT)
            tmpBtnSizer.Add(btn2Lbl, 0, wx.EXPAND|wx.ALIGN_RIGHT)
            tmpSizer.Add(tableLbl, 0, wx.EXPAND|wx.ALIGN_LEFT|wx.LEFT|wx.BOTTOM, 5)
            tmpSizer.Add(line1, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.LEFT|wx.BOTTOM|wx.TOP, 5)
            tmpSizer.Add(table, 1, wx.EXPAND|wx.LEFT, 5)
            tmpSizer.Add(line2, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.LEFT|wx.BOTTOM|wx.TOP, 5)
            tmpSizer.Add(tmpBtnSizer, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.ALL, 10)
            if lastLine:
                line3 = wx.StaticLine(panel, -1, size=(20,-1), style=wx.LI_HORIZONTAL)
                tmpSizer.Add(line3, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.LEFT|wx.BOTTOM|wx.TOP, 5)

            return tmpSizer, table, btn1Lbl, btn2Lbl

        tblSizer, self.EvtDbgTbl, DbgAddBtn, DbgAddAllBtn = TblSizer(EvtDbgItems, *lbls['DbgEvt'])
        DbgBox.Add(tblSizer, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.ALL, 5)
        tblSizer, self.DbgTbl, DbgDelBtn, DbgDelAllBtn = TblSizer(DbgItems, *lbls['Dbg'], lastLine=False)
        DbgBox.Add(tblSizer, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.ALL, 5)
        TableSizer.Add(DbgBox, 0, wx.EXPAND|wx.ALIGN_LEFT|wx.ALL, 5)

        tblSizer, self.EvtIgnTbl, IgnAddBtn, IgnAddAllBtn = TblSizer(EvtIgnItems, *lbls['IgnEvt'])
        IgnBox.Add(tblSizer, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.ALL, 5)
        tblSizer, self.IgnTbl, IgnDelBtn, IgnDelAllBtn = TblSizer(IgnItems, *lbls['Ign'], lastLine=False)
        IgnBox.Add(tblSizer, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.ALL, 5)
        TableSizer.Add(IgnBox, 0, wx.EXPAND|wx.ALIGN_RIGHT|wx.ALL, 5)

        PanelSizer.Add(TableSizer, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.ALL, 10)

        RfshBtn = wx.Button(panel, -1, lbls['Pnl'][0])
        OKBtn = wx.Button(panel, wx.ID_OK, lbls['Pnl'][1])
        CnclBtn = wx.Button(panel, wx.ID_CANCEL, lbls['Pnl'][2])

        PnlBtnSizer.Add(RfshBtn)
        PnlBtnSizer.Add(OKBtn)
        PnlBtnSizer.Add(CnclBtn)
        PanelSizer.Add(PnlBtnSizer, 0, wx.ALIGN_LEFT|wx.BOTTOM|wx.LEFT, 10)

        self.timer = wx.Timer(self,-1)

        def OnDbgAddBtn(evt):
            self.DbgTbl.InsertItems(self.EvtDbgTbl.DeleteSelect())
            wx.CallAfter(OnRfshBtn)
            evt.Skip()
        
        def OnDbgAddAllBtn(evt):
            self.DbgTbl.InsertItems(self.EvtDbgTbl.DeleteAll())
            wx.CallAfter(OnRfshBtn)
            evt.Skip()

        def OnDbgDelBtn(evt):
            self.EvtDbgTbl.InsertItems(self.DbgTbl.DeleteSelect())
            wx.CallAfter(OnRfshBtn)
            evt.Skip()

        def OnDbgDelAllBtn(evt):
            self.EvtDbgTbl.InsertItems(self.DbgTbl.DeleteAll())
            wx.CallAfter(OnRfshBtn)
            evt.Skip()

        def OnIgnAddBtn(evt):
            self.IgnTbl.InsertItems(self.EvtIgnTbl.DeleteSelect())
            wx.CallAfter(OnRfshBtn)
            evt.Skip()
        
        def OnIgnAddAllBtn(evt):
            self.IgnTbl.InsertItems(self.EvtIgnTbl.DeleteAll())
            wx.CallAfter(OnRfshBtn)
            evt.Skip()

        def OnIgnDelBtn(evt):
            self.EvtIgnTbl.InsertItems(self.IgnTbl.DeleteSelect())
            wx.CallAfter(OnRefresh)
            evt.Skip()

        def OnIgnDelAllBtn(evt):
            self.EvtIgnTbl.InsertItems(self.IgnTbl.DeleteAll())
            wx.CallAfter(OnRefresh)
            evt.Skip()

        def OnEvtDbgTbl(evt):
            DbgAddBtn.Enable(self.EvtDbgTbl.GetSelectedItemCount()>0)
            DbgDelBtn.Enable(False)
            evt.Skip()
        
        def OnDbgTbl(evt):
            DbgDelBtn.Enable(self.DbgTbl.GetSelectedItemCount()>0)
            DbgAddBtn.Enable(False)
            evt.Skip()

        def OnEvtIgnTbl(evt):
            IgnAddBtn.Enable(self.EvtIgnTbl.GetSelectedItemCount()>0)
            IgnDelBtn.Enable(False)
            evt.Skip()
        
        def OnIgnTbl(evt):
            IgnDelBtn.Enable(self.IgnTbl.GetSelectedItemCount()>0)
            IgnAddBtn.Enable(False)
            evt.Skip()

        def CycleButtons(btn):        
            DbgAddBtn.Enable(False)
            DbgAddAllBtn.Enable(self.EvtDbgTbl.GetItemCount()>0)
            DbgDelBtn.Enable(False)
            DbgDelAllBtn.Enable(self.DbgTbl.GetItemCount()>0)

            IgnAddBtn.Enable(False)
            IgnAddAllBtn.Enable(self.EvtIgnTbl.GetItemCount()>0)
            IgnDelBtn.Enable(False)
            IgnDelAllBtn.Enable(self.IgnTbl.GetItemCount()>0)

            RfshBtn.Enable(True)
            OKBtn.Enable(btn)
            CnclBtn.Enable(True)

        def OnRfshBtn(evt=None):
            self.EvtDbgTbl.InsertItems(
                        [item for item in self.plugin.DebugedEvt(self.DbgTbl.GetAll()) if item not in self.DbgTbl.GetAll()])
            self.EvtIgnTbl.InsertItems(
                        [item for item in self.plugin.IgnoredEvt(self.IgnTbl.GetAll()) if item not in self.IgnTbl.GetAll()])
            wx.CallAfter(CycleButtons, True)
            #if evt: evt.Skip()

        def OnOKBtn(evt):
            self.Close()

        def OnCnclBtn(evt):
            self.plugin.DebugedEvt(self.SavedDbg)
            self.plugin.IgnoredEvt(self.DavedIgn)
            self.Close()

        def OnClose(evt):
            self.timer.Stop()
            self.MakeModal(False)
            self.parent.Enable(True)
            self.parent.dialog.buttonRow.cancelButton.Enable(True)
            self.parent.EnableButtons(True)
            self.GetParent().GetParent().Raise()
            self.Destroy()

        DbgAddBtn.Bind(wx.EVT_BUTTON, OnDbgAddBtn)
        DbgAddAllBtn.Bind(wx.EVT_BUTTON, OnDbgAddAllBtn)
        DbgDelBtn.Bind(wx.EVT_BUTTON, OnDbgDelBtn)
        DbgDelAllBtn.Bind(wx.EVT_BUTTON, OnDbgDelAllBtn)

        IgnAddBtn.Bind(wx.EVT_BUTTON, OnIgnAddBtn)
        IgnAddAllBtn.Bind(wx.EVT_BUTTON, OnIgnAddAllBtn)
        IgnDelBtn.Bind(wx.EVT_BUTTON, OnIgnDelBtn)
        IgnDelAllBtn.Bind(wx.EVT_BUTTON, OnIgnDelAllBtn)

        self.EvtDbgTbl.Bind(wx.EVT_LIST_ITEM_SELECTED, OnEvtDbgTbl)
        self.EvtDbgTbl.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnEvtDbgTbl)
        self.DbgTbl.Bind(wx.EVT_LIST_ITEM_SELECTED, OnDbgTbl)
        self.DbgTbl.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnDbgTbl)

        self.EvtIgnTbl.Bind(wx.EVT_LIST_ITEM_SELECTED, OnEvtIgnTbl)
        self.EvtIgnTbl.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnEvtIgnTbl)
        self.IgnTbl.Bind(wx.EVT_LIST_ITEM_SELECTED, OnIgnTbl)
        self.IgnTbl.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnIgnTbl)

        RfshBtn.Bind(wx.EVT_BUTTON, OnRfshBtn)
        OKBtn.Bind(wx.EVT_BUTTON, OnOKBtn)
        CnclBtn.Bind(wx.EVT_BUTTON, OnCnclBtn)

        self.Bind(wx.EVT_CLOSE, OnClose)
        self.Bind(wx.EVT_TIMER, OnRfshBtn, self.timer)

        CycleButtons(btn=False)
        PanelSizer.Add((1,6))
        PanelSizer.Fit(self)
        self.SetMinSize(self.PanelMin)
        self.SetSize((-1, -1))
        PanelSizer.Layout()
        self.Raise()
        self.MakeModal(True)
        self.Show(True)

        self.timer.Start(5000)