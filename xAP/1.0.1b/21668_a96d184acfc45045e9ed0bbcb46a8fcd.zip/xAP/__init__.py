# -*- coding: utf-8 -*-
# 
# This file is a plugin for EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

eg.RegisterPlugin(
    name = "xAP",
    author = "K",
    version = "1.0.1b",
    canMultiLoad = False,
    kind = "external",
    guid = "{26649308-3137-4C33-A5D2-6F50DAE36A65}",
    description = "Send and receive xAP messages.",
    url = "",
)
    
import sys
import re
import socket
import wx
import threading
from copy import deepcopy as dc


class PRINT:
    def __init__(self, plugin):
        self.plugin = plugin
     
    def Log(self, logStr, event):
        if event in self.plugin.debuggdEvents: print logStr

    def Notice(self, noticeString):
        eg.PrintNotice(noticeString)

    def Error(self, errorString):
        eg.PrintError(errorString)

class Text:
    textBoxLabel   = "xAP Msg Type: "
    textBoxLabel0  = "xAP Schema: "
    textBoxLabel1  = "xAP Target: "
    textBoxLabel2  = "xAP Message: "
    AddressText    = "Listening Address: "
    HeartBeatText  = "HeartBeat Events: "
    HostPrefixText = "Host Information as Prefix: "
    AllDataText = "xAP DebuggingMode: "
    VenDescText = ('You may leave this as is or if you would like to specify a name you may do so.\n'
                  'The name has to be 2 sections seperated by a "." and the first section of the name\n'
                  'cannot be longer than 8 characters. The second section is the device if you will,\n'
                  'I am not sure if there are any limitations for this. There is a 3rd section that \n'
                  'is automatically added and that is the computers hostname. If you would like to send\n'
                  'a command to EG from an xAP whatever is in this field with a "." and the computers\n'
                  'host name would be the target that would have to be entered into that devices xAP\n'
                  'transmission. If you find this not working then you have a special character that is\n'
                  'not supported.\n')
    VendorText = "Vendor Name: "
    VersDescText = ("Set to 1.2 if you don't know what version of xAP your devices use. If they use 1.3\n"
                   "they will be able to talk to EG because of backwards compatability. 1.2 uses a\n"
                   "identifier (electronic serial number) formatted like FF5AC000 and 1.3 is like\n"
                   "FF.5AC0E811:0000. Not enough room to explain about it.\n")
    VersionText = "xAP Version: "
    SocketErr = "xAP: Hub: Failed to open socket: "
    BindSucess = "xAP: Hub: UDP Hub has Started bound on Port: "
    BindErr = "xAP: Hub: Failed to open port: This plugin acts as a hub also, restarting Hub in 30 seconds"
    SocketClose = "xAP: Hub: UDP Hub has Shutdown"
    HeartOpen = "xAP: Hub: HeartBeat has Started"
    HeartClose = "xAP: Hub: HeartBeat has Shutdown"
    MalformedData = "malformed Data"
    MalformedException = "malformed Data Exception"
    TerminateLease = "Terminating forwarding lease"
    Port = "Port"
    NewLease = "New forwarding lease"
    RenewLease = "Renewing forwarding lease"
    Duration = "Duration"
    Seconds = "seconds"
    Prefix = "Prefix"
    Suffix = "Suffix"
    Payload = "Payload"
    TimeoutLease = "Host timed out removing from lease"
    Host = "Host"
    Data = "Data"
    Message = "Message"
    Network = "Network"
    VersionBox = "Version"
    VendorBox = "Vendor Name"
    DebugFrame = 'xAP Debugging'
    IgnoreFrame = 'xAP Ignore'
    ColumnLabel = ["Source", "Message Type", "Message Schema", "Destination"]
    AddBtn = "Add"
    AddAllBtn = "Add All"
    DeleteBtn = "Delete"
    DeleteAllBtn = "Delete All"
    RefreshBtn = "Refresh Tables"
    OKBtn = "OK"
    CancelBtn = "Cancel"
    class sendxAP:
        name = "Send xAP message"
        description = "Sends an xAP message"

class Hub:

    text = Text

    def __init__(self, plugin):
        #super(Server, self).__init__()
        self.plugin = plugin
        self.UDPSock = False
        self.HBWait = False
        self.HBEvent = threading.Event()
        self.UDPEvent = threading.Event()
        self.hubTimers = [0]
        self.hubHosts = [['', 0]]
        self.Print = PRINT(self.plugin)
        self.PN = self.Print.Notice
        self.PE = self.Print.Error
        self.Log = self.Print.Log

    def Start(self, *args):
        self.startUp = True
        self.xAPstorage = {}
        self.hubHosts = [[self.plugin.hostname, self.plugin.port]]
        self.hubTimers = [0]

        try:
            threading.Thread(target=self.RunListener, args=args).start()
            return True
        except:
            self.PE("xAP: Hub: Start: "+str(sys.exc_info()))
            return False
        
    def RunListener(self, port, listenAddr, hostPrefix):
        text = self.text
        while self.UDPSock: pass

        listenAddr = listenAddr if listenAddr in self.plugin.GetAddresses() else 'localhost'
        self.listenAddr = listenAddr

        accept = None
        read = None
        while self.startUp:
            try:
                self.UDPSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            except:
                self.UDPSock = False
                self.startUp = False
                self.UDPEvent.set()
                self.PE(text.SocketErr+str(sys.exc_info()))
            if self.UDPSock:
                try:
                    self.UDPSock.bind((listenAddr, port))
                    self.startUp = False
                    self.PN(text.BindSucess+str(port))
                    threading.Thread(target=self.RunHeartBeat).start()
                except:
                    self.PE(text.BindErr)
                    self.UDPEvent.wait(30)

        while not self.UDPEvent.isSet():
            data, addr = self.UDPSock.recvfrom(1500)
            if not self.UDPEvent.isSet():
                self.IncomingData(data, addr, listenAddr, hostPrefix)

        try: self.UDPSock.close()
        except: pass

        self.UDPSock = False
        self.UDPEvent.clear()
        self.PN(text.SocketClose)

    def RunHeartBeat(self):
        text = self.text
        while not self.UDPSock: pass
        self.PN(text.HeartOpen)

        sendData = self.plugin.Message('xap-hbeat', 'xap-hbeat.alive', xAPinterval='60')

        while self.UDPSock:
            self.Send(*sendData)
            self.HBEvent.wait(60) 
        
        self.Send(*self.plugin.Message('xap-hbeat', 'xap-hbeat.stopped', xAPinterval='60'))

        self.HBEvent.clear()
        self.PN(text.HeartClose)

    def IncomingData(self, data, addr, listenAddr, hostPrefix):

        text = self.text

        pData = {}
        payload = {}

        fData = data.split('}\n')
        fData.pop()

        for i in range(len(fData)):
            try:
                trim = fData[i].find('\n')
                pData['type'] = fData[i][:trim]
                fData[i] = fData[i][trim+1:].replace('\n', '","').replace('=', '":"')
                fData[i] = '{'+fData[i][3:-2]+'}'
                if pData: pData.update(eval(fData[i]))
                else: pData = eval(fData[i])
            except:
                self.Log('>     '+txt.MalformedData+": "+data, False)
                self.Log('>     '+txt.MalformedException+": "+str(sys.exc_info()), False)
                return
        for key in pData.keys():
            payload[key.title()] = dc(pData[key])

        Type = dc(payload['Type']) if 'Type' in payload else None
        Port = dc(payload['Port']) if 'Port' in payload else None
        Hbeat = dc(payload['Class']) if Type == 'xap-hbeat' else None
        Class = dc(payload['Class']) if 'Class' in payload else None
        Target = dc(payload['Target']) if 'Target' in payload else None
        Source = dc(payload['Source']) if 'Source' in payload else None
        Interval = str(int(dc(payload['Interval']))*2) if 'Interval' in payload else '120'

        Hostname = self.plugin.hostname

        if Type is None: return
        Tar = Target if Target else '**NODATA**'
        Cla = Class if Class else '**NODATA**'
        Sou = Source if Source else '**NODATA**'
        newEvent = self.plugin.CheckEvent([Sou, Type, Cla, Tar])

        self.Log(">     "+text.Data+": "+data, newEvent)
        self.Log(">     formatted data: "+str(payload), newEvent)

        if not Hbeat: pass
        elif addr[0] != listenAddr: pass
        elif addr[1] == self.plugin.port: pass
        elif Source == Hostname: pass
        else:
            alive = True if Hbeat.find('alive') > -1 else False
            idx = len(self.hubHosts)-1
            lease = text.TerminateLease+": "+Source
            if Port:
                lease += text.Port+": "+Port
                newHost = [Source, Port]
                try:
                    idx = self.hubHosts.index(newHost)
                    self.hubTimers.pop(idx).cancel()
                    self.hubHosts.pop(idx)
                except: pass
                    
            if alive:
                lease = text.NewLease+": " if idx == len(self.hubHosts)-1 else text.RenewLease+": "
                lease += Source+", "+text.Port+": "+Port+", "+text.Duration+": "+Interval+" "+text.Seconds
                self.hubTimers.append(threading.Timer(int(Interval), self.RemoveHost, args=[idx]))
                self.hubHosts.append(newHost)
            self.Log(lease)

        for host in self.hubHosts:
            if int(host[1]) != self.plugin.port:
                self.Send(int(host[1]), data, newEvent)

        presuf = [Source]
        presuf += ['xAP'+Class[3:].title() if Hbeat else Class]

        prefix = presuf[0] if hostPrefix else presuf[1]
        suffix = presuf[1] if hostPrefix else presuf[0]

        self.Log(">     "+text.Prefix+": "+prefix, newEvent)
        self.Log(">     "+text.Suffix+": "+suffix, newEvent)
        self.Log(">     "+text.Payload+": "+str(payload), newEvent)

        if newEvent not in self.plugin.ignoredEvents:
            eg.TriggerEvent(prefix=prefix, suffix=suffix, payload=payload)

    def RemoveHost(self, idx):
        text = self.text
        host = self.hubHosts.pop(idx)
        self.Log(text.TimeoutLease+": "+text.Host+": "+host[0]+", "+text.Port+": "+host[1], False)
        self.hubTimers.pop(idx)

    def Send(self, port, msg, event):
        text = self.text

        if self.UDPSock:
            network = '.'.join(self.listenAddr.split('.')[:-1]+['255'])
            self.Log("<     "+text.Message+": "+msg+", "+text.Network+": "+network+", "+text.Port+": "+str(port), event)
            self.UDPSock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)   
            self.UDPSock.sendto(msg, (network, port))

    def Stop(self):
        self.startUp = False
        for t in self.hubTimers:
            try: t.cancel()
            except: pass
       
        self.HBEvent.set()
        self.UDPEvent.set()

class xAP(eg.PluginBase):

    text = Text

    def __init__(self):
        self.localIP = socket.gethostbyname(socket.gethostname())
        self.Hub = Hub(self)         
        self.AddAction(sendxAP)
        self.eventList = [['**NODATA**']*len(self.text.ColumnLabel)]
        self.debuggdEvents = [['**NODATA**']*len(self.text.ColumnLabel)]
        self.ignoredEvents = [['**NODATA**']*len(self.text.ColumnLabel)]
        self.serverStarted = False

    def __start__(
                self,
                listenAddr="",
                hbeatEvent=False,
                hostPrefix=False,
                xAPvendor='EvntGhst.Hub',
                xAPversion='1.3',
                debuggdEvents=False,
                ignoredEvents=False,  
                ):

        self.StartUp(
                    listenAddr,
                    hostPrefix,
                    xAPvendor,
                    xAPversion,
                    debuggdEvents,
                    ignoredEvents,
                    )

    def StartUp(
                self,
                listenAddr,
                hostPrefix,
                xAPvendor,
                xAPversion,
                debuggdEvents,
                ignoredEvents,
                ):

        self.debuggdEvents = debuggdEvents if debuggdEvents else [['**NODATA**']*len(self.text.ColumnLabel)]
        self.ignoredEvents = ignoredEvents if ignoredEvents else [['**NODATA**']*len(self.text.ColumnLabel)]
        
        self.xAPversion = xAPversion
        self.uid = "FF.5AC0E811:0000" if xAPversion == "1.3" else "FF5AC000"
        self.hostname = xAPvendor+"."+str(socket.gethostname())

        self.port = 3639
        self.serverStarted = self.Hub.Start(self.port, listenAddr, hostPrefix)

    def __stop__(self):
        self.Hub.Stop()

    def __close__(self):
        self.Hub.Stop()

    def Debugging(self, items=False):
        if items: self.debuggdEvents = items
        return self.eventList

    def IgnoreEvt(self, items=False):
        if items: self.ignoredEvents = items
        return self.eventList

    def GetAddresses(self):
        addresses = socket.gethostbyname_ex(socket.gethostname())[2]
        addresses.sort(key=lambda a: [int(b) for b in a.split('.', 4)])
        return addresses

    def CheckEvent(self, event):
        if self.eventList == [['**NODATA**']*len(self.text.ColumnLabel)]:
            self.eventList = [event]
        elif event not in self.eventList:
            self.eventList.append(event)
        return event

    def Message(self, xAPheader, xAPclass, xAPtarget=None, xAPinterval=None, xAPport=None, xAPtype=None, xAPmsg=None):

        msg = xAPheader+"\n"
        msg += "{\n" 
        msg += "v="+self.xAPversion.replace('.', '')+"\n"
        msg += "hop=1\n"
        msg += "uid="+self.uid+"\n"
        msg += "class="+xAPclass+"\n"
        msg += "source="+self.hostname+"\n"
        msg += "target="+xAPtarget+"\n" if xAPtarget else ""
        msg += "interval="+xAPinterval+"\n" if xAPinterval else ""
        msg += "port="+xAPport+"\n" if xAPport else ""
        msg += "}\n"
        msg += xAPtype+"\n" if xAPtype else ""
        msg += "{\n" if xAPtype else ""
        msg += xAPmsg+"\n" if xAPmsg else ""
        msg += "}\n" if xAPtype else ""

        Type = xAPtype if xAPtype else xAPheader
        Target = xAPtarget if xAPtarget else '**NODATA**'
        Class = xAPclass if xAPclass else '**NODATA**'

        newEvent = self.CheckEvent([self.hostname, Type, Class, Target])

        return (self.port, msg, newEvent)

    def Configure(
                self,
                listenAddr="",
                hbeatEvent=False,
                hostPrefix=False,
                xAPvendor='EvntGhst.Hub',
                xAPversion='1.3',
                debuggdEvents=False,
                ignoredEvents=False
                ):

        text = self.text
        panel = eg.ConfigPanel(self)

        buttonSizer = wx.BoxSizer(wx.VERTICAL)      

        addrs = self.GetAddresses()
        try: addr = addrs.index(listenAddr)
        except ValueError: addr = 0

        versions = ['1.2', '1.3']
        try: version = versions.index(xAPversion)
        except ValueError: version = 0

        st1 = panel.Choice(addr, addrs)
        st3 = panel.CheckBox(hostPrefix)
        st4 = panel.TextCtrl(xAPvendor)
        st6 = panel.Choice(version, versions)
        st7 = panel.StaticText(text.VenDescText)
        st8 = panel.StaticText(text.VersDescText)
        st9 = wx.Button(panel, -1, text.DebugFrame)
        st10 = wx.Button(panel, -1, text.IgnoreFrame)

        def GetPanelResults():
            return [
                    addrs[st1.GetValue()],
                    hbeatEvent,
                    st3.GetValue(),
                    st4.GetValue(),
                    versions[st6.GetValue()],
                    self.debuggdEvents,
                    self.ignoredEvents
                    ]

        def OnDebugBtn(evt):
            if not self.serverStarted:
                self.StartUp(*GetPanelResults())
            dlg = Frame(
                        parent=panel,
                        plugin=self,
                        text=text,
                        title=text.DebugFrame
                        )
            dlg.Centre()
            wx.CallAfter(
                        dlg.ShowDialog,
                        text.ColumnLabel,
                        self.debuggdEvents,
                        self.Debugging
                        )
            evt.Skip()
        st9.Bind(wx.EVT_BUTTON, OnDebugBtn)

        def OnEventBtn(evt):
            if not self.serverStarted:
                self.StartUp(*GetPanelResults())
            dlg = Frame(
                        parent=panel,
                        plugin=self,
                        text=text,
                        title=text.IgnoreFrame
                        )
            dlg.Centre()
            wx.CallAfter(
                        dlg.ShowDialog,
                        text.ColumnLabel,
                        self.ignoredEvents,
                        self.IgnoreEvt
                        )
            evt.Skip()
        st10.Bind(wx.EVT_BUTTON, OnEventBtn)

        eg.EqualizeWidths((st1, st3, st4, st6, st7, st8, st9, st10))

        box1 = panel.BoxedGroup(
                                '',
                                (text.AddressText, st1),
                                (text.HostPrefixText, st3)
                                )
        box2 = panel.BoxedGroup(
                                text.VendorBox,
                                st7,
                                (text.VendorText, st4),
                                )
        box3 = panel.BoxedGroup(
                                text.VersionBox,
                                st8,
                                (text.VersionText, st6)
                                )

        box4 = panel.BoxedGroup('', st9, st10)


        panel.sizer.AddMany([
                    (box1, 0, wx.EXPAND),
                    (box2, 0, wx.EXPAND),
                    (box3, 0, wx.EXPAND),
                    (box4, 0, wx.EXPAND)
                    ])

        while panel.Affirmed():
            panel.SetResult(*GetPanelResults())

class sendxAP(eg.ActionClass):

    text = Text

    def __call__(self, xAPtype, xAPclass, xAPtarget, xAPmsg):
        xAPMessage=re.compile('\r')
        xAPMessage.sub('',xAPmsg)
        xAPMessage=re.compile('\n ')
        xAPMessage.sub('\n',xAPmsg)
        self.plugin.Hub.Send(*self.plugin.Message('xap-header', xAPclass, xAPtarget, xAPtype=xAPtype, xAPmsg=xAPmsg))
        
    def Configure(
        self, 
        xAPtype="Audio.Transport",
        xAPclass="xAP-Audio.Transport",
        xAPtarget="ersp.SlimServer.SOMEHOSTNAME:PLAYERNAME",
        xAPmsg="Command=Play"
        ):

        text = self.text

        panel = eg.ConfigPanel(self)
        plugin = self.plugin

        st1 = panel.TextCtrl(xAPtype, size=(300, 20))
        st2 = panel.TextCtrl(xAPclass, size=(300, 20))
        st3 = panel.TextCtrl(xAPtarget, size=(300, 20))
        st4 = panel.TextCtrl(xAPmsg, style=wx.TE_MULTILINE, size=(300, 200))

        #eg.EqualizeWidths((st1, st2, st3, st4))

        box1 = panel.BoxedGroup(text.textBoxLabel, st1)
        box2 = panel.BoxedGroup(text.textBoxLabel0, st2)
        box3 = panel.BoxedGroup(text.textBoxLabel1, st3)
        box4 = panel.BoxedGroup(text.textBoxLabel2, st4)

        panel.sizer.AddMany([
                            (box1, 0, wx.EXPAND),
                            (box2, 0, wx.EXPAND),
                            (box3, 0, wx.EXPAND),
                            (box4, 0, wx.EXPAND)
                            ])
        
        while panel.Affirmed():
            panel.SetResult(
                st1.GetValue(), 
                st2.GetValue(), 
                st3.GetValue(), 
                st4.GetValue(), 
            )

class Table(wx.ListCtrl):

    def __init__(self, parent, header, table):
        wx.ListCtrl.__init__(
            self,
            parent,
            -1,
            style=wx.LC_REPORT|wx.VSCROLL|wx.HSCROLL|wx.LC_HRULES|wx.LC_VRULES,
        )

        self.nC = len(header)
        self.cW = []

        self.InsertItems(table, header)

        for i in range(self.nC):
            self.SetColumnWidth(i, wx.LIST_AUTOSIZE)
            self.cW += [self.GetColumnWidth(i)]

        self.tW = wx.SYS_VSCROLL_X+self.GetWindowBorderSize()[0]+sum(self.cW)
        rect = self.GetItemRect(0, wx.LIST_RECT_BOUNDS)
        self.SetMinSize((max(self.tW , 200), 2+rect[1]+10*rect[3]))

        if self.GetItemCount() == 1 and self.GetAll() == [['**NODATA**']*self.nC]:
            self.DeleteAllItems()

        self.Bind(wx.EVT_SIZE, self.OnSize)
        
    def InsertItems(self, table, header=''):
        if not header:
            table += self.GetAll()
            self.DeleteAllItems()

        while header: self.InsertColumn( self.nC-len(header), header.pop(0), format=wx.LIST_FORMAT_LEFT)

        table.sort()
        tLen = len(table)

        for i in range(tLen):
            items = table.pop(0)
            if table and items in table: continue
            pos = False
            for j, item in enumerate(items):
                if pos is False: pos = self.InsertStringItem(j, item)
                else: self.SetStringItem(pos, j, item)

        return self.GetAll()

    def IterColumn(self, row):
        tmpData = [self.GetItemText(row)]
        for i in range(1, self.nC):
            tmpData += [self.GetItem(row, i).GetText()]
        return tmpData

    def DeleteSelect(self):
        row = self.GetFirstSelected()
        selits = []
        data = []
        while row != -1:
            selits.append(row)
            data += [self.IterColumn(row)]
            row = self.GetNextSelected(row)
        selits.reverse()
        for row in selits: self.DeleteItem(row)
        if self.GetItemCount() < 0:
            self.DeleteAllItems()
        return data

    def DeleteAll(self):
        tableData = self.GetAll()
        self.DeleteAllItems()
        return tableData

    def GetSelect(self):
        data = []
        row = self.GetFirstSelected()
        while row != -1:
            data += [self.IterColumn(row)]
            row = self.GetNextSelected(row)
        return data

    def GetAll(self):
        data = []
        for row in range(self.GetItemCount()):
            data += [self.IterColumn(row)]
        return data

    def SetWidth(self):
        for i in range(self.nC):
            self.SetColumnWidth(i, (self.GetSize().width - self.tW)/self.nC + self.cW[i])

    def OnSize(self, event):
        wx.CallAfter(self.SetWidth)
        event.Skip()


class Frame(wx.Frame):

    def __init__(self, parent, plugin, text, title):
        wx.Frame.__init__(
            self,
            parent,
            -1,
            style=wx.DEFAULT_DIALOG_STYLE | wx.TAB_TRAVERSAL| wx.RESIZE_BORDER,
            name=title
        )
        
        self.plugin = plugin
        self.text = text
        self.title = title
        self.parent = parent
        self.panel = wx.Panel(self)
        self.SetIcon(self.plugin.info.icon.GetWxIcon())

    def ShowDialog(self, header, oldItems, func):
        
        self.SetTitle(self.title)
        text = self.text
        panel = self.panel
        self.header = header

        if not oldItems: oldItems = [['**NODATA**']*len(header)]

        self.newItems = func(oldItems)
        self.oldItems = oldItems
        self.newItems.sort()
        self.oldItems.sort()
        self.savedOld = oldItems
        self.func = func

        self.parent.Enable(False)
        self.parent.dialog.buttonRow.cancelButton.Enable(False)
        self.parent.EnableButtons(False)

        sizer = wx.BoxSizer(wx.VERTICAL)
        panel.SetSizer(sizer)

        newSizer = wx.BoxSizer(wx.VERTICAL)
        newBtnSizer = wx.BoxSizer(wx.HORIZONTAL)

        line1 = wx.StaticLine(panel, -1, size=(20,-1), style=wx.LI_HORIZONTAL)
        line2 = wx.StaticText(panel, -1, 'Event List')
        self.newTable = Table(panel, dc(header), self.newItems)
        addButton = wx.Button(panel, -1, text.AddBtn)
        addAllButton = wx.Button(panel, -1, text.AddAllBtn)

        newSizer.Add(line1, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.TOP|wx.BOTTOM, 10)
        newSizer.Add(line2, 0, wx.EXPAND|wx.ALIGN_LEFT, 10)
        newSizer.Add(self.newTable, 1, wx.EXPAND|wx.BOTTOM, 5)
        newBtnSizer.Add(addButton)
        newBtnSizer.Add(addAllButton)
        newSizer.Add(newBtnSizer, 0, wx.EXPAND|wx.ALIGN_LEFT, 10)
        sizer.Add(newSizer, 0, wx.EXPAND|wx.ALIGN_CENTER, 10)

        oldSizer = wx.BoxSizer(wx.VERTICAL)
        oldBtnSizer = wx.BoxSizer(wx.HORIZONTAL)

        line3 = wx.StaticLine(panel, -1, size=(20,-1), style=wx.LI_HORIZONTAL)
        line4 = wx.StaticText(panel, -1, self.title)
        self.oldTable = Table(panel, dc(header), self.oldItems)
        deleteButton = wx.Button(panel, -1, text.DeleteBtn)
        deleteAllButton = wx.Button(panel, -1, text.DeleteAllBtn)

        oldSizer.Add(line3, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.TOP|wx.BOTTOM, 10)
        oldSizer.Add(line4, 0, wx.EXPAND|wx.ALIGN_LEFT, 10)
        oldSizer.Add(self.oldTable, 1, wx.EXPAND|wx.BOTTOM, 5)
        oldBtnSizer.Add(deleteButton)
        oldBtnSizer.Add(deleteAllButton)
        oldSizer.Add(oldBtnSizer, 0, wx.EXPAND|wx.ALIGN_LEFT, 10)
        sizer.Add(oldSizer, 0, wx.EXPAND|wx.ALIGN_CENTER, 10)

        pnlBtnSizer = wx.BoxSizer(wx.HORIZONTAL)
        line5 = wx.StaticLine(panel, -1, size=(20,-1), style=wx.LI_HORIZONTAL)
        refreshButton = wx.Button(panel, -1, text.RefreshBtn)
        okButton = wx.Button(panel, wx.ID_OK, text.OKBtn)
        cancelButton = wx.Button(panel, wx.ID_CANCEL, text.CancelBtn)

        sizer.Add(line5, 0, wx.EXPAND|wx.ALIGN_CENTER|wx.TOP|wx.BOTTOM, 10)
        pnlBtnSizer.Add(refreshButton)
        pnlBtnSizer.Add(okButton)
        pnlBtnSizer.Add(cancelButton)
        sizer.Add(pnlBtnSizer, 0, wx.EXPAND|wx.ALIGN_RIGHT, 10)

        def CycleButtons(okBtn):        
            addButton.Enable(False)
            addAllButton.Enable(self.newTable.GetItemCount()>0)
            deleteButton.Enable(False)
            deleteAllButton.Enable(self.oldTable.GetItemCount()>0)
            refreshButton.Enable(True)
            okButton.Enable(okBtn)
            cancelButton.Enable(True)

        def OnRefresh(evt=None, table=None, data=None):
            self.oldItems = self.oldTable.GetAll()
            if not self.oldTable.GetItemCount():
                self.oldItems = [['**NODATA**']*len(self.header)]

            newItems = self.func(self.oldItems)
            for item in newItems:
                if item not in self.oldItems: continue
                newItems.remove(item)
            self.newItems = self.newTable.InsertItems(newItems)

            wx.CallAfter(CycleButtons, True)

            if evt: evt.Skip()
        refreshButton.Bind(wx.EVT_BUTTON, OnRefresh)

        def OnDelete(evt):
            self.newTable.InsertItems(self.oldTable.DeleteSelect())
            wx.CallAfter(OnRefresh)
            evt.Skip()
        deleteButton.Bind(wx.EVT_BUTTON, OnDelete)

        def OnDeleteAll(evt):
            self.newTable.InsertItems(self.oldTable.DeleteAll())
            wx.CallAfter(OnRefresh)
            evt.Skip()
        deleteAllButton.Bind(wx.EVT_BUTTON, OnDeleteAll)

        def OnAdd(evt):
            self.oldTable.InsertItems(self.newTable.DeleteSelect())
            wx.CallAfter(OnRefresh)
            evt.Skip()
        addButton.Bind(wx.EVT_BUTTON, OnAdd)

        def OnAddAll(evt):
            self.oldTable.InsertItems(self.newTable.DeleteAll())
            wx.CallAfter(OnRefresh)
            evt.Skip()
        addAllButton.Bind(wx.EVT_BUTTON, OnAddAll)

        def OnSelectedNew(evt):
            addButton.Enable(self.newTable.GetSelectedItemCount()>0)
            deleteButton.Enable(False)
            evt.Skip()
        self.newTable.Bind(wx.EVT_LIST_ITEM_SELECTED, OnSelectedNew)
        self.newTable.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnSelectedNew)

        def OnSelectedOld(evt):
            deleteButton.Enable(self.oldTable.GetSelectedItemCount()>0)
            addButton.Enable(False)
            evt.Skip()
        self.oldTable.Bind(wx.EVT_LIST_ITEM_SELECTED, OnSelectedOld)
        self.oldTable.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnSelectedOld)

        def OnOK(evt):
            oldItems = self.oldTable.GetAll()
            if len(oldItems) == 0:
                oldItems = [['**NODATA**']*len(self.header)]
            func(oldItems)

            self.Close()
        okButton.Bind(wx.EVT_BUTTON, OnOK)

        def OnClose(evt):
            self.MakeModal(False)
            self.parent.Enable(True)
            self.parent.dialog.buttonRow.cancelButton.Enable(True)
            self.parent.EnableButtons(True)
            self.GetParent().GetParent().Raise()
            self.Destroy()
        self.Bind(wx.EVT_CLOSE, OnClose)

        def OnCancel(evt):
            self.func(self.savedOld)
            self.Close()
        cancelButton.Bind(wx.EVT_BUTTON, OnCancel)

        CycleButtons(okBtn=False)
        
        sizer.Add((1,6))
        sizer.Fit(self)

        self.SetSize((500, -1))
        self.SetMinSize((500, -1))
        sizer.Layout()
        self.Raise()
        self.MakeModal(True)
        self.Show()
        wx.CallAfter(OnRefresh)