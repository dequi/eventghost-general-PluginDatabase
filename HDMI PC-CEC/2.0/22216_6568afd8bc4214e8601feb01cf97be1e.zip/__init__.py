# This file is a plugin for EventGhost.
# EventGhost is Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
# ================================
#
# Plugin Name:   RCAware PC-CEC
# Plugin Author: Patrick Byrne
#                RCAware, LLC
#
# ================================
# Revision history:
# -----------------
# 0.9 - Beta Release
# 1.0 - Initial Release - Samsung, Sony, LG, Others
# 1.1 - Panasonic
# 1.2 - Philips
# 1.3 - Yamaha (Generic)
# 1.4 - Sharp
# 1.5 - Monitor hotplugging physical address detection
# 1.6 Better Yamaha and possibly Generic amp sync

""" KNOWN ISSUES

Plugin stays loaded even if you cancel the install

TO DO

  GENERAL
    Add adjustable button repeat rate (helps volsyncint and mouse repeat timeout)
    
    Add multiple adapter support

  Panasonic
    Mouse drag not working, might not be Panasonic specific

""" 

help = """\
Plugin for <b><a href=www.RCAware.com>RCAware</a></b> PC-CEC Hardware but without their binary stuff."""

eg.RegisterPlugin(
    name = "HDMI PC-CEC",
    author = "Patrick Byrne, Achim Koenigs",
    version = "2.0",
    kind = "external",
    description = "RCAware PC-CEC",
    help = help,
    canMultiLoad = False,
    guid = '{D624DDBA-2536-4B53-B6B1-4779A733DFDE}',
)

import sys
import os
import thread
import threading
import time
import wx
import string
import copy
from ctypes import *
from _ctypes import LoadLibrary, FreeLibrary
from math import floor
import traceback

class lAddresses:
    addr = {}
    addr[0]="TV"
    addr[1]="Recording Device 1"
    addr[2]="Recording Device 2"
    addr[3]="Tuner 1"
    addr[4]="Playback Device 1"
    addr[5]="Audio System"
    addr[6]="Tuner 2"
    addr[7]="Tuner 3"
    addr[8]="Playback Device 2"
    addr[9]="Recording Device 3"
    addr[10]="Tuner 4"
    addr[11]="Playback Device 3"
    addr[12]="Reserved"
    addr[13]="Reserved"
    addr[14]="Free Use"


class lDevTypes:
    addr = {}
    addr[0]="00"
    addr[1]="01"
    addr[2]="01"
    addr[3]="03"
    addr[4]="04"
    addr[5]="05"
    addr[6]="03"
    addr[7]="03"
    addr[8]="04"
    addr[9]="01"
    addr[10]="03"
    addr[11]="04"
    addr[12]="02"
    addr[13]="02"
    addr[14]="Free Use"


class volMap:
    button = {}
    button["44.41"]=["Volume Up",False, 2]
    button["44.42"]=["Volume Down",False, -2]
    button["44.43"]=["Toggle Mute",False, 0]
    button["89.10.75"]=["Panasonic",False, None]
    button["7A"]=["Generic",False, None]


class cmdMap:
    cmd={'~': [ 'System Information', 'Polling Message', ['None'], '1', 'Used by any device for device discovery - similar to ping in other protocols.'], \
    '1': [ 'System Information', 'Polling Response', ['Polling Response'], 'None', 'Response by a device to device discovery - similar to ping in other protocols.'], \
    '32': [ 'System Information', 'Set Menu Language', ['Language'], 'None', 'Used by a TV or another device to indicate the menu language.'], \
    '83': [ 'System Information', 'Give Physical Address', ['None'], '84', 'A request to a device to return its physical address.'], \
    '84': [ 'System Information', 'Report Physical Address', ['Physical Address'], 'None', 'Used to inform all other devices of the mapping between physical and logical address of the initiator.'], \
    '91': [ 'System Information', 'Get Menu Language', ['None'], '32', 'Sent by a device capable of character generation (for OSD and Menus) to a TV in order to discover the currently selected Menu language. Also used by a TV during installation to discover the currently set menu language of other devices.'], \
    '9E': [ 'System Information', 'CEC Version', ['CEC Version'], 'None', 'Used to indicate the supported CEC version, in response to a <Get CEC Version'], \
    '9F': [ 'System Information', 'Get CEC Version', ['None'], '9E', 'Used by a device to enquire which version of CEC the target supports'], \
    '00': [ 'General Protocol', 'Feature Abort', ['Feature Opcode','Abort Reason'], 'None', 'Used as a response to indicate that the device does not support the requested message type, or that it cannot execute it at the present time.'], \
    'FF': [ 'General Protocol', 'Abort Message', ['None'], 'None', 'This message is reserved for testing purposes.'], \
    '04': [ 'One Touch Play', 'Image View On', ['None'], 'None', 'Sent by a source device to the TV whenever it enters the active state (alternatively it may send <Text View On>).'], \
    '0D': [ 'One Touch Play', 'Text View On', ['None'], 'None', 'As <Image View On>, but should also remove any text, menus and PIP windows from the TV display.'], \
    '82': [ 'One Touch Play', 'Active Source', ['Physical Address'], 'None', 'Used by a new source to indicate that it has started to transmit a stream OR used in response to a <Request Active Source'], \
    '05': [ 'Tuner Control', 'Tuner Step Increment', ['None'], 'None', 'Used to tune to next highest service in a tuner service list. Can be used for PIP.'], \
    '06': [ 'Tuner Control', 'Tuner Step Decrement', ['None'], 'None', 'Used to tune to next lowest service in a tuner service list. Can be used for PIP.'], \
    '07': [ 'Tuner Control', 'Tuner Device Status', ['Tuner Device Info'], 'None', 'Use by a tuner device to provide its status to the initiator of the <Give Tuner Device Status> message.'], \
    '08': [ 'Tuner Control', 'Give Tuner Device Status', ['Status Request'], '07', 'Used to request the status of a tuner device.'], \
    '92': [ 'Tuner Control', 'Select Analogue Service', ['Analogue Broadcast Type','Analogue Frequency','Broadcast System'], 'None', 'Directly selects an Analogue TV service'], \
    '93': [ 'Tuner Control', 'Select Digital Service', ['Digital Service Identification'], 'None', 'Directly selects a Digital TV, Radio or Data Broadcast Service'], \
    '09': [ 'One Touch Record', 'Record On', ['Record Source'], '0A', 'Attempt to record the specified source.'], \
    '0A': [ 'One Touch Record', 'Record Status', ['Record Status Info'], 'None', 'Used by a Recording Device to inform the initiator of the message <Record On> about its status.'], \
    '0B': [ 'One Touch Record', 'Record Off', ['None'], '0A', 'Requests a device to stop a recording.'], \
    '0F': [ 'One Touch Record', 'Record TV Screen', ['None'], '0A', 'Request by the Recording Device to record the presently displayed source.'], \
    '1A': [ 'Deck Control', 'Give Deck Status', ['Status Request'], '1B', 'Used to request the status of a device, regardless of whether or not it is the current active source.'], \
    '1B': [ 'Deck Control', 'Deck Status', ['Deck Info'], 'None', 'Used to provide a deck status to the initiator of the <Give Deck Status> message.'], \
    '41': [ 'Deck Control', 'Play', ['Play Mode'], 'None', 'Used to control the playback behaviour of a source device.'], \
    '42': [ 'Deck Control', 'Deck Control', ['Deck Control Mode'], 'None', 'Used to control a device media functions.'], \
    '33': [ 'Timer Programming', 'Clear Analogue Timer', ['Day of Month','Month of Year','Start Time','Duration','Recording Sequence','Analogue Broadcast Type','Analogue Frequency','Broadcast System'], '43', 'Used to clear an Analogue timer block of a device.'], \
    '34': [ 'Timer Programming', 'Set Analogue Timer', ['Day of Month','Month of Year','Start Time','Duration','Recording Sequence','Analogue Broadcast Type','Analogue Frequency','Broadcast System'], '35', 'Used to set a single timer block on an Analogue Recording Device.'], \
    '35': [ 'Timer Programming', 'Timer Status', ['Timer Status Data'], 'None', 'Used to send timer status to the initiator of a <Set Timer> message.'], \
    '43': [ 'Timer Programming', 'Timer Cleared Status', ['Timer Cleared Status Data'], 'None', 'Used to give the status of a <Clear Analogue Timer>, <Clear Digital Timer> or <Clear External Timer> message.'], \
    '67': [ 'Timer Programming', 'Set Timer Program Title', ['Program Title String'], 'None', 'Used to set the name of a program associated with a timer block. Sent directly after sending a <Set Analogue Timer> or <Set Digital Timer> message. The name is then associated with that timer block.'], \
    '97': [ 'Timer Programming', 'Set Digital Timer', ['Day of Month','Month of Year','Start Time','Duration','Recording Sequence','Digital Service Identification'], '35', 'Used to set a single timer block on a Digital Recording Device.'], \
    '99': [ 'Timer Programming', 'Clear Digital Timer', ['Day of Month','Month of Year','Start Time','Duration','Recording Sequence','Digital Service Identification'], '43', 'Used to clear a Digital timer block of a device.'], \
    'A1': [ 'Timer Programming', 'Clear External Timer', ['Day of Month','Month of Year','Start Time','Duration','Recording Sequence','External Source Specifier','External Plug | External Physical Address'], '43', 'Used to clear an External timer block of a device.'], \
    'A2': [ 'Timer Programming', 'Set External Timer', ['Day of Month','Month of Year','Start Time','Duration','Recording Sequence','External Source Specifier','External Plug | External Physical Address'], '35', 'Used to set a single timer block to record from an external device.'], \
    '36': [ 'Standby', 'Standby', ['None'], 'None', 'Switches one or all devices into standby mode. Can be used as a broadcast message or be addressed to a specific device. See section CEC 13.3 for important notes on the use of this message'], \
    '8D': [ 'Device Menu Control', 'Menu Request', ['Menu Request Type'], '8E', 'A request from the TV for a device to show/remove a menu or to query if a device is currently showing a menu.'], \
    '8E': [ 'Device Menu Control', 'Menu Status', ['Menu State'], 'None', 'Used to indicate to the TV that the device is showing/has removed a menu and requests the remote control keys to be passed though.'], \
    '44': [ 'Remote Control Passthrough', 'User Control Pressed', ['UI Command'], 'None', 'Used to indicate that the user pressed a remote control button or switched from one remote control button to another.'], \
    '45': [ 'Remote Control Passthrough', 'User Control Released', ['None'], 'None', 'Indicates that user released a remote control button (the last one indicated by the <User Control Pressed> message)'], \
    '70': [ 'System Audio Control', 'System Audio Mode Request', ['Physical Address'], '72', 'A device implementing System Audio Control and which has volume control RC buttons (eg TV or STB) requests to use System Audio Mode to the amplifier'], \
    '71': [ 'System Audio Control', 'Give Audio Status', ['None'], '7A', 'Requests an amplifier to send its volume and mute status'], \
    '72': [ 'System Audio Control', 'Set System Audio Mode', ['System Audio Status'], 'None', 'Turns the System Audio Mode On or Off.'], \
    '7A': [ 'System Audio Control', 'Report Audio Status', ['Audio Mute Status','Audio Volume Status'], 'None', 'Reports an amplifier volume and mute status.  Used to indicate the current audio mute status of a device.  Used to indicate the current audio volume status of a device.  N indicates audio playback volume, expressed as a percentage (0% - 100%). N=0 is no sound; N=100 is maximum volume sound level. The linearity of the sound level is device dependent. This value is mainly used for displaying a volume status bar on a TV screen.'], \
    '7D': [ 'System Audio Control', 'Give System Audio Mode Status', ['None'], '7E', 'Requests the status of the System Audio Mode'], \
    '7E': [ 'System Audio Control', 'System Audio Mode Status', ['System Audio Status'], 'None', 'Reports the current status of the System Audio Mode'], \
    '9A': [ 'Audio Rate Control', 'Set Audio Rate', ['Audio Rate'], 'None', 'Used to control audio rate from Source Device.'], \
    '46': [ 'Device OSD Transfer', 'Give OSD Name', ['None'], '47', 'Used to request the preferred OSD name of a device for use in menus associated with that device.'], \
    '47': [ 'Device OSD Transfer', 'Set OSD Name', ['OSD Name'], 'None', 'Used to set the preferred OSD name of a device for use in menus associated with that device.'], \
    '64': [ 'OSD Display', 'Set OSD String', ['Display Control','OSD String'], 'None', 'Used to send a text message to output on a TV.'], \
    '80': [ 'Routing Control', 'Routing Change', ['Original Address','New Address'], 'None', 'Sent by a CEC Switch when it is manually switched to inform all other devices on the network that the active route below the switch has changed.'], \
    '81': [ 'Routing Control', 'Routing Information', ['Physical Address'], 'None', 'Sent by a CEC Switch to indicate the active route below the switch.'], \
    '82': [ 'Routing Control', 'Active Source', ['Physical Address'], 'None', 'Used by a new source to indicate that it has started to transmit a stream OR used in response to a <Request Active Source'], \
    '85': [ 'Routing Control', 'Request Active Source', ['None'], '82', 'Used by a new device to discover the status of the system.'], \
    '86': [ 'Routing Control', 'Set Stream Path', ['Physical Address'], '82', 'Used by the TV to request a streaming path from the specified physical address.'], \
    '9D': [ 'Routing Control', 'Inactive Source', ['Physical Address'], 'None', 'Used by the currently active source to inform the TV that it has no video to be presented to the user, or is going into standby as the result of a local user command on the device.'], \
    '87': [ 'Vendor Specific Commands', 'Device Vendor ID', ['Vendor ID'], 'None', 'Reports the vendor ID of this device.'], \
    '89': [ 'Vendor Specific Commands', 'Vendor Command', ['Vendor Specific Data'], 'None', 'Allows vendor specific commands to be sent between two devices.'], \
    '8A': [ 'Vendor Specific Commands', 'Vendor Remote Button Down', ['Vendor Specific RC Code'], 'None', 'Indicates that a remote control button has been depressed.'], \
    '8B': [ 'Vendor Specific Commands', 'Vendor Remote Button Up', ['None'], 'None', 'Indicates that a remote control button (the last button pressed indicated by the Vendor Remote Button Down message) has been released.'], \
    '8C': [ 'Vendor Specific Commands', 'Give Device Vendor ID', ['None'], '87', 'Requests the Vendor ID from a device.'], \
    '9E': [ 'Vendor Specific Commands', 'CEC Version', ['CEC Version'], 'None', 'Used to indicate the supported CEC version, in response to a <Get CEC Version'], \
    '9F': [ 'Vendor Specific Commands', 'Get CEC Version', ['None'], '9E', 'Used by a device to enquire which version of CEC the target supports'], \
    'A0': [ 'Vendor Specific Commands', 'Vendor Command With ID', ['Vendor ID','Vendor Specific data'], 'None', 'Allows vendor specific commands to be sent between two devices or broadcast.'], \
    '8F': [ 'Power Status', 'Give Device Power Status', ['None'], '90', 'Used to determine the current power status of a target device'], \
    '90': [ 'Power Status', 'Report Power Status', ['Power Status'], 'None', 'Used to inform a requesting device of the current power status']
    }
    opt={'UI Command': {
        '00': 'Select', '01': 'Up', '02': 'Down', '03': 'Left', '04': 'Right', '05': 'Right-Up', '06': 'Right-Down', '07': 'Left-Up', '08': 'Left-Down',\
        '09': 'Root Menu', '0A': 'Setup Menu', '0B': 'Contents Menu', '0C': 'Favorite Menu', '0D': 'Exit',\
        '20': '0', '21': '1', '22': '2', '23': '3', '24': '4',  '25': '5', '26': '6', '27': '7', '28': '8', '29': '9',\
        '2A': 'Dot', '2B': 'Enter', '2C': 'Clear', '2F': 'Next Favorite', '30': 'Channel Up', '31': 'Channel Down', '32': 'Previous Channel',\
        '33': 'Sound Select', '34': 'Input Select', '35': 'Display Information', '36': 'Help', '37': 'Page Up', '38': 'Page Down', '40': 'Power',\
        '41': 'Volume Up', '42': 'Volume Down', '43': 'Mute', '44': 'Play', '45': 'Stop', '46': 'Pause', '47': 'Record', '48': 'Rewind', '49': 'Fast forward',\
        '4A': 'Eject', '4B': 'Forward', '4C': 'Backward', '4D': 'Stop-Record', '4E': 'Pause-Record', '50': 'Angle', '51': 'Sub picture',\
        '52': 'Video on Demand', '53': 'Electronic Program Guide', '54': 'Timer Programming', '55': 'Initial Configuration',\
        '60': 'Play Function', '61': 'Pause-Play Function', '62': 'Record Function', '63': 'Pause-Record Function', '64': 'Stop Function',\
        '65': 'Mute Function', '66': 'Restore Volume Function', '67': 'Tune Function', '68': 'Select Media Function',\
        '69': 'Select A/V Input Function', '6A': 'Select Audio Input Function',\
        '6B': 'Power Toggle Function', '6C': 'Power Off Function', '6D': 'Power On Function',\
        '71': 'F1 (Blue)', '72': 'F2 (Red)', '73': 'F3 (Green)', '74': 'F4 (Yellow)', '75': 'F5'},
    'Polling Response': {'01': 'Responding', '02': 'Not Responding'},
    'CEC Version': {'00': 'Version 1.1', '01': 'Version 1.2', '02': 'Version 1.2a', '03': 'Version 1.3', '04': 'Version 1.3a'},
    'Abort Reason': {'00': 'Unrecognized opcode', '01': 'Not in correct mode to respond', '02': 'Cannot provide source', '03': 'Invalid operand', '04': 'Refused'},
    'Status Request': {'01': 'On', '02': 'Off', '03': 'Once'},
    'Analogue Broadcast Type': {'00': 'Cable', '01': 'Satellite', '02': 'Terrestrial'},
    'Deck Info': { '11': 'Play', '12': 'Record', '13': 'Play Reverse', '14': 'Still', '15': 'Slow', '16': 'Slow Reverse', '17': 'Fast Forward', '18': 'Fast Reverse', '19': 'No Media',\
        '1A': 'Stop', '20': 'LG Stop', '1B': 'Skip Forward / Wind', '1C': 'Skip Reverse / Rewind', '1D': 'Index Search Forward', '1E': 'Index Search Reverse', '1F': 'Other Status'},
    'Play Mode': {'24': 'Play Forward', '20': 'Play Reverse', '25': 'Play Still', '05': 'Fast Forward Min Speed', '06': 'Fast Forward Medium Speed', '07': 'Fast Forward Max Speed',\
        '09': 'Fast Reverse Min Speed', '0A': 'Fast Reverse Medium Speed', '0B': 'Fast Reverse Max Speed', '15': 'Slow Forward Min Speed', '16': 'Slow Forward Medium Speed',\
        '17': 'Slow Forward Max Speed', '19': 'Slow Reverse Min Speed', '1A': 'Slow Reverse Medium Speed', '1B': 'Slow Reverse Max Speed'},
    'Deck Control Mode': {'01': 'Skip Forward / Wind', '02': 'Skip Reverse / Rewind', '03': 'Stop', '04': 'Eject'},
    'Menu Request Type': {'00': 'Activate', '01': 'Deactivate', '02': 'Query'},
    'Menu State': {'00': 'Activated', '01': 'Deactivated'},
    'Audio Mute Status': {'00': 'Audio Mute Off', '01': 'Audio Mute On'},
    'System Audio Status': {'00': 'Off', '01': 'On'},
    'Power Status': {'00': 'On', '01': 'Standby', '02': 'In transition Standby to On', '03': 'In transition On to Standby'},
    'Record Status Info': {'01': 'Recording currently selected source', '02': 'Recording Digital Service', '03': 'Recording Analogue Service',
    '04': 'Recording External input', '05': 'No recording - unable to record Digital Service', '06': 'No recording - unable to record Analogue Service',
    '07': 'No recording - unable to select required service', '09': 'No recording - invalid External plug number',
    '0A': 'No recording - invalid External Physical Address', '0B': 'No recording - CA system not supported',
    '0C': 'No Recording - No or Insufficient CA Entitlements', '0D': 'No recording - Not allowed to copy source',
    '0E': 'No recording - No further copies allowed', '10': 'No recording - no media', '11': 'No recording - playing',
    '12': 'No recording - already recording', '13': 'No recording - media protected', '14': 'No recording - no source signal',
    '15': 'No recording - media problem', '16': 'No recording - not enough space available', '17': 'No recording - Parental Lock On',
    '1A': 'Recording terminated normally', '1B': 'Recording has already terminated', '1F': 'No recording - other reason'}
    }
    buttons=['05','06','41','42','44','8A','92','93']


class TextEntryDialog(wx.Dialog):
    def __init__(self, parent, id, title):
        wx.Dialog.__init__(self, parent, id, title, (400,300), style=wx.EXPAND|wx.ALL|wx.ALIGN_CENTER|wx.RESIZE_BORDER)
        panel = wx.Panel(self, -1)
        sizer = wx.BoxSizer(wx.VERTICAL)
        
        myGrid0 = wx.GridBagSizer(1, 1)
        Add = myGrid0.Add
        
        input = wx.TextCtrl(panel, -1, pos=wx.DefaultPosition, size=(350,160), style=wx.TE_MULTILINE)
        
        Add(input, (0,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, border=10)
        
        okBtn = wx.Button(panel, wx.ID_OK, "OK")
        cancelBtn = wx.Button(panel, wx.ID_CANCEL, "Cancel")
        
        sizer.Add(myGrid0, 0, wx.EXPAND, border=10)
        
        myGrid1 = wx.GridBagSizer(1, 3)
        Add = myGrid1.Add
           
        Add(okBtn, (0,1), flag = wx.ALIGN_CENTER_HORIZONTAL)
        Add(cancelBtn, (0,2), flag = wx.ALIGN_CENTER_HORIZONTAL)
      
        sizer.Add(myGrid1, 0, wx.EXPAND, border=10)
        
        def OnOkBtnPress(event):
            self.SetReturnCode(wx.ID_OK)
            self.EndModal(wx.ID_OK)
        
        def OnCancelBtnPress(event):
            self.SetReturnCode(wx.ID_CANCEL)
            self.EndModal(wx.ID_CANCEL)
        
        okBtn.Bind(wx.EVT_BUTTON, OnOkBtnPress)
        cancelBtn.Bind(wx.EVT_BUTTON, OnCancelBtnPress)
        
        panel.SetSizerAndFit(sizer)
        self.Fit()
        self.SetMinSize(self.GetSize())
        self.CentreOnParent()
        self.input = input
    
    def SetValue(self, value):
        self.input.SetValue(value)
    
    def GetValue(self):
        return self.input.GetValue()
    

class MouseMapper(wx.Dialog):
    def __init__(self, parent, id, title):
        self.mouseMap = {}
        self.cmdMap = cmdMap

        choicesType=['None','moverelative','moveabsolute','rightclick','leftclick','toggle']
        choicesGenEvent=['False','True']

        def getChoiceIdx(list,choice):
            for idx,value in enumerate(list):
                if value == choice:
                    return idx
        
        code=""
        name=""
        gEvent=0
        type=0
        x="0"
        y="0"
                
        wx.Dialog.__init__(self, parent, id, title, (350,250), style=wx.EXPAND|wx.ALL|wx.ALIGN_CENTER|wx.RESIZE_BORDER)
        panel = wx.Panel(self, -1)
        sizer = wx.BoxSizer(wx.VERTICAL)
        
        itemList = wx.ListCtrl(panel, -1, pos=wx.DefaultPosition,
            size=(400,250), style=wx.LC_REPORT | wx.LC_SINGLE_SEL)

        itemList.InsertColumn(0, "Code")
        itemList.InsertColumn(1, "Name")
        itemList.InsertColumn(2, "Gen Event")
        itemList.InsertColumn(3, "Type")
        itemList.InsertColumn(4, "X")
        itemList.InsertColumn(5, "Y")

        self.itemList=itemList

        sizer.Add(self.itemList, 1, flag = wx.ALL|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, border=10)

        myGrid1 = wx.GridBagSizer(7, 7)
        Add = myGrid1.Add

        #Detect button press
        detectBtn = wx.Button(panel, -1, "Detect")
        Add(detectBtn, (0,1), flag = wx.ALIGN_CENTER_HORIZONTAL)
        
        addBtn = wx.Button(panel, -1, "Add")
        Add(addBtn, (0,3), flag = wx.ALIGN_CENTER_HORIZONTAL)
       
        delBtn = wx.Button(panel, -1, "Delete")
        Add(delBtn, (0,4), flag = wx.ALIGN_CENTER_HORIZONTAL)
        delBtn.Enable(False)

        mapImpExpBtn = wx.Button(panel, -1, "Import/Export")
        Add(mapImpExpBtn, (0,7), flag = wx.ALIGN_CENTER_HORIZONTAL)
        
        sizer.Add(myGrid1,0, wx.EXPAND, border=10)
        sizer.Add((10,10))

        myGrid2 = wx.GridBagSizer(7, 7)
        Add = myGrid2.Add

        #Cec Code Text
        codeTxt = wx.StaticText(panel, 9, "Code:")
        codeCtrl = wx.TextCtrl(panel, value=code)
        Add(codeTxt,(0,1))
        Add(codeCtrl,(0,2))

        #Name Text
        nameTxt = wx.StaticText(panel, 9, "Name:")
        nameCtrl = wx.TextCtrl(panel, value=name)
        Add(nameTxt,(0,3))
        Add(nameCtrl,(0,4))

        #Generate Event dropdown
        eventTxt = wx.StaticText(panel, 9, "Gen Event:")
        eventCtrl = wx.Choice(panel, -1, choices=choicesGenEvent)
        eventCtrl.SetSelection(gEvent)
        Add(eventTxt,(0,5))
        Add(eventCtrl,(0,6))

        #control type dropdown
        typeTxt = wx.StaticText(panel, 9, "Type:")
        typeCtrl = wx.Choice(panel, -1, choices=choicesType)
        typeCtrl.SetSelection(type)
        Add(typeTxt,(1,1))
        Add(typeCtrl,(1,2))

        #X Text
        xTxt = wx.StaticText(panel, 9, "Horizontal:")
        xCtrl = wx.TextCtrl(panel, value=x)
        Add(xTxt,(1,3))
        Add(xCtrl,(1,4))

        #Y Text
        yTxt = wx.StaticText(panel, 9, "Vertical:")
        yCtrl = wx.TextCtrl(panel, value=y)
        Add(yTxt,(1,5))
        Add(yCtrl,(1,6))

        sizer.Add(myGrid2,0, wx.EXPAND, border=10)
        sizer.Add((10,10))
        
        myGrid3 = wx.GridBagSizer(7, 7)
        Add = myGrid3.Add
        
        lineCtrl = wx.StaticLine( panel, -1, [0,0], [550,1], wx.LI_HORIZONTAL )
        Add(lineCtrl, (0,0))

        sizer.Add(myGrid3, 0, wx.FIXED_MINSIZE, border=5)
        sizer.Add((5,5))

        myGrid4 = wx.GridBagSizer(7, 7)
        Add = myGrid4.Add
        
        okBtn = wx.Button(panel, wx.ID_OK, "OK")
        Add(okBtn, (0,18))
        cancelBtn = wx.Button(panel, wx.ID_CANCEL, "Cancel")
        Add(cancelBtn, (0,20))
        
        sizer.Add(myGrid4,0, wx.EXPAND|wx.ALIGN_CENTER, border=10)
        sizer.Add((10,10))
        
        def updMap(detailList,code,name=None,gEvent=None,type=None,x=None,y=None):
            try:
                del detailList[code]
            except:
                pass
            if name != None:
                detailList[code]=[name,gEvent,type,int(x),int(y)]
            return detailList

        def AfterItemListClick(oldSel):
            fSel = itemList.GetFirstSelected()
            if fSel == oldSel:
                itemList.SetItemState(fSel, 0, wx.LIST_STATE_SELECTED|wx.LIST_STATE_FOCUSED)

        def OnItemListClick(event):
            fSel=itemList.GetFirstSelected()
            if fSel != -1:
                wx.CallAfter(AfterItemListClick, fSel)
            event.Skip()

        def OnItemListSelect(event):
            fSel = self.itemList.GetFirstSelected()
            delBtn.Enable(not int(fSel == -1))
            
            if fSel != -1:
                codeCtrl.ChangeValue(self.itemList.GetItem(fSel,0).GetText())
                nameCtrl.SetValue(self.itemList.GetItem(fSel,1).GetText())
                eventCtrl.SetSelection(getChoiceIdx(choicesGenEvent,self.itemList.GetItem(fSel,2).GetText()))
                typeCtrl.SetSelection(getChoiceIdx(choicesType,self.itemList.GetItem(fSel,3).GetText()))
                xCtrl.SetValue(self.itemList.GetItem(fSel,4).GetText())
                yCtrl.SetValue(self.itemList.GetItem(fSel,5).GetText())
                addBtn.SetLabel('Update')
            else:
                codeCtrl.ChangeValue("")
                nameCtrl.SetValue("")
                eventCtrl.SetSelection(0)
                typeCtrl.SetSelection(0)
                xCtrl.SetValue("0")
                yCtrl.SetValue("0")
                addBtn.SetLabel('Add')
            event.Skip()

        def OnMapImpExpBtnPress(event):
            importError=True
            editMap=str(self.mouseMap).replace('], ','], \n')
            while importError:
                dlg = TextEntryDialog(panel, -1, 'Import/Export Mouse Map')
                dlg.CentreOnParent()
                dlg.SetValue(editMap)
                if dlg.ShowModal() == wx.ID_OK:
                    mdlg = wx.MessageDialog(panel, 'Are you sure you want to overwrite mouse map?', 'Import Map',  wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
                    mdlg.CentreOnParent()
                    if mdlg.ShowModal() == wx.ID_YES:
                        editMap=dlg.GetValue()
                        try:
                            self.popItemList(eval(dlg.GetValue()))
                            self.mouseMap = eval(dlg.GetValue())
                            importError=False
                        except:
                            dlg = wx.MessageDialog(panel, 'Error importing map, please correct and retry.', 'Map Import Error',  wx.OK)
                            dlg.CentreOnParent()
                            dlg.ShowModal()
                            pass
                    else:
                        importError=False
                else:
                    importError=False
            event.Skip()

        def OnCodeCtrlChange(event):
            cecCode=''
            loseFocus=False
            cecCode=event.GetString()
            try:
                niceCode=""
                opts=''
                c=cecCode.split('.')
                try:
                    if len(c) == 1:
                        niceCode=self.cmdMap.cmd[c[0]][1]
                    else:
                        niceCode=self.cmdMap.opt[self.cmdMap.cmd[c[0]][2][0]][c[1]]
                    nameCtrl.SetValue(niceCode)
                except:
                    nameCtrl.SetValue(cecCode)
                    pass
            except:
                nameCtrl.SetValue(cecCode)
                pass
            event.Skip()
        
        def OnDetectBtnPress(event):
            result='TIMEOUT.WAITING.FOR.RESPONSE'
            progress=0
            pBarDialog = wx.ProgressDialog ( 'Detect Button Press', 'Press any key on TV remote...', maximum = 10, parent=self )
            pBarDialog.CentreOnParent()
            pBarDialog.SetFocus()
            while result == 'TIMEOUT.WAITING.FOR.RESPONSE' and progress <= 10:
                pBarDialog.Update (progress, 'Press any key on TV remote...')
                progress=progress+1
                result=eg.plugins.HdmiCec.Read('BUTTONS')
            pBarDialog.Destroy()
            if result <> 'TIMEOUT.WAITING.FOR.RESPONSE':
                if addBtn.Label == 'Add':
                    for idx in range(self.itemList.GetItemCount()):
                        if self.itemList.GetItem(idx, 0).GetText() == result:
                            itemList.SetItemState(idx, wx.LIST_STATE_SELECTED, wx.LIST_STATE_SELECTED)
                            return 0
                codeCtrl.SetValue(result)
            event.Skip()
        
        def OnAddBtnPress(event):
            idx=-1
            code=codeCtrl.GetValue()
            name=nameCtrl.GetValue()
            if code == '' or name == '':
                dlg=eg.MessageDialog(panel, 'Code and Name are required.', caption='Mapping Error', style=wx.OK, pos=wx.Point(-1, -1))
                dlg.CentreOnParent()
                dlg.ShowModal()
                dlg.Destroy()
                event.Skip()
                return
            gEvent=eventCtrl.GetStringSelection()
            type=typeCtrl.GetStringSelection()
            x = xCtrl.GetValue()
            y = yCtrl.GetValue()
            if addBtn.Label == 'Add':
                try:
                    test=self.mouseMap[code]
                    dlg=eg.MessageDialog(panel, 'CEC Code Already Assigned.', caption='Mapping Error', style=wx.OK, pos=wx.Point(-1, -1))
                    dlg.CentreOnParent()
                    dlg.ShowModal()
                    dlg.Destroy()
                    event.Skip()
                    return
                    if type == "toggle":
                        for i, c in enumerate(self.mouseMap):
                            if c != code and self.mouseMap[c][2] == "toggle":
                                self.mouseMap[c][2] = "None"
                except:
                    pass
                self.mouseMap = updMap(self.mouseMap,code,name,eval(gEvent),type,x,y)
            else:
                idx=self.itemList.GetFirstSelected()
                try:
                    for i, c in enumerate(sorted(self.mouseMap)):
                        if c == code and i != idx:
                            dlg=eg.MessageDialog(panel, 'CEC Code Already Assigned.', caption='Mapping Error', style=wx.OK, pos=wx.Point(-1, -1))
                            dlg.CentreOnParent()
                            dlg.ShowModal()
                            dlg.Destroy()
                            event.Skip()
                            return
                    for i, c in enumerate(self.mouseMap):
                        if type == "toggle" and c != code and self.mouseMap[c][2] == "toggle":
                            self.mouseMap[c][2] = "None"
                except:
                    pass
                curMap=copy.deepcopy(self.mouseMap)
                del curMap[code]
                newMap=copy.deepcopy(curMap)
                newMap = updMap(newMap,code,name,eval(gEvent),type,x,y)
                if newMap != curMap:
                    self.mouseMap=newMap
            self.popItemList(self.mouseMap)
            self.itemList.Select(idx)
            event.Skip()

        def OnDelBtnPress(event):
            fSel=self.itemList.GetFirstSelected()
            code = self.itemList.GetItem(fSel,0).GetText()
            if code == '45':
                dlg = wx.MessageDialog(panel, 'Button Released should not be removed.', 'Map Editor Warning',  wx.OK)
                #dlg.CentreOnParent()
                dlg.ShowModal()
                return 0
            self.mouseMap = updMap(self.mouseMap, code)
            self.itemList.DeleteItem(fSel)
            event.Skip()

        def OnOkBtnPress(event):
            self.SetReturnCode(wx.ID_OK)
            self.EndModal(wx.ID_OK)

        def OnCancelBtnPress(event):
            self.SetReturnCode(wx.ID_CANCEL)
            self.EndModal(wx.ID_CANCEL)

        mapImpExpBtn.Bind(wx.EVT_BUTTON, OnMapImpExpBtnPress)
        detectBtn.Bind(wx.EVT_BUTTON, OnDetectBtnPress)
        itemList.Bind(wx.EVT_LIST_ITEM_SELECTED, OnItemListSelect)
        itemList.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnItemListSelect)
        itemList.Bind(wx.EVT_LEFT_DOWN, OnItemListClick)
        codeCtrl.Bind(wx.EVT_TEXT, OnCodeCtrlChange)
        addBtn.Bind(wx.EVT_BUTTON, OnAddBtnPress)
        delBtn.Bind(wx.EVT_BUTTON, OnDelBtnPress)
        okBtn.Bind(wx.EVT_BUTTON, OnOkBtnPress)
        cancelBtn.Bind(wx.EVT_BUTTON, OnCancelBtnPress)

        panel.SetSizerAndFit(sizer)
        self.Fit()
        self.SetMinSize(self.GetSize())
        self.CentreOnParent()
        
    def popItemList(self,itemDtls):
        self.itemList.DeleteAllItems()
        for idx,code in enumerate(sorted(itemDtls)):
            self.itemList.InsertStringItem(sys.maxint, code)
            self.itemList.SetStringItem(idx, 1, itemDtls[code][0])
            self.itemList.SetStringItem(idx, 2, str(itemDtls[code][1]))
            self.itemList.SetStringItem(idx, 3, str(itemDtls[code][2]))
            self.itemList.SetStringItem(idx, 4, str(itemDtls[code][3]))
            self.itemList.SetStringItem(idx, 5, str(itemDtls[code][4]))

        for idx in range(self.itemList.GetColumnCount()):
            self.itemList.SetColumnWidth(idx, wx.LIST_AUTOSIZE_USEHEADER)
            size =self.itemList.GetColumnWidth(idx)
            self.itemList.SetColumnWidth(idx, wx.LIST_AUTOSIZE)
            self.itemList.SetColumnWidth(idx, max(size, self.itemList.GetColumnWidth(idx) + 5))
        self.Fit()

    def GetValue(self):
        return self.mouseMap

    def SetValue(self,mouseMap):
        self.mouseMap = mouseMap
        self.popItemList(self.mouseMap)

class ButtonMapper(wx.Dialog):

    def __init__(self, parent, id, title):
        self.btnMap = {}
        self.cmdMap = cmdMap
        choicesGenEvent=['False','True']

        def getChoiceIdx(list,choice):
            for idx,value in enumerate(list):
                if value == choice:
                    return idx
        
        mapName=[]
        code=""
        name=""
        gEvent=0
        key=""
        longKeyTm="0"
        longKey=""
        
        wx.Dialog.__init__(self, parent, id, title, (350,300), style=wx.EXPAND|wx.ALL|wx.ALIGN_CENTER|wx.RESIZE_BORDER)
        panel = wx.Panel(self, -1)
        sizer = wx.BoxSizer(wx.VERTICAL)
        
        myGrid0 = wx.GridBagSizer(7, 7)
        Add = myGrid0.Add
        
        mapNameTxt = wx.StaticText(panel, 9, "Map Name:")
        self.mapNameCtrl = wx.Choice(panel, -1, choices=['Media Center'])
        self.mapNameCtrl.SetSelection(0)
        Add(mapNameTxt,(0,1))
        Add(self.mapNameCtrl,(0,2))
        
        mapAddBtn = wx.Button(panel, -1, "Add")
        Add(mapAddBtn, (0,4), flag = wx.ALIGN_CENTER_HORIZONTAL)
        
        mapDelBtn = wx.Button(panel, -1, "Delete")
        Add(mapDelBtn, (0,5), flag = wx.ALIGN_CENTER_HORIZONTAL)
        #mapDelBtn.Enable(True)
        
        mapImpExpBtn = wx.Button(panel, -1, "Import/Export")
        Add(mapImpExpBtn, (0,6), flag = wx.ALIGN_CENTER_HORIZONTAL)
        
        sizer.Add((10,10))
        sizer.Add(myGrid0,0, wx.EXPAND, border=10)
        sizer.Add((10,10))

        itemList = wx.ListCtrl(panel, -1, pos=wx.DefaultPosition,
            size=(300,250), style=wx.LC_REPORT | wx.LC_SINGLE_SEL)

        itemList.InsertColumn(0, "Code")
        itemList.InsertColumn(1, "Name")
        itemList.InsertColumn(2, "Gen Event")
        itemList.InsertColumn(3, "Key")
        itemList.InsertColumn(4, "Long Time")
        itemList.InsertColumn(5, "Long Key")

        self.itemList=itemList

        sizer.Add(self.itemList, 1, flag = wx.ALL|wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, border=10)

        myGrid1 = wx.GridBagSizer(7, 7)
        Add = myGrid1.Add

        #Detect button press
        detectBtn = wx.Button(panel, -1, "Detect")
        Add(detectBtn, (0,1), flag = wx.ALIGN_CENTER_HORIZONTAL)
        
        addBtn = wx.Button(panel, -1, "Add")
        Add(addBtn, (0,6), flag = wx.ALIGN_CENTER_HORIZONTAL)
       
        delBtn = wx.Button(panel, -1, "Delete")
        Add(delBtn, (0,8), flag = wx.ALIGN_CENTER_HORIZONTAL)
        delBtn.Enable(False)

        sizer.Add(myGrid1,0, wx.EXPAND, border=10)
        sizer.Add((10,10))

        myGrid2 = wx.GridBagSizer(7, 7)
        Add = myGrid2.Add

        #Cec Code Text
        codeTxt = wx.StaticText(panel, 9, "Code:")
        codeCtrl = wx.TextCtrl(panel, value=code)
        Add(codeTxt,(0,1))
        Add(codeCtrl,(0,2))
        
        #Name Text
        nameTxt = wx.StaticText(panel, 9, "Name:")
        nameCtrl = wx.TextCtrl(panel, value=name)
        Add(nameTxt,(0,3))
        Add(nameCtrl,(0,4))
        
        #Generate Event dropdown
        eventTxt = wx.StaticText(panel, 9, "Gen Event:")
        eventCtrl = wx.Choice(panel, -1, choices=choicesGenEvent)
        eventCtrl.SetSelection(gEvent)
        Add(eventTxt,(0,5))
        Add(eventCtrl,(0,6))

        #key text
        keyTxt = wx.StaticText(panel, 9, "Key:")
        keyCtrl = wx.TextCtrl(panel, value=key)
        Add(keyTxt,(1,1))
        Add(keyCtrl,(1,2))

        #long key time
        longKeyTmTxt = wx.StaticText(panel, 9, "Long Time:")
        longKeyTmCtrl = wx.TextCtrl(panel, value=longKeyTm)
        Add(longKeyTmTxt,(1,3))
        Add(longKeyTmCtrl,(1,4))

        #long key text
        longKeyTxt = wx.StaticText(panel, 9, "Long Key:")
        longKeyCtrl = wx.TextCtrl(panel, value=longKey)
        Add(longKeyTxt,(1,5))
        Add(longKeyCtrl,(1,6))

        sizer.Add(myGrid2,0, wx.EXPAND, border=10)
        sizer.Add((10,10))
        
        myGrid3 = wx.GridBagSizer(7, 7)
        Add = myGrid3.Add
        
        lineCtrl = wx.StaticLine( panel, -1, [0,0], [550,1], wx.LI_HORIZONTAL )
        Add(lineCtrl, (0,0))

        sizer.Add(myGrid3, 0, wx.FIXED_MINSIZE, border=5)
        sizer.Add((5,5))

        myGrid4 = wx.GridBagSizer(7, 7)
        Add = myGrid4.Add
        
        okBtn = wx.Button(panel, wx.ID_OK, "OK")
        Add(okBtn, (0,18))
        cancelBtn = wx.Button(panel, wx.ID_CANCEL, "Cancel")
        Add(cancelBtn, (0,20))
        
        sizer.Add(myGrid4,0, wx.EXPAND|wx.ALIGN_CENTER, border=10)
        sizer.Add((10,10))
        
        def updMap(detailList,code,name=None,gEvent=None,key=None,longKeyTm=None,longKey=None):
            try:
                del detailList[code]
            except:
                pass
            if name != None:
                detailList[code]=[name,gEvent,key,float(longKeyTm),longKey]
            return detailList

        def AfterItemListClick(oldSel):
            fSel = itemList.GetFirstSelected()
            if fSel == oldSel:
                itemList.SetItemState(fSel, 0, wx.LIST_STATE_SELECTED|wx.LIST_STATE_FOCUSED)

        def OnItemListClick(event):
            fSel=itemList.GetFirstSelected()
            if fSel != -1:
                wx.CallAfter(AfterItemListClick, fSel)
            event.Skip()

        def OnItemListSelect(event):
            fSel = self.itemList.GetFirstSelected()
            delBtn.Enable(not int(fSel == -1))
            
            if fSel != -1:
                codeCtrl.ChangeValue(self.itemList.GetItem(fSel,0).GetText())
                nameCtrl.SetValue(self.itemList.GetItem(fSel,1).GetText())
                eventCtrl.SetSelection(getChoiceIdx(choicesGenEvent,self.itemList.GetItem(fSel,2).GetText()))
                keyCtrl.SetValue(self.itemList.GetItem(fSel,3).GetText())
                longKeyTmCtrl.SetValue(self.itemList.GetItem(fSel,4).GetText())
                longKeyCtrl.SetValue(self.itemList.GetItem(fSel,5).GetText())
                addBtn.SetLabel('Update')
            else:
                codeCtrl.ChangeValue("")
                nameCtrl.SetValue("")
                eventCtrl.SetSelection(0)
                keyCtrl.SetValue("")
                longKeyTmCtrl.SetValue("0")
                longKeyCtrl.SetValue("")
                addBtn.SetLabel('Add')
            event.Skip()

        def OnMapNameCtrlChange(event):
            mapName=self.mapNameCtrl.GetStringSelection()
            self.popItemList(self.btnMap[mapName])
            event.Skip()
        
        def OnMapAddBtnPress(event):
            dlg = wx.TextEntryDialog(panel, 'New Map Name','Enter a name for the new map...')
            dlg.CentreOnParent()
            if dlg.ShowModal() == wx.ID_OK:
                self.btnMap[dlg.GetValue()]=copy.deepcopy(self.btnMap[self.mapNameCtrl.GetStringSelection()])
                self.mapNameCtrl.Clear()
                self.mapNameCtrl.AppendItems(self.btnMap.keys())
                self.mapNameCtrl.SetSelection(self.btnMap.keys().index(dlg.GetValue()))
            dlg.Destroy()
            event.Skip()

        def OnMapDelBtnPress(event):
            dlg = wx.MessageDialog(panel, 'Are you sure you want to delete map "' + self.mapNameCtrl.GetStringSelection() + '"?', 'Delete Map',  wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
            dlg.CentreOnParent()
            if dlg.ShowModal() == wx.ID_YES:
                del self.btnMap[self.mapNameCtrl.GetStringSelection()]
            event.Skip()

        def OnMapImpExpBtnPress(event):
            importError=True
            editMap=str(self.btnMap[self.mapNameCtrl.GetStringSelection()]).replace('], ','], \n')
            while importError:
                dlg = TextEntryDialog(panel, -1, 'Import/Export Button Map')
                dlg.CentreOnParent()
                dlg.SetValue(editMap)
                if dlg.ShowModal() == wx.ID_OK:
                    mdlg = wx.MessageDialog(panel, 'Are you sure you want to overwrite map "' + self.mapNameCtrl.GetStringSelection() + '"?', 'Import Map',  wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
                    mdlg.CentreOnParent()
                    if mdlg.ShowModal() == wx.ID_YES:
                        editMap=dlg.GetValue()
                        try:
                            self.popItemList(eval(dlg.GetValue()))
                            self.btnMap[self.mapNameCtrl.GetStringSelection()] = eval(dlg.GetValue())
                            importError=False
                        except:
                            dlg = wx.MessageDialog(panel, 'Error importing map, please correct and retry.', 'Map Import Error',  wx.OK)
                            dlg.CentreOnParent()
                            dlg.ShowModal()
                            pass
                    else:
                        importError=False
                else:
                    importError=False
            event.Skip()

        def OnCodeCtrlChange(event):
            cecCode=''
            loseFocus=False
            cecCode=event.GetString()
            try:
                niceCode=""
                opts=''
                c=cecCode.split('.')
                try:
                    if len(c) == 1:
                        niceCode=self.cmdMap.cmd[c[0]][1]
                    else:
                        niceCode=self.cmdMap.opt[self.cmdMap.cmd[c[0]][2][0]][c[1]]
                    nameCtrl.SetValue(niceCode)
                except:
                    nameCtrl.SetValue(cecCode)
                    pass
            except:
                nameCtrl.SetValue(cecCode)
                pass
            event.Skip()
        
        def OnDetectBtnPress(event):
            result='TIMEOUT.WAITING.FOR.RESPONSE'
            progress=0
            pBarDialog = wx.ProgressDialog ( 'Detect Button Press', 'Press any key on TV remote...', maximum = 10, parent=self )
            pBarDialog.SetFocus()
            pBarDialog.CentreOnParent()
            while result == 'TIMEOUT.WAITING.FOR.RESPONSE' and progress <= 10:
                pBarDialog.Update (progress, 'Press any key on TV remote...')
                progress=progress+1
                result=eg.plugins.HdmiCec.Read('BUTTONS')
            pBarDialog.Destroy()
            if result <> 'TIMEOUT.WAITING.FOR.RESPONSE':
                if addBtn.Label == 'Add':
                    for idx in range(self.itemList.GetItemCount()):
                        if self.itemList.GetItem(idx, 0).GetText() == result:
                            itemList.SetItemState(idx, wx.LIST_STATE_SELECTED, wx.LIST_STATE_SELECTED)
                            return 0
                codeCtrl.SetValue(result)
            event.Skip()
        
        def OnAddBtnPress(event):
            idx=-1
            mapName=self.mapNameCtrl.GetStringSelection()
            code=codeCtrl.GetValue()
            name=nameCtrl.GetValue()
            if code == '' or name == '':
                dlg=eg.MessageDialog(panel, 'Code and Name are required.', caption='Mapping Error', style=wx.OK, pos=wx.Point(-1, -1))
                dlg.CentreOnParent()
                dlg.ShowModal()
                dlg.Destroy()
                event.Skip()
                return
            gEvent=eventCtrl.GetStringSelection()
            key=keyCtrl.GetValue()
            longKeyTm=longKeyTmCtrl.GetValue()
            longKey=longKeyCtrl.GetValue()
            if addBtn.Label == 'Add':
                try:
                    test=self.btnMap[mapName][code]
                    dlg=eg.MessageDialog(panel, 'CEC Code Already Assigned.', caption='Mapping Error', style=wx.OK, pos=wx.Point(-1, -1))
                    dlg.CentreOnParent()
                    dlg.ShowModal()
                    dlg.Destroy()
                    event.Skip()
                    return
                except:
                    pass
                self.btnMap[mapName] = updMap(self.btnMap[mapName],code,name,eval(gEvent),key,longKeyTm,longKey)
            else:
                idx=self.itemList.GetFirstSelected()
                try:
                    for i, c in enumerate(sorted(self.btnMap[mapName])):
                        if c == code and i != idx:
                            dlg=eg.MessageDialog(panel, 'CEC Code Already Assigned.', caption='Mapping Error', style=wx.OK, pos=wx.Point(-1, -1))
                            dlg.CentreOnParent()
                            dlg.ShowModal()
                            dlg.Destroy()
                            event.Skip()
                            return
                except:
                    pass
                curMap=copy.deepcopy(self.btnMap[mapName])
                del curMap[code]
                newMap=copy.deepcopy(curMap)
                newMap = updMap(newMap,code,name,eval(gEvent),key,longKeyTm,longKey)
                if newMap != curMap:
                    self.btnMap[mapName]=newMap
            self.popItemList(self.btnMap[mapName])
            self.itemList.Select(idx)
            event.Skip()
        
        def OnDelBtnPress(event):
            mapName=self.mapNameCtrl.GetStringSelection()
            fSel=self.itemList.GetFirstSelected()
            code = self.itemList.GetItem(fSel,0).GetText()
            if code == '45':
                dlg = wx.MessageDialog(panel, 'Button Released should not be removed.', 'Map Editor Warning',  wx.OK)
                dlg.CentreOnParent()
                dlg.ShowModal()
                return 0
            self.btnMap[mapName] = updMap(self.btnMap[mapName], code)
            self.itemList.DeleteItem(fSel)
            event.Skip()
        
        def OnOkBtnPress(event):
            self.SetReturnCode(wx.ID_OK)
            self.EndModal(wx.ID_OK)
        
        def OnCancelBtnPress(event):
            self.SetReturnCode(wx.ID_CANCEL)
            self.EndModal(wx.ID_CANCEL)
        
        self.mapNameCtrl.Bind(wx.EVT_CHOICE, OnMapNameCtrlChange)
        detectBtn.Bind(wx.EVT_BUTTON, OnDetectBtnPress)
        mapAddBtn.Bind(wx.EVT_BUTTON, OnMapAddBtnPress)
        mapDelBtn.Bind(wx.EVT_BUTTON, OnMapDelBtnPress)
        mapImpExpBtn.Bind(wx.EVT_BUTTON, OnMapImpExpBtnPress)
        itemList.Bind(wx.EVT_LIST_ITEM_SELECTED, OnItemListSelect)
        itemList.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnItemListSelect)
        itemList.Bind(wx.EVT_LEFT_DOWN, OnItemListClick)
        codeCtrl.Bind(wx.EVT_TEXT, OnCodeCtrlChange)
        addBtn.Bind(wx.EVT_BUTTON, OnAddBtnPress)
        delBtn.Bind(wx.EVT_BUTTON, OnDelBtnPress)
        okBtn.Bind(wx.EVT_BUTTON, OnOkBtnPress)
        cancelBtn.Bind(wx.EVT_BUTTON, OnCancelBtnPress)

        panel.SetSizerAndFit(sizer)
        self.Fit()
        self.SetMinSize(self.GetSize())
        self.CentreOnParent()
        
    def popItemList(self,itemDtls):
        self.itemList.DeleteAllItems()
        for idx,code in enumerate(sorted(itemDtls)):
            self.itemList.InsertStringItem(sys.maxint, code)
            self.itemList.SetStringItem(idx, 1, itemDtls[code][0])
            self.itemList.SetStringItem(idx, 2, str(itemDtls[code][1]))
            self.itemList.SetStringItem(idx, 3, str(itemDtls[code][2]))
            self.itemList.SetStringItem(idx, 4, str(itemDtls[code][3]))
            self.itemList.SetStringItem(idx, 5, str(itemDtls[code][4]))

        for idx in range(self.itemList.GetColumnCount()):
            self.itemList.SetColumnWidth(idx, wx.LIST_AUTOSIZE_USEHEADER)
            size =self.itemList.GetColumnWidth(idx)
            self.itemList.SetColumnWidth(idx, wx.LIST_AUTOSIZE)
            self.itemList.SetColumnWidth(idx, max(size, self.itemList.GetColumnWidth(idx) + 5))
        self.Fit()

    def GetValue(self):
        return self.btnMap

    def SetValue(self,btnMap):
        self.btnMap = btnMap
        self.mapNameCtrl.Clear()
        self.mapNameCtrl.AppendItems(self.btnMap.keys())
        self.mapNameCtrl.SetSelection(0)
        self.popItemList(self.btnMap[self.mapNameCtrl.GetStringSelection()])

class UpdDevDetail(eg.ActionBase):
    name='Update the List of Devices'

    def __call__(self,detailList,lAddr,pAddr=None,dType=None,osdName=None,vendorID=None,pStatus=None,cecName=None, detectPA=1):
        if lAddr != 0 and pAddr != '0.0.0.0':
            if pAddr == None:
                del detailList[lAddr]
            else:
                for i, details in enumerate(detailList):
                    if details[0] == lAddr:
                        del detailList[i]
                detailList.append([lAddr,pAddr,dType,osdName,vendorID,pStatus,cecName,detectPA])
        else:
            if pAddr == None:
                del detailList[lAddr]
            else:
                for i, details in enumerate(detailList):
                    if details[0] == lAddr:
                        del detailList[i]
                detailList.append([lAddr,pAddr,dType,osdName,vendorID,pStatus,cecName,detectPA])
            #dlg = eg.MessageDialog(None, 'Can not use logical 0 or physical 0.0.0.0.', caption='Device Config Error', style=wx.OK, pos=wx.Point(-1, -1))
            #dlg.CentreOnParent()
            #dlg.ShowModal()
            #dlg.Destroy()
        return sorted(detailList, key=lambda item: item[0])

class SetActiveButtonMap(eg.ActionBase):
    name = 'Set Active Button Map'
    description = """\
    Select a button map to be used to map remote keys.\
    You can add/edit button maps in the plugin configuration panel."""

    def __call__(self,idx,mapName):
        self.plugin.activeBtnMap=mapName

    def GetLabel(self,idx=0,mapName=""):
        return self.name + ': ' + mapName

    def Configure(self,idx=0,mapName=''):
        panel = eg.ConfigPanel()
        
        #Map dropdown
        if mapName != '':
            try:
                idx=self.plugin.btnMap.keys().index(mapName)
            except:
                idx=0
                pass
        mapCtrl = panel.Choice(idx,self.plugin.btnMap.keys())
        panel.sizer.Add(mapCtrl,0, wx.FIXED_MINSIZE)
        
        #Hidden actual name of map 
        mapNameCtrl = wx.TextCtrl(panel, value=mapName)
        mapNameCtrl.Hide()
        panel.sizer.Add(mapNameCtrl,0, wx.EXPAND)
        
        def OnMapChange(event):
            mapNameCtrl.SetValue(mapCtrl.GetStringSelection())
        
        OnMapChange(wx.CommandEvent())
        mapCtrl.Bind(wx.EVT_CHOICE, OnMapChange)
        
        while panel.Affirmed():
            panel.SetResult(mapCtrl.GetSelection(),mapNameCtrl.GetValue())


class DetPhysAddr(eg.ActionBase):
    name = 'Determine Physical Address'
    description = """\
    Find the current physical address; returns physical address of the specified monitor."""

    def __call__(self,display=0):
        pAddr=None

        def parse_edid(pEdid):
            p1=None
            p2=None
            addr=None
            for i in range(252):
                try:
                    if [pEdid[i]+pEdid[i+1]+pEdid[i+2]] == ['\x03\x0c\x00']:
                        try:
                            p1=hex(ord(pEdid[i+3]))+'00'
                        except:
                            p1=[pEdid[i+3]]+'00'
                        try:
                            p2=hex(ord(pEdid[i+4]))+'00'
                        except:
                            p2=pEdid[i+4]+'00'
                        addr=p1[2]+'.'+p1[3]+'.'+p2[2]+'.'+p2[3]
                        break
                except:
                    pass
            return addr

        if sys.platform == "win32":
            if sys.getwindowsversion() >= (6, ):
                # Use WMI for Vista/Win7
                import wmi
                wmi_connection = wmi.WMI(namespace="WMI")
            else:
                # Use registry as fallback for Win2k/XP/2003
                import _winreg
                wmi_connection = None
            import win32api

        edid = None
        if sys.platform == "win32":
            try:
                if wmi_connection:
                    for monitor in [wmi_connection.WmiMonitorDescriptorMethods()[display]]:
                        try:
                            edid = monitor.WmiGetMonitorRawEEdidV1Block(1)
                        except:
                            pass
                        else:
                            edid = "".join(chr(i) for i in edid[0])
                            pAddr=parse_edid(edid)
                        if pAddr <> None:
                            break
                else:
                    for monitor in win32api.EnumDisplayMonitors(None, None):
                        moninfo = win32api.GetMonitorInfo(monitor[0])
                        device = win32api.EnumDisplayDevices(moninfo["Device"])
                        id = device.DeviceID.split("\\")[1]
                        driver = "\\".join(device.DeviceID.split("\\")[-2:])
                        subkey = "\\".join(["SYSTEM", "CurrentControlSet", "Enum", "DISPLAY", id])
                        key = _winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, subkey)
                        numsubkeys, numvalues, mtime = _winreg.QueryInfoKey(key)
                        for i in range(numsubkeys):
                            hkname = _winreg.EnumKey(key, i)
                            hk = _winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, "\\".join([subkey, hkname]))
                            if _winreg.QueryValueEx(hk, "Driver")[0] == driver:
                                devparms = _winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, "\\".join([subkey, hkname, "Device Parameters"]))
                                try:
                                    edid = _winreg.QueryValueEx(devparms, "EDID")
                                    pAddr=parse_edid(edid)
                                    break
                                except:
                                    pass
                            if pAddr <> None:
                                break
            except:
                pass
        return pAddr

    def Configure(self,display=0):
        panel = eg.ConfigPanel()
        choicesDetect=[]
        if sys.platform == "win32":
            if sys.getwindowsversion() >= (6, ):
                # Use WMI for Vista/Win7
                import wmi
                wmi_connection = wmi.WMI(namespace="WMI")
                wmi_connection2 = wmi.WMI(namespace="CIMV2")
                for monitor in wmi_connection.WmiMonitorID():
                    str1=''
                    for i in monitor.UserFriendlyName:
                        if i > 0:
                            str1+=chr(i)
                    choicesDetect.append(str1)
                for idx, monitor in enumerate(wmi_connection2.CIM_Display()):
                    choicesDetect[idx]=choicesDetect[idx]+'('+monitor.DeviceID+')'
        
        detectCtrl = panel.Choice(display,choicesDetect)
        detectCtrl.SetSelection(display)
        panel.sizer.Add(detectCtrl,0, wx.FIXED_MINSIZE)
        
        while panel.Affirmed():
            panel.SetResult(detectCtrl.GetSelection())


class SetLogicalAddress(eg.ActionBase):
    name = 'Set/Get Logical Address'
    description = """\
    Set or find the current logical address; returns device setting.\
    During write operations this can be used to emulate another device.\
    Refer to RCAware documentation for instructions."""

    def __call__(self,lAddr=-1,newEmList=None,osdName=''):
        try:
            newPrimary=lAddr
            if osdName != 'Find Current' and osdName != '':
                lAddr=filter(lambda i: i[3] == osdName, self.plugin.devDetails)[0][0]
                
            # For some reason, need to pause when switching back and forth or else
            # the device will perform the switch before the last command
            time.sleep(0.1)

            result=eg.plugins.HdmiCec.WriteRead('!a~','?ADR').replace('.',' ')
    
            if osdName == 'Find Current' or lAddr == -1:
                return result
    
            newPrimary=hex(int(lAddr))[2:].upper()
    
            if newEmList == None:
                if result[0] == newPrimary:
                    return result
                else:
                    result=eg.plugins.HdmiCec.WriteRead('!a'+newPrimary+'~','?ADR').replace('.',' ')
                    return result
            else:
                if newEmList==[]:
                    newSetting=newPrimary+" 0000"
                else: 
                    #Add the primary to the emulate list too
                    newEmList.append(newPrimary)
                    newEmList=list(set(newEmList))
                    #Convert the new emulate list to hex
                    Emlist=[]
                    mybin=""
                    for i in reversed(range(14)):
                        if newEmList.count(i) == 0:
                            mybin=mybin+"0"
                        else:
                            mybin=mybin+"1"
                    newSetting=newPrimary+" "+hex(int(mybin,2))[2:].zfill(4).upper()
                if newSetting != result:
                    result=eg.plugins.HdmiCec.WriteRead('!a'+newSetting+'~','?ADR')
            return result
        except:
            pass

    def GetLabel(self,lAddr=None,newEmList=None,osdName=''):
        return self.name + ': ' + osdName

    def Configure(self,lAddr=0,newEmList=None,osdName=''):
        panel = eg.ConfigPanel()
        
        #Logical Address dropdown
        lst=['Find Current']
        lst.extend([i[3] for i in eg.plugins.HdmiCec.plugin.devDetails])
        if osdName == 'Find Current':
            lAddr=0
        elif osdName != '':
            try:
                lAddr=self.plugin.devDetails.index(filter(lambda i: i[3] == osdName, self.plugin.devDetails)[0])+1
            except:
                lAddr=0
                pass
        lAddrCtrl = panel.Choice(lAddr,lst)
        lAddrCtrl.SetSelection(lAddr)
        panel.sizer.Add(lAddrCtrl,0, wx.FIXED_MINSIZE)
        
        while panel.Affirmed():
            panel.SetResult(-1, None, lAddrCtrl.GetStringSelection())


class SetOsdName(eg.ActionBase):
    name = 'Set On Screen Display Name'

    def __call__(self,newName=None):
        try:
            result=eg.plugins.HdmiCec.WriteRead('!o~','?OSD')
            if newName != result and newName != None:
                result=eg.plugins.HdmiCec.WriteRead('!o '+newName+'~','?OSD')
            return result
        except:
            pass


class SetConfig(eg.ActionBase):
    name = 'Set Device Configuration'

    def __call__(self,newConfig=None):
        try:
            result=eg.plugins.HdmiCec.WriteRead('!c~','?CFG')
            if newConfig != result and newConfig != None:
                result=eg.plugins.HdmiCec.WriteRead('!c '+newConfig+'~','?CFG')
            return result
        except:
            pass


class SetPhysicalAddress(eg.ActionBase):
    name = 'Set Physical Address'

    def __call__(self,lAddr,newAddr=None,broadcast=False):
        try:
            newAddr=newAddr.replace('.','')+' '+lDevTypes.addr[int(lAddr)]
            result=eg.plugins.HdmiCec.WriteRead('!p~','?PHY').replace('.',' ')
            if newAddr != None and newAddr != result:
                result=eg.plugins.HdmiCec.WriteRead('!p '+newAddr+'~','?PHY')
                if broadcast:
                    try:
                        eg.plugins.HdmiCec.Write('!xF 84 '+newAddr+'~')
                    except:
                        pass
            return result
        except:
            #print traceback.format_exc()
            pass

class GetDevDetails(eg.ActionBase):
    name = 'Return List of Devices'
    description = """\
    Performs real device discovery and returns a detailed list of all real devices currently attached.\
    May be useful for Python coding."""

    def __call__(self,detailList=[],pBar=False,pBarParent=None):
        try:
            progress=1
            volSyncType=self.plugin.volSyncType
            self.plugin.volSyncType="NONE"
            if pBar:
                pBarDialog = wx.ProgressDialog ( 'Device Discovery', 'Discovering Devices...', maximum=len(lAddresses.addr)+2, parent=pBarParent )
                pBarDialog.SetFocus ()
                pBarDialog.CentreOnParent()
            for i, details in reversed(list(enumerate(detailList))):
                if details[2] == 'Real':
                    del detailList[i]
            if pBar:
                pBarDialog.Update (progress, 'Discovering Devices...' )
                myDevList=self.getDevices(pBarDialog)
            else:
                myDevList=self.getDevices()
            for i, lAddr in enumerate(myDevList):
                try:
                    tst=filter(lambda i: i[0] == lAddr, detailList)[0]
                    dlg=eg.MessageDialog(None, 'Device conflict logical address '+str(lAddr)+'.Change the Primary or Emulated device and discover again.', caption='Device Config Error', style=wx.OK, pos=wx.Point(-1, -1))
                    dlg.CentreOnParent()
                    dlg.ShowModal()
                    dlg.Destroy()
                    continue
                except:
                    pass
                pStatus=eg.plugins.HdmiCec.IsOnline(lAddr)
                pBarDialog.SetFocus ()
                pAddr=self.getPhysAddr(lAddr)
                if lAddr == 0:
                    osdName='TV'
                elif lAddr == 5:
                    osdName='Receiver'
                else:
                    osdName=self.getOSDName(lAddr)
                    if osdName == '':
                        osdName=lAddresses.addr[lAddr]
                vendorID=self.getVendorID(lAddr)
                detailList.append([lAddr,pAddr,'Real',self.pChars(osdName),self.pChars(vendorID),pStatus,lAddresses.addr[lAddr], 1])
            if pBar:
                 pBarDialog.Update (len(lAddresses.addr)+2, 'Completed.' )
                 pBarDialog.Hide()
                 pBarDialog.Destroy()
            self.plugin.volSyncType=volSyncType
        except:
            pBarDialog.Hide()
            pBarDialog.Destroy()
            pass
        return sorted(detailList, key=lambda item: int(item[0]))

    def pChars(self,str):
        return ''.join([c for c in str if ord(c) > 31 or ord(c) == 9])

    def getPCDevices(self):
        resultlist=[]
        result=''
        retry=0
        while (len(result) > 4 or result[0:3] != '?ADR') and retry < 5:
            result=eg.plugins.HdmiCec.WriteRead('!a~','?ADR')
            retry=retry+1
        parts=result.split('.')
        resultlist.append(int(parts[0], 16))
        mybin=bin(int(parts[1], 16))[2:].zfill(15)
        for i in range(14):
            if mybin[i] == '1':
                resultlist.append(14-i)
        resultlist = list(set(resultlist))
        return resultlist

    def getDevices(self,pBarDialog=None):
        progress=1
        status='Discovering Devices'
        devList=[]
        PCList=self.getPCDevices()
        for i, addr in enumerate(lAddresses.addr):
            if pBarDialog != None:
                progress=progress+1
                pBarDialog.Update (progress, status)
            hexAddr=hex(addr)[2:].upper()
            if PCList.count(int(addr)) == 0:
                result=None
                #result=eg.plugins.HdmiCec.WriteRead('!x' + hexAddr + '~', '1', addr)
                retry=0
                while not (result != None and result.split('.')[0] == '00' and len(result.split('.')) >= 2 and result.split('.')[1] == 'FF') and retry < 5:
                    result=eg.plugins.HdmiCec.WriteRead('!x' + hexAddr + ' FF~', '00.FF', addr)
                    retry=retry+1
                #if result == '1.01':
                if result != None and result.split('.')[0] == '00' and len(result.split('.')) >= 2 and result.split('.')[1] == 'FF':
                    if pBarDialog != None:
                        status='Found ' + lAddresses.addr[addr]
                        pBarDialog.Update (progress, status )
                    devList.append(addr)
        return devList

    def getPhysAddr(self,lAddr):
        result='XX.XX'
        retry=0
        while result[0:2] != "84" and retry < 5:
            r=eg.plugins.HdmiCec.WriteRead('!x' + str(lAddr) + ' 83~', '84', lAddr)
            if len(r) > 2:
                result=r
            retry=retry+1
        if result[0:2] == "84":
            return result[3]+'.'+result[4]+'.'+result[6]+'.'+result[7]
        else:
            return ""

    def getOSDName(self,lAddr):
        result='XX.XX'
        retry=0
        while result[0:2] != "47" and retry < 5:
            r=eg.plugins.HdmiCec.WriteRead('!x' + str(lAddr) + ' 46~', '47', lAddr)
            if len(r) > 2:
                result=r
            retry=retry+1

        if result[0:2] == "47":
            return result[3:].replace('.','').decode('hex')
        else:
            return ""

    def getVendorID(self,lAddr):
        result='XX.XX'
        retry=0
        while result[0:2] != "87" and retry < 5:
            r=eg.plugins.HdmiCec.WriteRead('!x' + str(lAddr) + ' 8C~', '87', lAddr)
            if len(r) > 2:
                result=r
            retry=retry+1

        if result[0:2] == "87":
            return result[3:].replace('.','')
        else:
            return ""


class IsOnline(eg.ActionBase):
    name = 'Is Device Online'
    description = """\
    Check power status of a device; returns True (online) or False (standby)."""

    def __call__(self, lAddr, osdName=''):
        try:
            if osdName != '':
                lAddr=filter(lambda i: i[3] == osdName, self.plugin.real)[0][0]
            hexAddr=hex(int(lAddr))[2:].upper()
    
            result='XX.XX'
            retry=0
            while result[0:2] != "90" and retry < 5:
                r=eg.plugins.HdmiCec.WriteRead('!x' + hexAddr + ' 8F~', '90', lAddr)
                retry=retry+1
                if len(r) > 2:
                    result=r
            
            if result == "90.00":
                return True
            else:
                return False
        except:
            pass
    def GetLabel(self, lAddr, osdName=''):
        return self.name + ': ' + osdName

    def Configure(self, lAddr=0, osdName=''):
        panel = eg.ConfigPanel()
        
        #Logical Address dropdown
        if osdName != '':
            try:
                lAddr=self.plugin.real.index(filter(lambda i: i[3] == osdName, self.plugin.real)[0])
            except:
                lAddr=0
                pass
        lAddrCtrl = panel.Choice(lAddr,[i[3] for i in self.plugin.real])
        panel.sizer.Add(lAddrCtrl,0, wx.FIXED_MINSIZE)
        
        #Hidden to device osd name  (device list and logical address may change)
        osdNameCtrl = wx.TextCtrl(panel, value=osdName)
        osdNameCtrl.Hide()
        panel.sizer.Add(osdNameCtrl,0, wx.EXPAND)
        
        def OnlAddrChange(event):
            osdNameCtrl.SetValue([i[3] for i in self.plugin.real][lAddrCtrl.GetValue()])
        
        OnlAddrChange(wx.CommandEvent())
        lAddrCtrl.Bind(wx.EVT_CHOICE, OnlAddrChange)
        
        while panel.Affirmed():
            panel.SetResult(lAddrCtrl.GetValue(), osdNameCtrl.GetValue())


class WakeUp(eg.ActionBase):
    name = 'Wake Up Device'
    description = """\
    Bring the specified device out of standby (sleep)\
    Returns True (SUCCESS) or False (FAILED)"""
    
    def __call__(self, lAddr, timeOut, osdName=''):
        try:
            if osdName != '':
                lAddr=filter(lambda i: i[3] == osdName, self.plugin.real)[0][0]
            hexAddr=hex(int(lAddr))[2:].upper()
            
            if lAddr == 0:
                eg.plugins.HdmiCec.Write(u'!x' + hexAddr + ' 04~')
                time.sleep(1.0)
            
            online=eg.plugins.HdmiCec.IsOnline(lAddr)
            if not online:
                eg.plugins.HdmiCec.Write(u'!x' + hexAddr + ' 44 6D~x' + hexAddr + ' 45~')
                retry=0
                while not online and retry < timeOut:
                    time.sleep(0.5)
                    online=eg.plugins.HdmiCec.IsOnline(lAddr)
                    retry=retry+1

            if not online:
                eg.plugins.HdmiCec.Write(u'!x' + hexAddr + ' 44 40~x' + hexAddr + ' 45~')
                retry=0
                while not online and retry < timeOut:
                    time.sleep(0.5)
                    online=eg.plugins.HdmiCec.IsOnline(lAddr)
                    retry=retry+1
            
            return online
        except:
            pass
            
    def GetLabel(self, lAddr, timeOut, osdName=''):
        return self.name + ': ' + osdName

    def Configure(self, lAddr=0, timeOut=10, osdName=''):
        panel = eg.ConfigPanel()
        
        #Logical Address dropdown
        myGrid1 = wx.GridBagSizer(10, 10)
        Add = myGrid1.Add

        if osdName != '':
            try:
                lAddr=self.plugin.real.index(filter(lambda i: i[3] == osdName, self.plugin.real)[0])
            except:
                lAddr=0
                pass
        lAddrTxt = wx.StaticText(panel, 10, "Device Name:")
        lAddrCtrl = panel.Choice(lAddr,[i[3] for i in self.plugin.real])
        Add(lAddrTxt,(0,0))
        Add(lAddrCtrl,(0,1))

        timeOutTxt = wx.StaticText(panel, 10, "Timeout (seconds):")
        timeOutCtrl = wx.SpinCtrl(panel, -1) #, '',  (150, 75), (60, -1))
        timeOutCtrl.SetRange(0, 60)
        timeOutCtrl.SetValue(timeOut)
        Add(timeOutTxt,(1,0))
        Add(timeOutCtrl,(1,1))

        panel.sizer.Add(myGrid1,0, wx.EXPAND)
        
        #Hidden to device osd name  (device list and logical address may change)
        osdNameCtrl = wx.TextCtrl(panel, value=osdName)
        osdNameCtrl.Hide()
        panel.sizer.Add(osdNameCtrl,0, wx.EXPAND)
        
        def OnlAddrChange(event):
            osdNameCtrl.SetValue([i[3] for i in self.plugin.real][lAddrCtrl.GetValue()])
        
        OnlAddrChange(wx.CommandEvent())
        lAddrCtrl.Bind(wx.EVT_CHOICE, OnlAddrChange)
        
        while panel.Affirmed():
            panel.SetResult(lAddrCtrl.GetValue(), timeOutCtrl.GetValue(), osdNameCtrl.GetValue())


class StandBy(eg.ActionBase):
    name = 'Standby Device'
    description = """\
    Put the specified device into standby (sleep).\
    Returns True (SUCCESS) or False (FAILED)"""
    
    def __call__(self, lAddr, timeOut=10, osdName=''):
        try:
            if osdName != 'All Devices' and str(lAddr) !='15' and str(lAddr) !='F':
                if osdName != '':
                    lAddr=filter(lambda i: i[3] == osdName, self.plugin.real)[0][0]
                hexAddr=hex(int(lAddr))[2:].upper()
                    
                online=eg.plugins.HdmiCec.IsOnline(lAddr)
                if online:
                    eg.plugins.HdmiCec.Write(u'!x' + hexAddr + ' 36~')
                    retry=0
                    while online and retry < timeOut:
                        time.sleep(1.0)
                        online=eg.plugins.HdmiCec.IsOnline(lAddr)
                        retry=retry+1
            else:
                eg.plugins.HdmiCec.Write(u'!xF 36~')
                online=False
            return not online
        except:
            pass
            
    def GetLabel(self, lAddr, timeOut=10, osdName=''):
        return self.name + ': ' + osdName

    def Configure(self, lAddr=0, timeOut=10, osdName=''):
        panel = eg.ConfigPanel()
        
        #Logical Address dropdown
        myGrid1 = wx.GridBagSizer(10, 10)
        Add = myGrid1.Add

        lAddrTxt = wx.StaticText(panel, 10, "Device Name:")
        lst=[i[3] for i in eg.plugins.HdmiCec.plugin.real]
        lst.append('All Devices')
        if osdName == 'All Devices':
            lAddr=len(lst)
        elif osdName != '':
            try:
                lAddr=self.plugin.real.index(filter(lambda i: i[3] == osdName, self.plugin.real)[0])
            except:
                lAddr=0
                pass
        lAddrCtrl = panel.Choice(lAddr,lst)
        Add(lAddrTxt,(0,0))
        Add(lAddrCtrl,(0,1))

        timeOutTxt = wx.StaticText(panel, 10, "Timeout (seconds):")
        timeOutCtrl = wx.SpinCtrl(panel, -1) #, '',  (150, 75), (60, -1))
        timeOutCtrl.SetRange(0, 60)
        timeOutCtrl.SetValue(timeOut)
        Add(timeOutTxt,(1,0))
        Add(timeOutCtrl,(1,1))

        panel.sizer.Add(myGrid1,0, wx.EXPAND)
        
        #Hidden to device osd name  (device list and logical address may change)
        osdNameCtrl = wx.TextCtrl(panel, value=osdName)
        osdNameCtrl.Hide()
        panel.sizer.Add(osdNameCtrl,0, wx.EXPAND)
        
        def OnlAddrChange(event):
            try:
                osdNameCtrl.SetValue([i[3] for i in self.plugin.real][lAddrCtrl.GetValue()])
            except:
                osdNameCtrl.SetValue('All Devices')
                pass
        
        OnlAddrChange(wx.CommandEvent())
        lAddrCtrl.Bind(wx.EVT_CHOICE, OnlAddrChange)
        
        while panel.Affirmed():
            panel.SetResult(lAddrCtrl.GetValue(), timeOutCtrl.GetValue(), osdNameCtrl.GetValue())


class TVPower(eg.ActionBase):
    name = 'TV on/off at PC Sleep/Wake'
    description = """\
    Enable or disable turning the TV on/off during PC Sleep/Wake.
    Default is Disbaled."""
    
    def __call__(self, setting=0):
        try:
            eg.plugins.HdmiCec.plugin.TVpowerOnSleepWake=setting
        except:
            pass
            
    def GetLabel(self, setting=0):
        return self.name + ['Disabled','Enabled'][setting]

    def Configure(self, setting=0):
        panel = eg.ConfigPanel()
        
        #Enable/Disable Dropdown
        myGrid1 = wx.GridBagSizer(10, 10)
        Add = myGrid1.Add

        settingCtrl = panel.Choice(setting,['Disabled','Enabled'])
        Add(settingCtrl,(0,0))

        panel.sizer.Add(myGrid1,0, wx.EXPAND)
        
        while panel.Affirmed():
            panel.SetResult(settingCtrl.GetValue())


class ActiveSource(eg.ActionBase):
    name = 'Find the Active Source'
    description = """\
    Returns the display name of the currently active source."""
    
    def __call__(self):
        try:
            result='XX.XX'
            retry=0
            while result[0:2] != "82" and retry < 5:
                r=eg.plugins.HdmiCec.WriteRead('!xF 85~','82')
                retry=retry+1
                if len(r) > 2:
                    result=r
            
            if result[0:2] == "82":
                return filter(lambda i: i[1] == result[3]+'.'+result[4]+'.'+result[6]+'.'+result[7], self.plugin.devDetails)[0][3]
            else:
                 return "SELF"
        except:
            pass
            
class SelectSource(eg.ActionBase):
    name = 'Select Source'
    description = """\
    Change Source; returns True (Success) or False (Failed)."""
    
    def __call__(self, lAddr, pAddr, timeOut=10, osdName=''):
        vendorID='000000'
        try:

            if osdName != '':
                lAddr=filter(lambda i: i[3] == osdName, self.plugin.devDetails)[0][0]

            pAddr=filter(lambda i: i[0] == lAddr, self.plugin.devDetails)[0][1].replace('.','')
            vendorID=filter(lambda i: i[0] == lAddr, self.plugin.devDetails)[0][4]
                
            activeSource=''
            retry=0
            if vendorID == '00E091':
                eg.plugins.HdmiCec.Write(u'!x' + str(lAddr) + ' 89 04 ' + str(lDevTypes.addr[int(lAddr)]) + '~')
            else:
                eg.plugins.HdmiCec.Write(u'!xF 82 ' + pAddr + '~')
            while not activeSource == osdName and retry <= int(timeOut):
                activeSource=eg.plugins.HdmiCec.ActiveSource()
                time.sleep(1.0)
                retry=retry+1
            if activeSource == osdName:
                print 'Active Source: ' + osdName
                return True
            else:
                print 'Failed to switch to ' + osdName
                return False
        except:
            pass
            
    def GetLabel(self, lAddr, pAddr, timeOut, osdName=''):
        return self.name + ': ' + osdName

    def Configure(self, lAddr=0, pAddr='', timeOut=10, osdName=''):
        panel = eg.ConfigPanel()
        
        #Logical Address dropdown
        myGrid1 = wx.GridBagSizer(10, 10)
        Add = myGrid1.Add

        if osdName != '':
            try:
                lAddr=self.plugin.devDetails.index(filter(lambda i: i[3] == osdName, self.plugin.devDetails)[0])
            except:
                lAddr=0
                pass
        lAddrTxt = wx.StaticText(panel, 10, "Device Name:")
        lAddrCtrl = panel.Choice(lAddr,[i[3] for i in self.plugin.devDetails])
        Add(lAddrTxt,(0,0))
        Add(lAddrCtrl,(0,1))

        timeOutTxt = wx.StaticText(panel, 10, "Timeout (seconds):")
        timeOutCtrl = wx.SpinCtrl(panel, -1) #, '',  (150, 75), (60, -1))
        timeOutCtrl.SetRange(0, 60)
        timeOutCtrl.SetValue(timeOut)
        Add(timeOutTxt,(1,0))
        Add(timeOutCtrl,(1,1))

        panel.sizer.Add(myGrid1,0, wx.EXPAND)
        
        #Hidden to device osd name  (device list and logical address may change)
        osdNameCtrl = wx.TextCtrl(panel, value=osdName)
        osdNameCtrl.Hide()
        panel.sizer.Add(osdNameCtrl,0, wx.EXPAND)
        
        def OnlAddrChange(event):
            osdNameCtrl.SetValue([i[3] for i in self.plugin.devDetails][lAddrCtrl.GetValue()])
        
        OnlAddrChange(wx.CommandEvent())
        lAddrCtrl.Bind(wx.EVT_CHOICE, OnlAddrChange)
        
        while panel.Affirmed():
            panel.SetResult(lAddrCtrl.GetValue(), '', timeOutCtrl.GetValue(), osdNameCtrl.GetValue())


class GetAudioMode(eg.ActionBase):
    name = 'Get Audio Mode'
    description = """\
    Check amplifier status; returns True (On) or False (Off)."""
    
    def __call__(self):
        try:
            if eg.plugins.HdmiCec.IsOnline(5):
                result='XX.XX'
                retry=0
                while result[0:2] != "7E" and retry < 5:
                    r=eg.plugins.HdmiCec.WriteRead('!x5 7D~','7E')
                    retry=retry+1
                    if len(r) > 2:
                        result=r
                if result == "7E.01":
                    return True
            return False
        except:
            pass

class SetAudioMode(eg.ActionBase):
    name = 'Set Audio Mode'
    description = """\
    Turn Amp on/off; returns resulting audio status: True (On) or False (Off)."""

    def __call__(self, mode, lAddr, pAddr, timeOut=10, osdName=''):
        try:
            if mode == 0:
                pAddr=''
            elif osdName != '':
                pAddr=filter(lambda i: i[3] == osdName, self.plugin.devDetails)[0][1].replace('.','')
            hexAddr=hex(int(lAddr))[2:].upper()
    
            online=eg.plugins.HdmiCec.GetAudioMode()
            if online != mode:
                result=eg.plugins.HdmiCec.WriteRead('!x5 70 ' + pAddr + '~','7E')
                if result == "7E.01":
                    online=True
                else:
                    online=False
    
            retry=0
            while (mode == True != online) and retry < timeOut:
                online=eg.plugins.HdmiCec.GetAudioMode()
                retry=retry+1
                time.sleep(1.0)
            return online
        except:
            pass

    def GetLabel(self, mode, lAddr, pAddr, timeOut, osdName=''):
        if mode==0: 
            return self.name + ': Off'
        else:
            return self.name + ': On : ' + osdName

    def Configure(self, mode=0, lAddr=0, pAddr='', timeOut=10, osdName=''):
        panel = eg.ConfigPanel()
        
        #Logical Address dropdown
        myGrid1 = wx.GridBagSizer(10, 10)
        Add = myGrid1.Add

        modeTxt = wx.StaticText(panel, 10, "Mode:")
        modeCtrl = panel.Choice(mode,['Off', 'On'])
        Add(modeTxt,(0,0))
        Add(modeCtrl,(0,1))

        if osdName != '':
            try:
                lAddr=self.plugin.devDetails.index(filter(lambda i: i[3] == osdName, self.plugin.devDetails)[0])
            except:
                lAddr=0
                pass
        lAddrTxt = wx.StaticText(panel, 10, "Control Device:")
        lAddrCtrl = panel.Choice(lAddr,[i[3] for i in self.plugin.devDetails])
        Add(lAddrTxt,(1,0))
        Add(lAddrCtrl,(1,1))

        timeOutTxt = wx.StaticText(panel, 10, "Timeout (seconds):")
        timeOutCtrl = wx.SpinCtrl(panel, -1) #, '',  (150, 75), (60, -1))
        timeOutCtrl.SetRange(0, 60)
        timeOutCtrl.SetValue(timeOut)
        Add(timeOutTxt,(2,0))
        Add(timeOutCtrl,(2,1))

        panel.sizer.Add(myGrid1,0, wx.EXPAND)
        
        #Hidden to device osd name  (device list and logical address may change)
        osdNameCtrl = wx.TextCtrl(panel, value=osdName)
        osdNameCtrl.Hide()
        panel.sizer.Add(osdNameCtrl,0, wx.EXPAND)
        
        def OnModeChange(event):
            if modeCtrl.GetValue() == 0:
                lAddrCtrl.Enable(False)
            else:
                lAddrCtrl.Enable(True)        
                osdNameCtrl.SetValue([i[3] for i in self.plugin.devDetails][lAddrCtrl.GetValue()])

        def OnlAddrChange(event):
            osdNameCtrl.SetValue([i[3] for i in self.plugin.devDetails][lAddrCtrl.GetValue()])
        
        OnModeChange(wx.CommandEvent())
        modeCtrl.Bind(wx.EVT_CHOICE, OnModeChange)

        OnlAddrChange(wx.CommandEvent())
        lAddrCtrl.Bind(wx.EVT_CHOICE, OnlAddrChange)
        
        while panel.Affirmed():
            panel.SetResult(modeCtrl.GetValue(), lAddrCtrl.GetValue(), '', timeOutCtrl.GetValue(), osdNameCtrl.GetValue())

class SuspendSerialRead(eg.ActionBase):
    name = 'Pause Plugin Reading'
    description = """\
    Normally the plugin is always tying up the serial bus,\
    use this to temporarily pause plugin automatic serial reading.\
    Other actions like Write, Read and WriteRead always pause\
    and ressume serial read, so it is not needed for simple use of those actions.\
    This could be called if you are performing a long conversation and don't want\
    any messages/events being missed.<BR><BR>\
    Always remember to restart using ResumeSerialRead after you are done."""

    def __call__(self):
        self.plugin.serialOn = False

class ResumeSerialRead(eg.ActionBase):
    name = 'Resume Plugin Reading'
    description = """\
    Restarts plugin automatic serial reading.\
    Always call this at some point if you called SuspendSerialRead."""

    def __call__(self):
        self.plugin.serialOn = True


class Write(eg.ActionWithStringParameter):
    name = 'Write Message'
    description = """\
    Writes a message to the CEC bus.\
    Refer to RCAware documentation for instructions."""

    def __call__(self, data):
        if self.plugin.comOn:
            data=data.strip(' ')
            if data[len(data)-1] != "~":
                data = data + "~"
            self.plugin.cecCon.write(data)
            return True
        else:
            return False

class Read(eg.ActionWithStringParameter):
    name = 'Read Response'
    description = """\
    Read message from CEC bus.\
    This is meant to be called after Write if you want to\
    get a response.  Specify an opcode to wait for otherwise\
    the first response will be returned."""

    @eg.LogItWithReturn
    def __call__(self, retCode='', fromAddr='', timeout=.5):
        #print "Reading. retCode: " + str(retCode) + " fromAddr: " + str(fromAddr) + " timeout: " + str(timeout)
        if not self.plugin.comOn:
            #print "Com is down, can't read."
            return "COMMUNICATIONS.ARE.NOT.AVAILABLE"
        try:
            result=""
            serialState=self.plugin.serialOn
            if serialState:
                eg.plugins.HdmiCec.SuspendSerialRead()
            buffer = ""
            counter=0
            sTime=eg.Utils.time.time()
            
            while counter <= timeout:
                time.sleep(0.1)
                counter=eg.Utils.time.time()-sTime
                lBuffer = []
                if self.plugin.backbuffer == '':
                    #print "backbuffer emtpy, wait some more."
                    continue
                else:
                    #print "Backbuffer: " + str(self.plugin.backbuffer)
                    lBuffer = ''.join([s if s not in '\r\n' else '~' for s in self.plugin.backbuffer]).split('~')
                    self.plugin.backbuffer = ''
                for buffer in lBuffer:
                    if buffer == "":
                        continue
                    parts = buffer.split(' ')
                    
                    if parts[0] == "?REC":
                        #Test if was sent by me then skip it unless it matches the opcode we want
                        try:
                            tst = filter(lambda i: i[0] == int(parts[1][0]) and i[2] != 'Real', self.plugin.devDetails)[0]
                            if retCode == '' or (retCode != '' and parts[2] != retCode):
                                buffer=""
                                continue
                        except:
                            pass
                        #If looking for a specific device, or a opCode to be returned (including feature abort) then skip others
                        try:
                            fromAddr=int(fromAddr)
                        except:
                            fromAddr=''
                        if (fromAddr != '' and int(parts[1][0]) != fromAddr) or (retCode != '' and parts[2] != retCode.split('.')[0] and not (len(retCode.split('.')) >= 2 and parts[3] != retCode.split('.')[1]) and not (parts[2] == '00' and parts[3] == retCode)):
                            #Special logic when looking only for remote key button presses
                            if retCode == 'BUTTONS':
                                try:
                                    tst = filter(lambda i: i == parts[2], cmdMap.buttons)[0]
                                except:
                                    self.plugin.OnReceive(buffer+'\n')
                                    buffer=""
                                    continue
                                    pass
                            else:
                                self.plugin.OnReceive(buffer+'\n')
                                buffer=""
                                continue
                        if len(parts) == 4:
                            result=parts[2]
                        else:
                            result='.'.join(parts[2:-1])
                    elif parts[0] == "?STA" or (retCode != '' and parts[0] != retCode):
                        buffer=""
                        continue
                    elif parts[0] == "?OSD":
                        result=buffer[4:].strip()
                    else:
                        if len(parts) == 2:
                            result=parts[1]
                        else:
                            result='.'.join(parts[1:])
                    buffer=""
                    if serialState:
                        eg.plugins.HdmiCec.ResumeSerialRead()
                    return result
            if serialState:
                eg.plugins.HdmiCec.ResumeSerialRead()
            return "TIMEOUT.WAITING.FOR.RESPONSE"
        except:
            if serialState:
                eg.plugins.HdmiCec.ResumeSerialRead()
            pass

class WriteRead(eg.ActionBase):
    name = 'Write Message and Read Response'
    description = """\
    Writes a message to the CEC bus and then waits for a reply.\
    Simple version of...<BR><BR>\
    SuspendSerialRead()<BR>\
    Write()<BR>\
    Read()<BR>\
    ResumeSerialRead()<BR><BR>\
    ...but in one operation when you do not need that level of control.\
    Refer to RCAware documentation for instructions."""

    def __call__(self, data, retCode='', fromAddr='', timeout=.5):
        eg.plugins.HdmiCec.SuspendSerialRead()
        eg.plugins.HdmiCec.Write(data)
        result=eg.plugins.HdmiCec.Read(retCode, fromAddr, timeout)
        # This is for ping
        if retCode == '1' and result == "TIMEOUT.WAITING.FOR.RESPONSE":
            result='1.02'
        eg.plugins.HdmiCec.ResumeSerialRead()
        return result

    def Configure(self, data='', retCode='', fromAddr='', timeout=1):
        panel = eg.ConfigPanel()
        
        myGrid1 = wx.GridBagSizer(10, 10)
        Add = myGrid1.Add

        dataTxt = wx.StaticText(panel, 10, "Message Data:")
        dataCtrl = wx.TextCtrl(panel, value=data)
        Add(dataTxt,(0,0))
        Add(dataCtrl,(0,1))
        
        retCodeTxt = wx.StaticText(panel, 10, "Expected Return Code (optional):")
        retCodeCtrl = wx.TextCtrl(panel, value=retCode)
        Add(retCodeTxt,(1,0))
        Add(retCodeCtrl,(1,1))

        fromAddrTxt = wx.StaticText(panel, 10, "From Logical Address (optional):")
        fromAddrCtrl = wx.TextCtrl(panel, value=fromAddr)
        Add(fromAddrTxt,(2,0))
        Add(fromAddrCtrl,(2,1))

        timeoutTxt = wx.StaticText(panel, 10, "Timeout: (optional)")
        timeoutCtrl = wx.TextCtrl(panel, value=str(timeout))
        Add(timeoutTxt,(3,0))
        Add(timeoutCtrl,(3,1))

        panel.sizer.Add(myGrid1,0, wx.EXPAND)

        while panel.Affirmed():
            try:
                timeout=int(timeoutCtrl.GetValue())
            except:
                timeout=1
            panel.SetResult(dataCtrl.GetValue(), retCodeCtrl.GetValue(), fromAddrCtrl.GetValue(), timeout)


class CecCommand(eg.ActionBase):
    name = 'CEC Command'
    description = """\
    Send a specific CEC command to a device.\
    If the command has an expected response you can choose to return in the eg.result variable,\
    or select an exact expected return message and true or false will be returned."""
    
    def __call__(self, lAddr=0, osdName='', cmdType=0, cmd=0, cmdTxt="", opt1Txt="", opt2Txt="",opt3Txt="",opt4Txt="",opt5Txt="",opt6Txt="",opt7Txt="",opt1=0, opt2=0, opt3=0, opt4=0, opt5=0, opt6=0, opt7=0, cmdOpts="", retVal=0, retCodeTxt="None", retValTxt=""):
        result=""
        try:
            if osdName == 'Broadcast':
                lAddr=15
            elif osdName == 'Event Sender':
                lAddr=filter(lambda i: i[3] == eg.event.payload, self.plugin.real)[0][0]
            elif osdName != '':
                lAddr=filter(lambda i: i[3] == osdName, self.plugin.real)[0][0]
            hexAddr=hex(int(lAddr))[2:].upper()
        except:
            print cmdTxt + ': lAddr not found for ' + osdName
            eg.StopMacro()
            return

        try:
            if retCodeTxt != "None":
                result=eg.plugins.HdmiCec.WriteRead('!x' + hexAddr + ' ' + cmdOpts + '~', retCodeTxt)
                niceCode=""
                niceTo=""
                niceFrom=""
                opts=''
                for i, c in enumerate(result.split('.')):
                    if i == 0:
                        if c== '70' or c== '81'  or c== '82'  or c== '86'  or c== '9D':
                            try:
                                niceCode=filter(lambda i: i[1] == result[3]+'.'+result[4]+'.'+result[6]+'.'+result[7], self.plugin.devDetails)[0][3]
                            except:
                                niceCode=result[3:7]
                                pass
                            break
                        try:
                            opts=self.plugin.cmdMap.cmd[c][2]
                        except:
                            opts=[]
                            pass
                    else:
                        try:
                            if i == 1:
                                if retValTxt != "":
                                    if c == retValTxt:
                                        niceCode=True
                                    else:
                                        niceCode=False
                                    break
                                niceCode=self.plugin.cmdMap.opt[opts[i-1]][c]
                            else:
                                niceCode=niceCode+'.'+self.plugin.cmdMap.opt[opts[i-1]][c]
                        except:
                            if i == 1:
                                niceCode=c
                            else:
                                niceCode=niceCode+'.'+c
                            pass
                return niceCode
            else:
                eg.plugins.HdmiCec.Write('!x' + hexAddr + ' ' + cmdOpts + ' ~')
        except:
            pass

    def GetLabel(self, lAddr=0, osdName='', cmdType=0, cmd=0, cmdTxt="", opt1Txt="", opt2Txt="",opt3Txt="",opt4Txt="",opt5Txt="",opt6Txt="",opt7Txt="",opt1=0, opt2=0, opt3=0, opt4=0, opt5=0, opt6=0, opt7=0, cmdOpts="", retVal=0, retCodeTxt="None", retValTxt=""):
        return cmdTxt + ': ' + osdName

    def Configure(self, lAddr=0, osdName='', cmdType=0, cmd=0, cmdTxt="", opt1Txt="", opt2Txt="",opt3Txt="",opt4Txt="",opt5Txt="",opt6Txt="",opt7Txt="",opt1=0, opt2=0, opt3=0, opt4=0, opt5=0, opt6=0, opt7=0, cmdOpts="", retVal=0, retCodeTxt="None", retValTxt=""):
        lAddr=0
        self.cmdTxt=cmdTxt
        self.cmdOpts=cmdOpts
        self.retVal=retVal
        self.retCodeTxt=retCodeTxt
        self.retValTxt=retValTxt
        self.retValList=['None.']
        self.opt1=opt1
        self.opt2=opt2
        self.opt3=opt3
        self.opt4=opt4
        self.opt5=opt5
        self.opt6=opt6
        self.opt7=opt7
        self.optList1=None
        self.optList2=None
        self.optList3=None
        self.optList4=None
        self.optList5=None
        self.optList6=None
        self.optList7=None
        
        panel = eg.ConfigPanel(self, resizable=False)

        myGrid1 = wx.GridBagSizer(7, 7)
        Add = myGrid1.Add

        #Logical Address dropdown
        lAddrTxt = wx.StaticText(panel, 10, "To Device:")
        addrList=['Broadcast', 'Event Sender']
        addrList.extend([i[3] for i in self.plugin.real])
        try:
            lAddr=addrList.index(osdName)
        except:
            pass
        lAddrCtrl = panel.Choice(lAddr,addrList)
        lAddrCtrl.SetSelection(lAddr)
        Add(lAddrTxt, (0,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
        Add(lAddrCtrl, (0,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
        
        #list of command types
        cmdTypeTxt = wx.StaticText(panel, 10, "Command Type:")
        cmdTypeCtrl = panel.Choice(cmdType, self.plugin.cmdTypeList)
        cmdTypeCtrl.SetSelection(cmdType)
        Add(cmdTypeTxt, (1,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
        Add(cmdTypeCtrl, (1,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
        
        #list of commands of selected type
        cmdText = wx.StaticText(panel, 10, "Command:")
        cmdCtrl = panel.Choice(cmd, [i[1] for i in self.plugin.cmdList[cmdTypeCtrl.GetStringSelection()]])
        cmdCtrl.SetSelection(cmd)
        cmdCtrl.SetToolTip(wx.ToolTip(filter(lambda i: i[1] == cmdCtrl.GetStringSelection(), self.plugin.cmdList[cmdTypeCtrl.GetStringSelection()])[0][4]))
        Add(cmdText, (2,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
        Add(cmdCtrl, (2,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)

        #Open Text type-ins for options with no dropdowns
        openText1Txt = wx.TextCtrl(panel, value=opt1Txt)
        openText1Txt.Hide()
        openText1 = wx.StaticText(panel, 10, "")
        openText1.Hide()
        openText2Txt = wx.TextCtrl(panel, value=opt2Txt)
        openText2Txt.Hide()
        openText2 = wx.StaticText(panel, 10, "")
        openText2.Hide()
        openText3Txt = wx.TextCtrl(panel, value=opt3Txt)
        openText3Txt.Hide()
        openText3 = wx.StaticText(panel, 10, "")
        openText3.Hide()
        openText4Txt = wx.TextCtrl(panel, value=opt4Txt)
        openText4Txt.Hide()
        openText4 = wx.StaticText(panel, 10, "")
        openText4.Hide()
        openText5Txt = wx.TextCtrl(panel, value=opt5Txt)
        openText5Txt.Hide()
        openText5 = wx.StaticText(panel, 10, "")
        openText5.Hide()
        openText6Txt = wx.TextCtrl(panel, value=opt6Txt)
        openText6Txt.Hide()
        openText6 = wx.StaticText(panel, 10, "")
        openText6.Hide()
        openText7Txt = wx.TextCtrl(panel, value=opt7Txt)
        openText7Txt.Hide()
        openText7 = wx.StaticText(panel, 10, "")
        openText7.Hide()

        #For Options with dropdowns
        opt1Txt = wx.StaticText(panel, 10, "")
        opt1Txt.Hide()
        opt1Ctrl = panel.Choice(opt1, [])
        opt1Ctrl.Hide()
        opt2Txt = wx.StaticText(panel, 10, "")
        opt2Txt.Hide()
        opt2Ctrl = panel.Choice(opt2, [])
        opt2Ctrl.Hide()
        opt3Txt = wx.StaticText(panel, 10, "")
        opt3Txt.Hide()
        opt3Ctrl = panel.Choice(opt3, [])
        opt3Ctrl.Hide()
        opt4Txt = wx.StaticText(panel, 10, "")
        opt4Txt.Hide()
        opt4Ctrl = panel.Choice(opt4, [])
        opt4Ctrl.Hide()
        opt5Txt = wx.StaticText(panel, 10, "")
        opt5Txt.Hide()
        opt5Ctrl = panel.Choice(opt5, [])
        opt5Ctrl.Hide()
        opt6Txt = wx.StaticText(panel, 10, "")
        opt6Txt.Hide()
        opt6Ctrl = panel.Choice(opt6, [])
        opt6Ctrl.Hide()
        opt7Txt = wx.StaticText(panel, 10, "")
        opt7Txt.Hide()
        opt7Ctrl = panel.Choice(opt7, [])
        opt7Ctrl.Hide()
        
        # Dropdown for return value
        retValTxtCtrl = wx.StaticText(panel, 10, "Return Value: ")
        retValTxtCtrl.Hide()
        retValCtrl = panel.Choice(retVal, [])
        retValCtrl.Hide()


        panel.sizer.Add(myGrid1,0, wx.EXPAND)
        panel.Layout()

        def OnRetValChange(event):
            self.retVal=retValCtrl.GetSelection()
            self.retCodeTxt=self.retValList[self.retVal].split('.')[0]
            self.retValTxt=self.retValList[self.retVal].split('.')[1]
            event.Skip()
        
        def OnCmdChange(event,firstCall=False):

            openText1Txt.Hide()
            openText1.Hide()
            openText2Txt.Hide()
            openText2.Hide()
            openText3Txt.Hide()
            openText3.Hide()
            openText4Txt.Hide()
            openText4.Hide()
            openText5Txt.Hide()
            openText5.Hide()
            openText6Txt.Hide()
            openText6.Hide()
            openText7Txt.Hide()
            openText7.Hide()
            opt1Txt.Hide()
            opt1Ctrl.Hide()
            opt2Txt.Hide()
            opt2Ctrl.Hide()
            opt3Txt.Hide()
            opt3Ctrl.Hide()
            opt4Txt.Hide()
            opt4Ctrl.Hide()
            opt5Txt.Hide()
            opt5Ctrl.Hide()
            opt6Txt.Hide()
            opt6Ctrl.Hide()
            opt7Txt.Hide()
            opt7Ctrl.Hide()
            retValTxtCtrl.Hide()
            retValCtrl.Hide()
            myGrid1.Detach(opt1Txt)
            myGrid1.Detach(opt1Ctrl)
            myGrid1.Detach(opt2Txt)
            myGrid1.Detach(opt2Ctrl)
            myGrid1.Detach(opt3Txt)
            myGrid1.Detach(opt3Ctrl)
            myGrid1.Detach(opt4Txt)
            myGrid1.Detach(opt4Ctrl)
            myGrid1.Detach(opt5Txt)
            myGrid1.Detach(opt5Ctrl)
            myGrid1.Detach(opt6Txt)
            myGrid1.Detach(opt6Ctrl)
            myGrid1.Detach(opt7Txt)
            myGrid1.Detach(opt7Ctrl)
            myGrid1.Detach(openText1)
            myGrid1.Detach(openText1Txt)
            myGrid1.Detach(openText2)
            myGrid1.Detach(openText2Txt)
            myGrid1.Detach(openText3)
            myGrid1.Detach(openText3Txt)
            myGrid1.Detach(openText4)
            myGrid1.Detach(openText4Txt)
            myGrid1.Detach(openText5)
            myGrid1.Detach(openText5Txt)
            myGrid1.Detach(openText6)
            myGrid1.Detach(openText6Txt)
            myGrid1.Detach(openText7)
            myGrid1.Detach(openText7Txt)
            myGrid1.Detach(retValTxtCtrl)
            myGrid1.Detach(retValCtrl)
            if not firstCall and self.cmdTxt != cmdCtrl.GetStringSelection():
                openText1Txt.SetValue("")
                openText2Txt.SetValue("")
                openText3Txt.SetValue("")
                openText4Txt.SetValue("")
                openText5Txt.SetValue("")
                openText6Txt.SetValue("")
                openText7Txt.SetValue("")
                self.opt1=0
                self.opt2=0
                self.opt3=0
                self.opt4=0
                self.opt5=0
                self.opt6=0
                self.opt7=0
            else:
                self.cmdTxt=cmdCtrl.GetStringSelection()
            
            self.optList1=None
            self.optList2=None
            self.optList3=None
            self.optList4=None
            self.optList5=None
            self.optList6=None
            self.optList7=None
            rSpot=3
            
            cl=filter(lambda i: i[1] == cmdCtrl.GetStringSelection(), self.plugin.cmdList[cmdTypeCtrl.GetStringSelection()])[0]
            cmdCtrl.SetToolTip(wx.ToolTip(cl[4]))
            cecCode=cl[0]
            for i, o in enumerate(cl[2]):
                optList=[]
                try:
                    optList=self.plugin.cmdMap.opt[o]
                except:
                    optList=None
                    pass
                if i == 0 and o <> 'None' and optList == None:
                    myGrid1.Add(openText1, (3,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(openText1Txt, (3,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    openText1.Show()
                    openText1.SetLabel(o+' :') 
                    openText1Txt.Show()
                    rSpot=4
                elif i == 0 and o <> 'None' and optList <> None:
                    opt1Txt.SetLabel(o+' :') 
                    opt1Txt.InvalidateBestSize()
                    opt1Txt.SetSize(opt1Ctrl.GetBestSize())
                    opt1Ctrl.Clear()
                    opt1Ctrl.AppendItems([optList[i] for i in optList])
                    opt1Ctrl.InvalidateBestSize()
                    opt1Ctrl.SetSize(opt1Ctrl.GetBestSize())
                    opt1Ctrl.SetSelection(self.opt1)
                    myGrid1.Add(opt1Txt, (3,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(opt1Ctrl, (3,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    opt1Txt.Show()
                    opt1Ctrl.Show()
                    self.optList1=optList
                    rSpot=4
                elif i == 1 and o <> 'None' and optList == None:
                    myGrid1.Add(openText2, (4,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(openText2Txt, (4,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    openText2.Show()
                    openText2.SetLabel(o+' :') 
                    openText2Txt.Show()
                    rSpot=5
                elif i == 1 and o <> 'None' and optList <> None:
                    opt2Txt.SetLabel(o+' :') 
                    opt2Txt.InvalidateBestSize()
                    opt2Txt.SetSize(opt2Ctrl.GetBestSize())
                    opt2Ctrl.Clear()
                    opt2Ctrl.AppendItems([optList[i] for i in optList])
                    opt2Ctrl.InvalidateBestSize()
                    opt2Ctrl.SetSize(opt2Ctrl.GetBestSize())
                    opt2Ctrl.SetSelection(self.opt2)
                    myGrid1.Add(opt2Txt, (4,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(opt2Ctrl, (4,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    opt2Txt.Show()
                    opt2Ctrl.Show()
                    self.optList2=optList
                    rSpot=5
                elif i == 2 and o <> 'None' and optList == None:
                    myGrid1.Add(openText3, (5,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(openText3Txt, (5,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    openText3.Show()
                    openText3.SetLabel(o+' :') 
                    openText3Txt.Show()
                    rSpot=6
                elif i == 2 and o <> 'None' and optList <> None:
                    opt3Txt.SetLabel(o+' :') 
                    opt3Txt.InvalidateBestSize()
                    opt3Txt.SetSize(opt3Ctrl.GetBestSize())
                    opt3Ctrl.Clear()
                    opt3Ctrl.AppendItems([optList[i] for i in optList])
                    opt3Ctrl.InvalidateBestSize()
                    opt3Ctrl.SetSize(opt3Ctrl.GetBestSize())
                    opt3Ctrl.SetSelection(self.opt3)
                    myGrid1.Add(opt3Txt, (5,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(opt3Ctrl, (5,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    opt3Txt.Show()
                    opt3Ctrl.Show()
                    self.optList3=optList
                    rSpot=6
                elif i == 3 and o <> 'None' and optList == None:
                    myGrid1.Add(openText4, (6,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(openText4Txt, (6,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    openText4.Show()
                    openText4.SetLabel(o+' :') 
                    openText4Txt.Show()
                    rSpot=7
                elif i == 3 and o <> 'None' and optList <> None:
                    opt4Txt.SetLabel(o+' :') 
                    opt4Txt.InvalidateBestSize()
                    opt4Txt.SetSize(opt4Ctrl.GetBestSize())
                    opt4Ctrl.Clear()
                    opt4Ctrl.AppendItems([optList[i] for i in optList])
                    opt4Ctrl.InvalidateBestSize()
                    opt4Ctrl.SetSize(opt4Ctrl.GetBestSize())
                    opt4Ctrl.SetSelection(self.opt4)
                    myGrid1.Add(opt4Txt, (6,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(opt4Ctrl, (6,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    opt4Txt.Show()
                    opt4Ctrl.Show()
                    self.optList4=optList
                    rSpot=7
                elif i == 4 and o <> 'None' and optList == None:
                    myGrid1.Add(openText5, (7,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(openText5Txt, (7,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    openText5.Show()
                    openText5.SetLabel(o+' :') 
                    openText5Txt.Show()
                    rSpot=8
                elif i == 4 and o <> 'None' and optList <> None:
                    opt5Txt.SetLabel(o+' :') 
                    opt5Txt.InvalidateBestSize()
                    opt5Txt.SetSize(opt5Ctrl.GetBestSize())
                    opt5Ctrl.Clear()
                    opt5Ctrl.AppendItems([optList[i] for i in optList])
                    opt5Ctrl.InvalidateBestSize()
                    opt5Ctrl.SetSize(opt5Ctrl.GetBestSize())
                    opt5Ctrl.SetSelection(self.opt5)
                    myGrid1.Add(opt5Txt, (7,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(opt5Ctrl, (7,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    opt5Txt.Show()
                    opt5Ctrl.Show()
                    self.optList5=optList
                    rSpot=8
                elif i == 5 and o <> 'None' and optList == None:
                    myGrid1.Add(openText6, (8,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(openText6Txt, (8,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    openText6.Show()
                    openText6.SetLabel(o+' :') 
                    openText6Txt.Show()
                    rSpot=9
                elif i == 5 and o <> 'None' and optList <> None:
                    opt6Txt.SetLabel(o+' :') 
                    opt6Txt.InvalidateBestSize()
                    opt6Txt.SetSize(opt6Ctrl.GetBestSize())
                    opt6Ctrl.Clear()
                    opt6Ctrl.AppendItems([optList[i] for i in optList])
                    opt6Ctrl.InvalidateBestSize()
                    opt6Ctrl.SetSize(opt6Ctrl.GetBestSize())
                    opt6Ctrl.SetSelection(self.opt6)
                    myGrid1.Add(opt6Txt, (8,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(opt6Ctrl, (8,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    opt6Txt.Show()
                    opt6Ctrl.Show()
                    self.optList6=optList
                    rSpot=9
                elif i == 6 and o <> 'None' and optList == None:
                    myGrid1.Add(openText7, (9,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(openText7Txt, (9,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    openText7.Show()
                    openText7.SetLabel(o+' :') 
                    openText7Txt.Show()
                    rSpot=10
                elif i == 6 and o <> 'None' and optList <> None:
                    opt7Txt.SetLabel(o+' :') 
                    opt7Txt.InvalidateBestSize()
                    opt7Txt.SetSize(opt7Ctrl.GetBestSize())
                    opt7Ctrl.Clear()
                    opt7Ctrl.AppendItems([optList[i] for i in optList])
                    opt7Ctrl.InvalidateBestSize()
                    opt7Ctrl.SetSize(opt7Ctrl.GetBestSize())
                    opt7Ctrl.SetSelection(self.opt7)
                    myGrid1.Add(opt7Txt, (9,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    myGrid1.Add(opt7Ctrl, (9,1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                    opt7Txt.Show()
                    opt7Ctrl.Show()
                    self.optList7=optList
                    rSpot=10
            
            vOptList=None
            if cl[3] != "None":
                self.retCodeTxt=cl[3]
                retValCtrl.Clear()
                niceRetVal=self.plugin.cmdMap.cmd[cl[3]][1]
                self.retValList=["None.", cl[3]+'.']
                retValCtrl.AppendItems(['None (Allow Event)'])
                retValCtrl.AppendItems([niceRetVal + ' (Trap Event)'])
                try:
                    vOptList=self.plugin.cmdMap.opt[self.plugin.cmdMap.cmd[cl[3]][2][0]]
                    for i,o in enumerate(vOptList):
                        retValCtrl.AppendItems([niceRetVal + '.' + vOptList[o] + ' (True/False)'])
                        self.retValList.append(cl[3] + '.' + o)
                except:
                    pass

                retValCtrl.InvalidateBestSize()
                retValCtrl.SetSize(retValCtrl.GetBestSize())
                myGrid1.Add(retValTxtCtrl, (rSpot,0), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                myGrid1.Add(retValCtrl, (rSpot, 1), flag = wx.ALL|wx.EXPAND|wx.ALIGN_LEFT, border=2)
                if firstCall:
                    retValCtrl.SetSelection(self.retVal)
                else:
                    self.retVal=0
                    retValCtrl.SetSelection(0)
                
                retValTxtCtrl.Show()
                retValCtrl.Show()
            else:
                self.retVal=0
                self.retCodeTxt="None"
                self.retValTxt=""
            myGrid1.Layout()
            panel.Layout()
            panel.InvalidateBestSize()
            h, w = panel.GetBestSize()
            w += 5
            panel.Fit()
            panel.Refresh()
            panel.SetSize((h,w))
            panel.SetMinSize((h,w))
            panel.SetMaxSize((h,w))
            panel.SetVirtualSize((h,w))
            panel.sizer.FitInside(panel)
            panel.GetParent().SetMinSize(panel.GetParent().GetBestSize())
            panel.GetParent().SetSize(panel.GetParent().GetBestSize())
            panel.GetParent().Fit()
            panel.GetParent().Refresh()
            panel.GetParent().GetParent().SetMinSize(panel.GetParent().GetParent().GetBestSize())
            panel.GetParent().GetParent().SetSize(panel.GetParent().GetParent().GetBestSize())
            panel.GetParent().GetParent().Fit()
            panel.GetParent().GetParent().Refresh()
            panel.sizer.Fit(panel)
            OnRetValChange(wx.CommandEvent())
            event.Skip()

        def OnCmdTypeChange(event,firstCall=False):
            cmdCtrl.Clear()
            cmdCtrl.AppendItems([i[1] for i in self.plugin.cmdList[cmdTypeCtrl.GetStringSelection()]])
            cmdCtrl.InvalidateBestSize() 
            cmdCtrl.SetSize(cmdCtrl.GetBestSize()) 
            if firstCall:
                cmdCtrl.SetSelection(cmd)
            else:
                cmdCtrl.SetSelection(0)
            OnCmdChange(wx.CommandEvent(),firstCall)
            event.Skip()
        
        OnCmdTypeChange(wx.CommandEvent(),True)
        
        cmdTypeCtrl.Bind(wx.EVT_CHOICE, OnCmdTypeChange)
        cmdCtrl.Bind(wx.EVT_CHOICE, OnCmdChange)
        retValCtrl.Bind(wx.EVT_CHOICE, OnRetValChange)
        
        while panel.Affirmed():
            self.cmdOpts=filter(lambda i: i[1] == cmdCtrl.GetStringSelection(), self.plugin.cmdList[cmdTypeCtrl.GetStringSelection()])[0][0]
            if openText1Txt.GetValue() != "":
                self.cmdOpts=self.cmdOpts + ' ' + openText1Txt.GetValue()
            elif self.optList1 != None:
                self.cmdOpts=self.cmdOpts + ' ' + self.optList1.keys()[opt1Ctrl.GetSelection()]
            if openText2Txt.GetValue() != "":
                self.cmdOpts=self.cmdOpts + ' ' + openText2Txt.GetValue()
            elif self.optList2 != None:
                self.cmdOpts=self.cmdOpts + ' ' + self.optList2.keys()[opt2Ctrl.GetSelection()]
            if openText3Txt.GetValue() != "":
                self.cmdOpts=self.cmdOpts + ' ' + openText3Txt.GetValue()
            elif self.optList3 != None:
                self.cmdOpts=self.cmdOpts + ' ' + self.optList3.keys()[opt3Ctrl.GetSelection()]
            if openText4Txt.GetValue() != "":
                self.cmdOpts=self.cmdOpts + ' ' + openText4Txt.GetValue()
            elif self.optList4 != None:
                self.cmdOpts=self.cmdOpts + ' ' + self.optList4.keys()[opt4Ctrl.GetSelection()]
            if openText5Txt.GetValue() != "":
                self.cmdOpts=self.cmdOpts + ' ' + openText5Txt.GetValue()
            elif self.optList5 != None:
                self.cmdOpts=self.cmdOpts + ' ' + self.optList5.keys()[opt5Ctrl.GetSelection()]
            if openText6Txt.GetValue() != "":
                self.cmdOpts=self.cmdOpts + ' ' + openText6Txt.GetValue()
            elif self.optList6 != None:
                self.cmdOpts=self.cmdOpts + ' ' + self.optList6.keys()[opt6Ctrl.GetSelection()]
            if openText7Txt.GetValue() != "":
                self.cmdOpts=self.cmdOpts + ' ' + openText7Txt.GetValue()
            elif self.optList7 != None:
                self.cmdOpts=self.cmdOpts + ' ' + self.optList7.keys()[opt7Ctrl.GetSelection()]
            panel.SetResult(lAddrCtrl.GetSelection(),
                                      lAddrCtrl.GetStringSelection(),
                                      cmdTypeCtrl.GetSelection(),
                                      cmdCtrl.GetSelection(),
                                      cmdCtrl.GetStringSelection(),
                                      openText1Txt.GetValue(),
                                      openText2Txt.GetValue(),
                                      openText3Txt.GetValue(),
                                      openText4Txt.GetValue(),
                                      openText5Txt.GetValue(),
                                      openText6Txt.GetValue(),
                                      openText7Txt.GetValue(),
                                      opt1Ctrl.GetSelection(),
                                      opt2Ctrl.GetSelection(),
                                      opt3Ctrl.GetSelection(),
                                      opt4Ctrl.GetSelection(),
                                      opt5Ctrl.GetSelection(),
                                      opt6Ctrl.GetSelection(),
                                      opt7Ctrl.GetSelection(),
                                      self.cmdOpts,
                                      self.retVal,
                                      self.retCodeTxt,
                                      self.retValTxt
            )


class IsFromDevice(eg.ActionBase):
    name = 'Is From Device'
    description = """\
    Check if an event is from a specific device; returns True or False.\
    NOTE: The from device name is found in the payload of all HDMI-CEC generated events."""

    def __call__(self, lAddr, osdName=''):
        result=None
        try:
            result=(eg.event.payload == osdName)
        except:
            return
        return result

    def GetLabel(self, lAddr, osdName=''):
        return self.name + ': ' + osdName

    def Configure(self, lAddr=0, osdName=''):
        panel = eg.ConfigPanel()
        
        #Logical Address dropdown
        if osdName != '':
            try:
                lAddr=self.plugin.real.index(filter(lambda i: i[3] == osdName, self.plugin.real)[0])
            except:
                lAddr=0
                pass
        lAddrCtrl = panel.Choice(lAddr,[i[3] for i in self.plugin.real])
        panel.sizer.Add(lAddrCtrl,0, wx.FIXED_MINSIZE)
        
        while panel.Affirmed():
            panel.SetResult(lAddrCtrl.GetSelection(), lAddrCtrl.GetStringSelection())


class HdmiCec(eg.PluginClass):     
    def __init__(self):
        group=self
        group.AddAction(DetPhysAddr)
        group.AddAction(SetLogicalAddress)
        group.AddAction(CecCommand)
        group.AddAction(IsFromDevice)
        group.AddAction(SetActiveButtonMap)
        group = self.AddGroup("Power","Easy access to enhanced versions of popular CEC Power Commands.")
        group.AddAction(IsOnline)
        group.AddAction(WakeUp)
        group.AddAction(StandBy)
        group.AddAction(TVPower)
        group = self.AddGroup("Routing","Easy access to enhanced versions of popular CEC Souce Routing Commands.")
        group.AddAction(ActiveSource)
        group.AddAction(SelectSource)
        group.AddAction(GetDevDetails)
        group = self.AddGroup("Audio","Easy access to enhanced versions of popular CEC Audio Commands.")
        group.AddAction(GetAudioMode)
        group.AddAction(SetAudioMode)
        group = self.AddGroup("Raw Messaging","Lower level communications.")
        group.AddAction(SuspendSerialRead)
        group.AddAction(Write)
        group.AddAction(Read)
        group.AddAction(ResumeSerialRead)
        group.AddAction(WriteRead)
        group=self
        group.AddAction(UpdDevDetail,hidden=True)
        group.AddAction(SetPhysicalAddress,hidden=True)
        group.AddAction(SetOsdName,hidden=True)
        group.AddAction(SetConfig,hidden=True)
        self.pluginDir = os.path.abspath(os.path.split(__file__)[0])
        try:
            self.dllPath = os.path.join(os.getenv('ProgramFiles(x86)')+'\\RCAware\\', "_pccec.dll")
        except:
            self.dllPath = os.path.join(os.getenv('ProgramFiles')+'\\RCAware\\', "_pccec.dll")
            pass
        self.volMap = volMap
        self.cmdMap = cmdMap
        self.cmdMap.opt['Feature Opcode']={}
        for i, k in enumerate(self.cmdMap.cmd):
            self.cmdMap.opt['Feature Opcode'][k]=self.cmdMap.cmd[k][1]
        self.cmdTypeList=sorted(list(set([self.cmdMap.cmd[i][0] for i in self.cmdMap.cmd])))
        self.cmdList={}
        for i, c in enumerate(self.cmdTypeList):
            self.cmdList[c]=[]
        for i, c in enumerate(self.cmdMap.cmd):
            self.cmdList[self.cmdMap.cmd[c][0]].append([c, self.cmdMap.cmd[c][1],self.cmdMap.cmd[c][2],self.cmdMap.cmd[c][3],self.cmdMap.cmd[c][4]])
        for i, c in enumerate(self.cmdTypeList):
            self.cmdList[c].sort()
        #TODO Add to config panel
        self.TVpowerOnSleepWake = 0
        self.screenEvents=[]
        self.suppressFromMe=True
        self.toggleMouse = False
        self.activeBtnMap=""
        self.syncVolume=0
        self.volSyncType="PC"
        self.lkTimer = threading.Timer(0, self.longKeyPress, [False, None])
        self.llcTimer = threading.Timer(0, self.longLeftClick, [False])
        self.volSyncInt = 0.15
        self.volSyncTimer = threading.Timer(0, self.volSync)
        self.lastVol=0
        self.lastMute=False
        self.detectedPhysAddr = None
        try:
            self.detectedPhysAddr = eg.plugins.HdmiCec.DetPhysAddr(self.primary[7]-1)
        except:
            pass
        self.stopReadThreadEvent = threading.Event()
        self.startReadThreadEvent = threading.Event()
        self.exitReadThreadEvent = threading.Event()
        self.cecCon=None
        self.stopReadThreadEvent.set()
        self.readThread = threading.Thread(
            target=self.ReadThreadLoop,
            args=(self.stopReadThreadEvent, self.startReadThreadEvent, self.exitReadThreadEvent, )
        )
        self.readThread.start()
        self.comOn=False
        self.serialOn = False
        self.backbuffer=""
        result = 0

    def ReadThreadLoop(self, stopReadThreadEvent, startReadThreadEvent, exitReadThreadEvent):
        buffer = ''
        while not exitReadThreadEvent.isSet():
            while not stopReadThreadEvent.isSet():
                ch = self.cecCon.read()
                if buffer == '?' and ch == '?':
                    #print "Skipping double ?"
                    continue
                buffer=buffer+ch
                if stopReadThreadEvent.isSet() or exitReadThreadEvent.isSet():
                    startReadThreadEvent.clear()
                    break
                if buffer == '':
                    continue
                if buffer[-1] not in '\r\n':
                    continue
                if self.serialOn:
                    self.OnReceive(buffer)
                else:
                    #print "Filling buffer with " + str(buffer)
                    self.backbuffer=self.backbuffer+buffer
                buffer = ''
            if exitReadThreadEvent.isSet():
                break
            startReadThreadEvent.wait()
            if exitReadThreadEvent.isSet():
                break
            stopReadThreadEvent.clear()

    def startCom(self):
        retry=0
        while self.portNum != 0 and not self.comOn and retry < 20:
            try:
                print "Looking for HDMI CEC on port " + str(self.portNum)
                self.cecCon = eg.SerialPort(self.portNum-1) # com ports start counting by 0.
                self.cecCon.baudrate = 9600
                self.cecCon.timeout = 30.0
                self.cecCon.setDTR(1)
                self.cecCon.setRTS(1)
                self.comOn = True
                time.sleep(0.1)
            except:
                pass
            retry=retry+1
        if not self.comOn:
            eg.PrintError("Communications Error")
            return
        self.backbuffer=''
        self.stopReadThreadEvent.clear()
        self.startReadThreadEvent.set()
        self.serialOn = True
        self.comOn = True
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()

    def stopCom(self):
        self.volSyncTimer.cancel()
        self.stopReadThreadEvent.set()
        self.cecCon.write('!v~')
        time.sleep(0.1)
        self.cecCon.close()
        self.serialOn = False
        self.comOn = False

    def OnResume(self, event):
        eg.plugins.EventGhost.FlushEvents()
        self.startReadThreadEvent.set()
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()
        eg.plugins.EventGhost.FlushEvents()
        if self.TVpowerOnSleepWake == 1:
            eg.plugins.HdmiCec.WakeUp(0, 10, u'TV')

    def OnSuspend(self, event):
        if self.TVpowerOnSleepWake == 1:
            eg.plugins.HdmiCec.StandBy(0, 10, u'TV')
        eg.plugins.EventGhost.FlushEvents()
        self.volSyncTimer.cancel()
        self.stopReadThreadEvent.set()
        self.cecCon.write('!v~')
        time.sleep(0.1)
        eg.plugins.EventGhost.FlushEvents()

    def DisconnectDevice(self, event):
        try:
            if event.payload[0].upper().index(u'VID_04D8&PID_FF59') > 0:
                print "PC-CEC Disconnected"
                eg.plugins.EventGhost.FlushEvents()
                self.exitReadThreadEvent.set()
                self.startReadThreadEvent.set()
                self.volSyncTimer.cancel()
                self.cecCon.write('!v~')
                time.sleep(0.1)
                self.cecCon.close()
                del self.cecCon
                self.serialOn = False
                self.comOn = False
                eg.plugins.EventGhost.FlushEvents()
        except:
            pass

    def ReconnectDevice(self, event):
        try:
            if event.payload[0].upper().index(u'VID_04D8&PID_FF59') > 0:
                print "PC-CEC Reconnected"
                eg.plugins.EventGhost.FlushEvents()
                self.exitReadThreadEvent.clear()
                self.stopReadThreadEvent.clear()
                self.startReadThreadEvent.clear()
                self.readThread = threading.Thread(
                    target=self.ReadThreadLoop,
                    args=(self.stopReadThreadEvent, self.startReadThreadEvent, self.exitReadThreadEvent, ))
                self.startCom()
                eg.plugins.HdmiCec.SetLogicalAddress(self.primary[0], [int(i[0]) for i in self.emulated])
                self.readThread.start()
                eg.plugins.EventGhost.FlushEvents()
        except:
            pass

    def DisconnectDisplay(self, event):
        try:
            pass
        except:
            pass

    def ReconnectDisplay(self, event):
        try:
            detectedPhysAddr = eg.plugins.HdmiCec.DetPhysAddr(self.primary[7]-1)
            if detectedPhysAddr <> self.detectedPhysAddr:
                idx=self.devDetails.index(self.primary)
                curDetails=self.devDetails[:]
                del curDetails[idx]
                newDetails=self.devDetails[:]
                del newDetails[idx]
                newDetails = eg.plugins.HdmiCec.UpdDevDetail(newDetails,self.primary[0],detectedPhysAddr,self.primary[2],self.primary[3],self.primary[4],self.primary[5],self.primary[6],self.primary[7])
                if newDetails != curDetails:
                    self.devDetails=newDetails
                self.primary=filter(lambda i: i[2] == 'Primary', self.devDetails)[0]
                self.detectedPhysAddr = detectedPhysAddr
                eg.plugins.HdmiCec.SetPhysicalAddress(self.primary[0],self.primary[1],True)
        except:
            #print traceback.format_exc()
            pass

    def __start__(self, portNum, syncVolume, autoMapKeys, autoMouse, devDetailsTxt, mouseMapTxt, btnMapTxt, screenEvents='', firstLoad=True):
        self.syncVolume = syncVolume
        self.autoMapKeys = autoMapKeys
        self.autoMouse = autoMouse
        self.devDetailsTxt = devDetailsTxt
        self.devDetails=eval(self.devDetailsTxt)
        self.mouseMapTxt=mouseMapTxt
        self.mouseMap=eval(self.mouseMapTxt)
        self.mdSize=0
        self.muSize=0
        self.mlSize=0
        self.mrSize=0
        now=eg.Utils.time.time()-1
        self.muTime=now
        self.mdTime=now
        self.mlTime=now
        self.mrTime=now
        self.lastLeftClick=eg.Utils.time.time()-1
        self.btnMapTxt=btnMapTxt
        self.btnMap=eval(self.btnMapTxt)
        self.activeBtnMap=self.btnMap.keys()[0]
        if self.syncVolume in (2,6):
            self.volSyncInt = 0.1
            try:
                self.lastVol=round(eg.plugins.System.SetMasterVolume(200.0,0)/2,0)
                self.lastMute=eg.plugins.System.GetMute()
            except:
                pass
        else:
            try:
                self.lastVol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                self.lastMute=eg.plugins.System.GetMute()
            except:
                pass
            if self.syncVolume == 4:
                self.volSyncInt = 0.3
            elif self.syncVolume == 5:
                self.volSyncInt = 0.5
            elif self.syncVolume in (7,8,9):
                self.volSyncInt = 0.1
            else:
                self.volSyncInt = 0.15
        # Special code for Panasonic to use sync in place of PC volume
        if self.syncVolume == 1 and filter(lambda i: i[0] == 5, self.devDetails)[0][4] == '008045':
            self.syncVolume = 5
        self.backbuffer=""
        self.screenEvents=[i.strip() for i in screenEvents.split('\n')]
        self.portNum = portNum
        if not self.comOn:
            self.startCom()
        else:
            if self.syncVolume >= 2 and not self.volSyncTimer.isAlive():
                self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
                self.volSyncTimer.start()
        if self.syncVolume == 6:
            print "Initializing Philips Amp"
            self.initAmp()
        eg.Bind("System.Resume", self.OnResume)
        eg.Bind("System.Suspend", self.OnSuspend)
        eg.Bind("System.DeviceRemoved", self.DisconnectDevice)
        eg.Bind("System.DeviceAttached", self.ReconnectDevice)
        eg.Bind("System.DisplayRemoved", self.DisconnectDisplay)
        eg.Bind("System.DisplayAttached", self.ReconnectDisplay)
        self.devConfig='000F'
        self.primary=filter(lambda i: i[2] == 'Primary', self.devDetails)[0]
        self.emulated=filter(lambda i: i[2] == 'Emulated', self.devDetails)
        self.real=filter(lambda i: i[2] == 'Real', self.devDetails)
        try:
            self.ampVendorID = filter(lambda i: i[0] == 5, self.real)[0][4]
        except:
            self.ampVendorID = None
        eg.plugins.HdmiCec.SetLogicalAddress(self.primary[0], [int(i[0]) for i in self.emulated])
        eg.plugins.HdmiCec.SetPhysicalAddress(self.primary[0],self.primary[1])
        eg.plugins.HdmiCec.SetConfig(self.devConfig)
        eg.plugins.HdmiCec.SetOsdName(self.primary[3])
        print 'HDMI-CEC Initialized'

    def __stop__(self):
        if self.comOn:
            self.stopCom()
        self.cecCon = None
        eg.Unbind("System.Resume", self.OnResume)
        eg.Unbind("System.Suspend", self.OnSuspend)
        eg.Unbind("System.DeviceAttached", self.ReconnectDevice)
        eg.Unbind("System.DeviceRemoved", self.DisconnectDevice)
        eg.Unbind("System.DisplayRemoved", self.DisconnectDisplay)
        eg.Unbind("System.DisplayAttached", self.ReconnectDisplay)


    def Configure(self, portNum=4,syncVolume=0,autoMapKeys=0,autoMouse=0, \
                            devDetailsTxt="[[1, '1.0.0.0', 'Primary', 'Media Center', '000000', 'True', 'Recording Device 1',1]]", \
                            mouseMapTxt="{'44.03': ['Left', False, 'moverelative', -15, 0], '44.02': ['Up', False, 'moverelative', 0, 10], \
                            '44.01': ['Down', False, 'moverelative', 0, -10], '44.00': ['Left Click', False, 'leftclick', 0, 0], \
                            '44.04': ['Right', False, 'moverelative', 15, 0], '44.72': ['Red', True, None, 0, 0], '44.73': ['Green', True, None, 0, 0], \
                            '44.71': ['Blue', False, 'toggle', 0, 0], '44.74': ['Yellow', True, None, 0, 0], '44.0D': ['Right Click', False, 'rightclick', 0, 0], \
                            '45': ['Button Released', False, 'None', 0, 0] }",
                            btnMapTxt="{'Media Center': {'41.25': ['Pause', False, '{Ctrl+P}', 0, None], '8A.96': ['Guide', False, '{Ctrl+G}', 0, None], '45': ['Button Released', False, None, 0, None],\
                            '44.47': ['Record', False, '{Ctrl+R}', 0, None], '44.46': ['Pause', False, '{Ctrl+P}', 0, None], '44.45': ['Stop', False, '{Shift+Ctrl+S}', 0, None], \
                            '44.44': ['Play', False, '{Shift+Ctrl+P}', 0, None], '44.49': ['Fast Forward', False, '{Ctrl+F}', 0.34999999999999998, '{Shift+Ctrl+F}'], \
                            '44.48': ['Rewind', False, '{Ctrl+B}', 0.34999999999999998, '{Shift+Ctrl+B}'], '44.03': ['Left', False, '{Left}', 0, None], \
                            '44.02': ['Down', False, '{Down}', 0, None], '44.01': ['Up', False, '{Up}', 0, None], '44.00': ['Select', False, '{Return}', 0, None], \
                            '44.07': ['Left-Up', False, '{Left}{Up}', 0, None], '44.06': ['Right-Down', False, '{Right}{Down}', 0, None], '44.05': ['Right-Up', False, '{Right}{Up}', 0, None], \
                            '44.04': ['Right', False, '{Right}', 0, None], '41.24': ['Play', False, '{Shift+Ctrl+P}', 0, None], '44.08': ['Left-Down', False, '{Left}{Down}', 0, None], \
                            '44.29': ['9', False, '9', 0, None], '44.28': ['8', False, '8', 0, None], '44.25': ['5', False, '5', 0, None], '44.24': ['4', False, '4', 0, None], \
                            '44.27': ['7', False, '7', 0, None], '44.26': ['6', False, '6', 0, None], '44.2A': ['Erase', False, '{Backspace}', 0, None], \
                            '44.32': ['Previous Channel', False, '{Return}', 0, None], '44.0D': ['Exit', False, '{Ctrl+d}', 0, None], '44.21': ['1', False, '1', 0, None], \
                            '44.20': ['0', False, '0', 0, None], '44.4C': ['Back', False, '{Backspace}', 0, None], '44.23': ['3', False, '3', 0, None], \
                            '44.30': ['Channel Up', False, '{PageUp}', 0, None], '44.31': ['Channel Down', False, '{PageDown}', 0, None], \
                            '44.72': ['Red', False, '{Ctrl+R}', 0.34999999999999998, '{Ctrl+O}'], '44.22': ['2', False, '2', 0, None], \
                            '42.03': ['Stop', False, '{Shift+Ctrl+S}', 0, None], '8A.91': ['Back', False, '{Backspace}', 0, None]}}",
                            screenEvents="",
                            firstLoad=True):
                           
        self.firstLoad=firstLoad
        self.devDetailsTxt=devDetailsTxt
        self.devDetails=eval(self.devDetailsTxt)
        if len(self.devDetails) > 1:
            self.firstLoad=False
        self.primary=filter(lambda i: i[2] == 'Primary', self.devDetails)[0]
        self.detectedPhysAddr = eg.plugins.HdmiCec.DetPhysAddr(self.primary[7]-1)
        primDevCnt=len(filter(lambda i: i[2] == 'Primary', self.devDetails))
        dPA=1
        if primDevCnt == 0:
            if self.detectedPhysAddr == None:
                dPA=0
                self.detectedPhysAddr = '1.0.0.0'
            self.devDetails[1] = [1, self.detectedPhysAddr, 'Primary', 'Media Center', '000000', 'True', 'Recording Device 1', dPA]
        elif primDevCnt > 1:
            dPA=1
            if self.detectedPhysAddr == None:
                dPA=0
                self.detectedPhysAddr = self.primary[1]
            self.primary = [self.primary[0], self.detectedPhysAddr, 'Primary', self.primary[3], self.primary[4], 'True', self.primary[6], dPA]
            self.devDetails=filter(lambda i: i[2] != 'Primary', self.devDetails)
            self.devDetails.append(self.primary)
            self.devDetails=sorted(self.devDetails, key=lambda item: item[0])
        self.mouseMapTxt=mouseMapTxt
        self.mouseMap=eval(self.mouseMapTxt)
        self.btnMapTxt=btnMapTxt
        self.btnMap=eval(self.btnMapTxt)
        self.scrEvents=screenEvents

        panel = eg.ConfigPanel(self, resizable=True)

        choicesSyncVolume=['TV Speakers','PC Speakers','LG','Samsung','Sony','Panasonic','Philips','Sharp','Yamaha','Generic']
        choicesAutoMapKeys=['Events Only','Enhanced']
        choicesAutoMouse=['Off','On']
        choiceslAddr=['0','1','2','3','4','5','6','7','8','9','10','11']
        choicesDetect=['Manual']
        if sys.platform == "win32":
            if sys.getwindowsversion() >= (6, ):
                # Use WMI for Vista/Win7
                import wmi
                wmi_connection = wmi.WMI(namespace="WMI")
                wmi_connection2 = wmi.WMI(namespace="CIMV2")
                counter=1
                for monitor in wmi_connection.WmiMonitorID():
                    str1=''
                    try:
                        for i in monitor.UserFriendlyName:
                            if i > 0:
                                str1+=chr(i)
                        choicesDetect.append(str1)
                    except:
                        choicesDetect.append('Monitor DM'+str(counter))
                        pass
                    counter=counter+1;
                try:
                    for idx, monitor in enumerate(wmi_connection2.CIM_Display()):
                        choicesDetect[idx+1]=choicesDetect[idx+1]+' '+monitor.DeviceID.replace('DesktopMonitor','DM')
                except:
                    pass
        choicespAddr=['0','1','2','3','4']
        choicesdType=['Primary','Emulated','Real']
        
        def getChoiceIdx(list,choice):
            for idx,value in enumerate(list):
                if value == choice:
                    return idx
        
        myGrid1 = wx.GridBagSizer(10, 10)
        Add = myGrid1.Add
        
        #Port Number:
        portTxt = wx.StaticText(panel, 10, "COM Port:")
        portNumCtrl = wx.SpinCtrl(panel, value=str(portNum))
        btnPortBtn = wx.Button(panel, -1, "Test Port")
        Add(portTxt, (0,0))
        Add(portNumCtrl, (0,1))
        Add(btnPortBtn, (0,2))

        #Remote control
        keysTxt = wx.StaticText(panel, 10, "Remote:")
        autoMapKeysCtrl = panel.Choice(autoMapKeys,choicesAutoMapKeys)
        Add(keysTxt,(1,0))
        Add(autoMapKeysCtrl,(1,1))

        btnMapBtn=wx.Button(panel,-1,"Remote Map")
        Add(btnMapBtn,(1,2))

        #Mouse control
        mouseTxt = wx.StaticText(panel, 10, "Mouse:")
        autoMouseCtrl = panel.Choice(autoMouse,choicesAutoMouse)
        Add(mouseTxt,(2,0))
        Add(autoMouseCtrl,(2,1))
        
        mouseMapBtn=wx.Button(panel,-1,"Mouse Map")
        Add(mouseMapBtn,(2,2))

        #Amplifier mode selection dropdown
        ampTxt = wx.StaticText(panel, 10, "Amp:")
        syncVolumeCtrl = panel.Choice(syncVolume,choicesSyncVolume)
        Add(ampTxt,(1,3))
        Add(syncVolumeCtrl,(1,4))

        #Screen Events Button
        screenBtn=wx.Button(panel,-1,"Screen Events")
        Add(screenBtn,(2,4))

        panel.sizer.Add(myGrid1,0, wx.EXPAND)
        panel.sizer.Add((10,10))

        #######################################
        # Device Manager GUI
        #######################################
        lAddr=0
        detectPA=1
        pAddr1=0
        pAddr2=0
        pAddr3=0
        pAddr4=0
        dType=1
        cecName=""
        osdName=""
        vendorID=""

        devList = wx.ListCtrl(panel, -1, pos=wx.DefaultPosition,
            size=(300,150), style=wx.LC_REPORT | wx.LC_SINGLE_SEL)

        devList.InsertColumn(0, "Logical")
        devList.InsertColumn(1, "CEC Name")
        devList.InsertColumn(2, "Physical")
        devList.InsertColumn(3, "Type")
        devList.InsertColumn(4, "OSD Name")
        devList.InsertColumn(5, "Vndr")
        devList.InsertColumn(6, "Online")
        devList.InsertColumn(7, "DetectPA")

        def popDevList(devDtls):
            devList.DeleteAllItems()
            for idx,items in enumerate(devDtls):
                devList.InsertStringItem(sys.maxint, str(items[0]))
                devList.SetStringItem(idx, 1, items[6])
                devList.SetStringItem(idx, 2, items[1])
                devList.SetStringItem(idx, 3, items[2])
                devList.SetStringItem(idx, 4, items[3])
                devList.SetStringItem(idx, 5, items[4])
                devList.SetStringItem(idx, 6, str(items[5]))
                detectPA='Detect'
                try:
                    detectPA=choicesDetect[items[7]]
                except:
                    pass
                devList.SetStringItem(idx, 7, detectPA)

            for idx in range(devList.GetColumnCount()):
                devList.SetColumnWidth(idx, wx.LIST_AUTOSIZE_USEHEADER)
                size = devList.GetColumnWidth(idx)
                devList.SetColumnWidth(idx, wx.LIST_AUTOSIZE)
                devList.SetColumnWidth(idx, max(size, devList.GetColumnWidth(idx) + 5))
        
        if self.devDetails != []:
            popDevList(self.devDetails)

        panel.sizer.Add(devList, 1, flag = wx.EXPAND)
        panel.sizer.Add((3,3))

        myGrid2 = wx.GridBagSizer(1, 1)
        Add = myGrid2.Add
        
        #buttons
        addButtonCtrl = wx.Button(panel, -1, "Add")
        Add(addButtonCtrl, (0,0))
       
        deleteButtonCtrl = wx.Button(panel, -1, "Delete")
        Add(deleteButtonCtrl, (0,1), flag = wx.ALIGN_CENTER_HORIZONTAL)
        deleteButtonCtrl.Enable(False)

        discoverButtonCtrl = wx.Button(panel, -1, "Discover")
        Add(discoverButtonCtrl, (0,6), flag = wx.ALIGN_CENTER_HORIZONTAL)
        
        panel.sizer.Add(myGrid2, 0, flag = wx.EXPAND)
        panel.sizer.Add((10,10))
        
        myGrid3 = wx.GridBagSizer(10, 10)
        Add = myGrid3.Add
        
        #Logical Address dropdown
        lAddrTxt = wx.StaticText(panel, 9, "Logical:")
        lAddrCtrl = panel.Choice(lAddr,choiceslAddr)
        Add(lAddrTxt,(0,0))
        Add(lAddrCtrl,(0,1))
        
        #Physical Address dropdowns
        pAddrTxt = wx.StaticText(panel, 10, "Physical:")
        detectCtrl = panel.Choice(detectPA,choicesDetect)
        pAddrCtrl1 = panel.Choice(pAddr1,choicespAddr)
        dotTxt1 = wx.StaticText(panel, 1, ":")
        pAddrCtrl2 = panel.Choice(pAddr2,choicespAddr)
        dotTxt2 = wx.StaticText(panel, 1, ":")
        pAddrCtrl3 = panel.Choice(pAddr3,choicespAddr)
        dotTxt3 = wx.StaticText(panel, 1, ":")
        pAddrCtrl4 = panel.Choice(pAddr4,choicespAddr)
        Add(pAddrTxt,(0,2))
        Add(detectCtrl,(0,3))
        Add(pAddrCtrl1,(0,4))
        Add(dotTxt1,(0,5))
        Add(pAddrCtrl2,(0,6))
        Add(dotTxt2,(0,7))
        Add(pAddrCtrl3,(0,8))
        Add(dotTxt3,(0,9))
        Add(pAddrCtrl4,(0,10))
        
        panel.sizer.Add(myGrid3,0, wx.EXPAND)
        panel.sizer.Add((10,10))
        
        myGrid4 = wx.GridBagSizer(10, 10)
        Add = myGrid4.Add
        
        #Default CEC Name Text
        cecNameTxt = wx.StaticText(panel, 20, "CEC Name:")
        cecNameCtrl = wx.TextCtrl(panel, value=cecName)
        cecNameCtrl.Enable(False)
        Add(cecNameTxt,(0,0))
        Add(cecNameCtrl,(0,1))
        
        #Device Type dropdown
        dTypeTxt = wx.StaticText(panel, 10, "Type:")
        dType=1
        dTypeCtrl = panel.Choice(dType,choicesdType)
        dTypeCtrl.Enable(False)
        Add(dTypeTxt,(0,2))
        Add(dTypeCtrl,(0,3))
        
        #OSD Name Text String
        osdNameTxt = wx.StaticText(panel, 10, "OSD Name:")
        osdNameCtrl = wx.TextCtrl(panel, value=osdName)
        osdNameCtrl.SetMaxLength(20)
        Add(osdNameTxt,(1,0))
        Add(osdNameCtrl,(1,1))
        
        #Vendor ID HEX String
        vendorIDTxt = wx.StaticText(panel, 11, "Vendor ID:")
        vendorIDCtrl = wx.TextCtrl(panel, value=vendorID)
        vendorIDCtrl.SetMaxLength(6)
        Add(vendorIDTxt,(1,2))
        Add(vendorIDCtrl,(1,3))
        
        #Hidden to store mouse and button map and device list as text
        devDetailsCtrl = wx.TextCtrl(panel, value=devDetailsTxt)
        devDetailsCtrl.Hide()
        Add(devDetailsCtrl,(2,0))
        mouseMapCtrl = wx.TextCtrl(panel, value=mouseMapTxt)
        mouseMapCtrl.Hide()
        Add(mouseMapCtrl,(2,1))
        btnMapCtrl = wx.TextCtrl(panel, value=btnMapTxt)
        btnMapCtrl.Hide()
        Add(btnMapCtrl,(2,2))

        panel.sizer.Add(myGrid4,0, wx.EXPAND)
        
        def comCheck(pBarDialog):
            value=False
            status="RCAware PC-CEC Not Found"
            sv=self.syncVolume
            self.syncVolume=0
            try:
                if self.comOn:
                    print "Com was on, stopping."
                    self.stopCom()
                time.sleep(0.5)
                print "Starting Com."
                self.startCom()
                print "Com started..."
                if self.comOn:
                    print "Checking if right device."
                    version=eg.plugins.HdmiCec.WriteRead('!r~','?REV')
                    print "Got version: " + str(version)
                    if version != "TIMEOUT.WAITING.FOR.RESPONSE" and version != "":
                        status="RCAware PC-CEC Version = " + version
                        value=True
            except:
                pass
            self.syncVolume=sv
            pBarDialog.Update(50, status )
            time.sleep(1.0)
            pBarDialog.SetFocus()
            return value
        
        def OnlAddrChange(event):
            cecNameCtrl.SetValue(lAddresses.addr[int(lAddrCtrl.GetStringSelection())])
            event.Skip()
        
        def OnSyncVolumeCtrlChange(event):
            if syncVolumeCtrl.GetValue() == 1:
                if filter(lambda i: i[0] == 5, self.devDetails) == []:
                    self.devDetails = eg.plugins.HdmiCec.UpdDevDetail(self.devDetails,5,filter(lambda i: i[2] == 'Primary', self.devDetails)[0][1], 'Emulated', 'Receiver', filter(lambda i: i[2] == 'Primary', self.devDetails)[0][4], 'True', 'Audio System', filter(lambda i: i[2] == 'Primary', self.devDetails)[0][7])
                    popDevList(self.devDetails)
            else:
                for i, item in enumerate(self.devDetails):
                    if item[0] == 5 and item[2] == 'Emulated':
                        self.devDetails = eg.plugins.HdmiCec.UpdDevDetail(self.devDetails,i)
                        popDevList(self.devDetails)

        def OnBtnPortBtnPress(event):
            btnMapBtn.Enable(False)
            self.portNum = portNumCtrl.GetValue()
            CheckDevice(event, False, panel)
            btnMapBtn.Enable(True)
        
        def OnBtnMapBtnPress(event):
            buBtnMap=copy.deepcopy(self.btnMap)
            bDlg = ButtonMapper(panel,-1,"Remote Button Map")
            bDlg.SetValue(self.btnMap)
            if bDlg.ShowModal() == wx.ID_OK:
                self.btnMap=bDlg.GetValue()
                self.btnMapTxt=str(self.btnMap)
            else:
                self.btnMap=buBtnMap
            bDlg.Destroy()
            event.Skip()
        
        def OnMouseMapBtnPress(event):
            mDlg = MouseMapper(panel,-1,"Mouse Map")
            mDlg.SetValue(self.mouseMap)
            if mDlg.ShowModal() == wx.ID_OK:
                self.mouseMap=mDlg.GetValue()
                self.mouseMapTxt=str(self.mouseMap)
            mDlg.Destroy()
            event.Skip()
        
        def OnScreenBtnPress(event):
            dlg = TextEntryDialog(panel, -1, 'Events To Screen From Log')
            dlg.CentreOnParent()
            dlg.SetValue(self.scrEvents)
            if dlg.ShowModal() == wx.ID_OK:
                self.scrEvents=dlg.GetValue()
            dlg.Destroy()
            event.Skip()
        
        def OnDevListSelect(event):
            try:
                fSel = devList.GetFirstSelected()
                bStat = int(fSel == -1)
                if not bStat:
                    deleteButtonCtrl.Enable(int(devList.GetItem(fSel,3).GetText() == 'Emulated'))
                    bStat = int(devList.GetItem(fSel,3).GetText() != 'Real')
                else:
                    deleteButtonCtrl.Enable(False)
                addButtonCtrl.Enable(bStat)
                lAddrCtrl.Enable(bStat)
                detectCtrl.Enable(bStat)
                pAddrCtrl1.Enable(bStat)
                pAddrCtrl2.Enable(bStat)
                pAddrCtrl3.Enable(bStat)
                pAddrCtrl4.Enable(bStat)
                osdNameCtrl.Enable(bStat)
                vendorIDCtrl.Enable(bStat)
            
                if fSel != -1:
                    lAddrCtrl.SetValue(getChoiceIdx(choiceslAddr,devList.GetItem(fSel,0).GetText()))
                    detectCtrl.SetValue(getChoiceIdx(choicesDetect,devList.GetItem(fSel,7).GetText()))
                    pAddr = devList.GetItem(fSel,2).GetText()
                    pAddrCtrl1.SetValue(getChoiceIdx(choicespAddr,pAddr[0]))
                    pAddrCtrl2.SetValue(getChoiceIdx(choicespAddr,pAddr[2]))
                    pAddrCtrl3.SetValue(getChoiceIdx(choicespAddr,pAddr[4]))
                    pAddrCtrl4.SetValue(getChoiceIdx(choicespAddr,pAddr[6]))
                    dTypeCtrl.SetValue(getChoiceIdx(choicesdType,devList.GetItem(fSel,3).GetText()))
                    cecNameCtrl.SetValue(devList.GetItem(fSel,1).GetText())
                    osdNameCtrl.SetValue(devList.GetItem(fSel,4).GetText())
                    vendorIDCtrl.SetValue(devList.GetItem(fSel,5).GetText())
                    addButtonCtrl.SetLabel('Update')
                else:
                    lAddrCtrl.SetValue(0)
                    detectCtrl.SetValue(0)
                    pAddrCtrl1.SetValue(0)
                    pAddrCtrl2.SetValue(0)
                    pAddrCtrl3.SetValue(0)
                    pAddrCtrl4.SetValue(0)
                    dTypeCtrl.SetValue(1)
                    cecNameCtrl.SetValue('')
                    osdNameCtrl.SetValue('')
                    vendorIDCtrl.SetValue('')
                    addButtonCtrl.SetLabel('Add')
            except:
                pass
            event.Skip()

        def AfterDevListClick(oldSel):
            fSel = devList.GetFirstSelected()
            if fSel == oldSel:
                devList.SetItemState(fSel, 0, wx.LIST_STATE_SELECTED|wx.LIST_STATE_FOCUSED)

        def OnDevListClick(event):
            fSel=devList.GetFirstSelected()
            if fSel != -1:
                wx.CallAfter(AfterDevListClick, fSel)
            event.Skip()

        def OnAddButtonPress(event):
            idx=-1
            lAddr=int(lAddrCtrl.GetStringSelection())
            cecName=lAddresses.addr[lAddr]
            pAddr=choicespAddr[pAddrCtrl1.GetValue()]+'.'+choicespAddr[pAddrCtrl2.GetValue()]+'.'+choicespAddr[pAddrCtrl3.GetValue()]+'.'+choicespAddr[pAddrCtrl4.GetValue()]
            dType=choicesdType[dTypeCtrl.GetValue()]
            osdName=osdNameCtrl.GetValue()
            vendorID=vendorIDCtrl.GetValue()
            pStatus='True'
            detectPA=1
            try:
                detectPA=detectCtrl.GetValue()
            except:
                pass
            if addButtonCtrl.Label == 'Add':
                try:
                    check=filter(lambda i: i[0] == lAddr, self.devDetails)[0]
                    dlg=eg.MessageDialog(panel, 'Logical Address already in use.', caption='Device Config Error', style=wx.OK, pos=wx.Point(-1, -1))
                    dlg.CentreOnParent()
                    dlg.ShowModal()
                    dlg.Destroy()
                    event.Skip()
                    return
                except:
                    pass
                self.devDetails = eg.plugins.HdmiCec.UpdDevDetail(self.devDetails,lAddr,pAddr,dType,osdName,vendorID,pStatus,cecName, detectPA)
            else:
                idx=devList.GetFirstSelected()
                try:
                    if idx != self.devDetails.index(filter(lambda i: i[0] == lAddr, self.devDetails)[0]):
                        dlg=eg.MessageDialog(panel, 'Logical Address already in use.', caption='Device Config Error', style=wx.OK, pos=wx.Point(-1, -1))
                        dlg.CentreOnParent()
                        dlg.ShowModal()
                        dlg.Destroy()
                        event.Skip()
                        return
                except:
                    pass
                curDetails=self.devDetails[:]
                del curDetails[idx]
                newDetails=self.devDetails[:]
                del newDetails[idx]
                newDetails = eg.plugins.HdmiCec.UpdDevDetail(newDetails,lAddr,pAddr,dType,osdName,vendorID,pStatus,cecName,detectPA)
                if newDetails != curDetails:
                    self.devDetails=newDetails
            popDevList(self.devDetails)
            devList.Select(idx)
            event.Skip()

        def OnDeleteButtonPress(event):
            fSel=devList.GetFirstSelected()
            self.devDetails = eg.plugins.HdmiCec.UpdDevDetail(self.devDetails,fSel)
            devList.DeleteItem(fSel)
            devList.SetItemState(fSel, 0, wx.LIST_STATE_SELECTED|wx.LIST_STATE_FOCUSED)
            event.Skip()

        def OnDiscoverButtonPress(event):
            devList.SetItemState(devList.GetFirstSelected(), 0, wx.LIST_STATE_SELECTED|wx.LIST_STATE_FOCUSED)
            self.devDetails = eg.plugins.HdmiCec.GetDevDetails(self.devDetails,True,panel)
            popDevList(self.devDetails)
            if len(filter(lambda i: i[5] == False, self.devDetails)) > 0:
                dlg = wx.MessageDialog(panel, 'Some devices were not online, device info may not be fully populated. You should power all devices online and press "Discover".', 'Device Discovery Warning',  wx.OK)
                dlg.CentreOnParent()
                dlg.ShowModal()
        
        def OnAutoMapKeysChange(event):
            if autoMapKeysCtrl.GetValue() == 1:
                autoMouseCtrl.Enable(True)
                btnMapBtn.Enable(True)
            else:
                autoMouseCtrl.SetValue(0)
                autoMouseCtrl.Enable(False)
                btnMapBtn.Enable(False)
                mouseMapBtn.Enable(False)
            event.Skip()
        
        def OnAutoMouseChange(event):
            if autoMouseCtrl.GetValue() == 1:
                mouseMapBtn.Enable(True)
            else:
                mouseMapBtn.Enable(False)
            event.Skip()
        
        def CheckDevice(event, firstCall=False, pBarParent=None):
            bStat=False
            if self.firstLoad or not firstCall:
                print 'Communications Check', 'Looking for RCAware PC-CEC...'
                pBarDialog = wx.ProgressDialog ( 'Communications Check', 'Looking for RCAware PC-CEC...', maximum = 100, parent=pBarParent )
                pBarDialog.CentreOnParent()
                pBarDialog.Update (10, 'Looking for RCAware PC-CEC...')
                pBarDialog.SetFocus ()
                try:
                    bStat=comCheck(pBarDialog)
                except:
                    pass
                pBarDialog.Update (100, 'Done.' )
                pBarDialog.SetFocus ()
                pBarDialog.Destroy()
            else:
                bStat=True
            panel.EnableButtons(bStat)
            discoverButtonCtrl.Enable(bStat)
            if self.firstLoad:
                if bStat:
                    eg.plugins.HdmiCec.SetLogicalAddress(self.primary[0])
                    OnDiscoverButtonPress(wx.CommandEvent())
                    try:
                        tvVendorID = filter(lambda i: i[0] == 0, self.devDetails)[0][4]
                    except:
                        try:
                            tvVendorID = filter(lambda i: i[2] == 'Real', self.devDetails)[0][4]
                        except:
                            tvVendorID = self.primary[4]
                    # Workaround for Panasonic, because that vendor ID as primary or receiver causes issues
                    if tvVendorID == '008045':
                        tvVendorID = '000000'
                    dPA=1
                    if self.detectedPhysAddr == None:
                        dPA=0
                        self.detectedPhysAddr = '1.0.0.0'
                        self.primary = [self.primary[0], self.detectedPhysAddr, 'Primary', self.primary[3], tvVendorID, 'True', self.primary[6], dPA]
                        self.devDetails=filter(lambda i: i[2] != 'Primary', self.devDetails)
                        self.devDetails.append(self.primary)
                        self.devDetails=sorted(self.devDetails, key=lambda item: item[0])
                        popDevList(self.devDetails)
                        dlg=eg.MessageDialog(panel, 'Unable to detect Physical Address of Primary Media Center, you must set manually.', caption='Physical Address Error', style=wx.OK, pos=wx.Point(-1, -1))
                        dlg.CentreOnParent()
                        dlg.ShowModal()
                        dlg.Destroy()
                    else:
                        self.primary = [self.primary[0], self.detectedPhysAddr, 'Primary', self.primary[3], tvVendorID, 'True', self.primary[6], dPA]
                        self.devDetails=filter(lambda i: i[2] != 'Primary', self.devDetails)
                        self.devDetails.append(self.primary)
                        self.devDetails=sorted(self.devDetails, key=lambda item: item[0])
                        popDevList(self.devDetails)

        lAddrCtrl.Bind(wx.EVT_CHOICE, OnlAddrChange)
        syncVolumeCtrl.Bind(wx.EVT_CHOICE, OnSyncVolumeCtrlChange)
        autoMapKeysCtrl.Bind(wx.EVT_CHOICE, OnAutoMapKeysChange)
        autoMouseCtrl.Bind(wx.EVT_CHOICE, OnAutoMouseChange)
        btnPortBtn.Bind(wx.EVT_BUTTON, OnBtnPortBtnPress)
        btnMapBtn.Bind(wx.EVT_BUTTON, OnBtnMapBtnPress)
        mouseMapBtn.Bind(wx.EVT_BUTTON, OnMouseMapBtnPress)
        screenBtn.Bind(wx.EVT_BUTTON, OnScreenBtnPress)
        addButtonCtrl.Bind(wx.EVT_BUTTON, OnAddButtonPress)
        deleteButtonCtrl.Bind(wx.EVT_BUTTON, OnDeleteButtonPress)
        discoverButtonCtrl.Bind(wx.EVT_BUTTON, OnDiscoverButtonPress)
        devList.Bind(wx.EVT_LIST_ITEM_SELECTED, OnDevListSelect)
        devList.Bind(wx.EVT_LIST_ITEM_DESELECTED, OnDevListSelect)
        devList.Bind(wx.EVT_LEFT_DOWN, OnDevListClick)
        OnAutoMapKeysChange(wx.CommandEvent())
        OnAutoMouseChange(wx.CommandEvent())
        wx.CallAfter(CheckDevice, wx.CommandEvent(), True, panel)

        while panel.Affirmed():
            devDetailsTxt=str(self.devDetails)
            devDetailsCtrl.SetValue(devDetailsTxt)
            mouseMapTxt=str(self.mouseMap)
            mouseMapCtrl.SetValue(mouseMapTxt)
            btnMapTxt=str(self.btnMap)
            btnMapCtrl.SetValue(btnMapTxt)
            panel.SetResult(
                portNumCtrl.GetValue(),
                syncVolumeCtrl.GetValue(),
                autoMapKeysCtrl.GetValue(),
                autoMouseCtrl.GetValue(),
                devDetailsCtrl.GetValue(),
                mouseMapCtrl.GetValue(),
                btnMapCtrl.GetValue(),
                self.scrEvents,
                False
            )
            if self.firstLoad:
                try:
                    xmlFile = open(os.path.join(self.pluginDir, "macros.xml"), "r")
                    xmlString = xmlFile.read()
                    xmlFile.close()
                    wx.TheClipboard.Open()
                    wx.TheClipboard.SetData(wx.TextDataObject(xmlString))
                    wx.TheClipboard.Close()
                    eg.document.selection = eg.document.selection.parent
                    eg.UndoHandler.Paste(eg.document).Do(eg.document.selection)
                except:
                    pass

    def longKeyPress(self, gEvent, kStroke):
        self.lkTimer.cancel()
        self.btnMap[self.activeBtnMap]["45"]=["Button Released",gEvent, kStroke, 0, None]

    def longLeftClick(self, gEvent):
        self.llcTimer.cancel()
        self.mouseMap["45"]=["Button Released", gEvent, 'draglock', 0, 0]

    def volSync(self):
        try:
            eval('self.volSync_' + str(self.syncVolume) +'()')
        except:
            pass
    
    # LG volume sync
    def volSync_2(self):
        result=""
        self.volSyncTimer.cancel()
        try:
            vol=round(eg.plugins.System.SetMasterVolume(200.0,0)/2,0)
            mute=eg.plugins.System.GetMute()
            if self.volSyncType=="PC":
                if self.lastVol != vol or self.lastMute != mute:
                    result=eg.plugins.HdmiCec.WriteRead('!x5 89 09~','89.0A')
                    if result.split('.')[0] != "89" or result.split('.')[1] != '0A':
                        if self.syncVolume >= 2:
                            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
                            self.volSyncTimer.start()
                        return
                    status=int(result.split('.')[2], 16)
                    if status > 40:
                        ampmute=True
                        ampvol=status-41
                    else:
                        ampmute=False
                        ampvol=status
                    if self.lastVol != vol and vol != ampvol:
                        diff=vol-ampvol
                        while diff > 0:
                            eg.plugins.HdmiCec.Write('!x5 44 41~')
                            diff=diff-1
                        while diff < 0:
                            eg.plugins.HdmiCec.Write('!x5 44 42~')
                            diff=diff+1
                        #eg.plugins.HdmiCec.Write('!x5 45~')
                    if mute != ampmute and self.lastVol == vol:
                        eg.plugins.HdmiCec.Write('!x5 44 43~')
                    self.lastVol=vol
                    self.lastMute=mute
            elif self.volSyncType=="AMP":
                result=eg.plugins.HdmiCec.WriteRead('!x5 89 09~','89.0A')
                if result.split('.')[0] != "89" or result.split('.')[1] != '0A':
                    if self.syncVolume >= 2:
                        self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
                        self.volSyncTimer.start()
                    return
                self.volSyncType="PC"
                status=int(result.split('.')[2], 16)
                if status > 40:
                    ampmute=True
                    ampvol=status-41
                else:
                    ampmute=False
                    ampvol=status
                if vol != ampvol:
                    eg.plugins.System.SetMasterVolume(ampvol*2,0)
                    self.lastVol=ampvol
                if (ampvol == 0 and not ampmute):
                    eg.plugins.HdmiCec.Write('!x5 44 43~')
                    ampmute=True
                if ampmute or ampvol==0:
                    eg.plugins.System.MuteOn(0)
                    self.lastMute=True
                else:
                    eg.plugins.System.MuteOff(0)
                    self.lastMute=False
        except:
            pass
        self.volSyncType="PC"
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()

    # Samsung volume sync
    def volSync_3(self):
        result=""
        self.volSyncTimer.cancel()
        try:
            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
            mute=eg.plugins.System.GetMute()
            if self.volSyncType=="PC":
                if self.lastVol != vol or self.lastMute != mute:
                    result=eg.plugins.HdmiCec.WriteRead('!x5 71~','7A')
                    if result.split('.')[0] != "7A":
                        if self.syncVolume >= 2:
                            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
                            self.volSyncTimer.start()
                        return
                    status=bin(int(result.split('.')[1], 16))[2:].zfill(7)
                    if int(status[0]) == 1:
                        ampmute=True
                    else:
                        ampmute=False
                    ampvol=int(status[1:],2)
                    if self.lastVol != vol and vol != ampvol:
                        diff=vol-ampvol
                        while diff > 0:
                            eg.plugins.HdmiCec.Write('!x5 44 41~')
                            diff=diff-1
                        while diff < 0:
                            eg.plugins.HdmiCec.Write('!x5 44 42~')
                            diff=diff+1
                        eg.plugins.HdmiCec.Write('!x5 45~')
                    if mute != ampmute and self.lastVol == vol:
                        eg.plugins.HdmiCec.Write('!x5 44 43~x5 45~')
                    self.lastVol=vol
                    self.lastMute=mute
            elif self.volSyncType=="AMP":
                result=eg.plugins.HdmiCec.WriteRead('!x5 71~','7A')
                if result.split('.')[0] != "7A":
                    if self.syncVolume >= 2:
                        self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
                        self.volSyncTimer.start()
                    return
                self.volSyncType="PC"
                status=bin(int(result.split('.')[1], 16))[2:].zfill(7)
                if int(status[0]) == 1:
                    ampmute=True
                else:
                    ampmute=False
                ampvol=int(status[1:],2)
                if vol != ampvol:
                    eg.plugins.System.SetMasterVolume(ampvol*2,0)
                    self.lastVol=ampvol
                if (ampvol == 0 and not ampmute):
                    eg.plugins.HdmiCec.Write('!x5 44 43~x5 45~')
                    ampmute=True
                if ampmute or ampvol==0:
                    eg.plugins.System.MuteOn(0)
                    self.lastMute=True
                else:
                    eg.plugins.System.MuteOff(0)
                    self.lastMute=False
        except:
            pass
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()

    # Sony volume sync
    def volSync_4(self):
        result=""
        self.volSyncTimer.cancel()
        try:
            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
            if vol == 1 or vol == 2:
                vol=2
            elif vol <= 50:
                vol=(round(vol/3.0)*3)-1
            elif vol > 50 and vol < 100:
                vol=(round(vol/3.0)*3)+1
            mute=eg.plugins.System.GetMute()
            if self.volSyncType=="PC":
                if self.lastVol != vol or self.lastMute != mute:
                    result=eg.plugins.HdmiCec.WriteRead('!x5 71~','7A')
                    if result.split('.')[0] != "7A":
                        if self.syncVolume >= 2:
                            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
                            self.volSyncTimer.start()
                        return
                    status=int(result.split('.')[1], 16)
                    if status > 128:
                        ampmute=True
                        ampvol=status-128
                    else:
                        ampmute=False
                        ampvol=status
                    if self.lastVol != vol and vol != ampvol:
                        diff=vol-ampvol
                        while diff > 0:
                            trash=eg.plugins.HdmiCec.WriteRead('!x5 44 41~','7A')
                            diff=diff-3
                            if diff < 0:
                                diff = 0
                        while diff < 0:
                            trash=eg.plugins.HdmiCec.WriteRead('!x5 44 42~','7A')
                            diff=diff+3
                    if mute != ampmute and self.lastVol == vol:
                        trash=eg.plugins.HdmiCec.Write('!x5 44 43~','7A')
                    self.lastVol=vol
                    self.lastMute=mute
            elif self.volSyncType=="AMP":
                result=eg.plugins.HdmiCec.WriteRead('!x5 71~','7A')
                if result.split('.')[0] != "7A":
                    if self.syncVolume >= 2:
                        self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
                        self.volSyncTimer.start()
                    return
                self.volSyncType="PC"
                status=int(result.split('.')[1], 16)
                if status > 128:
                    ampmute=True
                    ampvol=status-128
                else:
                    ampmute=False
                    ampvol=status
                if vol != ampvol:
                    eg.plugins.System.SetMasterVolume(ampvol,0)
                    self.lastVol=ampvol
                if (ampvol == 0 and not ampmute):
                    trash=eg.plugins.HdmiCec.WriteRead('!x5 44 43~','7A')
                    ampmute=True
                if ampmute or ampvol==0:
                    eg.plugins.System.MuteOn(0)
                    self.lastMute=True
                else:
                    eg.plugins.System.MuteOff(0)
                    self.lastMute=False
        except:
            pass
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()

    # Panasonic volume sync
    def volSync_5(self):
        result=""
        self.volSyncTimer.cancel()
        try:
            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
            mute=eg.plugins.System.GetMute()
            if self.volSyncType=="PC":
                if self.lastVol != vol or self.lastMute != mute:
                    if mute:
                        eg.plugins.HdmiCec.Write('!x5 89 10 75 ' + hex(int(vol)+129)[2:] + '~')
                        eg.plugins.HdmiCec.Write('!x0 89 10 74 64 ' + hex(int(vol)+129)[2:] + '~')
                    else:
                        eg.plugins.HdmiCec.Write('!x5 89 10 75 ' + hex(int(vol)+1)[2:] + '~')
                        eg.plugins.HdmiCec.Write('!x0 89 10 74 64 ' + hex(int(vol)+1)[2:] + '~')
                    self.lastVol=vol
                    self.lastMute=mute
            elif self.volSyncType=="AMP":
                if vol != self.lastVol:
                    eg.plugins.System.SetMasterVolume(self.lastVol,0)
                if self.lastMute or self.lastVol==0:
                    eg.plugins.System.MuteOn(0)
                else:
                    eg.plugins.System.MuteOff(0)
        except:
            pass
        self.volSyncType="PC"
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()


    # Philips volume sync
    def volSync_6(self):
        result=""
        self.volSyncTimer.cancel()
        try:
            if self.volSyncType=="PC":
                lastVol=self.lastVol
                vol=round(eg.plugins.System.SetMasterVolume(200.0,0)/2,0)
                mute=eg.plugins.System.GetMute()
                diff=vol-self.lastVol
                if diff > 0 and self.lastVol < 50:
                    eg.plugins.HdmiCec.Write('!x5 44 41~x5 45~')
                    self.lastVol=self.lastVol+1
                    diff=diff-1
                if diff < 0 and self.lastVol > 0:
                    eg.plugins.HdmiCec.Write('!x5 44 42~x5 45~')
                    self.lastVol=self.lastVol-1
                    diff=diff+1
                if (mute <> self.lastMute and lastVol == vol) or (vol == 0 and vol < lastVol and diff == 0):
                    eg.plugins.HdmiCec.Write('!x5 44 43~x5 45~')
                self.lastMute=mute
        except:
            pass
        self.volSyncType="PC"
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()


    # Sharp volume sync
    def volSync_7(self):
        def checkVol():
            status=None
            result=""
            ampmute=False
            while result <> 'TIMEOUT.WAITING.FOR.RESPONSE':
                try:
                    eg.plugins.HdmiCec.SuspendSerialRead()
                    result=eg.plugins.HdmiCec.Read('7A','',.25)
                except:
                    pass
                eg.plugins.HdmiCec.ResumeSerialRead()
                if result.split('.')[0] == "7A":
                    status=int(result.split('.')[1], 16)
            while status == None:
                result=eg.plugins.HdmiCec.WriteRead('!x5 71~','7A','',1.0)
                if result.split('.')[0] == "7A":
                    status=int(result.split('.')[1], 16)
            if status >= 128:
                self.lastVol=status-128
            else:
                self.lastVol=status
            
        def checkMute():
            status=None
            while status == None:
                result=eg.plugins.HdmiCec.WriteRead('!x5 71~','7A')
                if result.split('.')[0] == "7A":
                    status=int(result.split('.')[1], 16)
            if status in (0,1) or status >= 128:
                return True
            else:
                return False

        result=""
        self.volSyncTimer.cancel()
        try:
            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
            if self.volSyncType=="PC":
                while abs(self.lastVol-vol) > 0:
                    while vol - self.lastVol > 0:
                        diff=vol - self.lastVol
                        while diff > 4:
                            eg.plugins.HdmiCec.Write('!x5 44 41~x5 44 41~')
                            checkVol()
                            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                            diff=vol - self.lastVol
                        eg.plugins.HdmiCec.Write('!x5 45~')
                        checkVol()
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        diff=vol - self.lastVol
                        while diff > 0:
                            eg.plugins.HdmiCec.Write('x5 44 41~x5 45~')
                            checkVol()
                            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                            diff=vol - self.lastVol
                    while self.lastVol - vol > 0:
                        diff=self.lastVol-vol
                        while diff > 4:
                            eg.plugins.HdmiCec.Write('!x5 44 42~x5 44 42~')
                            checkVol()
                            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                            diff=self.lastVol - vol
                        eg.plugins.HdmiCec.Write('!x5 45~')
                        checkVol()
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        diff=self.lastVol - vol
                        while diff > 0:
                            eg.plugins.HdmiCec.Write('x5 44 42~x5 45~')
                            checkVol()
                            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                            diff=self.lastVol - vol
                mute=eg.plugins.System.GetMute()
                if (mute <> self.lastMute and mute <> checkMute()):
                    result=eg.plugins.HdmiCec.Write('!x5 44 43~')
                    self.lastMute=mute
            elif self.volSyncType=="AMP":
                mute=eg.plugins.System.GetMute()
                if vol != self.lastVol:
                    eg.plugins.System.SetMasterVolume(self.lastVol,0)
                if self.lastMute or self.lastVol==0:
                    eg.plugins.System.MuteOn(0)
                else:
                    eg.plugins.System.MuteOff(0)
                try:
                    status=int(self.lastVol)
                    if self.lastMute:
                        status=int(self.lastVol)+128
                        eg.plugins.HdmiCec.SetLogicalAddress(5)
                        eg.plugins.HdmiCec.Write('!x0 7A '+hex(status)[2:].upper())
                        eg.plugins.HdmiCec.SetLogicalAddress(self.primary[0])
                except:
                    pass

        except:
            pass
        self.volSyncType="PC"
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()


    # Yamaha volume sync
    def volSync_8(self):
        def checkVol():
            status=None
            result=""
            eg.plugins.HdmiCec.SuspendSerialRead()
            try:
                result=eg.plugins.HdmiCec.Read('7A','',.25)
                while result == 'TIMEOUT.WAITING.FOR.RESPONSE':
                    eg.plugins.HdmiCec.Write('x5 71~')
                    result=eg.plugins.HdmiCec.Read('7A','',.25)
                if result.split('.')[0] == "7A":
                    status=int(result.split('.')[1], 16)
            except:
                pass
            eg.plugins.HdmiCec.ResumeSerialRead()
            if status >= 128:
                self.lastVol=status-128
            else:
                self.lastVol=status
            
        def checkMute():
            status=None
            while status == None:
                result=eg.plugins.HdmiCec.WriteRead('!x5 71~','7A')
                if result.split('.')[0] == "7A":
                    status=int(result.split('.')[1], 16)
            if status == 0 or status >= 128:
                return True
            else:
                return False

        result=""
        self.volSyncTimer.cancel()
        try:
            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
            if self.volSyncType=="PC":
                while abs(self.lastVol-vol) >= 1:
                    startdiff=diff=vol - self.lastVol
                    df=diff
                    stopper=False
                    while diff >= 4:
                        cec='!x5 44 41~'
                        while df >= 25:
                            cec=cec+'x5 44 41~'
                            df=df/3
                        eg.plugins.HdmiCec.Write(cec)
                        if diff/startdiff <= .5:
                            stopper=True
                            break
                        time.sleep(max(min(1.5/diff,.1),.00001))
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=vol - self.lastVol
                        startdiff=max(startdiff,diff)
                        df=diff
                        stopper=True
                    if stopper:
                        eg.plugins.HdmiCec.Write('!x5 45~')
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=vol - self.lastVol
                        stopper=False 
                    while diff >= 1 and diff <= 4:
                        eg.plugins.HdmiCec.Write('!x5 44 41~x5 45~')
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=vol - self.lastVol
                    startdiff=diff=self.lastVol-vol
                    df=diff
                    while diff >= 4:
                        cec='!x5 44 42~'
                        while df >= 25:
                            cec=cec+'x5 44 42~'
                            df=df/3
                        eg.plugins.HdmiCec.Write(cec)
                        if diff/startdiff <= .5:
                            stopper=True
                            break
                        time.sleep(max(min(1.5/diff,.1),.00001))
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=self.lastVol-vol
                        startdiff=max(startdiff,diff)
                        df=diff
                        stopper=True
                    if stopper:
                        eg.plugins.HdmiCec.Write('!x5 45~')
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=self.lastVol-vol
                        stopper=False 
                    while diff >= 1 and diff <= 4:
                        eg.plugins.HdmiCec.Write('!x5 44 42~x5 45~')
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=self.lastVol-vol

                mute=eg.plugins.System.GetMute()
                if (mute <> self.lastMute and mute <> checkMute()):
                    result=eg.plugins.HdmiCec.Write('!x5 44 43~')
                    self.lastMute=mute
            elif self.volSyncType=="AMP":
                if vol != self.lastVol:
                    eg.plugins.System.SetMasterVolume(self.lastVol,0)
                if self.lastMute or self.lastVol==0:
                    eg.plugins.System.MuteOn(0)
                else:
                    eg.plugins.System.MuteOff(0)
        except:
            pass
        self.volSyncType="PC"
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()


    # Generic volume sync
    def volSync_9(self):
        def checkVol():
            status=None
            result=""
            eg.plugins.HdmiCec.SuspendSerialRead()
            try:
                result=eg.plugins.HdmiCec.Read('7A','',.25)
                while result == 'TIMEOUT.WAITING.FOR.RESPONSE':
                    eg.plugins.HdmiCec.Write('x5 71~')
                    result=eg.plugins.HdmiCec.Read('7A','',.25)
                if result.split('.')[0] == "7A":
                    status=int(result.split('.')[1], 16)
            except:
                pass
            eg.plugins.HdmiCec.ResumeSerialRead()
            if status >= 128:
                self.lastVol=status-128
            else:
                self.lastVol=status
            
        def checkMute():
            status=None
            while status == None:
                result=eg.plugins.HdmiCec.WriteRead('!x5 71~','7A')
                if result.split('.')[0] == "7A":
                    status=int(result.split('.')[1], 16)
            if status == 0 or status >= 128:
                return True
            else:
                return False

        result=""
        self.volSyncTimer.cancel()
        try:
            vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
            if self.volSyncType=="PC":
                while abs(self.lastVol-vol) >= 1:
                    startdiff=diff=vol - self.lastVol
                    df=diff
                    stopper=False
                    while diff >= 4:
                        cec='!x5 44 41~'
                        while df >= 25:
                            cec=cec+'x5 44 41~'
                            df=df/3
                        eg.plugins.HdmiCec.Write(cec)
                        if diff/startdiff <= .5:
                            stopper=True
                            break
                        time.sleep(max(min(1.5/diff,.1),.00001))
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=vol - self.lastVol
                        startdiff=max(startdiff,diff)
                        df=diff
                        stopper=True
                    if stopper:
                        eg.plugins.HdmiCec.Write('!x5 45~')
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=vol - self.lastVol
                        stopper=False 
                    while diff >= 1 and diff <= 4:
                        eg.plugins.HdmiCec.Write('!x5 44 41~x5 45~')
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=vol - self.lastVol
                    startdiff=diff=self.lastVol-vol
                    df=diff
                    while diff >= 4:
                        cec='!x5 44 42~'
                        while df >= 25:
                            cec=cec+'x5 44 42~'
                            df=df/3
                        eg.plugins.HdmiCec.Write(cec)
                        if diff/startdiff <= .5:
                            stopper=True
                            break
                        time.sleep(max(min(1.5/diff,.1),.00001))
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=self.lastVol-vol
                        startdiff=max(startdiff,diff)
                        df=diff
                        stopper=True
                    if stopper:
                        eg.plugins.HdmiCec.Write('!x5 45~')
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=self.lastVol-vol
                        stopper=False 
                    while diff >= 1 and diff <= 4:
                        eg.plugins.HdmiCec.Write('!x5 44 42~x5 45~')
                        vol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
                        checkVol()
                        diff=self.lastVol-vol

                mute=eg.plugins.System.GetMute()
                if (mute <> self.lastMute and mute <> checkMute()):
                    result=eg.plugins.HdmiCec.Write('!x5 44 43~')
                    self.lastMute=mute
            elif self.volSyncType=="AMP":
                if vol != self.lastVol:
                    eg.plugins.System.SetMasterVolume(self.lastVol,0)
                if self.lastMute or self.lastVol==0:
                    eg.plugins.System.MuteOn(0)
                else:
                    eg.plugins.System.MuteOff(0)
        except:
            pass
        self.volSyncType="PC"
        if self.syncVolume >= 2:
            self.volSyncTimer = threading.Timer(self.volSyncInt, self.volSync)
            self.volSyncTimer.start()


    def initAmp(self):
        counter=0
        while counter <= 60:
            eg.plugins.HdmiCec.Write('x5 44 42~x5 45~')
            time.sleep(self.volSyncInt)
            counter=counter+1

        counter=0
        while counter < self.lastVol:
            eg.plugins.HdmiCec.Write('x5 44 41~x5 45~')
            time.sleep(self.volSyncInt)
            counter=counter+1

        if self.lastMute:
            eg.plugins.HdmiCec.Write('x5 44 43~x5 45~')


    def emulateAmp(self,volChange):
        lastVol=0
        self.volSyncType="AMP"
        if volChange == 0:
            eg.plugins.System.ToggleMute()
        else:
            eg.plugins.System.ChangeMasterVolumeBy(volChange)
        lastVol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
        if self.syncVolume in (2,6):
            self.lastVol=round(eg.plugins.System.SetMasterVolume(200.0,0)/2,0)
        else:
            self.lastVol=round(eg.plugins.System.SetMasterVolume(200.0,0),0)
        self.lastMute=eg.plugins.System.GetMute()
        if self.syncVolume == 1:
            try:
                status=int(lastVol)
                if self.lastMute:
                    status=int(lastVol)+128
                eg.plugins.HdmiCec.Write('!x0 7A '+hex(status)[2:].upper()+'~')
            except:
                pass
        self.volSyncType="PC"

    def OnReceive(self, rBuffer):
        try:
            lBuffer = ''.join([s if s not in '\r\n' else '~' for s in self.backbuffer + rBuffer]).split('~')
            self.backbuffer=''
            for buffer in lBuffer:
                if buffer == "":
                    continue
                processed=False
                genEvent=True
                longTimeout=0
                fromMe=False
                parts = buffer.split(' ')
                
                if len(parts) > 2 and parts[0] == '?REC':
                    fromDev=parts[1][0]
                    toDev=parts[1][1]
                    dPhysAddr=None
                    dName=None
                    
                    if self.suppressFromMe:
                        try:
                            tst = filter(lambda i: i[0] == int(fromDev) and i[2] != 'Real', self.devDetails)[0]
                            fromMe=True
                        except:
                            pass
                
                #This is for stuff we don't want
                if len(parts) < 3 or parts[0] != '?REC' or fromMe:
                    buffer=""
                    continue
                #This is for pings
                elif len(parts) == 3:
                    if parts[2]=='1':
                        cecCode='1.01'
                    else:
                        cecCode='1.02'
                #These two are for stuff we want with different number of codes
                elif len(parts) == 4:
                    cecCode=parts[2]
                else:
                    cecCode='.'.join(parts[2:-1])
                
                toMe=False
                try:
                    dc = filter(lambda i: i[0] == int(toDev) and i[2] != 'Real', self.devDetails)[0]
                    toMe=True
                except:
                    pass
                
                if self.syncVolume not in (0,1,6):
                    # Skip certain volume messages
                    try:
                        if cecCode[0:5] == '89.0A' or cecCode[0:8] == '89.10.74':
                            buffer=""
                            continue
                    except:
                        pass
                    try:
                        mp = self.volMap.button[cecCode[:2]]
                        genEvent=mp[1]
                        if self.syncVolume in (7,8,9):
                            thisVol=int(cecCode[3:5],16)
                            if thisVol > 128:
                                self.lastMute=True
                                self.lastVol=int(thisVol-128)
                            else:
                                self.lastMute=False
                                self.lastVol=int(thisVol)
                        self.volSyncType="AMP"
                        processed=True
                    except:
                        pass
                    try:
                        mp = self.volMap.button[cecCode[:8]]
                        genEvent=mp[1]
                        if self.syncVolume == 5:
                            thisVol=int(cecCode[9:11],16)
                            if thisVol > 128:
                                self.lastMute=True
                                self.lastVol=int(thisVol-128)
                            else:
                                self.lastMute=False
                                self.lastVol=int(thisVol)
                        self.volSyncType="AMP"
                        processed=True
                    except:
                        pass
                elif self.syncVolume <> 0:
                    try:
                        mp = self.volMap.button[cecCode[:8]]
                        self.volSyncType="AMP"
                        genEvent=mp[1]
                        self.emulateAmp(mp[2])
                        processed=True
                        self.volSyncType="PC"
                    except:
                        pass

                if toMe and not processed and self.autoMouse:
                    try:
                        mp = self.mouseMap[cecCode]
                        btnName=mp[0]
                        genEvent=mp[1]
                        btnType=mp[2]
                        param1=mp[3]
                        param2=mp[4]
                        if btnType == "toggle":
                            self.toggleMouse = not self.toggleMouse
                            processed=True
                        elif self.toggleMouse:
                            if btnType == "leftclick":
                                self.mouseMap["45"]=["Button Released", genEvent, 'click', 0, 0]
                                self.llcTimer.cancel()
                                self.llcTimer = threading.Timer(0.65, self.longLeftClick, [genEvent])
                                self.llcTimer.start()
                                processed=True
                            elif btnType == "click":
                                self.llcTimer.cancel()
                                self.mouseMap["45"]=["Button Released", False, None, 0, 0]
                                if eg.Utils.time.time()-self.lastLeftClick > 0.65:
                                    eg.plugins.Mouse.LeftButton()
                                    self.lastLeftClick=eg.Utils.time.time()
                                else:
                                    eg.plugins.Mouse.LeftDoubleClick()
                                processed=True
                            elif btnType == "draglock":
                                self.mouseMap["45"]=["Button Released", False, None, 0, 0]
                                eg.plugins.Mouse.ToggleLeftButton()
                                processed=True
                            elif btnType == "rightclick":
                                eg.plugins.Mouse.RightButton()
                                processed=True
                            elif btnType == "moveabsolute":
                                eg.plugins.Mouse.MoveAbsolute(param1,param2)
                                processed=True
                            elif btnType == "moverelative":
                                now=eg.Utils.time.time()
                                if param1 == 0:
                                    self.mlSize=0
                                    self.mlTime=now-1
                                    self.mrSize=0
                                    self.mrTime=now-1
                                elif param1 > 0:
                                    self.mlSize=0
                                    self.mlTime=now-1
                                    if now-self.mrTime < self.volSyncInt and self.mrSize <= param1*5:
                                        self.mrSize=int(self.mrSize+(param1*5 * round(now-self.mrTime,2)))
                                    elif now-self.mrTime >= self.volSyncInt and  self.mrSize > param1:
                                        self.mrSize=int(self.mrSize-(param1*10 * round(now-self.mrTime,2)))
                                    if self.mrSize > param1*5:
                                        self.mrSize = param1*5
                                    elif self.mrSize < param1:
                                        self.mrSize = param1
                                    param1=self.mrSize
                                    self.mrTime=now
                                elif param1 < 0:
                                    param1=abs(param1)
                                    self.mrSize=0
                                    self.mrTime=now
                                    if now-self.mlTime < self.volSyncInt and self.mlSize <= param1*5:
                                        self.mlSize=int(self.mlSize+(param1*5 * round(now-self.mlTime,2)))
                                    elif now-self.mlTime >= self.volSyncInt and  self.mlSize > param1:
                                        self.mlSize=int(self.mlSize-(param1*10 * round(now-self.mlTime,2)))
                                    if self.mlSize > param1*5:
                                        self.mlSize = param1*5
                                    elif self.mlSize < param1:
                                        self.mlSize = param1
                                    param1=(-1*self.mlSize)
                                    self.mlTime=now
                                if param2 == 0:
                                    self.muSize=0
                                    self.muTime=now-1
                                    self.mdSize=0
                                    self.mdTime=now-1
                                elif param2 > 0:
                                    self.mdSize=0
                                    self.mdTime=now
                                    if now-self.muTime < self.volSyncInt and self.muSize <= param2*5:
                                        self.muSize=int(self.muSize+(param2*5 * round(now-self.muTime,2)))
                                    elif now-self.muTime >= self.volSyncInt and  self.muSize > param2:
                                        self.muSize=int(self.muSize-(param2*10 * round(now-self.muTime,2)))
                                    if self.muSize > param2*5:
                                        self.muSize = param2*5
                                    elif self.muSize < param2:
                                        self.muSize = param2
                                    param2=self.muSize
                                    self.muTime=now
                                elif param2 < 0:
                                    param2=abs(param2)
                                    self.muSize=0
                                    self.muTime=now
                                    if now-self.mdTime < self.volSyncInt and self.mdSize <= param2*5:
                                        self.mdSize=int(self.mdSize+(param2*5 * round(now-self.mdTime,2)))
                                    elif now-self.mdTime >= self.volSyncInt and  self.mdSize > param2:
                                        self.mdSize=int(self.mdSize-(param2*10 * round(now-self.mdTime,2)))
                                    if self.mdSize > param2*5:
                                        self.mdSize = param2*5
                                    elif self.mdSize < param2:
                                        self.mdSize = param2
                                    param2=(-1*self.mdSize)
                                    self.mdTime=now
                                eg.plugins.Mouse.MoveRelative(param1, param2)
                                processed=True
                    except:
                        pass
                
                if toMe and not processed and self.autoMapKeys:
                    try:
                        mp = self.btnMap[self.activeBtnMap][cecCode]
                        btnName=mp[0]
                        genEvent=mp[1]
                        keyStroke=mp[2]
                        longTimeout=mp[3]
                        longKeyStroke=mp[4]
                        if longTimeout > 0:
                            self.btnMap[self.activeBtnMap]["45"]=["Button Released",genEvent, keyStroke, 0, None]
                            self.lkTimer.cancel()
                            self.lkTimer = threading.Timer(longTimeout, self.longKeyPress, [genEvent, longKeyStroke])
                            self.lkTimer.start()
                        else:
                            if cecCode == "45":
                                self.btnMap[self.activeBtnMap]["45"]=["Button Released",False, None, 0, None]
                                self.lkTimer.cancel()
                            eg.plugins.Window.SendKeys(keyStroke, False)
                    except:
                        pass
                
                if genEvent:
                    niceCode=""
                    niceTo=""
                    niceFrom=""
                    opts=''
                    for i, c in enumerate(cecCode.split('.')):
                        if i == 0:
                            try:
                                niceCode=niceCode+self.cmdMap.cmd[c][1]
                                if c== '70' or c== '81'  or c== '82'  or c== '86'  or c== '9D':
                                    try:
                                        niceCode=niceCode+'.'+filter(lambda i: i[1] == cecCode[3]+'.'+cecCode[4]+'.'+cecCode[6]+'.'+cecCode[7], self.devDetails)[0][3]
                                        break
                                    except:
                                        pass
                                opts=self.cmdMap.cmd[c][2]
                            except:
                                niceCode=cecCode
                                break
                                pass
                        else:
                            try:
                                niceCode=niceCode+'.'+self.cmdMap.opt[opts[i-1]][c]
                            except:
                                niceCode=niceCode+'.'+c
                                pass
                    if toDev=='F':
                        niceTo='Broadcast'
                    else:
                        try:
                            niceTo=filter(lambda i: i[0] == int(toDev), self.devDetails)[0][3]
                        except:
                            niceTo=toDev
                            pass
                    if fromDev=='F':
                        niceFrom='Unregistered'
                    else:
                        try:
                            niceFrom=filter(lambda i: i[0] == int(fromDev), self.devDetails)[0][3]
                        except:
                            niceFrom=fromDev
                            pass
                    #Only run if not in screen list
                    if 'HdmiCec.' + niceTo  + '.' + niceCode + " '" + niceFrom + "'" not in self.screenEvents:
                        if longTimeout > 0:
                            self.TriggerEnduringEvent(niceTo  + '.' + niceCode, payload=niceFrom)
                        else:
                            self.TriggerEvent(niceTo  + '.' + niceCode, payload=niceFrom)
                buffer=""
        except:
            pass
