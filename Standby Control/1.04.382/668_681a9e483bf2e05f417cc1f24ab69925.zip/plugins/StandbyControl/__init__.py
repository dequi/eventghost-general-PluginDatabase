#
# plugins/Standby/__init__.py
#
# Copyright (C) 2008 Stefan Gollmer
#
# This file is part of EventGhost.
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#
# $LastChangedDate: 2008-04-19 10:11:41 +0200  $
# $LastChangedRevision: 382 $
# $LastChangedBy: bitmonster $


eg.RegisterPlugin(
    name        = "Standby Control",
    author      = "Stefan Gollmer",
    version     = "1.04." + "$LastChangedRevision: 382 $".split()[1],
    kind        = "other",
    description = (
                    'Software plugin offers a better control '
                    'of the standby/hibernate function'        
                  ),
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeT"
        "AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH1QIRDwU5NWx/1gAAAl5JREFUeNqd"
        "k0tPU0EYhp9zzpy2NlDaCgqBBIo1Gi6NidE10cSNiXFr4sYfoO505+UHuHCJMbo10cS9"
        "QVR0YTR4CSCQQg2kgrSl9GI5PbcZFy1SxJWzmUzeeZ9vvjfzaXM3YgCK/1uaANTx62fQ"
        "f50GjL1y8HBjtzf+8vnItg8s3J9UAkAvjEKwfx/e77mA63lUvz6hKx7Zo+kFC5hENCrU"
        "QBUaSmQAKquARDNMTF2QW1uhK9wDZju41cY9p9YAAWBtQT0PsaOQOM+XTL5x3ommvglW"
        "EXnsEj9UArZzDc8fQHEadIXsHSMz8xatsgB+sflYBXYJttcpLb2jZ/Qc2aIL9VaAtQSB"
        "IJpu8m3iHqlBHfwidmWNciGLocpgF4hlHiF9j3J4CGpZgGYGwsCNDlPLLTMYeI+23Q1m"
        "HP/jNZaXK6R6BXhFNE/ibKaJdPZhzU4D7U2AoeNpAaT0iMYksAH2T9o8xaluBXUFtg+2"
        "g+FWMAyDUk21tCB0dGue6KEkVS0KIRNCAoI6mIDhg+GBKTC7T5DPTNMRagVoGsHqCwAC"
        "w7egLQhBEwICTAOEDkJHnbyLZoZZ//ycsKAFoAPOIluZcRKpy2zEb0NHbNdsHkCl7sDQ"
        "VWYnxkm6U6BUS4jNHA6Kx3xPhxhIXsF1L+KUZhFIRHQEIxBh7vVDNl/eZKxPB1+2AHxA"
        "SvBsEh0PWJl5Rc05S7xzBBAUFp+S/fSMI+4UY0kfrN0/JgBUroIWMMDxoVijX+XBekN1"
        "1aFcdhkQkpEuCbYCW4JUOx0gAG0+HVakbcD+58xW0JtBiX3j/Bvd+fjUkZbpxAAAAABJ"
        "RU5ErkJggg=="
    )    
)

from threading import Thread, Event, Timer, Lock
from pythoncom import CoInitialize, CoUninitialize
from win32com.client import GetObject
import time


DEFAULT_FONT_INFO = wx.Font(
    18, 
    wx.SWISS, 
    wx.NORMAL, 
    wx.BOLD
).GetNativeFontInfoDesc()



class Text :

    standbyTime            = "Standby default time"
    standbyTimeAfterWakeUp = "Standby time after wake up from standby"
    standbyTimePending     = "Standby default time, if standby was pending"

    pendingCheckBox        = "Pending status: "
    nextStandby            = "Next standby/release in "

    applications           = "Currently known applications:"
    applicationName        = "Application name"
    applicationCounter     = "Counter"
    applicationReleaseTime = "Release time"
    resetAfterStandby      = "Reset after standby"
    
    clearButton            = "Clear"
    clearAllButton         = "ClearAll"
    refreshButton          = "Refresh"
    

    processNameTxt         = "Process name:  "

    addProcess             = "Add"
    removeProcess          = "Remove"
    
    processName            = "Process name"
    processStatus          = "Process status"

    refreshProcesses       = "Refresh"

    notStarted             = "Plugin is not started, event was ignored"

    class InhibitStandbyByApplication:
        name              = "Inhibit Standby by application"
        description       = (
                                "Inhibit standby by an application. "
                                "The number of inhibits can be counted."
                           )
        applicationName   = "Application name:"
        
        releaseCheckBox   = "Set release Time [min]:"
        
        countUpCheckBox   = "Count up application counter"
        
        reserAfterStandby = "Reset application counter after standby"
        
        standbyTime       = "Trigger standby timer"
        doNotTrigger      = "Don't trigger"        
        defaultCheckBox   = "with default standby time"        
        triggerSpecial    = "with following value [s]:"

    class EnableStandbyByApplication :
        name             = "Enable Standby by application"
        description      = (
                            "Enable the standby by an application. "
                            "The number of inhibits can be counted."
                           )
        applicationName  = "Application name:"
        

        resetCheckBox    = "Reset the application counter (Otherwise decrement)"

        standbyTime      = "Trigger standby timer"

        pendingText      = "if application counter is equal to zero"
        doNotPending     = "Don't trigger"
        pendingCheckBox  = "with default pending time"
        pendingSpecial   = "with following value [s]:"
        
        standbyText      = "if application counter is unequal to zero"        
        doNotTrigger     = "Don't trigger"        
        defaultCheckBox  = "with default standby time"        
        triggerSpecial   = "with following value [s]:"
        
        applicationError = "Application name '%s' not found."

    class TriggerStandbyTimer:
        name             = "Trigger standby timer"
        description      = "Trigger the standby timer of the plugin"
        
        forceCheckBox    = "Force standby time"
        defaultCheckBox  = "Use standard standby time"
        standbyTime      = "Standby time:"

    class CountDownOSD:
        label = "Show OSD: %s"
        eventText = "OSD count down \nfinished event:"
        useExternal = "Use external OSD"
        externalOSD = "External OSD \nPython command:"
        headText = "Placeholder of the count down value: %c%"
        editText = "Text to display:"
        osdFont = "Text Font:"
        osdColour = "Text Colour:"
        outlineFont = "Outline OSD"
        alignment = "Alignment:"
        alignmentChoices = [
            "Top Left", 
            "Top Right", 
            "Bottom Left",
            "Bottom Right", 
            "Screen Center",
            "Bottom Center",
            "Top Center",
            "Left Center",
            "Right Center",
        ]
        display  = "Show on display:"
        xOffset  = "Horizontal offset X:"
        yOffset  = "Vertical offset Y:"
        wait     = "Time interval [s]"
        start    = "Start value:"
        end      = "End value:"
        interval = "Interval:"
        skin     = "Use skin"




class StandbyTimerThread( Thread ) :

    def __init__(
                    self,
                    plugin,
                    standbyTime,
                    standbyTimePending
                ) :
    
        Thread.__init__(self, name="StandbyTimerThread")
        
        self.plugin = plugin
        
        self.timeDefault         = standbyTime
        self.timePendingDefault  = standbyTimePending
        
        self.time         = standbyTime
        self.timePending  = standbyTimePending
        
        self.waitTime     = time
        
        self.pending   = False

        self.enabled            = True
        self.triggered          = True
        self.abort              = False
        self.getNewStatus       = False
        
        self.started = False
        
        self.nextStandby = 0.0 
        
        self.lock = Lock()
        
        self.event = Event()



    @eg.LogItWithReturn
    def run(self) :
        self.started = True
        
        self.event.clear()
        
        lock = self.lock
        
        lock.acquire()

        while not self.abort :
                        
            if self.triggered :
                if self.nextStandby == 0.0 :
                    self.waitTime = self.time
                else :
                    delta = self.nextStandby - time.time()
                    if delta < self.time :
                        self.waitTime = self.time
                    else :
                        self.waitTime = delta
                self.time = self.timeDefault
                self.pending = False
                
            elif self.pending :
                self.waitTime = self.timePending
                self.pending = False
                self.timePending = self.timePendingDefault
                self.pending = False
            
            else :
                self.waitTime = self.timeDefault
                    
            if not self.enabled and not self.triggered :
                self.pending = True
                
            self.triggered = False
            
            if self.pending :
                lock.release()
                self.event.wait()
                lock.acquire()
                self.nextStandby = 0.0
            else :
                self.nextStandby = time.time() + self.waitTime
                lock.release()
                self.event.wait( self.waitTime )
                lock.acquire()
                if not self.getNewStatus and self.enabled :
                    self.TriggerStandby()
                    self.nextStandby = 0.0
            self.event.clear()
            self.getNewStatus = False
            
        self.started = False
        
        lock.release()
        
        return True



    def TriggerStandby( self ) :
        self.plugin.TriggerEvent( "Trigger" )
        self.plugin.triggered = True



    def SetGetNewStatus( self ) :
    
        if self.started :
        
            self.lock.acquire()
        
            self.getNewStatus = True
            
            self.event.set()
            
            return True
        
        else :
            #print "Warning: Standby timer wasn't started"
            
            return False



    @eg.LogItWithReturn
    def finish(self) :
    
        if self.SetGetNewStatus() :
    
            self.abort = True
            
            self.lock.release()

            return True
            
        else :
            return False



    def triggerTimer( self, time ) :
    
        if time == 0.0 :
            return
    
        if self.SetGetNewStatus() :
    
            self.triggered = True
            self.time = time
        
            self.lock.release()
                
            return True
            
        else :
            return False



    @eg.LogItWithReturn
    def triggerTimerAndForceTime( self, time ) :
    
        if self.SetGetNewStatus() :
    
            self.nextStandby = 0.0
            self.triggered = True
            self.time = time
            
            if time == 0 :
                if self.enabled :
                    self.TriggerStandby()
                self.time = self.timeDefault
        
            self.lock.release()
            
            return True
            
        else :
            return False



    @eg.LogItWithReturn
    def enableStandby( self, setTime ) :
    
        if self.started :
    
            self.enabled = True

            if self.pending :

                if self.SetGetNewStatus() :
                
                    if ( setTime != 0.0 ) :
                        self.timePending = setTime
                    else :
                        self.timePending = self.timePendingDefault
                        
                    self.lock.release()
            return True
            
        else :
            return False



    @eg.LogIt
    def disableStandby( self ) :
    
        self.enabled = False



    def getPendingStatus( self ) :
        return( self.pending )



    def getActualStandbyTime( self ) :
        standby = self.nextStandby - time.time()
        if standby < 0.0 :
            standby = 0.0
        else :
            standby = int( standby * 10 ) / 10.0       # 0.1 s accuracy
        return( standby )




class ForceReleaseThread( Thread ) :

    def __init__(
                    self,
                    plugin
                ) :
                
        Thread.__init__(self, name="ForceReleaseThread")
        
        self.plugin = plugin
        
        self.time = -1.0
        self.nextReleaseTime = -1.0

        self.getNewStatus = False
        
        self.started = False
        self.abort = False
        
        self.event = Event()
        
        self.lock = Lock()



    @eg.LogItWithReturn
    def run(self) :
        
        self.started = True
        
        lock = self.lock
        lock.acquire()

        while not self.abort :
                
            delta = self.time
            self.nextReleaseTime = time.time() + delta

            if delta <= 0.0 :
                lock.release()
                self.event.wait()
                lock.acquire()
                self.event.clear()
            else :
                lock.release()
                self.event.wait( delta )
                lock.acquire()
                self.event.clear()
                if not self.getNewStatus :
                    self.plugin.updateReleaseTime(True)
            self.getNewStatus = False
                    
        self.started = False
        
        lock.release()

        return True



    def SetGetNewStatus( self ) :
    
        if self.started:
            self.lock.acquire()

            self.event.set()

            return True



    @eg.LogItWithReturn
    def finish( self ) :
        if self.SetGetNewStatus() :
            self.abort = True
            self.lock.release()
            
            return True
        else :
            return False



    def hold( self ) :
        if self.SetGetNewStatus() :
            self.time = -1.0
            self.lock.release()
            return True
        else :
            return False



    def setTime( self, time, noLock = False ) :
        if noLock :
            self.time = time
            return True
        elif self.SetGetNewStatus() :
            self.time = time
            self.lock.release()
            return True
        else :
            return False



    def getNextReleaseTime( self ) :
        delta = self.nextReleaseTime - time.time()
        if delta < 0.0 :
            delta = 0.0
        else :
            delta = int( delta )       # 1 s accuracy
        return( delta )




class Suspend( eg.ActionClass ) :

    def __call__( self ) :
        plugin = self.plugin
        
        plugin.OnComputerSuspend( None )




class Resume( eg.ActionClass ) :

    def __call__( self ) :
        plugin = self.plugin
        
        plugin.OnComputerResume( None )




class DisplayOSD( Thread ) :

    def __init__(
                    self,
                    plugin,
                    action,
                    osdText, 
                    fontInfo,
                    foregroundColour, 
                    backgroundColour,
                    alignment, 
                    offset, 
                    displayNumber, 
                    skin,

                    countDownTime,
                    startValue,
                    endValue,
                    interval,
                    countDownFinishEvent,
                    useExternalOSD,
                    alternativeOSD
                   ) :
                
        Thread.__init__(self, name="CountDownOSDThread")
        
        self.plugin = plugin
        
        self.osdText              = osdText 
        self.fontInfo             = fontInfo
        self.foregroundColour     = foregroundColour
        self.backgroundColour     = backgroundColour
        self.alignment            = alignment
        self.offset               = offset
        self.displayNumber        = displayNumber
        self.skin                 = skin
        self.countDownTime        = countDownTime
        self.endTime              = endValue
        self.interval             = interval
        self.countDownFinishEvent = countDownFinishEvent
        self.useExternalOSD       = useExternalOSD
        self.alternativeOSD       = alternativeOSD
 
        
        self.action = action

        length = 0

        pos = self.osdText.find( u'%c%' )
        if pos >= 0 :
            length = 3
            insert = u'%(counter)i'
        else :
            pos = self.osdText.find( u'%cf%' )
            if pos >= 0 :
                length = 4
                insert = u'%(counter)'       
        if length > 0 :
            self.osdText = self.osdText[:pos] + insert + self.osdText[pos+length:]
            self.formatedOSD = True
        else :
            self.formatedOSD = False
                
        self.nextTime = startValue
        self.action.started = False
        self.end = False
        self.close = False
        self.event = Event()



    @eg.LogItWithReturn
    def run(self) :
        
        self.action.started = True
        
        timeout = self.countDownTime * 2
        tries = 5
        useExternalOSD = self.useExternalOSD
        abort = False
        
        CoInitialize()
        
        while True :
        
            if self.close :
                break
        
            if self.end :
                timeout = 0.01
                self.nextTime = self.lastTime
                abort = True
                
            if self.formatedOSD :
                text = self.osdText % {'counter': self.nextTime}
            else :
                text = self.osdText
                
            if useExternalOSD :
                command = u'eg.plugins.' + self.alternativeOSD
                pos = command.find( u'%s%' )
                if pos >= 0 :
                    command = command[:pos] + "text" + command[pos+3:]
                pos = command.find( u'%t%' )
                if pos >= 0 :
                    command = command[:pos] + str(timeout) + command[pos+3:]
                #print "command = ", command
                
                try:
                    exec command in eg.globals.__dict__, locals()
                except:
                    eg.PrintError( "CountDownOSD: Error on executing external function")
                    tries -= 1

                    if tries == 0 :
                        eg.PrintError( "CountDownOSD: Too many errors on external function, set to standard OSD")
                        useExternalOSD = False
                
            else :
                
                debugLevel = eg.debugLevel
                eg.debugLevel = 0
                try:
                    eg.plugins.EventGhost.ShowOSD(
                        osdText          = text ,
                        fontInfo         = self.fontInfo ,
                        foregroundColour = self.foregroundColour ,
                        backgroundColour = self.backgroundColour ,
                        alignment        = self.alignment ,
                        offset           = self.offset ,
                        displayNumber    = self.displayNumber ,
                        timeout          = timeout ,
                        skin             = self.skin            
                    )
                    eg.debugLevel = debugLevel
                except:
                    eg.debugLevel = debugLevel
                    eg.PrintError( "EventGhost ShowOSD seems to be changed. Standby plugin must be changed")
            if abort :
                time.sleep( 2*timeout )
                break

            self.lastTime = self.nextTime
            self.nextTime -= self.interval

            if self.nextTime < self.endTime :
                self.nextTime = self.endTime
                self.event.wait( self.countDownTime )
                if not self.end :
                    self.plugin.TriggerEvent( self.countDownFinishEvent )
                self.end = True
            else :
                self.event.wait( self.countDownTime )
                
        self.action.started = False

        CoUninitialize()

        return True



    @eg.LogItWithReturn
    def finish( self ) :
        if self.action.started :
            self.end = True
            self.event.set()
            return True
        else :
            return False



    def OnClose(self):
        if self.action.started :
            self.close = True
            self.event.set()




class ProcessMonitorThread( Thread ) :

    def __init__( self, plugin, waitTime = 5.0 ) :

        Thread.__init__(self, name="ProcessMonitorThread")
        
        self.monitorProcessList = plugin.monitorProcessList
        
        self.wholeProcessList   = plugin.wholeProcessList
        self.abort = False
        self.plugin = plugin
        self.waitTime = waitTime
        self.event = Event()
        self.lock = Lock()



    def run( self ) :
    
        def trigger( name, created = True ) :
            self.monitorProcessList[ name ] = created
            pos = name.rfind( '.' )
            suffix = name[pos+1:]
            remove = False
            if suffix == 'exe' :
                remove = True
            if remove :
                name = name[:pos]
            name = name.replace('.', '_')
            plugin = self.plugin
            if created :
                event = "Created"
                plugin.numberOfActiveProcesses += 1
            else :
                event = "Terminated"
                plugin.numberOfActiveProcesses -= 1
            plugin.TriggerEvent( event + "." + name )
            if plugin.numberOfActiveProcesses == 0 :
                plugin.TriggerEvent( "AllMonitoredProcessesTerminated" )
            else :
                plugin.TriggerEvent( "MonitoredProcessesChanged" )
    
        CoInitialize()

        WMI = GetObject('winmgmts:{impersonationLevel=impersonate}')
        
        lock = self.lock
        
        lock.acquire()
                
        objectSet = WMI.ExecQuery('select * from Win32_Process')

        for obj in objectSet :
            name = obj.Caption
            if name == 'System Idle Process' :
                continue
            elif name == 'System' :
                continue
            self.wholeProcessList[ name ] = True
            if name in self.monitorProcessList :
                self.monitorProcessList[ name ] = True
                trigger( name, True )
                
        query = ( "SELECT * FROM __InstanceOperationEvent WITHIN " +
                  str( self.waitTime ) + " WHERE TargetInstance ISA 'Win32_Process'" )
                         
        eventSource = WMI.ExecNotificationQuery( query )
        
        while not self.abort :
        
            lock.release()

            lock.acquire()

            try :
                event = eventSource.NextEvent( 500 )

            except :
                continue
                
            type = event.Path_.Class
            name = event.TargetInstance.Name 
            
            if   type == '__InstanceCreationEvent' :
                #print "name = ", name
                created = True
            elif type == '__InstanceDeletionEvent' :
                #print "name = ", name
                created = False
            else :
                continue
                
            self.wholeProcessList[ name ] = created
            if name in self.monitorProcessList :
                trigger( name, created )
            
        pass            



    def terminate( self ) :
        self.lock.acquire()
        self.abort = True
        self.event.set()
        self.lock.release()




class StandbyControl(eg.PluginClass) :

    text = Text



    class Entry :

        def __init__( self ) :
            self.counter = 0
            self.releaseTime = -1.0
            self.resetAfterStandby = True



    def __init__(self) :
    
        self.countDownOSD = None

        self.AddEvents( ("Trigger", "Trigger standby") )
        self.AddAction(         TriggerStandbyTimer )
        self.AddAction( InhibitStandbyByApplication )
        self.AddAction(  EnableStandbyByApplication )
        self.AddAction(                CountDownOSD )
        self.AddAction(          CancelOSDCountDown )
        self.AddAction(                WasTriggered )
        self.AddAction(   IsMonitoredProcessRunning )
        #self.AddAction( Resume )                        # only for debugging the resume function of the plugin
        #self.AddAction( Suspend )                       # only for debugging the suspend function of the plugin
        
        self.applicationNames    = []                   # Map containing the application names
        self.applicationCounters = {}                   # Dictionary containing the application counters
        
        self.wholeProcessList = {}
        self.monitorProcessList = {}
        self.numberOfActiveProcesses = 0


        self.standbyTimeDefault        = 0.0
        self.standbyTimePendingDefault = 0.0
        self.standbyTimeAfterWakeUp    = 0.0
        
        self.lastApplicationName = ""
        
        self.threadStandby = None
        self.threadForce   = None
        
        self.triggered = False
        self.started = False



    @eg.LogIt
    def __start__(
                self,
                standbyTime=300.0,
                standbyTimePending=60.0,
                standbyTimeAfterWakeUp=300.0,
                monitorProcessList = []
                ) :

        self.standbyTimeDefault        = standbyTime
        self.standbyTimePendingDefault = standbyTimePending
        self.standbyTimeAfterWakeUp    = standbyTimeAfterWakeUp
        
        self.startThreads()

        self.started = True
                
        for name in monitorProcessList :
            self.monitorProcessList[ name ] = False
        
        return True



    @eg.LogItWithReturn
    def startThreads( self ) :
        self.threadStandby = StandbyTimerThread(
                                        self,
                                        self.standbyTimeDefault,
                                        self.standbyTimePendingDefault
                                        )
        self.threadStandby.start()
        
        
        self.threadForce = ForceReleaseThread( self )
        self.threadForce.start()
        
        self.processMonitor = ProcessMonitorThread( self, 5.0 )
        self.processMonitor.start()

        return True



    @eg.LogItWithReturn
    def finishThreads( self ) :
        if self.started :
            if self.threadStandby :
                self.threadStandby.finish()
                self.threadStandby.join()
                del self.threadStandby
                self.threadStandby = None
            if self.threadForce :
                self.threadForce.finish()
                self.threadForce.join()
                del self.threadForce
                self.threadForce = None
            if self.countDownOSD :
                self.countDownOSD.OnClose()
            self.processMonitor.terminate()
        return self.started



    @eg.LogIt
    def __stop__(self) :
        self.finishThreads()
        self.started = False



    @eg.LogIt
    def __close__(self) :
        self.__stop__()



    @eg.LogItWithReturn
    def OnComputerSuspend(self, suspendType ) :
        self.finishThreads()



    @eg.LogItWithReturn
    def OnComputerResume(self, suspendType ) :
        self.triggered = False
        if self.started :
            self.startThreads()
            self.threadStandby.triggerTimer( self.standbyTimeAfterWakeUp )
            return True
        else :
            return False



    def triggerTimer( self, time ) :
        if self.threadStandby :
            self.threadStandby.triggerTimer( time )



    @eg.LogIt
    def triggerTimerAndForceTime( self, time ) :
        if self.threadStandby :
            self.threadStandby.triggerTimerAndForceTime( time )



    @eg.LogIt
    def disableStandby( self ) :
        if self.threadStandby :
            self.threadStandby.disableStandby()



    @eg.LogItWithReturn
    def OSDCancel( self ) :
        if self.countDownOSD != None :
            self.countDownOSD.OSDCancel()
            return True
        else :
            return False



    class counterStatus :
    
        def __init__( self, changed = False, enabled = True ) :
            self.changed = changed
            self.enabled = enabled
        
        def setChanged( self, changed = True ) :
            self.changed = changed
        
        def setEnabled( self, enabled = True ) :
            self.enabled = enabled
            
        def getChanged( self ) :
            return self.changed
            
        def getEnabled( self ) :
            return self.enabled



    def setCounter(
                    self ,
                    applicationName ,
                    mode ,
                    maxTime = -1.0 ,
                    resetAfterStandby = True
                  ) :
                  
        # mode := 0     Set counter to 1
        # mode := 1     Increment counter
        # mode := 2     Decrement counter
        # mode := 3     Reset counter
        
        status = self.counterStatus()
                    
        if ( not applicationName or applicationName != "" ) :
        
            entry = self.Entry()
            
            exists = self.applicationCounters.has_key( applicationName )

            if exists :
                entry = self.applicationCounters[ applicationName ]
                
            entry.resetAfterStandby = resetAfterStandby
                
            if mode == 0 :
                if entry.counter == 0 :
                    status.setChanged()
                status.setEnabled( False )
                entry.counter = 1
            elif mode == 1 :
                if entry.counter == 0 :
                    status.setChanged()
                status.setEnabled( False )
                entry.counter += 1
            elif mode == 2 and entry.counter > 0 :
                entry.counter -= 1
                if entry.counter != 0 :
                    status.setEnabled( False )
                else :
                    status.setChanged()
            elif mode == 3 :
                if entry.counter > 0 :
                    status.setChanged()
                entry.counter = 0
            
            setReleaseTime = False

            if ( mode == 0 or mode == 1 ) :
                if maxTime >= 0.0 :
                    releaseTime = time.time() + maxTime
                    if ( releaseTime > entry.releaseTime ) :
                        entry.releaseTime = releaseTime
                        setReleaseTime = True
                elif mode == 0 :
                    entry.releaseTime = -1.0
                    setReleaseTime = True

            elif status.getChanged() :
                setReleaseTime = True
                entry.releaseTime = -1.0

            if ( exists or entry.counter > 0 ) :
                self.applicationCounters[ applicationName ] = entry
            
            if setReleaseTime :
                self.updateReleaseTime()
        
        return status



    def updateReleaseTime( self, noLock = False ) :
    
        if not self.started or not self.threadForce :
            return
        
        thread = self.threadForce
        
        if not noLock :
            thread.hold()
        
        now = time.time()
        nextTime = -1.0
        
        for name, entry in self.applicationCounters.iteritems() :
            releaseTime = entry.releaseTime
            if releaseTime >= 0.0 and entry.counter > 0 :
                if releaseTime - now <= 0 :
                    entry.counter = 0
                    entry.releaseTime = -1.0
                    self.checkAndEnable()
                    self.TriggerEvent( "Release." + name )
                else :
                    delta = releaseTime - now
                    if nextTime < 0.0 or delta < nextTime :
                        nextTime = delta
        if nextTime > 0.0 :
            thread.setTime( nextTime, noLock )



    def getApplicationNames(self) :
        self.applicationNames.sort(lambda a,b: cmp(a.lower(), b.lower()) )
        return self.applicationNames



    def addApplicationNames(self, applicationName ) :
        if not applicationName in self.applicationNames :
            self.applicationNames.append( applicationName )



    def checkAndEnable( self, time = 0.0, afterStandby = False ) :
        if not self.threadStandby :
            return False
        enable = True
        for name, entry in self.applicationCounters.iteritems() :
            if afterStandby and entry.resetAfterStandby :
                entry.counter = 0
                entry.releaseTime = -1.0
            if entry.counter != 0 :
                enable = False
                break
        if enable and self.started :
            self.threadStandby.enableStandby( time )
        return enable



    def Configure(self, standbyTime=600.0, standbyTimePending=60.0, standbyTimeAfterWakeUp=600.0, monitorProcessList = [] ) :

        def fillTable (event) :
            applicationListCtrl.DeleteAllItems()
            row = 0
            for name, entry in self.applicationCounters.iteritems() :
                counter = entry.counter
                applicationListCtrl.InsertStringItem( row, name)
                applicationListCtrl.SetStringItem( row, 1, str( counter ) )
                if entry.resetAfterStandby :
                    string = "Yes"
                else :
                    string = "No"
                applicationListCtrl.SetStringItem( row, 2, string )
                releaseTime = entry.releaseTime
                if ( releaseTime > 0.0 ) :
                    string = time.strftime( "%d.%m %H:%M:%S", time.localtime( releaseTime ) )
                else :
                    string = "Not set"
                applicationListCtrl.SetStringItem( row, 3, string )
                row += 1
            event.Skip()


        def listSelection(event):
            enable = applicationListCtrl.GetFirstSelected() != -1
            clearButton.Enable(enable)
            event.Skip()


        def onClearButton( event ) :
            item = applicationListCtrl.GetFirstSelected()
            while item != -1 :
                name = applicationListCtrl.GetItemText(item)
                self.applicationCounters[ name ] = self.Entry()
                item = applicationListCtrl.GetNextSelected(item)
            onRefreshButton(wx.CommandEvent())
            self.checkAndEnable()
            self.updateReleaseTime()
            event.Skip()


        def onClearAllButton( event ) :
            for name, counter in self.applicationCounters.iteritems() :
                self.applicationCounters[ name ] = self.Entry()
            onRefreshButton(wx.CommandEvent())
            self.checkAndEnable()
            self.updateReleaseTime()
            event.Skip()


        def onRefreshButton( event ) :
            fillTable( event )
            if self.started and self.threadStandby and self.threadForce :
                nextStandby = self.threadStandby.getActualStandbyTime()
                if self.threadStandby.getPendingStatus() :
                    status = "Pending"
                elif nextStandby >= 0.0 :
                    status = str( nextStandby ) + " s"
                else :
                    status = "None"
                status += " / "
                nextRelease = self.threadForce.getNextReleaseTime()
                if nextRelease :
                    status += str( nextRelease ) + " s"
                else :
                    status += "None"
                
                standbyTextCtrl.SetValue( status )


        def processSelection(event):
            enable = processListCtrl.GetFirstSelected() != -1
            removePButton.Enable(enable)
            event.Skip()


        def onProcessTxtChange( event ) :
            name = processNameCtrl.GetValue()
            addPButton.Enable( name != '' )


        def onProcessAddButton( event ) :
            name = processNameCtrl.GetValue()
            if name != '' and name not in monitorProcessList :
                monitorProcessList.append( name )
                monitorProcessList.sort()
                onRefreshProcessesButton( event )
            event.Skip()


        def onProcessRemoveButton( event ) :
            item = processListCtrl.GetFirstSelected()
            while item != -1 :
                name = processListCtrl.GetItemText(item)
                monitorProcessList.remove( name )
                item = processListCtrl.GetNextSelected(item)
            onRefreshProcessesButton( event )
            removePButton.Enable( False )
            event.Skip()


        def onRefreshProcessesButton( event ) :
            processListCtrl.DeleteAllItems()
            row = 0
            for name in monitorProcessList :
                if name in self.wholeProcessList :
                    if self.wholeProcessList[ name ] :
                        string = 'active'
                    else :
                        string = 'terminated'
                else :
                    string = 'terminated'
                processListCtrl.InsertStringItem( row, name)
                processListCtrl.SetStringItem( row, 1 , string )
                row += 1
            processNameCtrl.Clear()
            processNameCtrl.AppendItems( getProcessList() )
            event.Skip()


        def getProcessList() :
            
            processList = []
                
            for name, status in self.wholeProcessList.iteritems() :
                if name not in monitorProcessList :
                    processList.append( name )
            processList.sort( cmp=lambda x,y: cmp(x.lower(), y.lower()) )
            return processList


        text = self.text
        
        panel = eg.ConfigPanel(self, resizable=True)
        
        
        standbyTimeCtrl            = panel.SpinNumCtrl(           standbyTime, min=0, max=99999, fractionWidth=0, integerWidth=5)
        standbyTimePendingCtrl     = panel.SpinNumCtrl(    standbyTimePending, min=5, max= 9999, fractionWidth=0, integerWidth=5)
        standbyTimeAfterWakeUpCtrl = panel.SpinNumCtrl(standbyTimeAfterWakeUp, min=0, max=99999, fractionWidth=0, integerWidth=5)

        standbyTextCtrl = wx.TextCtrl( panel, -1, "None / None", style = wx.TE_RIGHT)
        standbyTextCtrl.Enable( False )

        gridSizer = wx.GridBagSizer(5, 5)
        

        #Input of the timer values
        rowCount = 0
        gridSizer.Add(
                    wx.StaticText(panel, -1, text.standbyTime),
                    (rowCount, 0),
                    flag = wx.ALIGN_CENTER_VERTICAL
                   )
        gridSizer.Add(standbyTimeCtrl, (rowCount, 1), flag = wx.ALIGN_RIGHT )

        gridSizer.Add(
                    wx.StaticText(panel, -1, text.standbyTimePending),
                    (rowCount, 2),
                    flag = wx.ALIGN_CENTER_VERTICAL | wx.LEFT, border = 5
                   )
        gridSizer.Add(standbyTimePendingCtrl, (rowCount, 3), flag = wx.EXPAND)

        rowCount += 1
        gridSizer.Add(
                    wx.StaticText(panel, -1, text.nextStandby),
                    (rowCount, 0),
                    flag = wx.ALIGN_CENTER_VERTICAL
                   )
        gridSizer.Add(standbyTextCtrl, (rowCount, 1), flag = wx.EXPAND)

        gridSizer.Add(
                    wx.StaticText(panel, -1, text.standbyTimeAfterWakeUp),
                    (rowCount, 2),
                    flag = wx.ALIGN_CENTER_VERTICAL | wx.LEFT, border = 5
                   )
        gridSizer.Add(standbyTimeAfterWakeUpCtrl, (rowCount, 3), flag = wx.EXPAND )

        #Application table
        panel.sizer.Add( gridSizer )
        panel.sizer.Add(wx.Size(5,10))

        panel.sizer.Add( 
                        wx.StaticText(panel, -1, self.text.applications),
                        flag = wx.ALIGN_CENTER_VERTICAL
                       )
        panel.sizer.Add(wx.Size(5,5))

        tableSizer = wx.GridBagSizer(5,5)
        tableSizer.AddGrowableRow(0)
        tableSizer.AddGrowableCol(1)

        applicationListCtrl = wx.ListCtrl(panel, -1, style=wx.LC_REPORT | wx.VSCROLL | wx.HSCROLL )
        
        applicationListCtrl.InsertColumn(0, text.applicationName )
        applicationListCtrl.InsertColumn(1, text.applicationCounter )
        applicationListCtrl.InsertColumn(2, text.resetAfterStandby )
        applicationListCtrl.InsertColumn(3, text.applicationReleaseTime )
        
        columnDelta = ( 30, 0, 0, 20 )
        
        size = 0
        for c in range(len(columnDelta)) :
            applicationListCtrl.SetColumnWidth(c, wx.LIST_AUTOSIZE_USEHEADER)
            csize = applicationListCtrl.GetColumnWidth( c ) + columnDelta[ c ]
            applicationListCtrl.SetColumnWidth(c, csize)
            size += csize
        
        applicationListCtrl.SetMinSize((size, -1))

        rowCount = 0
        tableRows = 6
        tableSizer.Add(applicationListCtrl, (0,0), (tableRows, 3), flag = wx.EXPAND)
        rowCount += tableRows


        #buttons
        clearButton = wx.Button( panel, -1, text.clearButton )
        tableSizer.Add(clearButton, (rowCount,0), flag = wx.LEFT )
        clearButton.Enable( False )
       
        clearAllButton = wx.Button( panel, -1, text.clearAllButton )
        tableSizer.Add(clearAllButton, (rowCount,1), flag = wx.ALIGN_CENTER_HORIZONTAL)
       
        refreshButton = wx.Button( panel, -1, text.refreshButton )
        tableSizer.Add(refreshButton, (rowCount,2), flag = wx.ALIGN_RIGHT )
        

        rowCount +=1
        
        processNameCtrl = wx.ComboBox(
                                        panel,
                                        -1,
                                        value='',
                                        choices = [],
                                        size=(200,-1)
                                        )

        rowCount += 1
        tableSizer.Add( 
                        wx.StaticText(panel, -1, self.text.processNameTxt), (rowCount, 0),
                        flag = wx.ALIGN_CENTER_VERTICAL
                       )
        tableSizer.Add(processNameCtrl, (rowCount, 1), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )

        #buttons
        addPButton    = wx.Button( panel, -1, text.addProcess )
        tableSizer.Add(addPButton, (rowCount,2), flag = wx.ALIGN_RIGHT )
        addPButton.Enable( False )


        processListCtrl = wx.ListCtrl(panel, -1, style=wx.LC_REPORT | wx.VSCROLL | wx.HSCROLL )

        processListCtrl.InsertColumn(0, text.processName )
        processListCtrl.InsertColumn(1, text.processStatus )

        columnDelta = ( 50, 0)

        size = 0
        for c in range(len(columnDelta)) :
            processListCtrl.SetColumnWidth(c, wx.LIST_AUTOSIZE_USEHEADER)
            csize = processListCtrl.GetColumnWidth( c ) + columnDelta[ c ]
            processListCtrl.SetColumnWidth(c, csize)
            size += csize

        processListCtrl.SetMinSize((size, -1))

        tableRows = 6
        rowCount += 1
        tableSizer.Add(processListCtrl, (rowCount,0), (tableRows, 3), flag = wx.EXPAND)
        rowCount += tableRows

        #buttons
        removePButton = wx.Button( panel, -1, text.removeProcess )
        tableSizer.Add(removePButton, (rowCount,0), flag = wx.ALIGN_RIGHT )
        removePButton.Enable( False )

        refreshPButton = wx.Button( panel, -1, text.refreshProcesses )
        tableSizer.Add(refreshPButton, (rowCount,2), flag = wx.ALIGN_RIGHT )


        panel.sizer.Add(tableSizer, 1, flag = wx.EXPAND)
        
        clearButton.Bind(    wx.EVT_BUTTON, onClearButton    )
        clearAllButton.Bind( wx.EVT_BUTTON, onClearAllButton )
        refreshButton.Bind(  wx.EVT_BUTTON, onRefreshButton  )
        applicationListCtrl.Bind(wx.EVT_LIST_ITEM_SELECTED,   listSelection)
        applicationListCtrl.Bind(wx.EVT_LIST_ITEM_DESELECTED, listSelection)

        processNameCtrl.Bind( wx.EVT_TEXT, onProcessTxtChange )
        addPButton.Bind( wx.EVT_BUTTON, onProcessAddButton )
        processListCtrl.Bind(wx.EVT_LIST_ITEM_SELECTED,   processSelection)
        processListCtrl.Bind(wx.EVT_LIST_ITEM_DESELECTED, processSelection)
        refreshPButton.Bind(  wx.EVT_BUTTON, onRefreshProcessesButton  )
        removePButton.Bind( wx.EVT_BUTTON, onProcessRemoveButton )

        onRefreshButton(wx.CommandEvent())        
        onRefreshProcessesButton(wx.CommandEvent())        

        while panel.Affirmed() :
            standbyTime            =            standbyTimeCtrl.GetValue()
            standbyTimePending     =     standbyTimePendingCtrl.GetValue()
            standbyTimeAfterWakeUp = standbyTimeAfterWakeUpCtrl.GetValue()
            panel.SetResult( standbyTime, standbyTimePending, standbyTimeAfterWakeUp, monitorProcessList )




class IsMonitoredProcessRunning( eg.ActionClass ) :

    @eg.LogIt
    def __call__( self ) :
        return self.plugin.numberOfActiveProcesses != 0




class TriggerStandbyTimer( eg.ActionClass ) :

    def __call__(
                self,
                force,
                useDefault,
                standbyTime
                ) :
        plugin = self.plugin

        if not plugin.started :
            self.PrintError(plugin.text.notStarted)
            return False
            
        if useDefault :
            standbyTime = plugin.standbyTimeDefault

        if force :
            plugin.triggerTimerAndForceTime( standbyTime )
        else :
            plugin.triggerTimer( standbyTime )
        
        return True



    def Configure( self, force = False, useDefault=True, standbyTime=600.0 ) :
    
        def onCheckBox( event ) :
            enable = not useDefaultCtrl.GetValue()
            standbyTimeCtrl.Enable( enable )

            event.Skip()
        

        text = self.text
        
        panel = eg.ConfigPanel(self)

        #showRemaingLoopsText

        forceCtrl = wx.CheckBox(panel, -1, text.forceCheckBox)
        forceCtrl.SetValue(force)
        
        useDefaultCtrl = wx.CheckBox(panel, -1, text.defaultCheckBox)
        useDefaultCtrl.SetValue(useDefault)
        useDefaultCtrl.Bind(wx.EVT_CHECKBOX, onCheckBox)
        
        standbyTimeCtrl = panel.SpinNumCtrl( standbyTime, min=0, max=99999, fractionWidth=0, integerWidth=5)
        
        onCheckBox(wx.CommandEvent())

        panel.AddLine( forceCtrl )
        panel.AddLine( useDefaultCtrl )
        panel.AddLine( text.standbyTime, standbyTimeCtrl )
        
        while panel.Affirmed() :
            force = forceCtrl.GetValue()
            useDefault  = useDefaultCtrl.GetValue()
            standbyTime = standbyTimeCtrl.GetValue()
            standbyTimePending = standbyTimeCtrl.GetValue()
            panel.SetResult( force, useDefault, standbyTime )




class InhibitStandbyByApplication( eg.ActionClass ) :

    def __call__(
                self ,
                applicationName = None ,
                countUp = True ,
                mode = 0 ,
                standbyTime = 600.0 ,
                enableRelease = False ,
                maxTime = -1.0 ,
                resetAfterStandby = True ,
                ) :
        # mode == 0:    doNotTrigger
        # mode == 1:    triggerDefault
        # mode == 2:    triggerSpecialValue
        
        
        plugin = self.plugin
        
        plugin.disableStandby()
        
        if not plugin.started :
            eg.PrintError(plugin.text.notStarted)
            return False
            
        if countUp :
            counterMode = 1
        else :
            counterMode = 0
            
        if not enableRelease :
            maxTime = -1.0

        plugin.setCounter( applicationName, counterMode, maxTime * 60, resetAfterStandby )
            
        if mode != 0 :
        
            if mode == 1 :
                standbyTime = plugin.standbyTimeDefault
                    
            plugin.triggerTimer( standbyTime )
            
        return True



    def Configure(
                self,
                applicationName = None ,
                countUp = True ,
                mode = 0 ,
                standbyTime = 600.0 ,
                enableRelease = False ,
                maxTime = 0.0 ,
                resetAfterStandby = True
                ) :


        def onRadioButton( event ) :
            enable = triggerSpecialCtrl.GetValue()
            standbyTimeCtrl.Enable( enable )

            event.Skip()


        def onCheckBox( event ) :
            enable = releaseCheckBoxCtrl.GetValue()
            releaseTimeCtrl.Enable( enable )

            event.Skip()


        text = self.text
        plugin = self.plugin
        
        if applicationName :
            plugin.addApplicationNames( applicationName )
        
        panel = eg.ConfigPanel(self)
        
        if not applicationName :
            applicationName = plugin.lastApplicationName
            

        #define controls

        applicationNameCtrl = wx.ComboBox(
                                        panel,
                                        -1,
                                        value=applicationName,
                                        choices=plugin.getApplicationNames(),
                                        size=(200,-1)
                                        )

        releaseCheckBoxCtrl = wx.CheckBox(panel, -1, text.releaseCheckBox)
        releaseCheckBoxCtrl.SetValue( enableRelease )
        releaseCheckBoxCtrl.Bind(wx.EVT_CHECKBOX, onCheckBox)
        
        maxTime = maxTime
        releaseTimeCtrl = panel.SpinNumCtrl( maxTime, min=0, max=99999, fractionWidth=0, integerWidth=5)
        
        countUpCheckBoxCtrl = wx.CheckBox(panel, -1, text.countUpCheckBox)
        countUpCheckBoxCtrl.SetValue(countUp)

        resetCheckBoxCtrl = wx.CheckBox(panel, -1, text.reserAfterStandby)
        resetCheckBoxCtrl.SetValue( resetAfterStandby )
        
        doNotTriggerCtrl = wx.RadioButton(panel, -1, text.doNotTrigger, style = wx.RB_GROUP)
        doNotTriggerCtrl.SetValue( mode == 0 )
        doNotTriggerCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButton)

        useDefaultCtrl = wx.RadioButton(panel, -1, text.defaultCheckBox )
        useDefaultCtrl.SetValue( mode == 1 )
        useDefaultCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButton)
        
        triggerSpecialCtrl = wx.RadioButton(panel, -1, text.triggerSpecial )
        triggerSpecialCtrl.SetValue( mode == 2 )
        triggerSpecialCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButton)
        
        standbyTimeCtrl = panel.SpinNumCtrl( standbyTime, min=0, max=99999, fractionWidth=0, integerWidth=5)

        #paint
        gridSizer = wx.GridBagSizer( 10, 5 )

        rowCount = 0
        gridSizer.Add(
                    wx.StaticText(panel, -1, text.applicationName),
                    (rowCount, 0),
                    flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL
                    )
        gridSizer.Add(applicationNameCtrl, (rowCount, 1), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        
        rowCount += 1
        gridSizer.Add(releaseCheckBoxCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        gridSizer.Add(releaseTimeCtrl,     (rowCount, 1), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        
        panel.sizer.Add( gridSizer )

        panel.sizer.Add(wx.Size(0,13))
        panel.sizer.Add(countUpCheckBoxCtrl, flag = wx.ALIGN_CENTER_VERTICAL )
        panel.sizer.Add(wx.Size(0,18))
        
        panel.sizer.Add(resetCheckBoxCtrl, flag = wx.ALIGN_CENTER_VERTICAL )
        panel.sizer.Add(wx.Size(0,15))

        sb = wx.StaticBox( panel, -1, text.standbyTime )
        boxSizer = wx.StaticBoxSizer( sb, wx.VERTICAL )
        
        gridSizer = wx.GridBagSizer(5, 5)
        rowCount = 0
        gridSizer.Add( doNotTriggerCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        rowCount += 1
        gridSizer.Add( useDefaultCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        rowCount += 1
        gridSizer.Add( triggerSpecialCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        gridSizer.Add( standbyTimeCtrl, (rowCount, 1), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        boxSizer.Add( gridSizer, flag = wx.TOP, border = 5 )
        panel.sizer.Add( boxSizer )
        
        onRadioButton(wx.CommandEvent())
        onCheckBox(wx.CommandEvent())

        
        while panel.Affirmed() :
            applicationName   = applicationNameCtrl.GetValue()
            enableRelease     = releaseCheckBoxCtrl.GetValue()
            maxTime           = releaseTimeCtrl.GetValue()
            countUp           = countUpCheckBoxCtrl.GetValue()
            mode              = useDefaultCtrl.GetValue() + triggerSpecialCtrl.GetValue() * 2
            standbyTime       = standbyTimeCtrl.GetValue()
            resetAfterStandby = resetCheckBoxCtrl.GetValue()
            panel.SetResult( 
                            applicationName, 
                            countUp, 
                            mode, 
                            standbyTime, 
                            enableRelease, 
                            maxTime,
                            resetAfterStandby
                            )

        plugin.lastApplicationName = applicationName
        plugin.addApplicationNames( applicationName )




class EnableStandbyByApplication( eg.ActionClass ) :

    def __call__(
                self,
                applicationName = None ,
                resetCounter = True ,
                modePending = 0 ,
                standbyTimePending = 60.0 ,
                modeStandby = 0,
                standbyTime = 600.0
                ) :

        # modePending == 0:    doNotTrigger
        # modePending == 1:    triggerPendingDefault
        # modePending == 2:    triggerStandbyDefault
        # modePending == 3:    triggerSpecialValue

        # modeStandby == 0:    doNotTrigger
        # modeStandby == 1:    triggerStandbyDefault
        # modeStandby == 2:    triggerSpecialValue

        plugin = self.plugin
        
        if not plugin.started :
            eg.PrintError(plugin.text.notStarted)
            return False
            
        if resetCounter :
            countMode = 3
        else :
            countMode = 2
            
        status = plugin.setCounter( applicationName, countMode )

        time = 0.0
        
        if status.getEnabled():
            if modePending != 0 :
                if modePending == 1 :
                    time = plugin.standbyTimePendingDefault
                elif modePending == 2 :
                    time = plugin.standbyTimeDefault
                else :
                    time = standbyTimePending
        else :
            if modeStandby != 0 :
                if modeStandby == 1 :
                    time = plugin.standbyTimeDefault
                else :
                    time = standbyTime

        plugin.checkAndEnable( time )

        plugin.triggerTimer( time )

        return True



    def Configure(
                self,
                applicationName = None ,
                resetCounter = True ,
                modePending = 0 ,
                standbyTimePending = 60.0 ,
                modeStandby = 0,
                standbyTime = 600.0
                ) :


        def onRadioButtonGroup1( event ) :
            enable = triggerSpecialPendingCtrl.GetValue()
            standbyTimePendingCtrl.Enable( enable )
            event.Skip()


        def onRadioButtonGroup2( event ) :
            enable = triggerSpecialCtrl.GetValue()
            standbyTimeCtrl.Enable( enable )
            event.Skip()


        text = self.text
        plugin = self.plugin
        
        if applicationName :
            plugin.addApplicationNames( applicationName )
        
        panel = eg.ConfigPanel(self)
        
        if not applicationName :
            applicationName = plugin.lastApplicationName
            
        applicationNameCtrl = wx.ComboBox(
                                        panel,
                                        -1,
                                        value=applicationName,
                                        choices=plugin.getApplicationNames(),
                                        size=(200,-1)
                                        )

        #define controls

        resetCheckBoxCtrl = wx.CheckBox(panel, -1, text.resetCheckBox)
        resetCheckBoxCtrl.SetValue( resetCounter )

        doNotPendingCtrl = wx.RadioButton(panel, -1, text.doNotPending, style = wx.RB_GROUP)
        doNotPendingCtrl.SetValue( modePending == 0 )
        doNotPendingCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButtonGroup1)

        usePendingCtrl = wx.RadioButton(panel, -1, text.pendingCheckBox )
        usePendingCtrl.SetValue( modePending == 1 )
        usePendingCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButtonGroup1)
        
        useStandbyCtrl = wx.RadioButton(panel, -1, text.defaultCheckBox )
        useStandbyCtrl.SetValue( modePending == 2 )
        useStandbyCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButtonGroup1)
        
        triggerSpecialPendingCtrl = wx.RadioButton(panel, -1, text.pendingSpecial )
        triggerSpecialPendingCtrl.SetValue( modePending == 3 )
        triggerSpecialPendingCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButtonGroup1)
        
        standbyTimePendingCtrl = panel.SpinNumCtrl( standbyTimePending, min=5, max=99999, fractionWidth=0, integerWidth=5)
                

        doNotTriggerCtrl = wx.RadioButton(panel, -1, text.doNotTrigger, style = wx.RB_GROUP)
        doNotTriggerCtrl.SetValue( modeStandby == 0 )
        doNotTriggerCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButtonGroup2)

        useDefaultCtrl = wx.RadioButton(panel, -1, text.defaultCheckBox )
        useDefaultCtrl.SetValue( modeStandby == 1 )
        useDefaultCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButtonGroup2)
        
        triggerSpecialCtrl = wx.RadioButton(panel, -1, text.triggerSpecial )
        triggerSpecialCtrl.SetValue( modeStandby == 2 )
        triggerSpecialCtrl.Bind(wx.EVT_RADIOBUTTON, onRadioButtonGroup2)
        
        standbyTimeCtrl = panel.SpinNumCtrl( standbyTime, min=0, max=99999, fractionWidth=0, integerWidth=5)


        #paint
        boxSizer = wx.BoxSizer( wx.HORIZONTAL )

        boxSizer.Add( wx.StaticText(panel, -1, text.applicationName), flag = wx.RIGHT | wx.ALIGN_CENTER_VERTICAL, border = 10 )
        boxSizer.Add( applicationNameCtrl, flag = wx.ALIGN_CENTER_VERTICAL )
        
        panel.sizer.Add( boxSizer )

        panel.sizer.Add(wx.Size( 0, 15))
        panel.sizer.Add( resetCheckBoxCtrl, flag = wx.ALIGN_CENTER_VERTICAL )
        panel.sizer.Add(wx.Size( 0, 15))

        sbO = wx.StaticBox( panel, -1, text.standbyTime )
        boxSizerO = wx.StaticBoxSizer( sbO, wx.HORIZONTAL )
        
        sb = wx.StaticBox( panel, -1, text.pendingText )
        boxSizer = wx.StaticBoxSizer( sb, wx.VERTICAL )

        gridSizer = wx.GridBagSizer(5, 5)
        rowCount = 0
        gridSizer.Add( doNotPendingCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        rowCount += 1
        gridSizer.Add( usePendingCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        rowCount += 1
        gridSizer.Add( useStandbyCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        rowCount += 1
        gridSizer.Add( triggerSpecialPendingCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        gridSizer.Add( standbyTimePendingCtrl, (rowCount, 1), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        boxSizer.Add( gridSizer, flag = wx.TOP, border = 5 )
        
        boxSizerO.Add( boxSizer, flag = wx.TOP, border = 3 )
        

        sb = wx.StaticBox( panel, -1, text.standbyText )
        boxSizer = wx.StaticBoxSizer( sb, wx.VERTICAL )
        
        gridSizer = wx.GridBagSizer(5, 5)
        rowCount = 0
        gridSizer.Add( doNotTriggerCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        rowCount += 1
        gridSizer.Add( useDefaultCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        rowCount += 1
        gridSizer.Add( triggerSpecialCtrl, (rowCount, 0), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        gridSizer.Add( standbyTimeCtrl, (rowCount, 1), flag = wx.LEFT | wx.ALIGN_CENTER_VERTICAL )
        boxSizer.Add( gridSizer, flag = wx.TOP, border = 5 )

        boxSizerO.Add( boxSizer, flag = wx.TOP, border = 3 )
        panel.sizer.Add( boxSizerO )
        
        onRadioButtonGroup1(wx.CommandEvent())
        onRadioButtonGroup2(wx.CommandEvent())

        
        while panel.Affirmed() :
            applicationName    = applicationNameCtrl.GetValue()
            resetCounter       = resetCheckBoxCtrl.GetValue()
            modePending        = (  usePendingCtrl.GetValue()
                                 + useStandbyCtrl.GetValue() * 2
                                 + triggerSpecialPendingCtrl.GetValue() * 3
                                 )
            standbyTimePending = standbyTimePendingCtrl.GetValue()
            modeStandby        = useDefaultCtrl.GetValue() + triggerSpecialCtrl.GetValue() * 2
            standbyTime        = standbyTimeCtrl.GetValue()
            panel.SetResult( applicationName, resetCounter, modePending, standbyTimePending, modeStandby, standbyTime )

        plugin.lastApplicationName = applicationName
        plugin.addApplicationNames( applicationName )




class WasTriggered( eg.ActionClass ) :

    @eg.LogIt
    def __call__( self ) :
        result = self.plugin.triggered
        self.plugin.triggered = False
        return result




class CountDownOSD( eg.ActionClass ) :

    @eg.LogIt
    def __init__( self ) :
        self.started = False
        self.plugin.countDownOSD = self



    def __call__(
        self, 
        osdText="", 
        fontInfo=None,
        foregroundColour=(255, 255, 255), 
        backgroundColour=(0, 0, 0),
        alignment=0, 
        offset=(0, 0), 
        displayNumber=0, 
        skin=None,
        
        countDownTime=3.0,
        startValue = 120,
        endValue = 0,
        interval = 1,
        countDownFinishEvent = "OSDCountDownFinished",
        useExternalOSD = False,
        alternativeOSD = ""
        ) :
        
        if self.started :
            self.thread.finish()
            self.thread.join()

        self.thread = DisplayOSD(
                    self.plugin,
                    self,
                    osdText, 
                    fontInfo,
                    foregroundColour, 
                    backgroundColour,
                    alignment, 
                    offset, 
                    displayNumber, 
                    skin,

                    countDownTime,
                    startValue,
                    endValue,
                    interval,
                    countDownFinishEvent,
                    useExternalOSD,
                    alternativeOSD
                    )
                    
        self.thread.start()



    def OSDCancel( self ) :
        if self.started :
            self.thread.finish()



    def OnClose(self):
        if self.started :
            self.thread.OnClose()



    def Configure(
                self,
                osdText="", 
                fontInfo=None,
                foregroundColour=(255, 255, 255), 
                backgroundColour=(0, 0, 0),
                alignment=0, 
                offset=(0, 0), 
                displayNumber=0, 
                skin=None,

                countDownTime=3.0,
                startValue = 120,
                endValue = 0,
                interval = 1,
                countDownFinishEvent = "OSDCountDownFinished",
                useExternalOSD = False,
                alternativeOSD = ""
                ) :


        def OnCheckBox(event):
            backgroundColourButton.Enable(outlineCheckBox.IsChecked())
            event.Skip()


        def OnCheckBoxExternalOSD( event ) :
            enable = useExternalOSDCheckBox.IsChecked()
            alignmentChoice.Enable( not enable )
            displayChoice.Enable( not enable )
            xOffsetCtrl.Enable( not enable )
            yOffsetCtrl.Enable( not enable )
            fontButton.Enable( not enable )
            foregroundColourButton.Enable( not enable )
            outlineCheckBox.Enable( not enable )
            backgroundColourButton.Enable( not enable )
            skinCtrl.Enable( not enable )
            externalOSDCtrl.Enable( enable )
            if enable :
                backgroundColourButton.Enable( False )
            else :
                OnCheckBox(wx.CommandEvent())

            event.Skip()


        if fontInfo is None:
            fontInfo = DEFAULT_FONT_INFO
        panel = eg.ConfigPanel(self)
        text = self.text
        eventTextCtrl = panel.TextCtrl(countDownFinishEvent )
        
        useExternalOSDCheckBox = wx.CheckBox(panel, -1, text.useExternal)
        useExternalOSDCheckBox.SetValue( useExternalOSD )
        externalOSDCtrl = panel.TextCtrl( alternativeOSD )

        editTextCtrl = panel.TextCtrl("\n\n", style=wx.TE_MULTILINE)
        w, h = editTextCtrl.GetBestSize()
        editTextCtrl.ChangeValue(osdText)
        editTextCtrl.SetMinSize((-1, h))
        
        alignmentChoice = panel.Choice(alignment, choices=text.alignmentChoices)
        displayChoice = eg.DisplayChoice(panel, displayNumber)
        xOffsetCtrl = panel.SpinIntCtrl(offset[0], -32000, 32000)
        yOffsetCtrl = panel.SpinIntCtrl(offset[1], -32000, 32000)
        timeCtrl = panel.SpinNumCtrl(countDownTime)
        startCtrl = panel.SpinNumCtrl(startValue)
        endCtrl = panel.SpinNumCtrl(endValue)
        intervalCtrl = panel.SpinNumCtrl(interval)
        
        fontButton = panel.FontSelectButton(fontInfo)
        foregroundColourButton = panel.ColourSelectButton(foregroundColour)
        
        if backgroundColour is None:
            tmpColour = (0,0,0)
        else:
            tmpColour = backgroundColour
        outlineCheckBox = panel.CheckBox(backgroundColour is not None, text.outlineFont)
        
        backgroundColourButton = panel.ColourSelectButton(tmpColour)
        skinCtrl = panel.CheckBox(bool(skin), text.skin)
        
        sizer = wx.GridBagSizer(5, 5)
        EXP = wx.EXPAND
        ACV = wx.ALIGN_CENTER_VERTICAL
        Add = sizer.Add
        
        rowCount = 0
        Add(wx.StaticText(panel, -1, text.eventText), (rowCount, 0), flag=ACV)
        Add(eventTextCtrl, (rowCount, 1), (1, 4), flag=EXP|ACV)
        
        rowCount += 1
        Add(useExternalOSDCheckBox, (rowCount, 1), (1, 4), flag=EXP|ACV)

        rowCount += 1
        Add(wx.StaticText(panel, -1, text.externalOSD), (rowCount, 0), flag=ACV)
        Add(externalOSDCtrl, (rowCount, 1), (1, 4), flag=EXP|ACV)

        rowCount += 1
        Add(wx.StaticText(panel, -1, text.headText), (rowCount, 1),(1,4), wx.ALIGN_BOTTOM |wx.ALIGN_CENTER)
        
        rowCount += 1
        Add(wx.StaticText(panel, -1, text.editText), (rowCount, 0), flag=ACV)
        Add(editTextCtrl, (rowCount, 1), (1, 4), flag=EXP)
        
        
        rowCount += 1
        sRowCount = rowCount
        Add(panel.StaticText(text.osdFont), (rowCount, 3), flag=ACV)
        Add(fontButton, (rowCount, 4))
        
        rowCount += 1
        Add(panel.StaticText(text.osdColour), (rowCount, 3), flag=ACV)
        Add(foregroundColourButton, (rowCount, 4))

        rowCount += 1
        Add(outlineCheckBox, (rowCount, 3), flag=EXP)
        Add(backgroundColourButton, (rowCount, 4))

        rowCount += 1
        Add(skinCtrl, (rowCount, 3))
        
        rowCount = sRowCount
        Add(panel.StaticText(text.alignment), (rowCount, 0), flag=ACV)
        Add(alignmentChoice, (rowCount, 1), flag=EXP)
        
        rowCount += 1
        Add(panel.StaticText(text.display), (rowCount, 0), flag=ACV)
        Add(displayChoice, (rowCount, 1), flag=EXP)
        
        rowCount += 1
        Add(panel.StaticText(text.xOffset), (rowCount, 0), flag=ACV)
        Add(xOffsetCtrl, (rowCount, 1), flag=EXP)
        
        rowCount += 1
        Add(panel.StaticText(text.yOffset), (rowCount, 0), flag=ACV)
        Add(yOffsetCtrl, (rowCount, 1), flag=EXP)
        
        rowCount += 1
        sRowCount = rowCount
        Add(panel.StaticText(text.start), (rowCount, 0), flag=ACV)
        Add(startCtrl, (rowCount, 1), flag=EXP)
            
        rowCount += 1
        Add(panel.StaticText(text.end), (rowCount, 0), flag=ACV)
        Add(endCtrl, (rowCount, 1), flag=EXP)
            
        rowCount = sRowCount
        Add(panel.StaticText(text.wait), (rowCount, 3), flag=ACV)
        Add(timeCtrl, (rowCount, 4), flag=EXP)
            
        rowCount += 1
        Add(panel.StaticText(text.interval), (rowCount, 3), flag=ACV)
        Add(intervalCtrl, (rowCount, 4), flag=EXP)

        sizer.AddGrowableCol(2)
        panel.sizer.Add(sizer, 1, wx.EXPAND)
        
        outlineCheckBox.Bind(wx.EVT_CHECKBOX, OnCheckBox)
        useExternalOSDCheckBox.Bind(wx.EVT_CHECKBOX, OnCheckBoxExternalOSD)
        
        OnCheckBoxExternalOSD(wx.CommandEvent())

        while panel.Affirmed():
            if outlineCheckBox.IsChecked():
                outlineColour = backgroundColourButton.GetValue()
            else:
                outlineColour = None
            panel.SetResult(
                editTextCtrl.GetValue(),
                fontButton.GetValue(), 
                foregroundColourButton.GetValue(), 
                outlineColour,
                alignmentChoice.GetValue(),
                (xOffsetCtrl.GetValue(), yOffsetCtrl.GetValue()),
                displayChoice.GetValue(),
                skinCtrl.GetValue(),
                timeCtrl.GetValue(),
                startCtrl.GetValue(),
                endCtrl.GetValue(),
                intervalCtrl.GetValue(),
                eventTextCtrl.GetValue(),
                useExternalOSDCheckBox.GetValue(),
                externalOSDCtrl.GetValue()
            )




class CancelOSDCountDown( eg.ActionClass ) :

    @eg.LogIt
    def __call__( self ) :
        self.plugin.OSDCancel()
