######################################## Register ############################################
eg.RegisterPlugin(
    name = "Sonos",
    author = "Jostein",
    version = "First",
    kind = "program",
    canMultiLoad = True,
    description = "Adds actions to control Sonos",
    createMacrosOnAdd = True,    
)
###################################### Import ###############################################
import eg
import win32api

###################################### Plugin Base #########################################
class Sonos(eg.PluginBase):

        
########## Config box
    def Configure(self, uuid="uuid:RINCON_000E583EABEC01400"):
        Uuidinput = "Insert your full uuid of the Sonos zone you want to control."
        panel = eg.ConfigPanel()
        UuidLabel = wx.StaticText(panel, -1, Uuidinput)
        textControl = wx.TextCtrl(panel, -1, uuid, size=(200, -1))
        panel.sizer.Add(UuidLabel,0,wx.TOP,15)
        panel.sizer.Add(textControl, 0, wx.TOP,1)
        while panel.Affirmed():
            panel.SetResult(textControl.GetValue())

########## init self
    def __init__(self):
        self.ZPCMD = eg.folderPath.ProgramFiles+'\\EventGhost\\plugins\\Sonos\\ZPCMD.exe'
        self.SonosWatcher = eg.folderPath.ProgramFiles+'\\EventGhost\\plugins\\Sonos\\SonosWatcher.exe'
        self.SonosEG = eg.folderPath.ProgramFiles+'\\EventGhost\\EventGhost.exe'
        self.WindowsRegvr = eg.folderPath.Windows+'\\syswow64\\regsvr32.exe'
        self.WindowsScrobj = eg.folderPath.Windows+'\\syswow64\\scrobj.dll'
        self.ZonePlayerController = eg.folderPath.ProgramFiles+'\\EventGhost\\plugins\\Sonos\\WSC\\ZonePlayerController\\ZonePlayerController.wsc'
        self.ZonePlayerFinder = eg.folderPath.ProgramFiles+'\\EventGhost\\plugins\\Sonos\\WSC\\ZonePlayerFinder\\ZonePlayerFinder.wsc'
        self.UniqueDeviceNames = eg.folderPath.ProgramFiles+'\\EventGhost\\plugins\\Sonos\\UniqueDeviceNames.wsc'
        self.AddActionsFromList(ACTIONS
        )

########## start self       
    def __start__(self, uuid=""):
        self.uuid = uuid
        

################################################ Actions ############################################

class Play(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Play")
        except: pass

        
class Pause(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Pause")
        except: pass
        
        
class Next(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Next")
        except: pass

        
class Previous(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Previous")
        except: pass

        
class Stop(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Stop")
        except: pass
        
class Volume0(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Volume0")
        except: pass

        
class Volume25(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Volume25")
        except: pass
        
        
class Volume50(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Volume50")
        except: pass        
        
class Volume75(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Volume75")
        except: pass

        
class Volume100(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Volume100")
        except: pass
        
        
class Unmute(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Unmute")
        except: pass

        
class Mute(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.ZPCMD + " " + self.plugin.uuid + " /Mute")
        except: pass

        
class Feedback(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.SonosWatcher + " /UDN " + self.plugin.uuid + " /OnPlay " + self.plugin.SonosEG + " -e Sonos_Play /OnPause " + self.plugin.SonosEG + " -e Sonos_paused /OnMute " + self.plugin.SonosEG + " -e Sonos_Mute /OnUnmute " + self.plugin.SonosEG + " -e Sonos_Un_Mute /OnVolumeIncrease " + self.plugin.SonosEG + " -e Sonos_Volume_Increase /OnVolumeDecrease " + self.plugin.SonosEG + " -e Sonos_Volume_Decrease")
        except: pass
        
        
class RegisterWSC(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.WindowsRegvr + " /i:" + '"' + self.plugin.ZonePlayerController + '"' + " " + '"' + self.plugin.WindowsScrobj + '"')
        except: pass
        
        
class UniqueDeviceNames(eg.ActionBase):

    def __call__(self):
        try: win32api.WinExec(self.plugin.UniqueDeviceNames)
        except: pass
        
  
########################################### Auto add Actions #####################################

ACTIONS = (    
    (Play,"Play","Play","Play Sonos.", None),
    (Pause,"Pause","Pause","Pause Sonos.", None),
    (Next,"Next","Next","Next Sonos.", None),
    (Previous,"Previous","Previous","Previous Sonos.", None),
    (Stop,"Stop","Stop","Stop Sonos.", None),
    (Volume0,"Volume0","Volume0","Volume0 Sonos.", None),
    (Volume25,"Volume25","Volume25","Volume25 Sonos.", None),
    (Volume50,"Volume50","Volume50","Volume50 Sonos.", None),
    (Volume75,"Volume75","Volume75","Volume75 Sonos.", None),
    (Volume100,"Volume100","Volume100","Volume100 Sonos.", None),
    (Unmute,"Unmute","Unmute","Unmute Sonos.", None),
    (Mute,"Mute","Mute","Mute Sonos.", None),
    (Feedback,"Feedback","Feedback","Feedback Sonos.", None),
    (RegisterWSC,"RegisterWSC","RegisterWSC","RegisterWSC Sonos.", None),
    (UniqueDeviceNames,"UniqueDeviceNames","UniqueDeviceNames","UniqueDeviceNames Sonos.", None),
)