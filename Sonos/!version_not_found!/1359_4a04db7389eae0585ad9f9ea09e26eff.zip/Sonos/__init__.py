######################################## Register ############################################
eg.RegisterPlugin(
    name = "Sonos",
    author = ".",
    version = ".",
    kind = "program",
    canMultiLoad = True,
    description = ".",
    createMacrosOnAdd = True,    
)
###################################### Import ###############################################
import eg
from xml.dom.minidom import parse, parseString
import httplib


###################################### Plugin Base #########################################
class Sonos(eg.PluginBase):

        
########## Config box
    def Configure(self, IP="IP of Sonos device"):
        IPinput = "Insert the IP of the Sonos device you want to control."
        panel = eg.ConfigPanel()
        IPLabel = wx.StaticText(panel, -1, IPinput)
        textControl = wx.TextCtrl(panel, -1, IP, size=(200, -1))
        panel.sizer.Add(IPLabel,0,wx.TOP,15)
        panel.sizer.Add(textControl, 0, wx.TOP,1)
        while panel.Affirmed():
            panel.SetResult(textControl.GetValue())

########## init self
    def __init__(self):
        self.AddActionsFromList(ACTIONS
        )

########## start self       
    def __start__(self, IP=""):
        self.IP = IP
        

################################################ Actions ############################################

class Play(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Play xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Play>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Play"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending PLAY to ", host
        res = conn.getresponse()
        print res.status, res.reason


class Pause(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Pause xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Pause>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Pause"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending Pause to ", host
        res = conn.getresponse()
        print res.status, res.reason
 

class Stop(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Stop xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Stop>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Stop"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending Stop to ", host
        res = conn.getresponse()
        print res.status, res.reason 


class Next(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Next xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Next>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Next"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending Next to ", host
        res = conn.getresponse()
        print res.status, res.reason


class Previous(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Previous xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Previous>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Previous"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending Previous to ", host
        res = conn.getresponse()
        print res.status, res.reason

        
class VolumUp(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/RenderingControl/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        volume = 5
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:SetRelativeVolume xmlns:u="urn:schemas-upnp-org:service:RenderingControl:1">
                 <InstanceID>0</InstanceID>
                 <Channel>Master</Channel>
                 <Adjustment>+''' + str(volume) +'''</Adjustment>
              </u:SetRelativeVolume>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:RenderingControl:1#SetRelativeVolume"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })


class VolumDown(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/RenderingControl/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        volume = -5
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:SetRelativeVolume xmlns:u="urn:schemas-upnp-org:service:RenderingControl:1">
                 <InstanceID>0</InstanceID>
                 <Channel>Master</Channel>
                 <Adjustment>+''' + str(volume) +'''</Adjustment>
              </u:SetRelativeVolume>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:RenderingControl:1#SetRelativeVolume"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })



########################################### Auto add Actions #####################################

ACTIONS = (    
    (Play,"Play","Play","Play Sonos.", None),
    (Pause,"Pause","Pause","Pause Sonos.", None),
    (Stop,"Stop","Stop","Stop Sonos.", None),
    (Next,"Next","Next","Next Sonos.", None),
    (Previous,"Previous","Previous","Previous Sonos.", None),
    (VolumUp,"VolumUp","VolumUp","VolumUp Sonos.", None),
    (VolumDown,"VolumDown","VolumDown","VolumDown Sonos.", None),
)