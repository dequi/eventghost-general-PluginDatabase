######################################## Register ############################################
eg.RegisterPlugin(
    name = "Sonos",
    author = ".",
    version = ".",
    kind = "program",
    canMultiLoad = True,
    description = ".",
    createMacrosOnAdd = True,    
)
###################################### Import ###############################################
import eg
from xml.dom.minidom import parse, parseString
import httplib
import wx.lib
from socket import *
import time

###################################### Functions ###########################################
def SearchForSonos(self):
    try:
        s = socket(AF_INET, SOCK_DGRAM)
        s.settimeout(2)#very important if useing while loop to receive all responses,if this is removed, loop occurs
        s.bind(('', 5001))
        s.setsockopt(SOL_SOCKET, SO_BROADCAST, 1)
        data = 'M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: "ssdp:discover"\r\nMX: 3\r\nST: urn:schemas-upnp-org:device:ZonePlayer:1\r\n\r\n'
        s.sendto(data, ('239.255.255.250', 1900))
        print "Searching for SONOS ZonePlayers on network..."
        time.sleep(1)
        #if i do a full search, i can get the zp type it's the only thing in ( )
        data, srv_sock = s.recvfrom(65565)
        #while True:#look until timeout
        #    data, srv_sock = s.recvfrom(65565)              
        #    if not data: break
        #    srv_addr = srv_sock[0]
        #    usn_id = ""
        #    print "USN: %s IP: %s" % (usn_id, srv_addr)
        s.close
        print "socket closed"
    
        zpInfo = {}
        host = srv_sock[0]
        port = 1400
        hostport = host + ":" + str(port)
        path = "/ZoneGroupTopology/Control HTTP/1.1"
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "requsting group info..."
        res = conn.getresponse()
        print res.status, res.reason
        xmlstring = res.read()
        #for some reason the encoding isn't working, need to figure this out, for now this works
        xmlstring = xmlstring.replace('&gt;',">").replace('&lt;',"<").replace('&quot;','"')
        #print xmlstring
        xml = parseString(xmlstring)
        grouplist = xml.getElementsByTagName('ZoneGroup')
        print "SONOS ZonePlayers found:"
        for zg in grouplist:
            #print zg.attributes['Coordinator'].value
            coordinator = zg.attributes['Coordinator'].value
            zplist = zg.getElementsByTagName('ZoneGroupMember')
            for zp in zplist:
                #print "" + zp.attributes['UUID'].value
                #print "   " + zp.attributes['Location'].value.split("/")[2].split(":")[0]
                #print "   Coordinator - " + coordinator
                attrlist = dict(zp.attributes.items())
                #for attr, value in attrlist:
                #    print "     " + attr + "= " + value
                #print attrlist['UUID'] + " (" + attrlist['ZoneName'] + ") " + attrlist['Location'].split("/")[2].split(":")[0]
                #print "     coordinator: " + coordinator
                uuid = attrlist['UUID']
                if uuid not in zpInfo:
                    zpInfo[uuid] = {}
                zpInfo[uuid]['ip'] = attrlist['Location'].split("/")[2].split(":")[0]
                #zpInfo[uuid]['coordinator'] = coordinator
                zpInfo[uuid]['name'] = attrlist['ZoneName']
                if "Invisible" in attrlist:
                    #print "    " + "ZP is invisible"
                    zpInfo[uuid]['invisible'] = 1
                    print '{0: <27}'.format(uuid) + '{0: <17}'.format(zpInfo[uuid]['ip']) + zpInfo[uuid]['name'] + " (Invisible)"
                else:
                    #print "    " + "ZP is visible"
                    zpInfo[uuid]['invisible'] = 0
                    #print uuid + " " + zpInfo[uuid]['ip'] + "  " + zpInfo[uuid]['name']
                    print '{0: <27}'.format(uuid) + '{0: <17}'.format(zpInfo[uuid]['ip']) + zpInfo[uuid]['name']
                #if uuid == zpInfo[uuid]['coordinator']:
                #    print "    Coordinator"
                #else:
                #    print "    Slave"
        return zpInfo
                
    except Exception, e:
        print "error occurred"
        print e
    
###################################### Plugin Base #########################################
class Sonos(eg.PluginBase):

        
########## Config box
    #def Configure(self, ZP_l={}):
    #    IPinput = "Insert the IP of the Sonos device you want to control."
    #    panel = eg.ConfigPanel()
    #    IPLabel = wx.StaticText(panel, -1, IPinput)
    #    textControl = wx.TextCtrl(panel, -1, IP, size=(200, -1))
    #    panel.sizer.Add(IPLabel,0,wx.TOP,15)
    #    panel.sizer.Add(textControl, 0, wx.TOP,1)
    #    while panel.Affirmed():
    #        panel.SetResult(textControl.GetValue())

########## init self
    def __init__(self):
        print "initializing SONOS plugin..."
        self.AddActionsFromList(ACTIONS
        )

########## start self       
    def __start__(self):
        print "SONOS plugin starting..."
        global zpList
        zpList = SearchForSonos(self)
        

################################################ Actions ############################################

class Play(eg.ActionBase):
    name = "Send SONOS PLay"
    description = "sends the play command to the ZP or the coordinator of the group the ZP is in."

    def __call__(self, uuid, zp_name):
        if uuid not in zpList:
            print "!!! zone player no longer in zpList (not found on network) !!!"
            print "either search the network again or update action"
            return
        print "sending Play..."
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = zpList[uuid]['ip']
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            coordinator = uuid
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Play xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Play>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Play"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending PLAY to ", zpList[coordinator]['name'] #host
        res = conn.getresponse()
        print res.status, res.reason
       
    def Configure(self, uuid="", zp_name=""):
        panel = eg.ConfigPanel()
        
        mySizer = wx.GridBagSizer(2, 1)
        mySizer.AddGrowableRow(1)
        mySizer.AddGrowableCol(0)
        
        panel.sizer.Add(mySizer, 1, flag = wx.EXPAND)
        
        TextZPSelect = wx.StaticText(panel, -1, "Select a Zone Player from the list below...", (12,15), (100,20))
        
        ChoiceList = []
        for k, v in zpList.iteritems():
            if v['invisible'] == 0:
                ChoiceList.append(v['name'] + "-" + k + "-" + v['ip'])
                #ChoiceList.append(k)
        ChoiceList.sort()
        ZPDropDown =  wx.Choice(panel, -1, (0,0), (100,20), choices=ChoiceList)
        
        #Identify the device and set dropdown to correct position
        p = 0
        try:
            p = ChoiceList.index(zpList[uuid]['name'] + "-" + uuid + "-" + zpList[uuid]['ip'])
            #p = ChoiceList.index(uuid)
            ZPDropDown.SetSelection(p)
        except: #ValueError:
            ZPDropDown.SetSelection(0)

        mySizer.Add(TextZPSelect, (0,0), flag = wx.EXPAND)
        mySizer.Add(ZPDropDown, (1,0), flag = (wx.ALIGN_TOP | wx.EXPAND))
        #print ZPDropDown.GetCurrentSelection()
        while panel.Affirmed():
            #FinalChoice = ZPDropDown.GetCurrentSelection()
            FinalChoice = ZPDropDown.GetStringSelection()
            panel.SetResult(
                #FinalChoice,
                #zpList[FinalChoice]['name']
                FinalChoice.split("-")[1], #save only the uuid from the list.
                FinalChoice.split("-")[0]
            )


class Pause(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Pause xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Pause>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Pause"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending Pause to ", host
        res = conn.getresponse()
        print res.status, res.reason
 

class Stop(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Stop xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Stop>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Stop"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending Stop to ", host
        res = conn.getresponse()
        print res.status, res.reason 


class Next(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Next xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Next>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Next"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending Next to ", host
        res = conn.getresponse()
        print res.status, res.reason


class Previous(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:GetMediaInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
              </u:GetMediaInfo>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#GetMediaInfo"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "finding coordinator of group.."
        res = conn.getresponse()
        print res.status, res.reason
        xml = res.read()
        dom = parseString(xml)
        uri = dom.getElementsByTagName('CurrentURI')[0].childNodes[0].nodeValue
        if uri.find("x-rincon:RINCON_") == 0:
            coordinator = uri.split(":")[1]
            print "current ZP is a slave, coordinator is ", coordinator
            path = "/ZoneGroupTopology/Control HTTP/1.1"
            xml = '''<?xml version="1.0" encoding="utf-8"?>
            <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
               <s:Body>
                  <u:GetZoneGroupState xmlns:u="urn:schemas-upnp-org:service:ZoneGroupTopology:1" />
               </s:Body>
            </s:Envelope>'''
            conn = httplib.HTTPConnection(host,port)
            conn.request("POST", path, body=xml, headers = {
                "Host": hostport,
                "SOAPACTION": '''"urn:schemas-upnp-org:service:ZoneGroupTopology:1#GetZoneGroupState"''',
                "Content-Type": "text/xml; charset=UTF-8",
                "Content-Length": len(xml)
            })
            print "requsting group info..."
            res = conn.getresponse()
            print res.status, res.reason
            xml = res.read()
            index = xml.find('UUID=&quot;'+coordinator)
            host = xml[index+57:index+86].split(":")[1].replace("//","")
        else:
            print "current zp is coordinator"

        path = "/MediaRenderer/AVTransport/Control HTTP/1.1"
        hostport = host + ":" + str(port)
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:Previous xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                 <InstanceID>0</InstanceID>
                 <Speed>1</Speed>
              </u:Previous>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:AVTransport:1#Previous"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })
        print "sending Previous to ", host
        res = conn.getresponse()
        print res.status, res.reason

        
class VolumUp(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/RenderingControl/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        volume = 5
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:SetRelativeVolume xmlns:u="urn:schemas-upnp-org:service:RenderingControl:1">
                 <InstanceID>0</InstanceID>
                 <Channel>Master</Channel>
                 <Adjustment>+''' + str(volume) +'''</Adjustment>
              </u:SetRelativeVolume>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:RenderingControl:1#SetRelativeVolume"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })


class VolumDown(eg.ActionBase):

    def __call__(self):
        path = "/MediaRenderer/RenderingControl/Control HTTP/1.1"
        host = self.plugin.IP
        port = 1400
        hostport = host + ":" + str(port)
        volume = -5
        xml = '''<?xml version="1.0" encoding="utf-8"?>
        <s:Envelope s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
           <s:Body>
              <u:SetRelativeVolume xmlns:u="urn:schemas-upnp-org:service:RenderingControl:1">
                 <InstanceID>0</InstanceID>
                 <Channel>Master</Channel>
                 <Adjustment>+''' + str(volume) +'''</Adjustment>
              </u:SetRelativeVolume>
           </s:Body>
        </s:Envelope>'''
        conn = httplib.HTTPConnection(host,port)
        conn.request("POST", path, body=xml, headers = {
            "Host": hostport,
            "SOAPACTION": '''"urn:schemas-upnp-org:service:RenderingControl:1#SetRelativeVolume"''',
            "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": len(xml)
        })

#    def Configure(self, SceneName="", SceneNum=""):
#        panel = eg.ConfigPanel()
#        
#        mySizer = wx.GridBagSizer(2, 1)
#        mySizer.AddGrowableRow(1)
#        mySizer.AddGrowableCol(0)
#
#        panel.sizer.Add(mySizer, 1, flag = wx.EXPAND)
#        
#        
#        TextSceneAddInfo = wx.StaticText(panel, -1, "Select a scene from the list below...", (12,15), (100,20))
#        
#        ChoiceList = []
#        for i in range(len(Scenes)):
#            ChoiceList.append(Scenes[i][0])
#        ChoiceList.sort()
#        SceneDropDown =  wx.Choice(panel, -1, (0,0), (100,20), choices=ChoiceList)
#        
#        #Identify the scene and set dropdown to correct position
#        p = 0
#        try:
#            p = ChoiceList.index(SceneName)
#            SceneDropDown.SetSelection(p)
#        except ValueError:
#            SceneDropDown.SetSelection(0)
#
#        mySizer.Add(TextSceneAddInfo, (0,0), flag = wx.EXPAND)
#        mySizer.Add(SceneDropDown, (1,0), flag = (wx.ALIGN_TOP | wx.EXPAND))
#        
#        while panel.Affirmed():
#            FinalChoice = SceneDropDown.GetCurrentSelection()
#            panel.SetResult(
#                Scenes[FinalChoice][0],
#                Scenes[FinalChoice][1]
#            )
#

########################################### Auto add Actions #####################################

ACTIONS = (    
    (Play,"Play","Play","Send Play to ZonePlayer.", None),
    (Pause,"Pause","Pause","Pause Sonos.", None),
    (Stop,"Stop","Stop","Stop Sonos.", None),
    (Next,"Next","Next","Next Sonos.", None),
    (Previous,"Previous","Previous","Previous Sonos.", None),
    (VolumUp,"VolumUp","VolumUp","VolumUp Sonos.", None),
    (VolumDown,"VolumDown","VolumDown","VolumDown Sonos.", None),
)