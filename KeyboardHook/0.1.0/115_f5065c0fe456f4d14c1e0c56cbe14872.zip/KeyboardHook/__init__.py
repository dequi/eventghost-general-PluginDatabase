# KeyboardHook plugin test for EventGhost
# 27.11.2009 by jinxdone
# 
"""<rst>
This plugin generates events on keypresses (hotkeys).

This is a non-blocking keyboard hook. It generates events closely following how
the standard EG Keyboard plugin works.
"""


import eg, pyHook

eg.RegisterPlugin(
    name = "KeyboardHook",
    author = "jinxdone",
    version = "0.1.0",
    kind = "remote",
    description = __doc__,
    canMultiLoad=False,
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeT"
        "AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH1QQIDBMjdIFglwAAADV0RVh0Q29t"
        "bWVudAAoYykgMjAwNCBKYWt1YiBTdGVpbmVyCgpDcmVhdGVkIHdpdGggVGhlIEdJTVCQ"
        "2YtvAAABfklEQVQ4y6WSv0sCYRjHP2+IGlI0GOeN4WQJQnd/gENbRHtTji2NIkhTROLa"
        "EATh0hpE0OTmKNzgQUpDFEhdmosNVw3d2yB3+HYXRX3h5Xnf7/v8fh7BL1CrHywASSAN"
        "uMAAeK2Uq56IUFwFtoAH4BG4AZ6BJ+AF+KiUq55vE/sS7Ai4Ag6Bh0q5+vZTdqJWP1gD"
        "mj/oWYARwe/EgObG+qZMpxcFgBACKSVCKNUZ/t80ThsnxzEATcuIfr//bXjbtslmlxQu"
        "lZpTe2DbtqKgaRqDwUDhEokG7+8lEokGsKs6KBQKOI6Drus4jkMmk0FKGbxvb+/IZkt4"
        "nsR93WZ+kgAzvoNpY13XGY/HigSIx5Mkk7Pc390TGuO0cZQE6PV6of4EDjqdDgDD4TBS"
        "AuRyOSzLYnllOeCCEkzTxHVdTNNUDkA+n8d13ck8DYPudTecQavVUuQ02u32ZJssK7qE"
        "0WhEsVhESomUEiB09zwvWDKf9x3sX1ye7/E3nPFffAJVOqjtMbQazAAAAABJRU5ErkJg"
        "gg=="
    ),
)

# keyidmap and keymap are there so we can rename and reorder certain keys
# to generate exactly identical events as the standard EG Keyboard plugin
keyidmap = {
    0xA0: 0x10, #VK_LSHIFT
    0xA1: 0x11, #VK_RSHIFT
    0xA2: 0x12, #VK_LCONTROL
    0xA3: 0x13, #VK_RCONTROL
    0xA4: 0x14, #VK_MENU (Left alt)
    0xA5: 0x15, #VK_RMENU (Right alt)
    0x5B: 0x16, #VK_LWIN
    0x5C: 0x17, #VK_RWIN
    0x5D: 0x18, #VK_APPS (windows right-click-menu button)
    }
    
keymap = {
    'Lshift': 'LShift',
    'Rshift': 'RShift',
    'Lcontrol': 'LCtrl',
    'Rcontrol': 'RCtrl',
    'Lmenu': 'LAlt',
    'Rmenu': 'RAlt',
    }


class KeyboardHook(eg.PluginBase):
    
    def __init__(self):
        self.hm = pyHook.HookManager()
        self.hm.KeyDown = self.OnKeyDown
        self.hm.KeyUp = self.OnKeyUp
        self.pressedkeys = []
        self.pressedkeyids = []
        
    
    def __start__(self, *dummyArgs):
        self.hm.HookKeyboard()
     
        
    def __stop__(self):
        self.hm.UnhookKeyboard()
        
    # adds pressed keys to pressedkeyids and pressedkeys lists
    # in order to generate identical events as the keyboard plugin
    def OnKeyDown(self, keyevent):
        if keyevent.Key in keymap:
            key = keymap[keyevent.Key]
        else:
            key = keyevent.Key
        if not key in self.pressedkeys:
            if keyevent.KeyID in keyidmap:
                keyid = keyidmap[keyevent.KeyID]
                #print "Remapped key", keyevent.KeyID, "to", keyid
            else:
                keyid = keyevent.KeyID
            i = 0
            for id in self.pressedkeyids:
                if keyid < id:
                    break
                else:
                    i += 1
            self.pressedkeyids.insert(i, keyid)
            self.pressedkeys.insert(i, key)
            #print '+'.join(self.pressedkeys)
            self.TriggerEnduringEvent('+'.join(self.pressedkeys))
        return True
        
    # removes released keys from pressedkeyids and pressedkeys lists
    def OnKeyUp(self, keyevent):
        if keyevent.Key in keymap:
            key = keymap[keyevent.Key]
        else:
            key = keyevent.Key       
        if keyevent.KeyID in keyidmap:
            keyid = keyidmap[keyevent.KeyID]
            #print "Remapped key", keyevent.KeyID, "to", keyid
        else:
            keyid = keyevent.KeyID
        if len(self.pressedkeys) > 0:
            try: self.pressedkeys.remove(key)
            except: pass
            try: self.pressedkeyids.remove(keyid)
            except: pass
            if len(self.pressedkeys) > 0:
                #print '+'.join(self.pressedkeys)
                self.TriggerEnduringEvent('+'.join(self.pressedkeys))
                return True
        self.EndLastEvent()
        return True