
########################################################
import re
import wx
import eg
import threading
import time

import warnings
with warnings.catch_warnings():
  warnings.simplefilter("ignore", category=DeprecationWarning)
  import xmpp

########################################################

users = []

########################################################

import win32api
import win32con
from ctypes import windll
user = windll.user32

########################################################

eg.RegisterPlugin(
  name          = "XMPP",
  author        = "Daniel Faust",
  kind          = "remote",
  version       = "1.0.0",
  canMultiLoad  = False,
  description   = ("Receives events sent to a XMPP account"),
)

########################################################

def nindex(mystr, substr, n=0, index=0):
  for _ in xrange(n+1):
    index = mystr.index(substr, index) + 1
  return index - 1

########################################################

def get_segments(jid):
  match = re.search("(.+?)/((.+?)[.|/](.+)|.+)", jid)
  if match:
    email     = None
    resource  = None
    device    = None
    unique    = None
    try:
      email     = match.group(1)
      resource  = match.group(2)
      device    = match.group(3)
      unique    = match.group(4)
    except:
      pass
    return [email, resource, device, unique]
  else:
    return [jid, None, None, None]

########################################################

client = None
account = None

########################################################
########################################################
########################################################
########################################################

class XMPP(eg.PluginClass):
  
  started = False
  stopped = False
  
  ########################################################
  def __init__(self):
    self.AddAction(SendXMPP)
  ########################################################
  def __start__(self, jid="username@gmail.com", password="password", resource="eg/", priority="63", status="chat", server="talk.google.com", port="5223"):
    global client
    global account
    
    self.started = True
    
    def presence_callback(client, event):
      (email, resource, device, id) = get_segments(str(event.getFrom()))
      if device == None:
        device = resource
      user = email+"/"+device
      if event.getType() == 'unavailable':
        if user in users:
          users.remove(user)
          self.TriggerEvent("Presence | Offline | %s" % user)
      else:
        if user not in users:
          users.append(user)
          self.TriggerEvent("Presence | Online | %s" % user)
    
    def message_callback(client, message):
      (email, resource, device, id) = get_segments(str(message.getFrom()))
      if device == None:
        device = resource
      self.TriggerEvent('Message | %s' % message.getBody())
      self.TriggerEvent('Message | %s | %s' % (email, message.getBody()))
      self.TriggerEvent('Message | %s | %s' % (email+"/"+device, message.getBody()))
    
    account  = jid
    username = "username"
    domain   = "gmail.com"    
    try:
      match = re.search("(.+)@(.+)", jid)
      if match:
        username  = match.group(1)
        domain    = match.group(2)
    except:
      pass
    
    client = xmpp.Client(domain, debug=False)
    client.connect(server=(server, int(port)))
    client.auth(username, password, resource=resource)
    client.RegisterHandler('message', message_callback)
    client.RegisterHandler('presence', presence_callback)
    client.sendInitPresence(requestRoster=1)
    client.send(xmpp.Presence(priority=int(priority), show=status))
    
    self.TriggerEvent("Login")
    #self.TriggerEvent("Login | %s" % account)
    
    startupEvent = threading.Event()
    self.thread = threading.Thread(
      target=self.ThreadLoop,
      name="EventGhostXMPPThread",
      args=(startupEvent,)
    )
    self.thread.start()
  
  ########################################################
  def ThreadLoop(self, startupEvent):
    global client
    try:
      self.stopped = False
      while self.started:
        client.Process(1)
      self.stopped = True
    except:
      pass
  
  ########################################################
  def __stop__(self):
    global client
    global account
    self.TriggerEvent("Logout")
    #self.TriggerEvent("Logout | %s" % account)
    time.sleep(1.0)
    self.started = False
    while not self.stopped:
      time.sleep(0.01)
    del client
    client = None
  
  ########################################################
  def Configure(self, jid="username@gmail.com", password="password", resource="eg/", priority="63", status="chat", server="talk.google.com", port="5223"):
    global client
    
    panel = eg.ConfigPanel()
    
    jidText = panel.StaticText("JID")
    jidCtrl = panel.TextCtrl(jid)
    
    pwdText = panel.StaticText("Password")
    pwdCtrl = panel.TextCtrl(password, style=wx.TE_PASSWORD)
    
    resText = panel.StaticText("Resource")
    resCtrl = panel.TextCtrl(resource)
    
    priText = panel.StaticText("Priority")
    priCtrl = panel.TextCtrl(priority)
    
    staText = panel.StaticText("Status")
    staCtrl = panel.TextCtrl(status)
    
    srvText = panel.StaticText("Server")
    srvCtrl = panel.TextCtrl(server)
    
    prtText = panel.StaticText("Port")
    prtCtrl = panel.TextCtrl(port)
    
    sizer = wx.FlexGridSizer(9, 2, 5, 5)
    sizer.AddGrowableCol(1)
    sizer.Add(jidText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(jidCtrl, 0, wx.EXPAND)
    sizer.Add(pwdText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(pwdCtrl, 0, wx.EXPAND)
    sizer.Add(panel.StaticText(""), 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(panel.StaticText(""), 0, wx.EXPAND)
    sizer.Add(resText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(resCtrl, 0, wx.EXPAND)
    sizer.Add(priText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(priCtrl, 0, wx.EXPAND)
    sizer.Add(staText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(staCtrl, 0, wx.EXPAND)
    sizer.Add(panel.StaticText(""), 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(panel.StaticText(""), 0, wx.EXPAND)
    sizer.Add(srvText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(srvCtrl, 0, wx.EXPAND)
    sizer.Add(prtText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(prtCtrl, 0, wx.EXPAND)
    panel.sizer.Add(sizer, 0, wx.EXPAND)
    
    while panel.Affirmed():
      panel.SetResult(
        jidCtrl.GetValue(),
        pwdCtrl.GetValue(),
        resCtrl.GetValue(),
        priCtrl.GetValue(),
        staCtrl.GetValue(),
        srvCtrl.GetValue(),
        prtCtrl.GetValue()
      )

########################################################
########################################################
########################################################
########################################################

class SendXMPP(eg.ActionBase):
  
  name = "Send Message"
  description   = ("Send a message to a XMPP account")
  
  ########################################################
  def __call__(self, message="", jid=""):
    global client
    if client:
      client.send(xmpp.Message(jid, message))
      
  ########################################################
  def Configure(self, message="", jid=""):
    panel = eg.ConfigPanel()
    jidText = panel.StaticText("JID")
    jidCtrl = panel.TextCtrl(jid)
    msgText = panel.StaticText("Message")
    msgCtrl = panel.TextCtrl(message)
    sizer = wx.FlexGridSizer(2, 2, 5, 5)
    sizer.AddGrowableCol(1)
    sizer.Add(jidText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(jidCtrl, 0, wx.EXPAND)
    sizer.Add(msgText, 0, wx.ALIGN_CENTER_VERTICAL)
    sizer.Add(msgCtrl, 0, wx.EXPAND)
    panel.sizer.Add(sizer, 0, wx.EXPAND)
    while panel.Affirmed():
      panel.SetResult(msgCtrl.GetValue(), jidCtrl.GetValue())
