# This file is part of EventGhost.
# Copyright (C) 2008 Lars-Peter Voss <bitmonster@eventghost.org>
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

ur"""<rst>
Plugin for the Twinhan USB Remote Control

|

.. image:: Twinhan.jpg
   :align: center

**Notice:** You need a special driver to use the remote with this plugin. 
Please `download it here`__ and install it while the device is connected.

__ http://www.eventghost.org/downloads/USB-Remote-Driver.exe
"""

import eg

eg.RegisterPlugin(
    name = "Twinhan USB Remote Control",
    author = "Bitmonster & Vadimz",
    version = "1.0.0",
    kind = "remote",
    description = __doc__,
)

CODES = {
    (0, 0, 29, 0): "Full Screen",
    (7, 0, 63, 0): "Power",
    (0, 0, 30, 0): "Num1",
    (0, 0, 31, 0): "Num2",
    (0, 0, 32, 0): "Num3",
    (0, 0, 33, 0): "Num4",
    (0, 0, 34, 0): "Num5",
    (0, 0, 35, 0): "Num6",
    (0, 0, 36, 0): "Num7",
    (0, 0, 37, 0): "Num8",
    (0, 0, 38, 0): "Num9",
    (0, 0, 39, 0): "Num0",
    (0, 0, 74, 0): "Record",
    (0, 0, 25, 0): "Favorite",
    (0, 0, 12, 0): "Rewind",
    (0, 0, 17, 0): "Forward",
    (0, 0, 75, 0): "CH+",
    (0, 0, 78, 0): "CH-",
    (0, 0, 40, 0): "Ok",
    (2, 0, 82, 0): "VOL+",
    (2, 0, 81, 0): "VOL-",
    (0, 0, 6, 0): "Recal",
    (0, 0, 77, 0): "Stop",
    (0, 0, 23, 0): "Pause",
    (0, 0, 16, 0): "Mute",
    (0, 0, 41, 0): "Cancel",
    (0, 0, 19, 0): "Capture",
    (0, 0, 14, 0): "Preview",
    (0, 0, 8, 0): "EPG",
    (0, 0, 15, 0): "Record List",
    (0, 0, 43, 0): "Tab",
    (0, 0, 4, 0): "Teletext",
}

class TwinhanRemote(eg.PluginBase):
                
    def __start__(self):
        self.usb = eg.WinUsbRemote("{72679574-1865-499d-B182-123456788391}", self.Callback, 4)
        if not self.usb.IsOk():
            raise self.Exceptions.DeviceNotFound

    def __stop__(self):
        self.usb.Close()

    def Callback(self, data):
        #print data
        value = data[:4]
        if value in CODES:
            self.TriggerEvent(CODES[value])
        else:
	    if data == (0, 0, 0, 0):
            	self.EndLastEvent()
	    else:	
		print(data)


