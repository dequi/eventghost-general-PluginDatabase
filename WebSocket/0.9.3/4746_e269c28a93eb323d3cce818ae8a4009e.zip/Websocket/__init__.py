import eg
eg.RegisterPlugin(
    name = "WebSocket",
    author = "cfull1",
    version = '0.9.3',
    kind = 'other',
    canMultiLoad = False,
    description = (
        "Creates a websocket server to provide a two-way connection, "
        "between EventGhost and webserver client."
    ),
)

# import wx
import time
import struct
import socket
import hashlib
import sys
from select import select
import re
from threading import Thread
import signal

class Text:
    tcpBox = "TCP/IP Settings"
    port = "Port:"
    host = "Host:"
    class SendMessageAll:
        parameterDescription = "Data to send to all clients:"

class WebSocketPlugin(eg.PluginBase):
    text = Text
    def __init__(self):
        self.AddAction(SendMessageAll)
        self.server = 0
    
    def __start__(self, host, port):
        self.server = WebSocketServer(host, port, WebSocket)
        server_thread = Thread(target=self.server.listen, args=[5])
        server_thread.start()
       
    def __stop__(self):
        self.server.running = False
        
    def Configure(self, host="", port=1235):
        text = self.text
        panel = eg.ConfigPanel()
        hostCtrl = panel.TextCtrl(host)
        portCtrl = panel.SpinIntCtrl(port)
        tcpBox = panel.BoxedGroup(
            text.tcpBox,
            (text.host, hostCtrl),
            (text.port, portCtrl),
        )
        eg.EqualizeWidths(tcpBox.GetColumnItems(0))
        panel.sizer.Add(tcpBox, 0, wx.EXPAND)
        while panel.Affirmed():
            panel.SetResult(
                hostCtrl.GetValue(),
                portCtrl.GetValue(), 
            )
            
    def SendAll(self, msg):
        for x in self.server.listeners[1:]:
            self.server.connections[x].send(msg)
        
class SendMessageAll(eg.ActionWithStringParameter):
    name = 'SendMessage'
    def __call__(self, msg):
        self.plugin.SendAll(msg)
        
class WebSocket(object):
    handshake = (
        "HTTP/1.1 101 Web Socket Protocol Handshake\r\n"
        "Upgrade: WebSocket\r\n"
        "Connection: Upgrade\r\n"
        "WebSocket-Origin: %(origin)s\r\n"
        "WebSocket-Location: ws://%(bind)s:%(port)s/\r\n"
        "Sec-Websocket-Origin: %(origin)s\r\n"
        "Sec-Websocket-Location: ws://%(bind)s:%(port)s/\r\n"
        "\r\n"
    )
    def __init__(self, client, server):
        self.client = client
        self.server = server
        self.handshaken = False
        self.header = ""
        self.data = ""
        self.userName = ""
        self.userDevice = ""
        self.userPayload = []
    def feed(self, data):
        if not self.handshaken:
            self.header += data
            if self.header.find('\r\n\r\n') != -1:
                parts = self.header.split('\r\n\r\n', 1)
                self.header = parts[0]
                if self.dohandshake(self.header, parts[1]):
                    # print "Handshake successful"
                    self.server.TriggerEvent('ClientConnected', self.userPayload)
                    self.handshaken = True
        else:
            self.data += data
            msgs = self.data.split('\xff')
            self.data = msgs.pop()
            for msg in msgs:
                if msg[0] == '\x00':
                    self.onmessage(msg[1:])

    def dohandshake(self, header, key=None):
        # print "Begin handshake:", header
        digitRe = re.compile(r'[^0-9]')
        spacesRe = re.compile(r'\s')
        part_1 = part_2 = origin = None
        for line in header.split('\r\n')[1:]:
            name, value = line.split(': ', 1)
            if name.lower() == "sec-websocket-key1":
                key_number_1 = int(digitRe.sub('', value))
                spaces_1 = len(spacesRe.findall(value))
                if spaces_1 == 0:
                    return False
                if key_number_1 % spaces_1 != 0:
                    return False
                part_1 = key_number_1 / spaces_1
            elif name.lower() == "sec-websocket-key2":
                key_number_2 = int(digitRe.sub('', value))
                spaces_2 = len(spacesRe.findall(value))
                if spaces_2 == 0:
                    return False
                if key_number_2 % spaces_2 != 0:
                    return False
                part_2 = key_number_2 / spaces_2
            elif name.lower() == "origin":
                origin = value
            elif name.lower() == "cookie":
                cookie = value.split(';')
                for x in cookie:
                    x.replace(' ', '')
                    temp = x.split('=')
                    if(temp[0].replace(' ', '') == 'username'):
                        if(temp[1] != ""):
                            self.userName = temp[1]
                            self.userPayload.append(temp[1])
                    elif(temp[0].replace(' ', '') == 'device'):
                        if(temp[1] != ""):
                            self.userDevice = temp[1]
                            self.userPayload.append(temp[1])
        if part_1 and part_2:
            # print("Using challenge + response")
            challenge = struct.pack('!I', part_1) + struct.pack('!I', part_2) + key
            response = hashlib.md5(challenge).digest()
            handshake = WebSocket.handshake % {
                'origin': origin,
                'port': self.server.port,
                'bind': self.server.bind
            }
            self.client.send(handshake)
            self.client.send(response)
        else:
            print ("Not using challenge + response")
            handshake = WebSocket.handshake % {
                'origin': origin,
                'port': self.server.port,
                'bind': self.server.bind
            }
            self.client.send(handshake)
        return True

    def onmessage(self, data):
        self.server.TriggerEvent('Message', data)

    def send(self, data):
        self.client.send("\x00")
        self.client.send(data)
        self.client.send("\xff")

    def close(self):
        self.client.close()

class WebSocketServer(object):
    def __init__(self, bind, port, cls):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind((bind, port))
        self.bind = bind
        self.port = port
        self.cls = cls
        self.connections = {}
        self.listeners = [self.socket]

    def listen(self, backlog=5):
        self.socket.listen(backlog)
        print 'Server Started on port:', self.port
        self.running = True
        while self.running:
            try:
                rList, wList, xList = select(self.listeners, [], self.listeners, 1)
                for ready in rList:
                    if ready == self.socket:
                        client, address = self.socket.accept()
                        fileno = client.fileno()
                        print 'New Client Connection',fileno
                        self.listeners.append(fileno)
                        self.connections[fileno] = self.cls(client, self)
                    else:
                        # print "Client ready for reading",ready
                        client = self.connections[ready].client
                        try:
                            data = client.recv(1024)
                            fileno = client.fileno()
                            if data:
                                for x in self.listeners[1:]:
                                    self.connections[x].feed(data)
                            else:
                                print "Closing Client",ready
                                self.TriggerEvent("ClientClosed", self.connections[fileno].userPayload)
                                self.connections[fileno].close()
                                del self.connections[fileno]
                                self.listeners.remove(ready)
                        except IOError as (errno, strerror):
                            print 'Removing Hard Closed Client'
                            for x in self.listeners[1:]:
                                if(self.connections[ready].client.fileno() == x):
                                    self.listeners.remove(x)
                            self.connections[ready].close()
                            del self.connections[ready]
                            
                for failed in xList:
                    if failed == self.socket:
                        print "Socket broke"
                        for fileno, conn in self.connections:
                            conn.close()
                        self.running = False
            except:
                print 'outside except'
                time.sleep(10)
        for x in self.listeners[1:]:
            self.connections[x].close()
        self.socket.close()
        self.socket = 0
        print 'Server Stopped'
        
    def TriggerEvent(self, data, Payload):
        if(len(Payload) == 0):
            eg.TriggerEvent(data, prefix="WebSocket")
        else:
            eg.TriggerEvent(data, prefix="WebSocket", payload=Payload)