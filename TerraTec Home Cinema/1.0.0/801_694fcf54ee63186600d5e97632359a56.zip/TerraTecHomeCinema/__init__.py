eg.RegisterPlugin(
    name="TerraTec Home Cinema",
    description="Adds actions to control TerraTec Home Cinema.",
    kind="program",
    author="BUddy",
    version="1.0.0",  
    createMacrosOnAdd = True,  
)

ACTIONS = (
(eg.ActionGroup, 'PlaybackControls', 'Playback Controls (Play, Timeshift, ...)', None,(
    #playback controls
    ("Play", "Play [SPACE]", "Video: Starts playback; Timeshift: Plays timeshift", "{Space}"),
    ("Pause", "Pause / Timeshift [MediaKey: PAUSE]", "Video: Pauses playback; Timeshift: enters timeshift mode, or pauses timeshift", "{Pause}"),
    ("Stop", "Stop [x]", "Video: Stops playback; Timeshift: Returns to live program; Note: You record simultaneously different streams. Press the key multible times to stop each.", "x"),
    ("Record", "Record [r]", "Records the actual TV / Radio - Programm", "r"),
    ("Previous", "Previous [l]", "VideoMode: Previous chapter; Timeschift: Jump to beginnig", "l"),
    ("Next", "Next [n]", "VideoMode: Next chapter; Timeschift: Jump to end", "n"),
    ("StepBackward", "Step backward [SHIFT + l]", "Goes to previous frame. Use Play to get to normal mode.", "{Shift+l}"),
    ("StepForward", "Step forward [SHIFT + n]", "Goes to next frame. Use Play to get to normal mode.", "{Shift+n}"),
 )),
(eg.ActionGroup, 'BasicControls', 'Basic Controls (Sound, Channel Selection, ...)', None,(
    #basic controls
    ("TerraTecHome", "TerraTec Home [o]", "View the home page. Let's you switch between functionalities", "o"),
    ("Mode", "Mode [TAB]", "Toogles TV -> Radio -> Records.", "{Tab}"),
    ("TeleText", "Tele text [t]", "Display the old school tele text", "t"),
    ("TeleTextSeperate", "Tele text seperate window [CRTL + t]", "Display the old school tele text in a seperate window.", "{Ctrl+t}"),
    ("ToggleFullscreen", "Toggle fullscreen [f]", "Toggles between fullscreen and window mode.", "f"),
    ("ChannelUp", "Channel up [PAGEUP]", "Switches one channel up", "{PageUp}"),
    ("ChannelDown", "Channel down [PAGEDOWN]", "Switches one channel down", "{PageDown}"),
    ("VolumeUp", "Volume Up [+]", "TerraTec Home Cinemas sound up", "{Add}"),
    ("VolumeDown", "Volume Down [-]", "Turn TerraTec Home Cinemas sound down ", "{Subtract}"),
    ("ToggleMute", "Toggle mute [m]", "Mute sound of TerraTec Home Cinema.", "m"),
    ("AspectRatio", "Toogle aspect ratio [<]", "Toogles between screen aspect ratios (4:3-original; 14:9-clipped; 16:9-clipped; 14:9-stretched; 16:9-stretched; free; automatic detection )", "<"),
    ("OptimalVideoSize", "Optimal video size [CTRL + o]", "Switches video window to the size defined in MPEG stream.", "{Ctrl+o}"),
    ("NextAudioStream", "Next audio stream [a]", "Switches among available audio streams.", "a"),
    ("NextSubtitle", "Next subtitle [b]", "Switches among available subtitles during playback.", "b"),
    ("ArrowUp", "Arrow Up [ARROWUP]", "", "{Up}"),
    ("ArrowDown", "Arrow Down [ARROWDOWN]", "", "{Down}"),
    ("ArrowLeft", "Arrow Left [ARROWLEFT]", "", "{Left}"),
    ("ArrowRight", "Arrow Right [ARROWRIGHT]", "", "{Right}"),
    ("Enter", "Enter [ENTER]", "", "{Enter}"),
    ("ColorKeyRed", "Red color Key [F5]", "Controls different actions, e.g. the color filds at the bottom of the tele text and in EPG.", "{F5}"),
    ("ColorKeyGreen", "Green color Key [F6]", "Controls different actions, e.g. the color filds at the bottom of the tele text and in EPG.", "{F5}"),
    ("ColorKeyYellow", "Yellow color Key [F7]", "Controls different actions, e.g. the color filds at the bottom of the tele text and in EPG.", "{F7}"),
    ("ColorKeyBlue", "Blue color Key [F8]", "Controls different actions, e.g. the color filds at the bottom of the tele text and in EPG.", "{F8}"),
    ("NumberKey1", "Number key 1", "", "1"),
    ("NumberKey2", "Number key 2", "", "2"),
    ("NumberKey3", "Number key 3", "", "3"),
    ("NumberKey4", "Number key 4", "", "4"),
    ("NumberKey5", "Number key 5", "", "5"),
    ("NumberKey6", "Number key 6", "", "6"),
    ("NumberKey7", "Number key 7", "", "7"),
    ("NumberKey8", "Number key 8", "", "8"),
    ("NumberKey9", "Number key 9", "", "9"),
    ("NumberKey0", "Number key 0", "", "0"),
)),
(eg.ActionGroup, 'EPG Controls', 'Electronic Program Guide', None,(	
    #EPG controls
	("EPG", "Electronic program guide [e]", "Displays the electronic program guide.", "e"),
	("Information", "EPG Information [i]", "Displays Information about actual programm. Press twice to display detailed information.", "i"),
    ("EpgSearch", "EPG Search [SHIFT + e]", "Opens a separate window where you can search within EPG data", "{Shift+e}"),
    ("EpgCurrent", "EPG all current broadcasts [CRTL + e]", "Displays the current broadcasts of all TV stations", "{Ctrl+e}"),
)),
(eg.ActionGroup, 'PIP Controls', 'Picture-In-Picture Controls', None,(
    #PIP controls
    ("PIP", "Picture-in-Picture [CRTL + ALT + p]", "Turn on Picture-in-Picture mode.", "{Ctrl+Alt+P}"),
    ("PIPtopLeft", "PIP top left [CRTL + 1]", "Displays Picture-in-Picture in top left position.", "{Ctrl+1}"),
    ("PIPtopMiddle", "PIP top middle [CRTL + 2]", "Displays Picture-in-Picture in top middle position.", "{Ctrl+2}"),
    ("PIPtopRight", "PIP top right [CRTL + 3]", "Displays Picture-in-Picture in top right position.", "{Ctrl+3}"),
    ("PIPmiddleLeft", "PIP middle left [CRTL + 4]", "Displays Picture-in-Picture in middle left position.", "{Ctrl+4}"),
    ("PIPmiddleMiddle", "PIP middle middle [CRTL + 5]", "Displays Picture-in-Picture in center position.", "{Ctrl+5}"),
    ("PIPmiddleRight", "PIP middle right [CRTL + 6]", "Displays Picture-in-Picture in middle right position.", "{Ctrl+6}"),
    ("PIPbottomLeft", "PIP bottom left [CRTL + 7]", "Displays Picture-in-Picture in bottom left position.", "{Ctrl+7}"),
    ("PIPbottomMiddle", "PIP bottom middle [CRTL + 8]", "Displays Picture-in-Picture in bottom middle position.", "{Ctrl+8}"),
    ("PIPtlbottomRight", "PIP bottom right [CRTL + 9]", "Displays Picture-in-Picture in bottom right position.", "{Ctrl+9}"),
    ("PIPSwitch", "Switch between PIP [z]", "Switchs between the pictures of PIP-Mode.", "z"),
)),
(eg.ActionGroup, 'External Controls', 'External Controls (Open Video Folder, ...)', None,(   
    #external controls
    ("OpenVideoFolder", "Open Video Folder", "Opens your Video Folder in Windows Explorer.", "{Ctrl+v}"),
    ("OpenPictureFolder", "Open Picture Folder", "Opens your Picture Folder in Windows Explorer.", "{Ctrl+p}"),
)),
(eg.ActionGroup, 'Special Controls', 'Special Controls (Signal Info, Exit, ...)', None,(    
    #special controls
    ("SignalInfo", "Signal Information [CRTL + i]", "Shows information of radio frequency signals power and quality.", "{Ctrl+i}"),
    ("OpenSettings", "Open settings [CRTL + s]", "Opens the settings dialog box.", "{Ctrl+s}"),
    ("HideVideoWin", "Hide / view video window [CRTL + x]", "Hides / viewes the video window, but sound keeps playing.", "{Ctrl+x}"),
    ("ContextMenu", "Context Menu [MENU]", "Shows the context menu with all controls.", "{Apps}"),
    ("Exit", "Exit TerraTec Home Cinema [ALT + F4]", "Exits TerraTec Home Cinema. Maybe recordings an timers me be lost.", "{Alt+F4}")
)),

)

from eg.WinApi.SendKeys import SendKeys

gWindowMatcher = eg.WindowMatcher('CinergyDvr.exe')


class ActionPrototype(eg.ActionClass):
    
    def __call__(self):
        hwnds = gWindowMatcher()
        if hwnds:
            SendKeys(hwnds[0], self.value)
        else:
            raise self.Exceptions.ProgramNotRunning
        
        
        
class TerraTec(eg.PluginClass):
    
    def __init__(self):
        self.AddActionsFromList(ACTIONS, ActionPrototype)