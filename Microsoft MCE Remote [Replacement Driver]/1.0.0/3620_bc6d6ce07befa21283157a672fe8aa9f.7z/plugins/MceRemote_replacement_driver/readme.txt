Note: This plugin will most likely only work with the replacement driver
      http://www.team-mediaportal.com/files/Download/Drivers/Remotes/MCERemoteReplacementDriver/
      if you are not using XP/Server 2003 64-bit edition then you probably don't need this.


	  
Little hack to make the replacement driver working with
newer EventGhost version (0.3.7.r1076) on XP/Server 2003 64-bit editions.

I just used the old MceRemote plugin from 0.3.5c and changed
a few lines of code to make it working with the new EventGhost.
Also I added the new "MceIr.dll" wich seems to work.

Just remove the "MCE Remote" plugin and add the "MCE Remote [Replacement Driver]"
plugin to your configuration then restart EventGhost and it should work.



Best regards,
JustSomeUser