import eg
import time
import datetime
import httplib2
from oauth2client.file import Storage
from apiclient import discovery
from oauth2client import client

eg.RegisterPlugin(
	name = "GoogleCalendar2Timer",
	author = "Surio",
	version = "0.2.2",
	kind = "other",
	description = "Connect your personal Google Calendar to EG and feed the EG Timer plugin with Events. Requires the EG Timer plugin to be initialized first."
)

class GoogleCalendar2Timer(eg.PluginBase):

	def __init__(self):
		self.AddAction(GetCalendarEvents)
			
	def __start__(self, clientsecretpath, authtoken, developerKey):
		
		
		flow = client.flow_from_clientsecrets(
		clientsecretpath,
		scope='https://www.googleapis.com/auth/calendar.readonly',
		redirect_uri='urn:ietf:wg:oauth:2.0:oob')
		auth_uri = flow.step1_get_authorize_url()
		
		if not authtoken:
			auth_uri = flow.step1_get_authorize_url()
			print "Please allow: " + auth_uri

		storage = Storage('calendar.dat')
		credentials = storage.get()
		
		if credentials is None or credentials.invalid == True:
			credentials = flow.step2_exchange(authtoken)
			storage.put(credentials)

		http_auth = credentials.authorize(httplib2.Http())
		self.calService =  discovery.build(serviceName='calendar', version='v3', http=http_auth, developerKey=developerKey)


	def __stop__(self):
		print "GoogleCalendar2Timer is stopped."

	def __close__(self):
		print "GoogleCalendar2Timer is closed."		

	def Configure(self, clientsecretpath="", authtoken="", developerKey=""):
		panel = eg.ConfigPanel()

		clientsecretTextControl = panel.TextCtrl(clientsecretpath)
		authtokenTextControl = panel.TextCtrl(authtoken)
		devkeyTextControl = panel.TextCtrl(developerKey)


		sizer = wx.FlexGridSizer(rows=6, cols=2, hgap=10, vgap=5)
		sizer.Add(panel.StaticText("Client Secret File: "))
		sizer.Add(clientsecretTextControl)
		sizer.Add(panel.StaticText("Developer Key: "))
		sizer.Add(devkeyTextControl)
		sizer.Add(panel.StaticText("Auth Code: "))
		sizer.Add(authtokenTextControl)				
		
		border = wx.BoxSizer()
		border.Add(sizer, 0, wx.ALL, 10)
		panel.SetSizerAndFit(border)
		
		while panel.Affirmed():
			panel.SetResult(
				clientsecretTextControl.GetValue(),
				authtokenTextControl.GetValue(),
				devkeyTextControl.GetValue()
			)

class GetCalendarEvents(eg.ActionBase):

	def __call__(self, calenderid, startSuffix, endSuffix, intermediateSuffix, prefix):
		page_token = None
		#print time.localtime()
		#print time.localtime()[3]
		#print time.gmtime()
		#print time.gmtime()[3]
		
		#CheckIfDayOffset
		DayOffset = time.localtime()[2] - time.gmtime()[2]
		
		if DayOffset == 0:
			offset = time.localtime()[3] - time.gmtime()[3]
		elif DayOffset == 1:
			offset = time.localtime()[3] - time.gmtime()[3] + 24;
		elif DayOffset == -1:
			offset = time.localtime()[3] - time.gmtime()[3] - 24;

		#offset = (time.altzone/(-3600))
		#print (time.altzone/(-3600))
		#offset = 1
		#print offset
		
		if offset > 0 and offset<10:
			gUTCString = "+0"+str(offset)+":00"
		elif offset >=10:
			gUTCString = "+"+str(offset)+":00"
		elif offset <0 and offset > -10:
			gUTCString = "-0"+ (str(offset*(-1))) +":00"			
		elif offset <= -10:
			gUTCString = "-"+(str(offset*(-1))) +":00"						
			
		
		minTime =  datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%S'+gUTCString)
		maxTime = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S'+gUTCString)
		counter= 0;
		
		timersnap = []
		for item in eg.plugins.Timer.plugin.timerObjects:
			timersnap.append(item)
		
		for timer in timersnap:
			if timer[0:5] == prefix:
				eg.plugins.Timer.plugin.AbortTimer(timer)
		
		while True:
			events = self.plugin.calService.events().list(calendarId=calenderid, pageToken=page_token, singleEvents='true', timeMin=minTime, timeMax=maxTime).execute()
			for event in events['items']:
				if event['start']['dateTime'] > minTime and event['start']['dateTime'] < maxTime and startSuffix:
					eg.plugins.Timer.TimerAction(prefix+str(counter)+"_"+event['summary']+startSuffix, 0, 1, 1.0, event['summary']+startSuffix, False, False, 2, event['start']['dateTime'][11:18])
					counter+=1
				elif intermediateSuffix:
					eg.plugins.Timer.TimerAction(prefix+str(counter)+"_"+event['summary']+intermediateSuffix, 0, 1, 1.0, event['summary']+intermediateSuffix, False, False, 2, (datetime.datetime.fromtimestamp(time.time())+ datetime.timedelta(seconds=1)).strftime('%H:%M:%S'))
					counter+=1
				if event['end']['dateTime'] > minTime and event['end']['dateTime'] < maxTime and endSuffix:
					eg.plugins.Timer.TimerAction(prefix+str(counter)+"_"+event['summary']+endSuffix, 0, 1, 1.0, event['summary']+endSuffix, False, False, 2, event['end']['dateTime'][11:18])
					counter+=1
			page_token = events.get('nextPageToken')
			if not page_token:
				break
				
		
				
	def checkIfTimerNameExists(self,name):
		for item in eg.plugins.Timer.plugin.timerObjects:
			if item == name:
				return true
			else:
				return false

	def Configure(self, calenderid="",startSuffix="_Start", endSuffix="_End", intermediateSuffix="_Intermediate",prefix="GC2T_"):
		panel = eg.ConfigPanel()

		calenderidTextControl = panel.TextCtrl(calenderid)
		startsuffixTextControl = panel.TextCtrl(startSuffix)
		endsuffixTextControl = panel.TextCtrl(endSuffix)
		intermediatesuffixTextControl = panel.TextCtrl(intermediateSuffix)
		prefixTextControl = panel.TextCtrl(prefix)
		
		
		sizer = wx.FlexGridSizer(rows=4, cols=2, hgap=10, vgap=5)
		sizer.Add(panel.StaticText("Calendar ID: "))
		sizer.Add(calenderidTextControl)
		sizer.Add(panel.StaticText("Start suffix: "))
		sizer.Add(startsuffixTextControl)	
		sizer.Add(panel.StaticText("End suffix: "))
		sizer.Add(endsuffixTextControl)	
		sizer.Add(panel.StaticText("Intermediate suffix: "))
		sizer.Add(intermediatesuffixTextControl)			
		sizer.Add(panel.StaticText("Prefix: "))
		sizer.Add(prefixTextControl)			
		
		border = wx.BoxSizer()
		border.Add(sizer, 0, wx.ALL, 10)
		panel.SetSizerAndFit(border)
		
		while panel.Affirmed():
			panel.SetResult(
				calenderidTextControl.GetValue(),
				startsuffixTextControl.GetValue(),
				endsuffixTextControl.GetValue(),
				intermediatesuffixTextControl.GetValue(),
				prefixTextControl.GetValue()				
			)				
