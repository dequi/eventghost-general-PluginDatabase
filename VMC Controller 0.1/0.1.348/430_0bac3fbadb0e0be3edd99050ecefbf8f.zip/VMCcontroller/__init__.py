# This file is part of EventGhost.
# Copyright (C) 2005 Lars-Peter Voss <bitmonster@eventghost.org>
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#
# $LastChangedDate: 2008-06-26 12:06:42 +0100 (Di, 04 Mrz 2008) $
# $LastChangedRevision: 348 $
# $LastChangedBy: kingtd $


eg.RegisterPlugin(
    name = "VMC Controller 0.1",
    description = "Receives events from a Vista Media Center with the controller installed from http://www.codeplex.com/VmcController",
    kind = "external",
    version = "0.1." + "$LastChangedRevision: 348 $".split()[1],
    author = "kingtd (based off original code from Bitmonster)",
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QAAAAAAAD5Q7t/"
        "AAAACXBIWXMAAAsSAAALEgHS3X78AAAAB3RJTUUH1gIQFgQb1MiCRwAAAVVJREFUOMud"
        "kjFLw2AQhp8vif0fUlPoIgVx6+AgopNI3fwBViiIoOAgFaugIDhUtP4BxWDs4CI4d3MR"
        "cSyIQ1tDbcHWtjFI4tAWG5pE8ca7997vnrtP4BOZvW0dSBAcZ0pAMTEzPUs4GvMsVkvP"
        "6HktGWRAOBpjIXVNKOSWWdYXN7lFAAINhBCEQgqxyTHAAQQAD/dFbLurUYJYT7P7TI2C"
        "VavwIiZodyyaH6ZLo/RZVTXiOYVhGOh5jcpbq5eRAXAc5wdBVSPMLR16GtxdbgJgN95d"
        "OxicACG6bPH4uIu1UHjE7sFqR/NDVxhaoixLvFYbtDufNFtu1tzxgdeAaZfBU7ECTvd1"
        "WRlxsa4sp1ydkiRxkstmlEFRrWT4nrRer3vmlf6mb883fK8AoF1d+Bqc6Xkt+cufT6e3"
        "dnb9DJJrq+uYpunZ2WcFfA0ol8v8N5Qgvr/EN8Lzfbs+L0goAAAAAElFTkSuQmCC"
    ),
)


import asynchat
import asyncore
import socket



class Text:
    host = "Hostname/IP Address:"
    port = "Listen Port:" 
    controlport = "Command Port:" 
    eventPrefix = "Event Prefix:"
    tcpBox = "TCP/IP Settings"
    securityBox = "Security"
    eventGenerationBox = "Event generation"
    class Send:
	name="Send"


class VMCcontroller(asynchat.async_chat):
    """Telnet engine class. Implements command line user interface."""
    
    def __init__ (self, host, port, plugin):
      
	asynchat.async_chat.__init__(self)

        self.set_terminator("\n")

        self.data = ""
	self.host=host
	self.port=port
	self.plugin=plugin

        # connect to ftp server
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)

        eg.RestartAsyncore()
        self.connect((host, port))

    def handle_connect(self):
        # connection succeeded
	pass
	
    def handle_close(self):
	self.plugin.TriggerEvent("VMC Session Closed", str(self.host)+":"+str(self.port))
        self.close()

                  
    def handle_expt(self):
        # connection failed
	self.plugin.TriggerEvent("VMC Error", str(self.host)+":"+str(self.port))
        self.close()

    def collect_incoming_data(self, data):
        # received a chunk of incoming data
        self.data = self.data + data

    def found_terminator(self):
        # got a response line
        data = self.data
        if data.endswith("\r"):
            data = data[:-1]
        self.data = ""
	self.plugin.TriggerEvent(data)

class VMCcommander(asynchat.async_chat):
    """Telnet engine class. Implements command line user interface."""
    
    def __init__ (self, host, controlport, plugin):
      
	asynchat.async_chat.__init__(self)

        self.set_terminator("\n")

        self.data = ""
	self.host=host
	self.controlport=controlport
	self.plugin=plugin

        # connect to ftp server
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)

        eg.RestartAsyncore()
        self.connect((host, controlport))

    def handle_connect(self):
        # connection succeeded
	pass
	self.push("version\r\n")
	
    def handle_close(self):
	self.plugin.TriggerEvent("VMC Control Session Closed", str(self.host)+":"+str(self.controlport))
        self.close()

                  
    def handle_expt(self):
        # connection failed
	self.plugin.TriggerEvent("VMC Control Session Error", str(self.host)+":"+str(self.controlport))
        self.close()

    def collect_incoming_data(self, data):
        # received a chunk of incoming data
        self.data = self.data + data

    def found_terminator(self):
        # got a response line
        data = self.data
        if data.endswith("\r"):
            data = data[:-1]
        self.data = ""
	self.plugin.TriggerEvent(data)
	
    def vmcsend(self,data):	
	print("Executing command: "+data)
	self.push(data+"\r\n")


class VMCControl(eg.PluginClass):
    canMultiLoad = True
    text = Text

    def __init__(self):
        self.AddAction(self.Send)

    
    def __start__(self, host, port, controlport, prefix):
	self.host=host
	self.port=port
	self.controlport=controlport
        self.info.eventPrefix = prefix
	try:
            self.controller = VMCcontroller(self.host, self.port, self)
       	except socket.error, exc:
	    raise self.Exception(exc[1])

	try:
            self.commander = VMCcommander(self.host, self.controlport, self)
       	except socket.error, exc:
	    raise self.Exception(exc[1])
       
        
    def __stop__(self):
        if self.controller:
            self.controller.close()
        self.controller = None


    def Configure(self, host="pc008", port=40400, controlport=40500, prefix="VMC"):
        text = self.text
        panel = eg.ConfigPanel(self)
        
	hostCtrl = panel.TextCtrl(host)
        portCtrl = panel.SpinIntCtrl(port, max=65535)
        controlportCtrl = panel.SpinIntCtrl(controlport, max=65535)
        eventPrefixCtrl = panel.TextCtrl(prefix)
        st1 = panel.StaticText(text.host)
	st2 = panel.StaticText(text.port)
	st3 = panel.StaticText(text.controlport)
        st4 = panel.StaticText(text.eventPrefix)
        eg.EqualizeWidths((st1, st2, st3, st4))
        box1 = panel.BoxedGroup(text.tcpBox, (st1, hostCtrl), (st2, portCtrl), (st3, controlportCtrl))
        box2 = panel.BoxedGroup(text.eventGenerationBox, (st4, eventPrefixCtrl))
        panel.sizer.AddMany([
            (box1, 0, wx.EXPAND),
            (box2, 0, wx.EXPAND|wx.TOP, 10),

        ])
        
        while panel.Affirmed():
            panel.SetResult(
		hostCtrl.GetValue(),
                portCtrl.GetValue(),
		controlportCtrl.GetValue(), 
                eventPrefixCtrl.GetValue()
            )


    class Send(eg.ActionWithStringParameter):
	description = ("Sends a command through the ISY-26.")

	class Text:
	    action = "Action:" 

	def __call__(self, action):
		self.SendCommand(action)
		return True

	def SendCommand(self, action):
	    self.plugin.commander.vmcsend(action)

	def Configure(self, action=""):
	        text = self.text
	        panel = eg.ConfigPanel(self)
      
	        actionCtrl = panel.TextCtrl(action)
	        st1 = panel.StaticText("Command:")
	        box1 = panel.BoxedGroup("Command", (st1, actionCtrl))
	        panel.sizer.AddMany([
	            (box1, 0, wx.EXPAND)
	        ])
        
	        while panel.Affirmed():
	            panel.SetResult(
	                actionCtrl.GetValue(), 
	            )


