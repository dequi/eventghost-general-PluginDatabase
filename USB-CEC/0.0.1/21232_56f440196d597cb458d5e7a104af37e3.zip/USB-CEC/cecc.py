# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import cecenums
from collections import namedtuple
from ctypes import CDLL, windll, c_char, c_char_p, c_int, c_uint, c_int8
from ctypes import c_uint8, c_int16, c_uint16, c_int32, c_uint32, c_int64, c_uint64
from ctypes import c_void_p, pointer, POINTER, CFUNCTYPE, Structure, byref, WinError
from ctypes import sizeof
from datetime import datetime, timedelta

# ctypes definitions for libcec - Structures
class cec_device_type_list(Structure):
    _fields_ = [("types", c_int * 5)] # the list of device types
    def __init__(self):
        self.clear()
    def clear(self):
        self.types = (cecenums.cec_device_type.CEC_DEVICE_TYPE_RESERVED, ) * 5
    def add(self, devicetype):
        pos = next(
            (i for i in range(len(self.types)) if self.types[i] == cecenums.cec_device_type.CEC_DEVICE_TYPE_RESERVED),
            None)
        if pos is not None:
            self.types[pos] = devicetype
    def is_set(self, devicetype):
        return devicetype in self.types
    def is_empty(self):
        return next(
            (i for i in range(len(self.types)) if self.types[i] != cecenums.cec_device_type.CEC_DEVICE_TYPE_RESERVED),
            None) is None
    def __str__(self):
        return ''.join("\n>  {0}".format(
            cecenums.reverse_enum(
                cecenums.cec_device_type,
                i)
            ) for i in self.types if i != cecenums.cec_device_type.CEC_DEVICE_TYPE_RESERVED)
class cec_logical_addresses(Structure):
    _fields_ = [
        ("primary", c_int), # the primary logical address to use
        ("addresses", c_int * 16)] # the list of addresses
    def __init__(self, addresses = None):
        self.clear()
        if addresses:
            self.primary = addresses[0]
            self.addresses = tuple((i in addresses) for i in range(len(self.addresses)))
    def clear(self):
        self.primary = cecenums.cec_logical_address.CECDEVICE_BROADCAST # means CECDEVICE_UNREGISTERED here
        self.addresses = (False, ) * 16
    def set(self, address):
        if self.primary == cecenums.cec_logical_address.CECDEVICE_BROADCAST: # means CECDEVICE_UNREGISTERED here
            self.primary = address
        self.addresses[address] = True
    def unset(self, address):
        if self.primary == address:
            self.primary = cecenums.cec_logical_address.CECDEVICE_BROADCAST # means CECDEVICE_UNREGISTERED here
        self.addresses[address] = False
    def __str__(self):
        return (
            ">  {0}\n".format("\n>  ".join("{0}{1}".format(
                cecenums.reverse_enum(cecenums.cec_logical_address, i),
                " (primary)" if self.primary == i else ""
            ) for i in range(len(self.addresses)) if self.addresses[i])))
CecLogicalAddresses = namedtuple('CecLogicalAddresses', ("primary", "addresses"))
class cec_menu_language(Structure):
    _fields_ = [
        ("language", c_char * 4), # the iso language code. @bug the language code is only 3 chars long, not 4. will be changed in v2.0, because changing it now would break backwards compat
        ("device", c_int)] # the logical address of the device
CecMenuLanguage = namedtuple('CecMenuLanguage', ("language", "device"))
class cec_osd_name(Structure):
    _fields_ = [
        ("name", c_char * 14), # the name of the device
        ("device", c_int)] # the logical address of the device 
    def __str__(self):
        return "OSD name of device {0} is {1}".format(
            cecenums.reverse_enum(cecenums.cec_logical_address, self.device),
            self.name)
CecOSDName = namedtuple('CecOSDName', ("name", "device"))
class cec_log_message(Structure):
    _fields_ = [
        ("message", c_char * 1024), # the actual message
        ("level", c_uint), # log level of the message
        ("time", c_int64)] # the timestamp of this message
    def __str__(self):
        timestamp = timedelta(milliseconds = self.time)
        hours, remainder = divmod(timestamp.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        milliseconds = timestamp.microseconds // 1000
        return (
            "{0}: [{1:d}:{2:02d}:{3:02d}.{4:03d}] {5}".format(
                cecenums.reverse_enum(cecenums.cec_log_level, self.level),
                hours, minutes, seconds, milliseconds,
                self.message))
class cec_keypress(Structure):
    _fields_ = [
        ("keycode", c_int), # the keycode
        ("duration", c_int)] # the duration of the keypress
    def __str__(self):
        duration = timedelta(milliseconds = self.duration)
        return (
            "CEC Key Press: {0} [{1:02d}.{2:03d}s]".format(
                cecenums.reverse_enum(cecenums.cec_user_control_code, self.keycode),
                duration.seconds, duration.microseconds // 1000))
    def eventparam(self):
        duration = timedelta(milliseconds = self.duration)
        return (
            "{0}, {1:02d}.{2:03d}s".format(
                cecenums.reverse_enum(cecenums.cec_user_control_code, self.keycode),
                duration.seconds,
                duration.microseconds // 1000))
class cec_adapter(Structure):
    _fields_ = [
        ("path", c_char * 1024), # the path to the com port
        ("comm", c_char * 1024)] # the name of the com port
cec_adapter_arrayType = cec_adapter * 10
CecAdapter = namedtuple('CecAdapter', ("path", "comm"))
class cec_adapter_descriptor(Structure):
    _fields_ = [
        ("strComPath", c_char * 1024), # the path to the com port
        ("strComName", c_char * 1024), # the name of the com port
        ("iVendorId", c_uint16), 
        ("iProductId", c_uint16), 
        ("iFirmwareVersion", c_uint16), 
        ("iPhysicalAddress", c_uint16), 
        ("iFirmwareBuildDate", c_uint32), 
        ("adapterType", c_int)]
cec_adapter_descriptor_arrayType = cec_adapter_descriptor * 10
CecAdapterDescriptor = namedtuple('CecAdapterDescriptor', (
    "strComPath",
    "strComName",
    "iVendorId",
    "iProductId",
    "iFirmwareVersion",
    "iPhysicalAddress",
    "iFirmwareBuildDate",
    "adapterType"))
class cec_datapacket(Structure):
    _fields_ = [
        ("data", c_uint8 * 100), # the actual data
        ("size", c_uint8)] # the size of the data
    def __str__(self):
        return "".join(":{0:02x}".format(a) for a in self.data[:self.size])
    def clear(self):
        self.data = (0, ) * 100
        self.size = 0
    def set(self, data):
        ldata = data.replace(':', ' ').split(None)
        if len(ldata) > sizeof(self.data):
            raise ValueError
        self.data[:len(ldata)] = tuple(int(ldata[i], 16) for i in range(len(ldata)))
        self.size = len(ldata)
class cec_command(Structure):
    _fields_ = [
        ("initiator", c_int), # the logical address of the initiator of this message
        ("destination", c_int), # the logical address of the destination of this message
        ("ack", c_int8), # 1 when the ACK bit is set, 0 otherwise
        ("eom", c_int8), # 1 when the EOM bit is set, 0 otherwise
        ("opcode", c_int), # the opcode of this message
        ("parameters", cec_datapacket), # the parameters attached to this message
        ("opcode_set", c_int8), # 1 when an opcode is set, 0 otherwise (POLL message)
        ("transmit_timeout", c_int32)] # the timeout to use in ms
    def __init__(self,
                 commandstr = '',
                 timeout = None):
        self.clear()
        iter = (a for a in commandstr.split(':', 2))
        endpoints, opcode, parameters = (next(iter, None) for x in range(3))
        if endpoints is not None and len(endpoints) > 1:
            self.initiator = int(endpoints[0], 16)
            self.destination = int(endpoints[1], 16)
        if opcode is not None:
            self.opcode = int(opcode, 16)
            self.opcode_set = opcode != cecenums.cec_opcode.CEC_OPCODE_NONE
        if parameters is not None:
            self.parameters.set(parameters)
        if timeout is not None:
            self.transmit_timeout = timeout
    def __str__(self):
        return (
            " {initiatornum:1x}{destinationnum:1x}:{opcodenum:02x}{parameters}"
            "\n> {initiator} -> {destination} {opcode}{ack}{eom}{opcode_set};"
            "\n> timeout: {transmit_timeout}msec").format(
                initiator = cecenums.reverse_enum(cecenums.cec_logical_address, self.initiator),
                initiatornum = self.initiator,
                destination = cecenums.reverse_enum(cecenums.cec_logical_address, self.destination),
                destinationnum = self.destination,
                ack = " ack" if self.ack else "",
                eom = " eom" if self.eom else "",
                opcode = cecenums.reverse_enum(cecenums.cec_opcode, self.opcode),
                opcodenum = self.opcode,
                parameters = self.parameters,
                opcode_set = " opcode_set" if self.opcode_set else "",
                transmit_timeout = self.transmit_timeout)
    def clear(self):
        self.initiator        = cecenums.cec_logical_address.CECDEVICE_UNKNOWN
        self.destination      = cecenums.cec_logical_address.CECDEVICE_UNKNOWN
        self.ack              = 0
        self.eom              = 0
        self.opcode_set       = 0
        self.opcode           = cecenums.cec_opcode.CEC_OPCODE_FEATURE_ABORT
        self.transmit_timeout = 1000 #CEC_DEFAULT_TRANSMIT_TIMEOUT
        self.parameters.clear()
    def eventparam(self):
        return (
            "{initiatornum:1x}{destinationnum:1x}:{opcodenum:02x}{parameters}").format(
                initiatornum = self.initiator,
                destinationnum = self.destination,
                opcodenum = self.opcode,
                parameters = self.parameters)
class libcec_parameter(Structure):
    _fields_ = [
        ("paramType", c_int), # the type of this parameter
        ("paramData", c_char_p)] # the value of this parameter
    def __str__(self):
        return (
            "{0}{1}").format(
                "! " if self.paramType != cecenums.libcec_parameter_type.CEC_PARAMETER_TYPE_STRING else "",
                self.paramData)
    def eventparam(self):
        return (
            "{0}{1}").format(
                "! " if self.paramType != cecenums.libcec_parameter_type.CEC_PARAMETER_TYPE_STRING else "",
                self.paramData)
class libcec_configuration(Structure):
    def __init__(self,
                 device_name = None,
                 device_types = None,
                 wake_devices = None,
                 power_off_devices = None,
                 get_settings_from_ROM = None,
                 monitor_only = None,
                 callbacks = None):
        self.clear()
        if device_name:
            self.strDeviceName = device_name
        if device_types:
            for device in device_types:
                self.deviceTypes.add(device)
        self.wakeDevices = cec_logical_addresses(wake_devices)
        self.powerOffDevices = cec_logical_addresses(power_off_devices)
        if get_settings_from_ROM:
            self.bGetSettingsFromROM = get_settings_from_ROM
        if monitor_only:
            self.bMonitorOnly = monitor_only
        if callbacks:
            self.callbacks = pointer(callbacks)
    def clear(self):
        self.client_version = cecenums.cec_client_version.CEC_CLIENT_VERSION_2_2_0 # CEC_CLIENT_VERSION_CURRENT
        self.strDeviceName = ""
        self.deviceTypes.clear()
        self.bAutodetectAddress = 0
        self.iPhysicalAddress = 0 # CEC_PHYSICAL_ADDRESS_TV
        self.baseDevice = 0 # CEC_DEFAULT_BASE_DEVICE
        self.iHDMIPort = 1 # CEC_DEFAULT_HDMI_PORT
        self.tvVendor = cecenums.cec_vendor_id.CEC_VENDOR_UNKNOWN
        self.wakeDevices.clear()
        self.powerOffDevices.clear()
        self.serverVersion = cecenums.cec_server_version.CEC_SERVER_VERSION_2_2_0 # CEC_SERVER_VERSION_CURRENT
        self.bGetSettingsFromROM = 0 # CEC_DEFAULT_SETTING_GET_SETTINGS_FROM_ROM
        self.bUseTVMenuLanguage = 1 # CEC_DEFAULT_SETTING_USE_TV_MENU_LANGUAGE
        self.bActivateSource = 1 # CEC_DEFAULT_SETTING_ACTIVATE_SOURCE
        self.bPowerOffScreensaver = 1 # CEC_DEFAULT_SETTING_POWER_OFF_SCREENSAVER;
        self.bPowerOnScreensaver = 1 # CEC_DEFAULT_SETTING_POWER_ON_SCREENSAVER
        self.bPowerOffOnStandby = 1 # CEC_DEFAULT_SETTING_POWER_OFF_ON_STANDBY
        self.bSendInactiveSource = 1 # CEC_DEFAULT_SETTING_SEND_INACTIVE_SOURCE
        self.callbackParam = None
        self.callbacks = None
        self.logicalAddresses.clear()
        self.iFirmwareVersion = 0xFFFF # CEC_FW_VERSION_UNKNOWN
        self.bPowerOffDevicesOnStandby = 1 # CEC_DEFAULT_SETTING_POWER_OFF_DEVICES_STANDBY
        self.bShutdownOnStandby = 0 # CEC_DEFAULT_SETTING_SHUTDOWN_ON_STANDBY
        self.strDeviceLanguage = ("eng") # CEC_DEFAULT_DEVICE_LANGUAGE
        self.iFirmwareBuildDate = 0 # CEC_FW_BUILD_UNKNOWN
        self.bMonitorOnly = 0
        self.cecVersion = 0x05 # CEC_DEFAULT_SETTING_CEC_VERSION
        self.adapterType = 0 # ADAPTERTYPE_UNKNOWN
        self.iDoubleTapTimeout50Ms = 4 # CEC_DOUBLE_TAP_TIMEOUT_50_MS
        self.comboKey = 0x45 # CEC_USER_CONTROL_CODE_STOP
        self.iComboKeyTimeoutMs = 1000 # CEC_DEFAULT_COMBO_TIMEOUT_MS
    def __str__(self):
        return (
            "> Client Version: {client_version}\n"
            "> Device Name: '{strDeviceName:>13s}'\n"
            "> Device Types:{deviceTypes}\n"
            "> Autodetect Address: {bAutodetectAddress}\n"
            "> Physical Address: {iPhysicalAddress}\n"
            "> Base Device: {baseDevice}\n"
            "> HDMI Port: {iHDMIPort:}\n"
            "> TV Vendor: {tvVendor}\n"
            "> Wake Devices:\n{wakeDevices}"
            "> Power Off Devices:\n{powerOffDevices}"
            "> Server Version: {serverVersion}\n"
            "> Get Settings From ROM: {bGetSettingsFromROM}\n"
            "> Use TV Menu Language: {bUseTVMenuLanguage}\n"
            "> Activate Source: {bActivateSource}\n"
            "> Power Off Screensaver: {bPowerOffScreensaver}\n"
            "> Power On Screensaver: {bPowerOnScreensaver}\n"
            "> Power Off On Standby: {bPowerOffOnStandby}\n"
            "> Send Inactive Source: {bSendInactiveSource}\n"
            "> Callback Param: {callbackParam}\n"
            "> Callbacks: {callbacks}\n"
            "> Logical Addresses:\n{logicalAddresses}"
            "> Firmware Version: {iFirmwareVersion:#4x}\n"
            "> Power Off Devices On Standby: {bPowerOffDevicesOnStandby}\n"
            "> Shutdown On Standby: {bShutdownOnStandby}\n"
            "> Device Language: {strDeviceLanguage}\n"
            "> Firmware Build Date: {iFirmwareBuildDate}\n"
            "> Monitor Only: {bMonitorOnly}\n"
            "> CEC Version: {cecVersion}\n"
            "> Adapter Type: {adapterType}\n"
            "> Double Tap Timeout 50ms: {iDoubleTapTimeout50Ms}\n"
            "> Combo Key: {comboKey}\n"
            "> Combo Key Timeout: {iComboKeyTimeoutMs}ms").format(
                client_version = cecenums.reverse_enum(cecenums.cec_client_version, self.client_version),
                strDeviceName = self.strDeviceName,
                deviceTypes = self.deviceTypes,
                bAutodetectAddress = bool(self.bAutodetectAddress),
                iPhysicalAddress = '.'.join('{0}'.format(
                    int(c, 16)
                    ) for c in '{0:04x}'.format(self.iPhysicalAddress)),
                baseDevice = self.baseDevice,
                iHDMIPort = self.iHDMIPort,
                tvVendor = cecenums.reverse_enum(cecenums.cec_vendor_id, self.tvVendor),
                wakeDevices = self.wakeDevices,
                powerOffDevices = self.powerOffDevices,
                serverVersion = cecenums.reverse_enum(cecenums.cec_server_version, self.serverVersion),
                bGetSettingsFromROM = bool(self.bGetSettingsFromROM),
                bUseTVMenuLanguage = bool(self.bUseTVMenuLanguage),
                bActivateSource = bool(self.bActivateSource),
                bPowerOffScreensaver = bool(self.bPowerOffScreensaver),
                bPowerOnScreensaver = bool(self.bPowerOnScreensaver),
                bPowerOffOnStandby = bool(self.bPowerOffOnStandby),
                bSendInactiveSource = bool(self.bSendInactiveSource),
                callbackParam = self.callbackParam,
                callbacks = type(self.callbacks),
                logicalAddresses = self.logicalAddresses,
                iFirmwareVersion = self.iFirmwareVersion,
                bPowerOffDevicesOnStandby = bool(self.bPowerOffDevicesOnStandby),
                bShutdownOnStandby = bool(self.bShutdownOnStandby),
                strDeviceLanguage = self.strDeviceLanguage,
                iFirmwareBuildDate = datetime.fromtimestamp(self.iFirmwareBuildDate),
                bMonitorOnly = bool(self.bMonitorOnly),
                cecVersion = cecenums.reverse_enum(cecenums.cec_version, self.cecVersion),
                adapterType = cecenums.reverse_enum(cecenums.cec_adapter_type, self.adapterType),
                iDoubleTapTimeout50Ms = self.iDoubleTapTimeout50Ms,
                comboKey = cecenums.reverse_enum(cecenums.cec_user_control_code, self.comboKey),
                iComboKeyTimeoutMs = self.iComboKeyTimeoutMs)

# ctypes definitions for libcec - callbacks
CBCecLogMessageType = CFUNCTYPE(c_int, c_void_p, cec_log_message)
CBCecKeyPressType = CFUNCTYPE(c_int, c_void_p, cec_keypress)
CBCecCommandType = CFUNCTYPE(c_int, c_void_p, cec_command)
CBCecConfigurationChangedType = CFUNCTYPE(c_int, c_void_p, libcec_configuration)
CBCecAlertType = CFUNCTYPE(c_int, c_void_p, c_int, libcec_parameter)
CBCecMenuStateChangedType = CFUNCTYPE(c_int, c_void_p, c_int)
CBCecSourceActivatedType = CFUNCTYPE(None, c_void_p, c_int, c_uint8)
class ICECCallbacks(Structure):
    _fields_ = [
        ("CBCecLogMessage", CBCecLogMessageType),
        ("CBCecKeyPress", CBCecKeyPressType),
        ("CBCecCommand", CBCecCommandType),
        ("CBCecConfigurationChanged", CBCecConfigurationChangedType),
        ("CBCecAlert", CBCecAlertType),
        ("CBCecMenuStateChanged", CBCecMenuStateChangedType),
        ("CBCecSourceActivated", CBCecSourceActivatedType)]

# ctypes definitions for libcec - libcec_configuration fields
libcec_configuration._fields_ = [
    ("client_version", c_uint32), # the version of the client that is connecting
    ("strDeviceName", c_char * 13), # the device name to use on the CEC bus
    ("deviceTypes", cec_device_type_list), # the device type(s) to use on the CEC bus for libCEC
    ("bAutodetectAddress", c_uint8), # (read only) set to 1 by libCEC when the physical address was autodetected
    ("iPhysicalAddress", c_uint16), # the physical address of the CEC adapter
    ("baseDevice", c_int), # the logical address of the device to which the adapter is connected. only used when iPhysicalAddress = 0 or when the adapter doesn't support autodetection
    ("iHDMIPort", c_uint8), # the HDMI port to which the adapter is connected. only used when iPhysicalAddress = 0 or when the adapter doesn't support autodetection
    ("tvVendor", c_uint64), # override the vendor ID of the TV. leave this untouched to autodetect
    ("wakeDevices", cec_logical_addresses), # list of devices to wake when initialising libCEC or when calling PowerOnDevices() without any parameter
    ("powerOffDevices", cec_logical_addresses), # list of devices to power off when calling StandbyDevices() without any parameter
# 
    ("serverVersion", c_uint32), # the version number of the server. read-only
# 
#   player specific settings
    ("bGetSettingsFromROM", c_uint8), # true to get the settings from the ROM (if set, and a v2 ROM is present), false to use these settings
    ("bUseTVMenuLanguage", c_uint8), # use the menu language of the TV in the player application
    ("bActivateSource", c_uint8), # make libCEC the active source on the bus when starting the player application
    ("bPowerOffScreensaver", c_uint8), # put devices in standby mode when activating the screensaver
    ("bPowerOnScreensaver", c_uint8), # wake devices when deactivating the screensaver
    ("bPowerOffOnStandby", c_uint8), # put this PC in standby mode when the TV is switched off. only used when bShutdownOnStandby = 0
    ("bSendInactiveSource", c_uint8), # send an 'inactive source' message when stopping the player. added in 1.5.1
# 
    ("callbackParam", c_void_p), # the object to pass along with a call of the callback methods. NULL to ignore
    ("callbacks", POINTER(ICECCallbacks)), # the callback methods to use. set this to NULL when not using callbacks
# 
    ("logicalAddresses", cec_logical_addresses), # (read-only) the current logical addresses. added in 1.5.3
    ("iFirmwareVersion", c_uint16), # (read-only) the firmware version of the adapter. added in 1.6.0
    ("bPowerOffDevicesOnStandby", c_uint8), # put devices in standby when the PC/player is put in standby. added in 1.6.0
    ("bShutdownOnStandby", c_uint8), # shutdown this PC when the TV is switched off. only used when bPowerOffOnStandby = 0. added in 1.6.0
    ("strDeviceLanguage", c_char * 3), # the menu language used by the client. 3 character ISO 639-2 country code. see http://http://www.loc.gov/standards/iso639-2/ added in 1.6.2
    ("iFirmwareBuildDate", c_uint32), # (read-only) the build date of the firmware, in seconds since epoch. if not available, this value will be set to 0. added in 1.6.2
    ("bMonitorOnly", c_uint8), # won't allocate a CCECClient when starting the connection when set (same as monitor mode). added in 1.6.3
    ("cecVersion", c_int), # CEC spec version to use by libCEC. defaults to v1.4. added in 1.8.0
    ("adapterType", c_int), # type of the CEC adapter that we're connected to. added in 1.8.2
    ("iDoubleTapTimeout50Ms", c_uint8), # prevent double taps within this timeout, in units of 50ms. defaults to 200ms (value: 4). added in 2.0.0, XXX changed meaning in 2.2.0 to not break binary compatibility. next major (3.0) release will fix it in a nicer way
    ("comboKey", c_int), # key code that initiates combo keys. defaults to CEC_USER_CONTROL_CODE_F1_BLUE. CEC_USER_CONTROL_CODE_UNKNOWN to disable. added in 2.0.5
    ("iComboKeyTimeoutMs", c_uint32)] # timeout until the combo key is sent as normal keypress

# ctypes errcheck callables
def cec_find_adapters_errcheck(result, func, args):
    if result <= 0:
        raise WinError()
    # out deviceList, in iBufSize, in strDevicePath
    return result, tuple(CecAdapter(args[0][i].path, args[0][i].comm) for i in range(args[1]))
def cec_get_device_menu_language_errcheck(result, func, args):
    if result <= 0:
        raise WinError()
    # in iLogicalAddress, out language
    return CecMenuLanguage(args[1].language, args[1].device)
def cec_get_active_devices_errcheck(result, func, args):
    return CecLogicalAddresses(
        result.primary,
        tuple(
            bool(result.addresses[i]) for i in range(len(result.addresses))))
def cec_get_device_osd_name_errcheck(result, func, args):
    return CecOSDName(result.name, result.device)
def cec_get_logical_addresses_errcheck(result, func, args):
    return CecLogicalAddresses(
        result.primary,
        tuple(
            bool(result.addresses[i]) for i in range(len(result.addresses))))
def cec_get_current_configuration_errcheck(result, func, args):
    if result <= 0:
        raise WinError()
    # out configuration
    return args[0]
def cec_get_device_information_errcheck(result, func, args):
    if result <= 0:
        raise WinError()
    # in strPort, out config, in iTimeoutMs
    return args[1]
def cec_detect_adapters_errcheck(result, func, args):
    if result <= 0:
        raise WinError()
    # out deviceList, in iBufSize, in strDevicePath
    return result, tuple(CecAdapterDescriptor(
        args[0][i].strComPath,
        args[0][i].strComName,
        args[0][i].iVendorId,
        args[0][i].iProductId,
        args[0][i].iFirmwareVersion,
        args[0][i].iPhysicalAddress,
        args[0][i].iFirmwareBuildDate,
        args[0][i].adapterType
        ) for i in range(args[1]))

class LibCECDLL(CDLL):
    class CECFunctions(object):
        cec_initialise = (
            (c_int, POINTER(libcec_configuration)),
            ((1,"configuration"), ),
            None)
        cec_destroy = (
            (None, ),
            None,
            None)
        cec_open = (
            (c_int, c_char_p, c_uint32),
            ((1, "strPort"), (1, "iTimeout", 10000)),
            None)
        cec_close = (
            (None, ),
            None,
            None)
        cec_get_lib_info = (
            (c_char_p, ),
            None,
            None)
        cec_find_adapters = (
            (c_int8, POINTER(cec_adapter_arrayType), c_uint8, c_char_p),
            ((2, "deviceList"), (1, "iBufSize"), (1, "strDevicePath", None)),
            cec_find_adapters_errcheck)
        cec_detect_adapters = (
            (c_int8, POINTER(cec_adapter_descriptor_arrayType), c_uint8, c_char_p),
            ((2, "deviceList"), (1, "iBufSize"), (1, "strDevicePath", None)),
            cec_detect_adapters_errcheck)
        cec_enable_callbacks = (
            (c_int, c_void_p, POINTER(ICECCallbacks)),
            ((1, "cbParam"), (1, "callbacks")),
            None)
        cec_ping_adapters = (
            (c_int, ),
            None,
            None)
        cec_start_bootloader = (
            (c_int, ),
            None,
            None)
        cec_power_on_devices = (
            (c_int, c_int),
            ((1, "address", 0), ), # CECDEVICE_TV
            None)
        cec_standby_devices = (
            (c_int, c_int),
            ((1, "address", 15), ), # CECDEVICE_BROADCAST
            None)
        cec_set_active_source = (
            (c_int, c_int),
            ((1, "address", 2), ), # CEC_DEVICE_TYPE_RESERVED
            None)
        cec_set_deck_control_mode = (
            (c_int, c_int, c_int),
            ((1, "mode"), (1, "bSendUpdate", 1)),
            None)
        cec_set_deck_info = (
            (c_int, c_int, c_int),
            ((1, "info"), (1, "bSendUpdate", 1)),
            None)
        cec_set_inactive_view = (
            (c_int, ),
            None,
            None)
        cec_set_menu_state = (
            (c_int, c_int, c_int),
            ((1, "state"), (1, "bSendUpdate", 1)),
            None)
        cec_transmit = (
            (c_int, POINTER(cec_command)),
            ((1, "data"), ),
            None)
        cec_set_logical_address = (
            (c_int, c_int),
            ((1, "iLogicalAddress", 4), ), # CECDEVICE_PLAYBACKDEVICE1,
            None)
        cec_set_physical_address = (
            (c_int, c_uint16),
            ((1, "iPhysicalAddress", 0x1000), ), # CEC_DEFAULT_PHYSICAL_ADDRESS
            None)
        cec_set_osd_string = (
            (c_int, c_int, c_int, c_char_p),
            ((1, "iLogicalAddress"), (1, "duration"), (1, "strMessage")),
            None)
        cec_switch_monitoring = (
            (c_int, c_int),
            ((1, "bEnable"), ),
            None)
        cec_get_device_cec_version = (
            (c_int, c_int),
            ((1, "iLogicalAddress", 2), ),
            None)
        cec_get_device_menu_language = (
            (c_int, c_int, POINTER(cec_menu_language)),
            ((1, "iLogicalAddress"), (2, "language")),
            cec_get_device_menu_language_errcheck)
        cec_get_device_vendor_id = (
            (c_uint64, c_int),
            ((1, "iAddress"), ),
            None)
        cec_get_device_physical_address = (
            (c_uint16, c_int),
            ((1, "iAddress"), ),
            None)
        cec_get_active_source = (
            (c_int, ),
            None,
            None)
        cec_is_active_source = (
            (c_int, c_int),
            ((1, "iAddress"), ),
            None)
        cec_get_device_power_status = (
            (c_int, c_int),
            ((1, "iAddress"), ),
            None)
        cec_poll_device = (
            (c_int, c_int),
            ((1, "iAddress"), ),
            None)
        cec_get_active_devices = (
            (cec_logical_addresses, ),
            None,
            cec_get_active_devices_errcheck)
        cec_is_active_device = (
            (c_int, c_int),
            ((1, "iAddress"), ),
            None)
        cec_is_active_device_type = (
            (c_int, c_int),
            ((1, "type"), ),
            None)
        cec_set_hdmi_port = (
            (c_int, c_int, c_uint8),
            ((1, "iBaseDevice"), (1, "iPort", 1)), # CEC_DEFAULT_HDMI_PORT,
            None)
        cec_volume_up = (
            (c_int, c_int),
            ((1, "bSendRelease", 1), ), # true
            None)
        cec_volume_down = (
            (c_int, c_int),
            ((1, "bSendRelease", 1), ), # true
            None)
        cec_mute_audio = (
            (c_int, c_int),
            ((1, "bSendRelease", 1), ), # true
            None)
        cec_send_keypress = (
            (c_int, c_int, c_int, c_int),
            ((1, "iDestination"), (1, "key"), (1, "bWait", 1)), # true
            None)
        cec_send_key_release = (
            (c_int, c_int, c_int),
            ((1, "iDestination"), (1, "bWait", 1)), # true
            None)
        cec_get_device_osd_name = (
            (cec_osd_name, c_int),
            ((1, "iAddress"), ),
            cec_get_device_osd_name_errcheck)
        cec_set_stream_path_logical = (
            (c_int, c_int),
            ((1, "iAddress"), ),
            None)
        cec_set_stream_path_physical = (
            (c_int, c_uint16),
            ((1, "iPhysicalAddress"), ),
            None)
        cec_get_logical_addresses = (
            (cec_logical_addresses, ),
            None,
            cec_get_logical_addresses_errcheck)
        cec_get_current_configuration = (
            (c_int, POINTER(libcec_configuration)),
            ((2, "configuration"), ),
            cec_get_current_configuration_errcheck)
        cec_can_persist_configuration = (
            (c_int, ),
            None,
            None)
        cec_persist_configuration = (
            (c_int, POINTER(libcec_configuration)),
            ((1, "configuration"), ),
            None)
        cec_set_configuration = (
            (c_int, POINTER(libcec_configuration)),
            ((1, "configuration"), ),
            None)
        cec_rescan_devices = (
            (None, ),
            None,
            None)
        cec_is_libcec_active_source = (
            (c_int, ),
            None,
            None)
        cec_get_device_information = (
            (c_int, c_char_p, POINTER(libcec_configuration), c_uint32),
            ((1, "strPort"), (2, "config"), (1, "iTimeoutMs", 10000)),
            cec_get_device_information_errcheck)
        cec_init_video_standalone = (
            (None, ),
            None,
            None)
        cec_get_adapter_vendor_id = (
            (c_uint16, ),
            None,
            None)
        cec_get_adapter_product_id = (
            (c_uint16, ),
            None,
            None)
        cec_audio_toggle_mute = (
            (c_uint8, ),
            None,
            None)
        cec_audio_mute = (
            (c_uint8, ),
            None,
            None)
        cec_audio_unmute = (
            (c_uint8, ),
            None,
            None)
        cec_audio_get_status = (
            (c_uint8, ),
            None,
            None)

    def __init__(self, dllPath):
        super(LibCECDLL, self).__init__(dllPath)

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        pass
##        if self._name is not None:
##            windll.kernel32.FreeLibrary(self._handle)

##    def __getattr__(self, name):
##        if name.startswith('__') and name.endswith('__'):
##            raise AttributeError, name
##        func = self.__getitem__(name)
##        setattr(self, name, func)
##        return func

    def __getitem__(self, name_or_ordinal):
        prototype, flags, errcheck = getattr(LibCECDLL.CECFunctions, name_or_ordinal)
        func = CFUNCTYPE(*prototype)((name_or_ordinal, self), flags)
        if errcheck:
            func.errcheck = errcheck
        if not isinstance(name_or_ordinal, (int, long)):
            func.__name__ = name_or_ordinal
        return func
