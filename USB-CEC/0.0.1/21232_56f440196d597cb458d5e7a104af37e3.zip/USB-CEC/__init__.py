# -*- coding: utf-8 -*-

# plugins/USB-CEC/__init__.py
#
# This file is a plugin for EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

eg.RegisterPlugin(
    name = "USB-CEC",
    author = "RichardH",
    version = "0.0.1",
    guid = '{AFCF34B2-4A07-4464-8347-490C969C1673}',
    kind = "external",
    createMacrosOnAdd = True,
    description = (
        "Provides access to functions exported from libcec.dll.\n"
        "Generates events from libcec callbacks.\n"
        "Plugin actions emulate Pulse-Eight's testclient.exe.\n"
        "See testclient help for details."))

# changelog:
# 0.0.1 by RichardH
#       - initial version

import os
import time
import _winreg
import cecconfig
import cecenums
from cecc import ICECCallbacks, libcec_configuration, LibCECDLL
from cecc import CBCecLogMessageType, CBCecKeyPressType
from cecc import CBCecCommandType, CBCecConfigurationChangedType
from cecc import CBCecAlertType, CBCecMenuStateChangedType
from cecc import CBCecSourceActivatedType
from cecc import cec_command
from collections import namedtuple
from ctypes import byref
from datetime import datetime, timedelta
from threading import Event, Thread

class CECTx(eg.ActionClass):
    def __call__(self,
                 commandstr = None,
                 timeout = 1000):
        if commandstr is not None and self.plugin.isopen:
            command = cec_command(
                commandstr,
                timeout)
            self.plugin._libcecdll.cec_transmit(byref(command))

    def Configure(self,
                 commandstr = None,
                 timeout = 1000):
        def format_command():
            initiator = getattr(cecenums.cec_logical_address, initiatorChoice.GetStringSelection())
            destination = getattr(cecenums.cec_logical_address, destinationChoice.GetStringSelection())
            opcode = getattr(cecenums.cec_opcode, opcodeChoice.GetStringSelection())
            parameters = parametersBox.GetValue()
            excessparameters = (len(parameters)+1)%3
            if excessparameters:
                parameters = parameters[:-excessparameters]
            return "{initiatornum:1x}{destinationnum:1x}{opcodenum}{parameters}".format(
                initiatornum = initiator,
                destinationnum = destination,
                opcodenum = '' if opcode == cecenums.cec_opcode.CEC_OPCODE_NONE else ':{0:02x}'.format(opcode),
                parameters = '' if opcode == cecenums.cec_opcode.CEC_OPCODE_NONE or parameters == '' else ':{0}'.format(parameters))
        def OnCommandChanged(e):
            e.Skip()
            commandText.SetLabel(format_command())
        def OnParametersChanged(e):
            def format(str, ip):
                offset = ip%3 == 1
                clean = ''.join(
                    c.lower() for c in str[:] if c in '0123456789abcdefABCDEF')
                return ''.join((':' if (pos+offset+ip) > 0 and not (
                            pos+offset)%2 else '') + c for pos in range(
                                len(clean)) for c in clean[pos])
            selfrom, selto = parametersBox.GetSelection()
            head = format(parametersBox.GetRange(0, selfrom), 0)
            selstr = format(parametersBox.GetStringSelection(), len(head))
            newselto = len(head) + len(selstr)
            tail = format(parametersBox.GetRange(selto, parametersBox.GetLastPosition()), newselto)
            parametersBox.ChangeValue((head + selstr + tail))
            parametersBox.SetSelection(len(head), newselto)
            OnCommandChanged(e)

        if commandstr is None:
            initiator = destination = cecenums.cec_logical_address.CECDEVICE_UNKNOWN
            opcode = cecenums.cec_opcode.CEC_OPCODE_NONE
        else:
            iter = (a for a in commandstr.split(':', 2))
            endpoints, opcode, parameters = (next(iter, None) for x in range(3))
            initiator = int(endpoints[0], 16)
            destination = int(endpoints[1], 16)
            opcode = cecenums.cec_opcode.CEC_OPCODE_NONE if opcode is None else int(opcode, 16)
        parameters = '' if opcode == cecenums.cec_opcode.CEC_OPCODE_NONE or parameters is None else parameters

        panel = eg.ConfigPanel(self)
        initiatorChoice = panel.Choice(
            value = 0,
            size = (300, -1),
            style = wx.CB_SORT,
            choices = cecenums.choices_from_enum(cecenums.cec_logical_address))
        initiatorChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, initiator))
        initiatorChoice.Bind(wx.EVT_CHOICE, OnCommandChanged)
        destinationChoice = panel.Choice(
            value = 0,
            size = (300, -1),
            style = wx.CB_SORT,
            choices = cecenums.choices_from_enum(cecenums.cec_logical_address))
        destinationChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, destination))
        destinationChoice.Bind(wx.EVT_CHOICE, OnCommandChanged)
        opcodeChoice = panel.Choice(
            value = 0,
            size = (300, -1),
            style = wx.CB_SORT,
            choices = cecenums.choices_from_enum(cecenums.cec_opcode))
        opcodeChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_opcode, opcode))
        opcodeChoice.Bind(wx.EVT_CHOICE, OnCommandChanged)
        parametersBox = panel.TextCtrl(parameters, size = (300, -1))
        parametersBox.SetMaxLength(299)
        parametersBox.Bind(wx.EVT_TEXT, OnParametersChanged)
        timeoutCtrl = panel.SmartSpinIntCtrl(timeout)
        commandText = panel.StaticText(format_command(), size = (300, -1))

        panel.AddLine("Initiator:", initiatorChoice)
        panel.AddLine("Destination:", destinationChoice)
        panel.AddLine("Opcode:", opcodeChoice)
        panel.AddLine("Parameters:", parametersBox)
        panel.AddLine("Timeout ms:", timeoutCtrl)
        panel.AddLine("Command: ", commandText)

        while panel.Affirmed():
            panel.SetResult(
                format_command(),
                timeoutCtrl.GetValue())
class CECOn(eg.ActionClass):
    def __call__(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_power_on_devices(address)
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = cecenums.choices_from_enum(cecenums.cec_logical_address))
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult('{0:02x}'.format(getattr(
                cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECStandby(eg.ActionClass):
    def __call__(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_BROADCAST if destination is None else int(destination, 16)
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_standby_devices(address)
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_BROADCAST if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = cecenums.choices_from_enum(cecenums.cec_logical_address))
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:02x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECLA(eg.ActionClass):
    def __call__(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_PLAYBACKDEVICE1 if destination is None else int(destination, 16)
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_set_logical_address(address)
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_PLAYBACKDEVICE1 if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = cecenums.choices_from_enum(cecenums.cec_logical_address))
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:02x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECP(eg.ActionClass):
    def __call__(self, destination = None, strport = None):
        device = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        port = 1 if strport is None else int(strport)
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_set_hdmi_port(device, port)
    def Configure(self, destination = None, strport = None):
        device = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        port = 1 if strport is None else int(strport)
        panel = eg.ConfigPanel(self)
        addressChoice = panel.Choice(
            value = 0,
            size = (250, -1),
            style = wx.CB_SORT,
            choices = cecenums.choices_from_enum(cecenums.cec_logical_address))
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, device))
        portCtrl = panel.SmartSpinIntCtrl(port, min=1, max=9)
        panel.AddLine("Device:", addressChoice, "HDMI port:", portCtrl)
        while panel.Affirmed():
            panel.SetResult(
                '{0:02x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())),
                '{0:1d}'.format(
                    portCtrl.GetValue()))
class CECPA(eg.ActionClass):
    def __call__(self, address = None):
        physical_address = 0x1000 if address is None else int(address, 16)
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_set_physical_address(physical_address)
    def Configure(self, address = None):
        physical_address = 0x1000 if address is None else int(address, 16)
        panel = eg.ConfigPanel(self)
        physical_address_str = "{0:04x}".format(physical_address)
        digit1Ctrl = panel.SmartSpinIntCtrl(int(physical_address_str[0]), numWidth=40, min=1, max=13)
        digit2Ctrl = panel.SmartSpinIntCtrl(int(physical_address_str[1]), numWidth=40, max=13)
        digit3Ctrl = panel.SmartSpinIntCtrl(int(physical_address_str[2]), numWidth=40, max=13)
        digit4Ctrl = panel.SmartSpinIntCtrl(int(physical_address_str[3]), numWidth=40, max=13)
        panel.AddLine("Physical address:", digit1Ctrl, ".", digit2Ctrl, ".", digit3Ctrl, ".", digit4Ctrl)
        while panel.Affirmed():
            panel.SetResult(
                '{0:1x}{1:1x}{2:1x}{3:1x}'.format(
                    digit1Ctrl.GetValue(),
                    digit2Ctrl.GetValue(),
                    digit3Ctrl.GetValue(),
                    digit4Ctrl.GetValue()))
class CECOSD(eg.ActionClass):
    def __call__(self, destination = None, message = None):
        device = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        message = "" if message is None else message
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_set_osd_string(
                device,
                cecenums.cec_display_control.CEC_DISPLAY_CONTROL_DISPLAY_FOR_DEFAULT_TIME,
                message)
    def Configure(self, destination = None, message = None):
        device = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        message = "" if message is None else message
        panel = eg.ConfigPanel(self)
        choices = cecenums.choices_from_enum(cecenums.cec_logical_address)
        try:
            choices.remove("CECDEVICE_BROADCAST")
        except ValueError:
            pass
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = choices)
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, device))
        messageCtrl = panel.TextCtrl(message)
        messageCtrl.SetMaxLength(13)
        panel.AddLine("Device:", addressChoice)
        panel.AddLine("Message:", messageCtrl)
        while panel.Affirmed():
            panel.SetResult(
                '{0:02x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection()),
                    messageCtrl.GetValue()))
class CECVer(eg.ActionClass):
    def __call__(self, destination = None):
        if destination is not None and self.plugin.isopen:
            version = cecenums.reverse_enum(
                cecenums.cec_version,
                self.plugin._libcecdll.cec_get_device_cec_version(int(destination, 16)))
            if self.plugin.logStatus:
                print "USB-CEC: CEC version {0}".format(version)
            return version
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        choices = cecenums.choices_from_enum(cecenums.cec_logical_address)
        try:
            choices.remove("CECDEVICE_BROADCAST")
        except ValueError:
            pass
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = choices)
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:02x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECVen(eg.ActionClass):
    def __call__(self, destination = None):
        if destination is not None and self.plugin.isopen:
            vendornum = self.plugin._libcecdll.cec_get_device_vendor_id(int(destination, 16))
            vendor = cecenums.reverse_enum(cecenums.cec_vendor_id, vendornum)
            if self.plugin.logStatus:
                print "USB-CEC: vendor id: {0} [{1:06x}]".format(
                    vendor,
                    vendornum)
            return (vendor, vendornum)
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        choices = cecenums.choices_from_enum(cecenums.cec_logical_address)
        try:
            choices.remove("CECDEVICE_BROADCAST")
        except ValueError:
            pass
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = choices)
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:06x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECLang(eg.ActionClass):
    def __call__(self, destination = None):
        if destination is not None and self.plugin.isopen:
            try:
                language = self.plugin._libcecdll.cec_get_device_menu_language(int(destination, 16)).language
            except WindowsError:
                language = ""
            if self.plugin.logStatus:
                print "USB-CEC: menu language: [{0}]".format(language)
            return language
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        choices = cecenums.choices_from_enum(cecenums.cec_logical_address)
        try:
            choices.remove("CECDEVICE_BROADCAST")
        except ValueError:
            pass
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = choices)
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:06x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECPow(eg.ActionClass):
    def __call__(self, destination = None):
        if destination is not None and self.plugin.isopen:
            power = cecenums.reverse_enum(
                cecenums.cec_power_status,
                self.plugin._libcecdll.cec_get_device_power_status(int(destination, 16)))
            if self.plugin.logStatus:
                print "USB-CEC: power status: {0}".format(power)
            return power
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        choices = cecenums.choices_from_enum(cecenums.cec_logical_address)
        try:
            choices.remove("CECDEVICE_BROADCAST")
        except ValueError:
            pass
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = choices)
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:06x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECName(eg.ActionClass):
    def __call__(self, destination = None):
        if destination is not None and self.plugin.isopen:
            name = self.plugin._libcecdll.cec_get_device_osd_name(int(destination, 16)).name
            if self.plugin.logStatus:
                print "OSD name of device {0} is {1}".format(
                    cecenums.reverse_enum(cecenums.cec_logical_address, int(destination, 16)),
                    name)
            return name
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        choices = cecenums.choices_from_enum(cecenums.cec_logical_address)
        try:
            choices.remove("CECDEVICE_BROADCAST")
        except ValueError:
            pass
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = choices)
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Device Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:02x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECPoll(eg.ActionClass):
    def __call__(self, destination = None):
        if destination is not None and self.plugin.isopen:
            result = self.plugin._libcecdll.cec_poll_device(int(destination, 16))
            if self.plugin.logStatus:
                print "USB-CEC: POLL message{0} sent".format(
                    '' if result else ' not')
            return result
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = cecenums.choices_from_enum(cecenums.cec_logical_address))
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:02x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECLad(eg.ActionClass):
    def __call__(self):
        if self.plugin.isopen:
            if self.plugin.logStatus:
                print "USB-CEC: listing active devices:"
            addresses = self.plugin._libcecdll.cec_get_active_devices().addresses
            devices = [(
                cecenums.reverse_enum(cecenums.cec_logical_address, i)
                ) for i in range(cecenums.cec_logical_address.CECDEVICE_RESERVED1) if addresses[i]]
            if self.plugin.logStatus:
                print '\n'.join(" logical address {0}".format(device) for device in devices)
            return devices
class CECAd(eg.ActionClass):
    def __call__(self, destination = None):
        if destination is not None and self.plugin.isopen:
            address = int(destination, 16)
            active = self.plugin._libcecdll.cec_is_active_device(address)
            if self.plugin.logStatus:
                print "USB-CEC: logical address {0} is {1}".format(
                    cecenums.reverse_enum(cecenums.cec_logical_address, address),
                    "active" if active else "inactive")
            return active
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        choices = cecenums.choices_from_enum(cecenums.cec_logical_address)
        try:
            choices.remove("CECDEVICE_BROADCAST")
        except ValueError:
            pass
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = choices)
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:06x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECAt(eg.ActionClass):
    typemap = dict(
        a = cecenums.cec_device_type.CEC_DEVICE_TYPE_AUDIO_SYSTEM,
        p = cecenums.cec_device_type.CEC_DEVICE_TYPE_PLAYBACK_DEVICE,
        r = cecenums.cec_device_type.CEC_DEVICE_TYPE_RECORDING_DEVICE,
        t = cecenums.cec_device_type.CEC_DEVICE_TYPE_TUNER)
    def __call__(self, typestr = None):
        if self.plugin.isopen:
            type = self.typemap[typestr] if typestr in self.typemap else cecenums.cec_device_type.CEC_DEVICE_TYPE_TV
            active = self.plugin._libcecdll.cec_is_active_device_type(type)
            if self.plugin.logStatus:
                print "USB-CEC: device {0} is {1}".format(
                    cecenums.reverse_enum(cecenums.cec_device_type, type),
                    "active" if active else "inactive")
            return active
    def Configure(self, typestr = None):
        typestr = '?' if typestr not in self.typemap else typestr
        panel = eg.ConfigPanel(self)
        typeChoice = panel.Choice(
            value = 0,
            size = (30, -1),
            style = wx.CB_SORT,
            choices = [choice for choice in self.typemap])
        typeChoice.SetStringSelection(typestr)
        panel.AddLine("Device type:", typeChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:1}'.format(typeChoice.GetStringSelection()))
class CECSp(eg.ActionClass):
    def __call__(self, address = None):
        physical_address = 0x1000 if address is None else int(address, 16)
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_set_stream_path_physical(physical_address)
    def Configure(self, address = None):
        physical_address = 0x1000 if address is None else int(address, 16)
        panel = eg.ConfigPanel(self)
        physical_address_str = "{0:04x}".format(physical_address)
        digit1Ctrl = panel.SmartSpinIntCtrl(int(physical_address_str[0]), numWidth=40, min=1, max=13)
        digit2Ctrl = panel.SmartSpinIntCtrl(int(physical_address_str[1]), numWidth=40, max=13)
        digit3Ctrl = panel.SmartSpinIntCtrl(int(physical_address_str[2]), numWidth=40, max=13)
        digit4Ctrl = panel.SmartSpinIntCtrl(int(physical_address_str[3]), numWidth=40, max=13)
        panel.AddLine("Physical address:", digit1Ctrl, ".", digit2Ctrl, ".", digit3Ctrl, ".", digit4Ctrl)
        while panel.Affirmed():
            panel.SetResult(
                '{0:1x}{1:1x}{2:1x}{3:1x}'.format(
                    digit1Ctrl.GetValue(),
                    digit2Ctrl.GetValue(),
                    digit3Ctrl.GetValue(),
                    digit4Ctrl.GetValue()))
class CECSpl(eg.ActionClass):
    def __call__(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_set_stream_path_logical(address)
    def Configure(self, destination = None):
        address = cecenums.cec_logical_address.CECDEVICE_TV if destination is None else int(destination, 16)
        panel = eg.ConfigPanel(self)
        choices = cecenums.choices_from_enum(cecenums.cec_logical_address)
        try:
            choices.remove("CECDEVICE_BROADCAST")
        except ValueError:
            pass
        addressChoice = panel.Choice(
            value = 0,
            size = (200, -1),
            style = wx.CB_SORT,
            choices = choices)
        addressChoice.SetStringSelection(cecenums.reverse_enum(cecenums.cec_logical_address, address))
        panel.AddLine("Logical Address:", addressChoice)
        while panel.Affirmed():
            panel.SetResult(
                '{0:02x}'.format(
                    getattr(cecenums.cec_logical_address, addressChoice.GetStringSelection())))
class CECVolUp(eg.ActionClass):
    def __call__(self):
        if self.plugin.isopen:
            result = self.plugin._libcecdll.cec_volume_up()
            if self.plugin.logStatus:
                print "USB-CEC: volume up {0:2x}".format(result)
            return result
class CECVolDown(eg.ActionClass):
    def __call__(self):
        if self.plugin.isopen:
            result = self.plugin._libcecdll.cec_volume_down()
            if self.plugin.logStatus:
                print "USB-CEC: volume down {0:2x}".format(result)
            return result
class CECMute(eg.ActionClass):
    def __call__(self):
        result = self.plugin._libcecdll.cec_mute_audio()
        if self.plugin.isopen:
            if self.plugin.logStatus:
                print "USB-CEC: mute {0:2x}".format(result)
            return result
class CECSelf(eg.ActionClass):
    def __call__(self):
        if self.plugin.isopen:
            addresses = self.plugin._libcecdll.cec_get_logical_addresses().addresses
            if self.plugin.logStatus:
                print "USB-CEC: Addresses controlled by libCEC:"
            result = [
                (cecenums.reverse_enum(cecenums.cec_logical_address, i),
                 self.plugin._libcecdll.cec_is_active_source(i)
                 ) for i in range(len(addresses)) if addresses[i]]
            if self.plugin.logStatus:
                print '\n'.join("{0}{1}".format(
                    item[0],
                    '*' if item[1] else ''
                    ) for item in result)
            return result
class CECScan(eg.ActionClass):
    def __call__(self):
        if self.plugin.isopen:
            if self.plugin.logStatus:
                print "USB-CEC: requesting CEC bus information ..."
            addresses = self.plugin._libcecdll.cec_get_active_devices().addresses
            active_source_num = self.plugin._libcecdll.cec_get_active_source()
            active_source = cecenums.reverse_enum(
                cecenums.cec_logical_address,
                active_source_num)
            result = ((
                active_source,
                active_source_num),
                [(
                    i, # devicenum
                    cecenums.reverse_enum(cecenums.cec_logical_address, i), # device
                    ''.join('{0:04x}'.format(
                        self.plugin._libcecdll.cec_get_device_physical_address(i))), # address
                    self.plugin._libcecdll.cec_is_active_source(i), # active
                    cecenums.reverse_enum(
                        cecenums.cec_vendor_id,
                        self.plugin._libcecdll.cec_get_device_vendor_id(i)), # vendor
                    self.plugin._libcecdll.cec_get_device_osd_name(i).name, # osdname
                    cecenums.reverse_enum(
                        cecenums.cec_version,
                        self.plugin._libcecdll.cec_get_device_cec_version(i)), # version
                    cecenums.reverse_enum(
                        cecenums.cec_power_status,
                        self.plugin._libcecdll.cec_get_device_power_status(i)), # power
                    self.plugin._libcecdll.cec_get_device_menu_language(i).language # lang
                 ) for i in range(16) if addresses[i]])
            if self.plugin.logStatus:
                print "CEC bus information\n==================="
                print '\n'.join((
                    "device         {device} [{devicenum:02x}]\n"
                    "address:       {address}\n"
                    "active source: {active}\n"
                    "vendor:        {vendor}\n"
                    "osd string:    {osdname}\n"
                    "CEC version:   {version}\n"
                    "power status:  {power}\n"
                    "language:      {lang}\n".format(
                        devicenum = item[0],
                        device = item[1],
##                        address = item[2],
                        address = '.'.join('{0}'.format(int(c, 16)) for c in item[2]),
                        active = "yes" if item[3] else "no",
                        vendor = item[4],
                        osdname = item[5],
                        version = item[6],
                        power = item[7],
                        lang = item[8]
                    )) for item in result[1])
                print "currently active source: {0} [{1:02x}]".format(*result[0])
            return result
class CECMon(eg.ActionClass):
    def __call__(self, enable = None):
        enable = False if enable is None else enable
        if self.plugin.isopen:
            self.plugin._libcecdll.cec_switch_monitoring(enable)
    def Configure(self, enable = None):
        enable = False if enable is None else enable
        panel = eg.ConfigPanel(self)
        enableBox = panel.CheckBox(enable)
        panel.AddLine(enableBox, "Enable")
        while panel.Affirmed():
            panel.SetResult(enableBox.GetValue())
class CECR(eg.ActionClass):
    def __call__(self):
        if self.plugin.strport:
            self.plugin.isopen = False
            isAS = self.plugin._libcecdll.cec_is_libcec_active_source()
            print "USB-CEC: closing the connection"
            self.plugin._libcecdll.cec_close()
            print "USB-CEC: opening a new connection"
            if not self.plugin._libcecdll.cec_open(self.plugin.strport):
                self.PrintError("USB-CEC: unable to reopen " + self.plugin.strport)
                return
            if isAS:
                print "USB-CEC: setting active source"
                self.plugin._libcecdll.cec_set_active_source()
            self.plugin.isopen = True
            self.plugin.TriggerEvent("Waiting for input")
##class CECClose(eg.ActionClass):
##    def __call__(self):
##        if self.plugin.strport:
##            self.plugin.isopen = False
##            self.plugin.isAS = self.plugin._libcecdll.cec_is_libcec_active_source()
##            print "USB-CEC: closing the connection"
##            self.plugin._libcecdll.cec_close()
##class CECOpen(eg.ActionClass):
##    def __call__(self):
##        if self.plugin.strport:
##            print "USB-CEC: opening a new connection"
##            if not self.plugin._libcecdll.cec_open(self.plugin.strport):
##                self.PrintError("USB-CEC: unable to reopen " + self.plugin.strport)
##                return
##            if self.plugin.isAS:
##                print "USB-CEC: setting active source"
##                self.plugin._libcecdll.cec_set_active_source()
##            self.plugin.isopen = True
##            self.plugin.TriggerEvent("Waiting for input")

ACTIONS = (
        (CECTx, "Tx", "Tx", "Transfer bytes over the CEC line", None),
        (CECOn, "On", "On", "Power on the device with the given logical address", None),
        (CECStandby, "Standby", "Standby", "Put the device with the given address in standby mode", None),
        (CECLA, "LA", "LA", "Change the logical address of the CEC adapter", None),
        (CECP, "P", "P", "Change the HDMI port number of the CEC adapter", None),
        (CECPA, "PA", "PA", "Change the physical address of the CEC adapter", None),
        ("AS", "AS", "Make the CEC adapter the active source", "cec_set_active_source"),
        ("IS", "IS","Mark the CEC adapter as inactive source","cec_set_inactive_view"),
        (CECOSD, "OSD", "OSD", "Set OSD message on the specified device", None),
        (CECVer, "Ver", "Ver", "Get the CEC version of the specified device", None),
        (CECVen, "Ven", "Ven", "Get the vendor ID of the specified device", None),
        (CECLang, "Lang", "Lang", "Get the menu language of the specified device", None),
        (CECPow, "Pow", "Pow", "Get the power status of the specified device", None),
        (CECName, "Name", "Name", "Get the OSD name of the specified device", None),
        (CECPoll, "Poll", "Poll", "Poll the specified device", None),
        (CECLad, "Lad", "Lad", "Lists active devices on the bus", None),
        (CECAd, "Ad", "Ad", "Checks whether the specified device is active", None),
        (CECAt, "At", "At", "Checks whether the specified device type is active", None),
        (CECSp, "Sp", "Sp", "Makes the specified physical address active", None),
        (CECSpl, "Spl", "Spl", "Makes the specified logical address active", None),
        (CECVolUp, "VolUp", "Volup","Send a volume up command to the amp if present", None),
        (CECVolDown, "VolDown", "VolDown","Send a volume down command to the amp if present", None),
        (CECMute, "Mute", "Mute","Send a mute/unmute command to the amp if present", None),
        (CECSelf, "Self", "Self", "Show the list of addresses controlled by libCEC", None),
        (CECScan, "Scan", "Scan", "Scan the CEC bus and display device info", None),
        (CECMon, "Mon", "Mon", "Enable or disable CEC bus monitoring", None),
        ("Ping", "Ping", "Send a ping command to the CEC adapter", "cec_ping_adapters"),
        (CECR, "R", "R", "Reconnect to the CEC adapter", None))
##        (CECClose, "Close", "Close", "Disconnect from the CEC adapter", None),
##        (CECOpen, "Open", "Open", "Connect to the CEC adapter", None))

class ActionPrototype(eg.ActionClass):
    def __call__(self):
        if self.plugin.isopen:
            result = getattr(self.plugin._libcecdll, self.value)()
            if self.plugin.logStatus:
                print "USB-CEC: action returned {0}".format(result)
            return result

#===============================================================================

# Plugin
class USB_CEC(eg.PluginClass):
    def __init__(self):
        self.AddActionsFromList(ACTIONS, ActionPrototype)

        self.callbacks = ICECCallbacks(
            CBCecLogMessage = CBCecLogMessageType(self.py_CBCecLogMessage),
            CBCecKeyPress = CBCecKeyPressType(self.py_CBCecKeyPress),
            CBCecCommand = CBCecCommandType(self.py_CBCecCommand),
            CBCecConfigurationChanged = CBCecConfigurationChangedType(self.py_CBCecConfigurationChanged),
            CBCecAlert = CBCecAlertType(self.py_CBCecAlert),
            CBCecMenuStateChanged = CBCecMenuStateChangedType(self.py_CBCecMenuStateChanged),
            CBCecSourceActivated = CBCecSourceActivatedType(self.py_CBCecSourceActivated))

        self.isrunning = self.isloaded = self.isopen = False
        self.strport = None

    def __start__(self,
        dllPath = None,
        strPort = None,
        strDeviceName = "Test",
        deviceTypes = (),
        wakeDevices = None,
        powerOffDevices = None,
        bGetSettingsFromROM = False,
        bMonitorOnly = False,
        logLevel = cecenums.cec_log_level.CEC_LOG_ERROR,
        bLogKeyPress = False,
        bLogCommand = False,
        bLogConfigurationChanged = False,
        bLogAlert = False,
        bLogMenuStateChanged = False,
        bLogSourceActivated = False,
        bLogStatus = False):

##        if dllPath is None:
##            dllPath = self.GetDllPath()
##        if not os.path.exists(dllPath):
##            self.PrintError("USB-CEC: " + dllPath + " not found")
##            return

        self.dllPath = dllPath
        self.logLevel = logLevel
        self.logKeyPress = bLogKeyPress
        self.logCommand = bLogCommand
        self.logConfigurationChanged = bLogConfigurationChanged
        self.logAlert = bLogAlert
        self.logMenuStateChanged = bLogMenuStateChanged
        self.logSourceActivated = bLogSourceActivated
        self.logStatus = bLogStatus

        self.stopThreadEvent = Event()
        thread = Thread(
            target=self.ThreadLoop,
            args=(self.stopThreadEvent, ))
        thread.start()
        while not self.isrunning:
            time.sleep(0.1)

        if not self.isloaded:
            self.PrintError("USB-CEC: " + dllPath + " is not a valid DLL")
            return

        self.configuration = libcec_configuration(
            device_name = strDeviceName,
            device_types = deviceTypes,
            wake_devices = (
                cecenums.cec_logical_address.CECDEVICE_TV,
                ) if wakeDevices is None else wakeDevices,
            power_off_devices = (
                cecenums.cec_logical_address.CECDEVICE_BROADCAST,
                ) if powerOffDevices is None else powerOffDevices,
            get_settings_from_ROM = bGetSettingsFromROM,
            monitor_only = bMonitorOnly,
            callbacks = self.callbacks)

        if self.configuration.deviceTypes.is_empty():
            self.configuration.deviceTypes.add(cecenums.cec_device_type.CEC_DEVICE_TYPE_RECORDING_DEVICE)

        if self.logConfigurationChanged:
            print "USB-CEC Initial configuration\n{0}".format(self.configuration)
        self._libcecdll.cec_initialise(byref(self.configuration))
        self._libcecdll.cec_init_video_standalone()

        if strPort is None:
            try:
                count, adapters = self._libcecdll.cec_detect_adapters(10)
            except WindowsError:
                self.PrintError("USB-CEC: no adapters found")
                return

            strPort = adapters[0].strComName
            print "USB-CEC: found", count, "adapters, first at", strPort, adapters[0].strComPath

        if not self._libcecdll.cec_open(strPort):
            self.PrintError("USB-CEC: unable to open " + strPort)
            return
        self.strport = strPort
        self.isopen = True
        self.TriggerEvent("Waiting for input")

    def __stop__(self):
        try:
            self._libcecdll.cec_close()
        except:
            pass
        try:
            self._libcecdll.cec_destroy()
        except:
            pass
        self.stopThreadEvent.set()

    def ThreadLoop(self, stopThreadEvent):
        self.isloaded = self.isrunning = False
        try:
            with LibCECDLL(self.dllPath) as self._libcecdll:
                self.isloaded = self._libcecdll is not None
                self.isrunning = True
                stopThreadEvent.wait()
                self._libcecdll = None
        except WindowsError:
            self.isrunning = True
            return
        self.isloaded = self.isrunning = False
        
    def Configure(self,
        dllPath = None,
        strPort = None,
        strDeviceName = "Test",
        deviceTypes = (),
        wakeDevices = None,
        powerOffDevices = None,
        bGetSettingsFromROM = False,
        bMonitorOnly = False,
        logLevel = cecenums.cec_log_level.CEC_LOG_ERROR,
        bLogKeyPress = False,
        bLogCommand = False,
        bLogConfigurationChanged = False,
        bLogAlert = False,
        bLogMenuStateChanged = False,
        bLogSourceActivated = False,
        bLogStatus = False):

        def OnDllInfoButton(e):
            _dllPath = dllPathCtrl.GetValue()
            if not os.path.exists(_dllPath):
                dllInfo.SetLabel(_dllPath + " not found")
                return
            if not self.isloaded:
                try:
                    with LibCECDLL(_dllPath) as libcecdll:
##                        if libcecdll is None:
##                            dllInfo.SetLabel(_dllPath + " is not a valid DLL")
##                            return
                        configuration = libcec_configuration()
                        configuration.clear()
                        libcecdll.cec_initialise(byref(configuration))
                        dllInfo.SetLabel(libcecdll.cec_get_lib_info())
                except WindowsError:
                    dllInfo.SetLabel(_dllPath + " is not a valid DLL")
                    return
            else:
                dllInfo.SetLabel(
                    "Path OK. Library in use - no information available\n"
                    "Library information is available when the plugin is disabled")

        def OnPortAutoDetectChanged(e):
            e.Skip()
            portNum.Enable(not portAutoDetect.GetValue())

        def OnDevicesChanged(e):
            e.Skip()
            validate_device_page()

        def validate_device_page():
            r = deviceRecording.GetValue()
            t = deviceTuner.GetValue()
            p = devicePlayback.GetValue()
            a = deviceAudioSystem.GetValue()
            if not (r or t or p or a):
                r = True
                deviceRecording.SetValue(True)
            deviceRecordingRB.Enable(r)
            if not r:
                deviceRecordingRB.SetValue(False)
            deviceTunerRB.Enable(t)
            if not t:
                deviceTunerRB.SetValue(False)
            devicePlaybackRB.Enable(p)
            if not p:
                devicePlaybackRB.SetValue(False)
            deviceAudioSystemRB.Enable(a)
            if not a:
                deviceAudioSystemRB.SetValue(False)
            if not (
                deviceRecordingRB.GetValue() or
                deviceTunerRB.GetValue() or
                devicePlaybackRB.GetValue() or
                deviceAudioSystemRB.GetValue()):
                if r:
                    deviceRecordingRB.SetValue(True)
                elif t:
                    deviceTunerRB.SetValue(True)
                elif p:
                    devicePlaybackRB.SetValue(True)
                elif a:
                    deviceAudioSystemRB.SetValue(True)

        if dllPath is None:
            dllPath = self.GetDllPath()
            if dllPath is None:
                dllPath = os.path.join(
                    eg.folderPath.ProgramFiles, 
                    "Pulse-Eight",
                    "USB-CEC Adapter",
                    "libcec.dll")

        # Define notebook
        panel = cecconfig.CECConfigPanel()
        libPage = cecconfig.CECConfigPage(panel, "Library")
        adapterPage = cecconfig.CECConfigPage(panel, "Adapter")
        devicePage = cecconfig.CECConfigPage(panel, "Device")
        modePage = cecconfig.CECConfigPage(panel, "Mode")
        logPage = cecconfig.CECConfigPage(panel, "Log")

        # Define and initialize controls
        dllPathCtrl = libPage.FileBrowseButton(
            dllPath, 
            startDirectory=eg.folderPath.ProgramFiles,
            fileMask = "libcec.dll|libcec.dll|All-Files (*.*)|*.*")
        dllInfoButton = libPage.Button("Test")
        dllInfoButton.Bind(wx.EVT_BUTTON, OnDllInfoButton)
        dllInfo = libPage.StaticText("No information available", size=(320, 40), style=wx.ST_NO_AUTORESIZE)
        dllInfo.Wrap(300)

        deviceName = devicePage.TextCtrl(strDeviceName)
        deviceName.SetMaxLength(13)

        useRom = adapterPage.CheckBox(bGetSettingsFromROM)
        portAutoDetect = adapterPage.CheckBox(strPort is None)
        portAutoDetect.Bind(wx.EVT_CHECKBOX, OnPortAutoDetectChanged)
        portNum = adapterPage.SerialPortChoice(strPort)
        portNum.Enable(strPort is not None)

##        deviceTV = devicePage.CheckBox(
##            cecenums.cec_device_type.CEC_DEVICE_TYPE_TV in deviceTypes)
##        deviceTVRB = devicePage.RadioButton(0, style=wx.RB_GROUP)
        primary_device = deviceTypes[0] if deviceTypes else None
        deviceRecording = devicePage.CheckBox(
            cecenums.cec_device_type.CEC_DEVICE_TYPE_RECORDING_DEVICE in deviceTypes)
        deviceRecording.Bind(wx.EVT_CHECKBOX, OnDevicesChanged)
        deviceRecordingRB = devicePage.RadioButton(
            primary_device == cecenums.cec_device_type.CEC_DEVICE_TYPE_RECORDING_DEVICE,
            style=wx.RB_GROUP)
        deviceRecordingRB.Bind(wx.EVT_RADIOBUTTON, OnDevicesChanged)
        deviceTuner = devicePage.CheckBox(
            cecenums.cec_device_type.CEC_DEVICE_TYPE_TUNER in deviceTypes)
        deviceTuner.Bind(wx.EVT_CHECKBOX, OnDevicesChanged)
        deviceTunerRB = devicePage.RadioButton(
            primary_device == cecenums.cec_device_type.CEC_DEVICE_TYPE_TUNER)
        deviceTunerRB.Bind(wx.EVT_RADIOBUTTON, OnDevicesChanged)
        devicePlayback = devicePage.CheckBox(
            cecenums.cec_device_type.CEC_DEVICE_TYPE_PLAYBACK_DEVICE in deviceTypes)
        devicePlayback.Bind(wx.EVT_CHECKBOX, OnDevicesChanged)
        devicePlaybackRB = devicePage.RadioButton(
            primary_device == cecenums.cec_device_type.CEC_DEVICE_TYPE_PLAYBACK_DEVICE)
        devicePlaybackRB.Bind(wx.EVT_RADIOBUTTON, OnDevicesChanged)
        deviceAudioSystem = devicePage.CheckBox(
            cecenums.cec_device_type.CEC_DEVICE_TYPE_AUDIO_SYSTEM in deviceTypes)
        deviceAudioSystem.Bind(wx.EVT_CHECKBOX, OnDevicesChanged)
        deviceAudioSystemRB = devicePage.RadioButton(
            primary_device == cecenums.cec_device_type.CEC_DEVICE_TYPE_AUDIO_SYSTEM)
        deviceAudioSystemRB.Bind(wx.EVT_RADIOBUTTON, OnDevicesChanged)
        validate_device_page()

        modeMonitorOnly = modePage.CheckBox(bMonitorOnly)

        logError = logPage.CheckBox(
            cecenums.cec_log_level.CEC_LOG_ERROR & logLevel)
        logWarning = logPage.CheckBox(
            cecenums.cec_log_level.CEC_LOG_WARNING & logLevel)
        logNotice = logPage.CheckBox(
            cecenums.cec_log_level.CEC_LOG_NOTICE & logLevel)
        logTraffic = logPage.CheckBox(
            cecenums.cec_log_level.CEC_LOG_TRAFFIC & logLevel)
        logDebug = logPage.CheckBox(
            cecenums.cec_log_level.CEC_LOG_DEBUG & logLevel)
        logKeyPress = logPage.CheckBox(bLogKeyPress)
        logCommand = logPage.CheckBox(bLogCommand)
        logConfigurationChanged = logPage.CheckBox(bLogConfigurationChanged)
        logAlert = logPage.CheckBox(bLogAlert)
        logMenuStateChanged = logPage.CheckBox(bLogMenuStateChanged)
        logSourceActivated = logPage.CheckBox(bLogSourceActivated)
        logStatus = logPage.CheckBox(bLogStatus)

        # Define sizers
        dllInfoBoxSizer = libPage.VStaticBoxSizer("Library information")

        # Add items to sizers
        dllInfoBoxSizer.Add(dllInfo)

        # Build notebook pages
        libPage.AddLabel("Path to CEC library:")
        libPage.AddCtrl(dllPathCtrl)
        libPage.AddCtrl(dllInfoButton)
        libPage.AddCtrl(dllInfoBoxSizer)

        adapterPage.AddLine(useRom, "Get settings from ROM")
        adapterPage.AddLine(portAutoDetect, "Detect COM port automatically", portNum, "COM port")

        devicePage.AddLabel("Name:")
        devicePage.AddCtrl(deviceName)
        devicePage.AddLine("", "", "primary")
##        devicePage.AddLine(deviceTV, "TV", deviceTVRB)
        devicePage.AddLine(deviceRecording, "Recording device", deviceRecordingRB)
        devicePage.AddLine(deviceTuner, "Tuner", deviceTunerRB)
        devicePage.AddLine(devicePlayback, "Playback device", devicePlaybackRB)
        devicePage.AddLine(deviceAudioSystem, "Audio system", deviceAudioSystemRB)

        modePage.AddLine(modeMonitorOnly, "Monitor only")

        logPage.AddLine(logError, "Log errors")
        logPage.AddLine(logWarning, "Log warnings")
        logPage.AddLine(logNotice, "Log notices")
        logPage.AddLine(logTraffic, "Log traffic")
        logPage.AddLine(logDebug, "Log debug")
        logPage.AddLine(logKeyPress, "Log key presses")
        logPage.AddLine(logCommand, "Log commands")
        logPage.AddLine(logConfigurationChanged, "Log configuration changes")
        logPage.AddLine(logAlert, "Log alerts")
        logPage.AddLine(logMenuStateChanged, "Log menu state changes")
        logPage.AddLine(logSourceActivated, "Log source activation")
        logPage.AddLine(logStatus, "Log output from plugin actions")

        while panel.Affirmed():
            if portAutoDetect.GetValue():
                strPort = None
            else:
                strPort = "COM" + repr(portNum.GetValue() + 1)

            if deviceRecordingRB.GetValue():
                deviceTypes = [cecenums.cec_device_type.CEC_DEVICE_TYPE_RECORDING_DEVICE]
            if deviceTunerRB.GetValue():
                deviceTypes = [cecenums.cec_device_type.CEC_DEVICE_TYPE_TUNER]
            if devicePlaybackRB.GetValue():
                deviceTypes = [cecenums.cec_device_type.CEC_DEVICE_TYPE_PLAYBACK_DEVICE]
            if deviceAudioSystemRB.GetValue():
                deviceTypes = [cecenums.cec_device_type.CEC_DEVICE_TYPE_AUDIO_SYSTEM]
            deviceTypes.extend(
                [device for device, isPresent in (
##                        (cecenums.cec_device_type.CEC_DEVICE_TYPE_TV, deviceTV.GetValue()),
                    (cecenums.cec_device_type.CEC_DEVICE_TYPE_RECORDING_DEVICE,
                     (deviceRecording.GetValue() and not deviceRecordingRB.GetValue())),
                    (cecenums.cec_device_type.CEC_DEVICE_TYPE_TUNER,
                     (deviceTuner.GetValue() and not deviceTunerRB.GetValue())),
                    (cecenums.cec_device_type.CEC_DEVICE_TYPE_PLAYBACK_DEVICE,
                     (devicePlayback.GetValue() and not devicePlaybackRB.GetValue())),
                    (cecenums.cec_device_type.CEC_DEVICE_TYPE_AUDIO_SYSTEM,
                     (deviceAudioSystem.GetValue() and not deviceAudioSystemRB.GetValue()))
                ) if isPresent])
            panel.SetResult(
                dllPathCtrl.GetValue(),
                strPort,
                deviceName.GetValue(),
                tuple(deviceTypes),
                None,
                None,
                useRom.GetValue(),
                modeMonitorOnly.GetValue(),
                sum((num for num, error in (
                    (cecenums.cec_log_level.CEC_LOG_ERROR, logError.GetValue()),
                    (cecenums.cec_log_level.CEC_LOG_WARNING, logWarning.GetValue()),
                    (cecenums.cec_log_level.CEC_LOG_NOTICE, logNotice.GetValue()),
                    (cecenums.cec_log_level.CEC_LOG_TRAFFIC, logTraffic.GetValue()),
                    (cecenums.cec_log_level.CEC_LOG_DEBUG, logDebug.GetValue())
                ) if error)),
                logKeyPress.GetValue(),
                logCommand.GetValue(),
                logConfigurationChanged.GetValue(),
                logAlert.GetValue(),
                logMenuStateChanged.GetValue(),
                logSourceActivated.GetValue(),
                logStatus.GetValue())

    def GetDllPath(self):
        """
        Get libcec install path from registry.
        """
        try:
            lc = _winreg.OpenKey(
                _winreg.HKEY_LOCAL_MACHINE,
                "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Pulse-Eight USB-CEC Adapter sofware"
            )
            try:
                dllPath, dummy =_winreg.QueryValueEx(lc, "InstallLocation")
            except WindowsError:
                dllPath, dummy =_winreg.QueryValueEx(lc, "UninstallString")
                dllPath = os.path.dirname(dllPath)
            _winreg.CloseKey(lc)
            dllPath = os.path.join(dllPath, "libcec.dll")
        except WindowsError:
            dllPath = None
        return dllPath

    # libcec callbacks
    def py_CBCecLogMessage(self, a, cec_log_message):
        if self.logLevel & cec_log_message.level:
            print cec_log_message
        return 0
    def py_CBCecKeyPress(self, a, cec_keypress):
        if self.logKeyPress:
            print cec_keypress
        self.TriggerEvent("KEY_PRESS", cec_keypress.eventparam())
        return 0
    def py_CBCecCommand(self, a, cec_command):
        if self.logCommand:
            print "USB-CEC Command:", str(cec_command)
        self.TriggerEvent("COMMAND", cec_command.eventparam())
        return 0
    def py_CBCecConfigurationChanged(self, a, libcec_configuration):
        if self.logConfigurationChanged:
            print "USB-CEC Configuration Changed\n{0}".format(libcec_configuration)
##        self.TriggerEvent("CONFIGURATION_CHANGED", libcec_configuration.eventparam())
        self.TriggerEvent("CONFIGURATION_CHANGED")
        return 0
    def py_CBCecAlert(self, a, libcec_alert, libcec_parameter):
        if self.logAlert:
            print "{0}: {1}".format(
                cecenums.reverse_enum(cecenums.libcec_alert, libcec_alert),
                libcec_parameter)
        self.TriggerEvent(
            cecenums.reverse_enum(cecenums.libcec_alert, libcec_alert),
            str(libcec_parameter))
        return 0
    def py_CBCecMenuStateChanged(self, a, cec_menu_state):
        if self.logMenuStateChanged:
            print "USB-CEC Menu State Changed:", cecenums.reverse_enum(cecenums.cec_menu_state, cec_menu_state)
        self.TriggerEvent(
            "MENU_STATE_CHANGED",
            cecenums.reverse_enum(cecenums.cec_menu_state, cec_menu_state))
        return 0
    def py_CBCecSourceActivated(self, a, cec_logical_address, b):
        if self.logSourceActivated:
            print "USB-CEC Source Activated: {0} {1}".format(
                cecenums.reverse_enum(cecenums.cec_logical_address, cec_logical_address),
                bool(b))
            suffix = "SOURCE_ACTIVATED" if b else "SOURCE_DEACTIVATED"
            self.TriggerEvent(suffix, cecenums.reverse_enum(cecenums.cec_logical_address, cec_logical_address))
        return 0
