# Xbox(original) remote control plugin for EventGhost by cory1492.
# Based on the XBOXCDRC plugin by jinxdone/Bartman.
#
"""<rst>
Xbox remote control plugin, based on the irdata plugin.

For this plugin to work you need to install winusb drivers via Zadig http://zadig.akeo.ie/

|

.. image:: xbcdrc.png
   :align: center
"""

eg.RegisterPlugin(
    name = "Xbox remote control (winusb dll)",
    author = "cory1492 / jinxdone / Bartman",
    version = "0.1.0." + "$LastChangedRevision: 348 $".split()[1],
    kind = "remote",
    guid = "{AEBA4413-1555-440A-A6CB-B7506B86A151}",
    canMultiLoad = False,
    description = __doc__,
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAeJJREFUOMul"
        "k09I02EYxz/Pu/e33J80R6UUlEsolDCCYkSJ5S3oD1RCHaJDSEhQEHjpItShSxAU1M2SCCLo0EU6"
        "RV2KQCwkaqXk2PyTy0bbbGtuv/ftEK0xo0Y+3+vz+fLl+fKIxbKcUSxzFIAoccWRYq2QaCmKltLv"
        "BEZkWz/T0q5i0iLxv8H+Dkls6mWGVZID0AAWowJDkt91wc4m4mRkXF7aYRuphr298rQtTM5ZQNl5"
        "Uw8glUcUJe7RmyQDnaSfDOJO+b1v7eVCj5x3HresL23ojhB8FWVy9IztKjPVLSiPuKcHSTUdI/Nh"
        "DD31HDe7EfaG0fEQI4/C9kjlvq6OaVzrWXND0gdLBPd34fMdRi8s4j5oYvhZqC5aU42fR2zD6maM"
        "D3TaUJAcKnOL7QXJD9Rk0HZN3rQ2EwiV0BNRTOorxc27WbnikIwuqbT6BuvOytjJPhqddwTv3cZ4"
        "/Jh6B919kex0EvfhXWKLd+y+MmAr1HCA8asxZo5fIQXKIhiLBcH41vL93AsSPUMk2KNf/2LKcHAn"
        "c5feMxmO8A2UtSyV8lI6MUC27z6zTiufygaBDuY7rzPha6T4J7BSIHbHKb5s7efjz3RB8moLSaVx"
        "/wVXStdRknbmRDy4xrWe//3GH4uN7Ni6Xm5TAAAAAElFTkSuQmCC"

    )
)


import threading
from os.path import abspath, split, join
from ctypes import cdll


DLL_PATH = join(abspath(split(__file__)[0]), "xboxirdll.dll")

CODES = {
    0x0006d50a: "DISPLAY", 0x00066a05: "DISPLAY", 0x00066afd: "DISPLAY", 
    0x0006e20a: "REVERSE", 0x000671f5: "REVERSE", 0x0006710d: "REVERSE", 
    0x0006ea0a: "PLAY", 0x000675f5: "PLAY", 0x0006750d: "PLAY", 
    0x0006e30a: "FORWARD", 0x00067105: "FORWARD", 0x000671fd: "FORWARD", 
    0x0006dd0a: "SKIP-", 0x00066e05: "SKIP-", 0x00066efd: "SKIP-", 
    0x0006e00a: "STOP", 0x000670f5: "STOP", 0x0006700d: "STOP", 
    0x0006e60a: "PAUSE", 0x000673f5: "PAUSE", 0x0006730d: "PAUSE", 
    0x0006df0a: "SKIP+", 0x00066f05: "SKIP+", 0x00066ffd: "SKIP+", 
    0x0006e50a: "TITLE", 0x00067205: "TITLE", 0x000672fd: "TITLE", 
    0x0006c30a: "INFO", 0x00066105: "INFO", 0x000661fd: "INFO", 
    0x0006a60a: "UP", 0x000653f5: "UP", 0x0006530d: "UP", 
    0x0006a70a: "DOWN", 0x00065305: "DOWN", 0x000653fd: "DOWN", 
    0x0006a90a: "LEFT", 0x00065405: "LEFT", 0x000654fd: "LEFT", 
    0x0006a80a: "RIGHT", 0x000654f5: "RIGHT", 0x0006540d: "RIGHT", 
    0x00060b0a: "SELECT", 0x00060505: "SELECT", 0x000605fd: "SELECT", 
    0x0006f70a: "MENU", 0x00067b05: "MENU", 0x00067bfd: "MENU", 
    0x0006d80a: "BACK", 0x00066cf5: "BACK", 0x00066c0d: "BACK", 
    0x0006ce0a: "1", 0x000667f5: "1", 0x0006670d: "1", 
    0x0006cd0a: "2", 0x00066605: "2", 0x000666fd: "2", 
    0x0006cc0a: "3", 0x000666f5: "3", 0x0006660d: "3", 
    0x0006cb0a: "4", 0x00066505: "4", 0x000665fd: "4", 
    0x0006ca0a: "5", 0x000665f5: "5", 0x0006650d: "5", 
    0x0006c90a: "6", 0x00066405: "6", 0x000664fd: "6", 
    0x0006c80a: "7", 0x000664f5: "7", 0x0006640d: "7", 
    0x0006c70a: "8", 0x00066305: "8", 0x000663fd: "8", 
    0x0006c60a: "9", 0x000663f5: "9", 0x0006630d: "9", 
    0x0006cf0a: "0", 0x00066705: "0", 0x000667fd: "0", 
    0x00064f0a: "AUDIO", 
    0x0006af0a: "ENT.", 
    0x0006d100: "LT", 
    0x0006890a: "LAST", 
    0x0006c000: "MUTE", 
    0x0006e70a: "A*B", 
    0x0006f90a: "EXIT", 
    0x00067f0a: "D", 
    0x00068c0a: "REC", 0x00006e80a: "REC",
	0x0006b80a: "INPUT",
	0x0006ac0a: "CANCEL",
	0x00066b0a: "RECALL"
}

class Xboxir(eg.PluginBase):

    def __init__(self):
        eg.PluginBase.__init__(self)
        self.AddEvents()


    def __start__(self):
        self.timer = eg.ResettableTimer(self.OnTimeout)
        self.lastCode = None
        self.abortThread = False
        self.lastException = None
        startupEvent = threading.Event()
        self.thread = threading.Thread(
            target=self.ReceiveThread,
            name="StreamzapReceiveThread",
            args=(startupEvent,)
        )
        self.thread.start()
        startupEvent.wait(5.0)
        if self.lastException:
            self.timer.Stop()
            raise self.lastException


    def __stop__(self):
        self.abortThread = True
        self.timer.Stop()
        self.thread.join(5.0)


    def ReceiveThread(self, startupEvent):
        # This is the code executing in the new thread.
        try:
            dll = cdll.LoadLibrary(DLL_PATH)
        except WindowsError:
            self.lastException = self.Exceptions.DriverNotFound
            startupEvent.set()
            return

        if dll.XboxIrStartup() != 1:
            self.lastException = self.Exceptions.DriverNotOpen
            startupEvent.set()
            return
        
        startupEvent.set()
        while not self.abortThread:
            code = dll.XboxIrGetKey()
            eventname = CODES.get(code, None)
            if eventname is None:
                self.EndLastEvent()
                self.lastCode = None
            else:
                if code != self.lastCode:
                    self.TriggerEnduringEvent(eventname)
                    self.lastCode = code
                self.timer.Reset(140)
            continue

        dll.XboxIrShutdown()


    def OnTimeout(self):
        self.EndLastEvent()
        self.lastCode = None

