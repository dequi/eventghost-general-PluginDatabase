#include "xboxirdll.h"
#include <libusb.h>

enum {
	START_NONE = 0,
	START_ERROR,
	START_OK,
};

#define IR_VID		0x045e
#define IR_PID		0x0284
#define IR_IN_EP	0x81	// device only has this one endpoint

static HMODULE hModuleDll;
static libusb_device_handle* hDev = NULL;
static libusb_context * hCtx = NULL;

// try to open and claim the xbox IR device
libusb_device_handle* usbTryOpen(libusb_device *Dev)
{
	int err, ret = START_ERROR;
	libusb_device_handle* tdev = NULL;
	err = libusb_open(Dev, &tdev);
	// these two errors occur when 'ghost' devices show up after uninstalling or changing ports, at least they do on windows 10
	if ((err != LIBUSB_ERROR_NO_DEVICE) && (err != LIBUSB_ERROR_NOT_SUPPORTED))
	{
		if (err)
		{
// 			printf("ERROR: usbStartup() unable to open device! (%i)\n", err);
			tdev = NULL;
		}
		else
		{
			// 			printf("device opened!\n");
			// 			printf("Claiming interface...\n");
			err = libusb_claim_interface(tdev, 0);

			if (err != LIBUSB_SUCCESS)
			{
// 				printf("ERROR: usbStartup() unable to claim interface (%i)\n", err);
				libusb_close(tdev);
				tdev = NULL;
			}
			// 			else
			// 				printf("interface claimed!\n");
		}
	}
	return tdev;
}

// clear the pipes in case anything was stacked up in here before
void usbFlushRead(void)
{
	int err = LIBUSB_SUCCESS, rlen = 0;
	unsigned char data[8]; // seems to only ever send 6 bytes
	while (err == LIBUSB_SUCCESS) // LIBUSB_ERROR_TIMEOUT
	{
		err = libusb_interrupt_transfer(hDev, IR_IN_EP, data, 6, &rlen, 10);
	}
}

unsigned int usbDoRead(void)
{
	int err, rlen = 0;
	unsigned char data[8]; // seems to only ever send 6 bytes, device spec says max transfer size of 8
	// 	printf("waiting for receive\n");
	err = libusb_interrupt_transfer(hDev, IR_IN_EP, data, 6, &rlen, 100);
	if (err == LIBUSB_ERROR_TIMEOUT)
	{
		return 0; // no button was pressed during the poll
	}
	else if (err == LIBUSB_SUCCESS)
	{
		return getu32(data);
	}
	//else
	//{
	//	printf("libusb error receiving interrupt transfer from device (%i)\n", err);
	//}
	return 0xFFFFFFFF;
}

// the list must be iterated as sometimes there are 'ghost' devices that libusb sees as active but not present
// when having done things like installed it into 2 different usb ports.. even after removing the non-present device from device manager
unsigned int usbStartup(void)
{
	int ret = START_NONE;
	int err, cnt, i;
	int nmIface = 0;
	libusb_device **list;

	err = libusb_init(&hCtx);
	// 	libusb_set_debug(&hCtx, LIBUSB_LOG_LEVEL_INFO);
	if (err < 0)
	{
// 		printf("ERROR: usbStartup() failed to init libusbx! (0x%x)\n", ret);
		return START_ERROR;
	}
	cnt = libusb_get_device_list(NULL, &list);
	//printf("enumerating %d devices\n", cnt);
	for (i = 0; i < cnt; i++)
	{
		struct libusb_device_descriptor desc;
		int r = libusb_get_device_descriptor(list[i], &desc);
		if (r >= 0)
		{
			if ((desc.idVendor == IR_VID) && (desc.idProduct == IR_PID))
			{
// 				printf("%d: %04x:%04x XboxIR trying...\n", i, desc.idVendor, desc.idProduct);
				hDev = usbTryOpen(list[i]);
				if (hDev != NULL)
				{
// 					printf("%d: %04x:%04x XboxIR Opened!\n", i, desc.idVendor, desc.idProduct);
					usbFlushRead();
					ret = START_OK;
					i = cnt; // break the for loop, we got a winner
				}
			}
		}
	}
	libusb_free_device_list(list, 1);
	return ret;
}

// export ordinal 1, finds and attaches to the first present xbox IR device
// returns FALSE is unable to attach or no device found
XBOXIRDLL_API BOOL XboxIrStartup(void)
{
	if (usbStartup() == START_OK)
		return TRUE;
	return FALSE;
}

// export ordinal 2, releases any opened xbox IR devices
XBOXIRDLL_API void XboxIrShutdown(void)
{
	if (hDev != NULL)
	{
		libusb_release_interface(hDev, 0);
		libusb_close(hDev);
		// 		printf("device closed!\n");
	}
	if (hCtx != NULL)
		libusb_exit(hCtx);
}

// export ordinal 3
XBOXIRDLL_API unsigned int XboxIrGetKey(void)
{
	return usbDoRead();
}

BOOL APIENTRY DllMain( HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		hModuleDll = hModule;
		DisableThreadLibraryCalls(hModule);
		break;
	case DLL_THREAD_ATTACH: // disabled due to DisableThreadLibraryCalls
		break;
	case DLL_THREAD_DETACH: // disabled due to DisableThreadLibraryCalls
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

