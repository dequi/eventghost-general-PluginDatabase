#ifndef __XBOXIRDLL_H
#define __XBOXIRDLL_H
// Including SDKDDKVer.h defines the highest available Windows platform.
// If you wish to build your application for a previous Windows platform, include WinSDKVer.h and
// set the _WIN32_WINNT macro to the platform you wish to support before including SDKDDKVer.h.

#include <SDKDDKVer.h>
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#include <windows.h>

#define XBOXIRDLL_API __declspec(dllexport)

#define getu32(x)	(((x[0]&0xFF)<<24)|((x[1]&0xFF)<<16)|((x[2]&0xFF)<<8)|(x[3]&0xFF))


#endif // __XBOXIRDLL_H
