========================================================================
	DYNAMIC LINK LIBRARY : xboxirdll
	created for use with EventGhost by cory1492
	based on existing RegSpy, irdata and XBCDRC plugins
========================================================================
	Requires original xbox IR remote USB receiver installed with winusb drivers via zadig
	zadig: http://zadig.akeo.ie/

	Created to remove the need for unsigned XBOXCDRC driver in later windows OS,
	currently only tested on windows 10 x64.
	
	This version is built against libusb-1.0.20, if you want to rebuild you will have to add it
	to the libusb folder 
	http://libusb.info/ (prebuilt binary package can be found here)
	expects/uses only:
	{solutiondir}\libusb\include\libusb-1.0\libusb.h
	{solutiondir}\libusb\MS32\libusb-1.0.lib
	
	This project was built with visual studio 2013, at the time of writing VS2015 isn't
	easily co-operating with the pre-built libusb libraries. No DDK was touched in any
	way shape or form during this projects build, appropriately or otherwise.
	
/////////////////////////////////////////////////////////////////////////////
