# This file is part of EventGhost.
# Copyright (C) 2005 Lars-Peter Voss <bitmonster@eventghost.org>
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#
# $LastChangedDate: 2007-12-22 14:02:56 +0100 (Sa, 22 Dez 2007) $
# $LastChangedRevision: 343 $
# $LastChangedBy: bitmonster $

import eg

eg.RegisterPlugin(
    name = "egBluetooth",
    author = "kingtd",
    version = "1.0." + "$LastChangedRevision: 343 $".split()[1],
    kind = "remote",
    description = "Bluetooth tester",
    help = """
        Placeholder
    """,
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeT"
        "AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH1QQIDBMjdIFglwAAADV0RVh0Q29t"
        "bWVudAAoYykgMjAwNCBKYWt1YiBTdGVpbmVyCgpDcmVhdGVkIHdpdGggVGhlIEdJTVCQ"
        "2YtvAAABfklEQVQ4y6WSv0sCYRjHP2+IGlI0GOeN4WQJQnd/gENbRHtTji2NIkhTROLa"
        "EATh0hpE0OTmKNzgQUpDFEhdmosNVw3d2yB3+HYXRX3h5Xnf7/v8fh7BL1CrHywASSAN"
        "uMAAeK2Uq56IUFwFtoAH4BG4AZ6BJ+AF+KiUq55vE/sS7Ai4Ag6Bh0q5+vZTdqJWP1gD"
        "mj/oWYARwe/EgObG+qZMpxcFgBACKSVCKNUZ/t80ThsnxzEATcuIfr//bXjbtslmlxQu"
        "lZpTe2DbtqKgaRqDwUDhEokG7+8lEokGsKs6KBQKOI6Drus4jkMmk0FKGbxvb+/IZkt4"
        "nsR93WZ+kgAzvoNpY13XGY/HigSIx5Mkk7Pc390TGuO0cZQE6PV6of4EDjqdDgDD4TBS"
        "AuRyOSzLYnllOeCCEkzTxHVdTNNUDkA+n8d13ck8DYPudTecQavVUuQ02u32ZJssK7qE"
        "0WhEsVhESomUEiB09zwvWDKf9x3sX1ye7/E3nPFffAJVOqjtMbQazAAAAABJRU5ErkJg"
        "gg=="
    ),
)

import os
import threading
import bluetooth


class ThreadLooper (threading.Thread):
 
	def __init__ (self, sleep_interval, function, args=[], kwargs={}):
		threading.Thread.__init__(self)
        	self.sleep_interval = sleep_interval
        	self.function = function
        	self.args = args
        	self.kwargs = kwargs
        	self.finished = threading.Event()
		print "Init BT"
 
	def stop (self):
	        self.finished.set()
	        self.join()
 
	def run (self):

		print "Starting up BT loop"
	        while not self.finished.isSet():
	            self.finished.wait(self.sleep_interval)
	            self.function(*self.args, **self.kwargs)


class egBluetooth(eg.PluginClass):
	
    	def inquiry(self,mode):	
		print "Querying Blackberry"
#		nearby_devices = bluetooth.discover_devices(flush_cache=True, lookup_names=False)
#		print "found %d devices" % len(nearby_devices)
#		for addr in nearby_devices:
#		    print "%s" % (addr)


#  NOTE: THIS IS WHERE YOU HARDCODE THE DEVICE ID YOU'RE LOOKING FOR 
#  This is a very sloppy way to do things, but this plug-in is a work
#  in progress and unfinished.
		server_addr = "00:00:00:00:00:00"


		services = bluetooth.find_service(address=server_addr)

		if len(services) > 0:
		    self.TriggerEvent("Device Present",server_addr)					
#		    print "found %d services on %s" % (len(services),server_addr)
#		    print
		else:
		    self.TriggerEvent("Device Not Present",server_addr)

#		for svc in services:
#		    print "Service Name: %s"    % svc["name"]
#		    print "    Host:        %s" % svc["host"]
#		    print "    Description: %s" % svc["description"]
#		    print "    Provided By: %s" % svc["provider"]
#		    print "    Protocol:    %s" % svc["protocol"]
#		    print "    channel/PSM: %s" % svc["port"]
#		    print "    svc classes: %s "% svc["service-classes"]
#		    print "    profiles:    %s "% svc["profiles"]
#		    print "    service id:  %s "% svc["service-id"]
#		    print        


 
	def __start__(self, *args):
	        self.abort = False
	        self.running = True
 		btfind=ThreadLooper(30, self.inquiry, (self,))
		btfind.start()

	def __stop__(self):
		btfind.stop()
		print "Stopping Inquiry Timer"

        
