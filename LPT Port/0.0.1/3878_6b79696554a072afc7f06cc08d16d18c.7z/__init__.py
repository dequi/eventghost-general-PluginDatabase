import eg
eg.RegisterPlugin(
    name = "LPT Port",
    author = "eltroGuru",
    version = "0.0." + "$LastChangedRevision: 1 $".split()[1],
    description = "Bitwise enable Pins of LPT.",
)

import ctypes
import BitVector
from threading import Event, Thread


class LPTPlugin(eg.PluginBase):

    def __init__(self):
        self.inpout = ctypes.windll.inpout32
        self.data_out = BitVector.BitVector(bitlist = [0,0,0,0,0,0,0,0]);
        self.AddAction(Write)

    def __start__(self, lpt_address):
        self.oldInput = self.inpout.Inp32(0x379)
        self.stopThreadEvent = Event()
        
        thread = Thread(
            target=self.ThreadLoop,
            args=(self.stopThreadEvent, )
        )
        thread.start()
        print "LPT is started with parameter: " + lpt_address

    def __stop__(self):
        self.stopThreadEvent.set()
        print "LPT is stopped."

    def __close__(self):
        print "LPT is closed."

    def Configure(self, lpt_address="0x378"):
        panel = eg.ConfigPanel()
        textControl = wx.TextCtrl(panel, -1, lpt_address)
        panel.sizer.Add(textControl, 1, wx.EXPAND)
        while panel.Affirmed():
            panel.SetResult(textControl.GetValue())

    def ThreadLoop(self, stopThreadEvent):
        while not stopThreadEvent.isSet():
            input = self.inpout.Inp32(0x379)
            if self.oldInput != input:
                self.oldInput = input
                self.TriggerEvent("LPT IN CHANGED " + str(input))
            stopThreadEvent.wait(0.1)



class Write(eg.ActionBase):
    name = "Writes the Bits"
    description = "You won't guess what this action does."

    def __call__(self,changeBits,valBits):
        for i in range(0,7):
            if changeBits[i]:
                self.plugin.data_out[i] = valBits[i]
        self.plugin.inpout.Out32(0x378,self.plugin.data_out.intValue())

    def Configure(self,
        changeBits=[False,False,False,False,False,False,False,False],

        valBits=[False,False,False,False,False,False,False,False]
    ):
        panel = eg.ConfigPanel()

        gridSizer = wx.GridSizer(cols = 2, rows=8)

        vbox1Sizer = wx.BoxSizer(wx.VERTICAL)
        vbox2Sizer = wx.BoxSizer(wx.VERTICAL)


        chkCtrlcB0 = wx.CheckBox(panel, -1, "change bit 0")
        chkCtrlcB1 = wx.CheckBox(panel, -1, "change bit 1")
        chkCtrlcB2 = wx.CheckBox(panel, -1, "change bit 2")
        chkCtrlcB3 = wx.CheckBox(panel, -1, "change bit 3")
        chkCtrlcB4 = wx.CheckBox(panel, -1, "change bit 4")
        chkCtrlcB5 = wx.CheckBox(panel, -1, "change bit 5")
        chkCtrlcB6 = wx.CheckBox(panel, -1, "change bit 6")
        chkCtrlcB7 = wx.CheckBox(panel, -1, "change bit 7")

        chkCtrlcB0.SetValue(changeBits[0])
        chkCtrlcB1.SetValue(changeBits[1])
        chkCtrlcB2.SetValue(changeBits[2])
        chkCtrlcB3.SetValue(changeBits[3])
        chkCtrlcB4.SetValue(changeBits[4])
        chkCtrlcB5.SetValue(changeBits[5])
        chkCtrlcB6.SetValue(changeBits[6])
        chkCtrlcB7.SetValue(changeBits[7])

        chkCtrlvB0 = wx.CheckBox(panel, -1, "set bit 0")
        chkCtrlvB1 = wx.CheckBox(panel, -1, "set bit 1")
        chkCtrlvB2 = wx.CheckBox(panel, -1, "set bit 2")
        chkCtrlvB3 = wx.CheckBox(panel, -1, "set bit 3")
        chkCtrlvB4 = wx.CheckBox(panel, -1, "set bit 4")
        chkCtrlvB5 = wx.CheckBox(panel, -1, "set bit 5")
        chkCtrlvB6 = wx.CheckBox(panel, -1, "set bit 6")
        chkCtrlvB7 = wx.CheckBox(panel, -1, "set bit 7")

        chkCtrlvB0.SetValue(valBits[0])
        chkCtrlvB1.SetValue(valBits[1])
        chkCtrlvB2.SetValue(valBits[2])
        chkCtrlvB3.SetValue(valBits[3])
        chkCtrlvB4.SetValue(valBits[4])
        chkCtrlvB5.SetValue(valBits[5])
        chkCtrlvB6.SetValue(valBits[6])
        chkCtrlvB7.SetValue(valBits[7])

        vbox1Sizer.Add(chkCtrlcB0,0,  wx.ALL, 3)
        vbox1Sizer.Add(chkCtrlcB1,0,  wx.ALL, 3)
        vbox1Sizer.Add(chkCtrlcB2,0,  wx.ALL, 3)
        vbox1Sizer.Add(chkCtrlcB3,0,  wx.ALL, 3)
        vbox1Sizer.Add(chkCtrlcB4,0,  wx.ALL, 3)
        vbox1Sizer.Add(chkCtrlcB5,0,  wx.ALL, 3)
        vbox1Sizer.Add(chkCtrlcB6,0,  wx.ALL, 3)
        vbox1Sizer.Add(chkCtrlcB7,0,  wx.ALL, 3)

        vbox2Sizer.Add(chkCtrlvB0,0,  wx.ALL, 3)
        vbox2Sizer.Add(chkCtrlvB1,0,  wx.ALL, 3)
        vbox2Sizer.Add(chkCtrlvB2,0,  wx.ALL, 3)
        vbox2Sizer.Add(chkCtrlvB3,0,  wx.ALL, 3)
        vbox2Sizer.Add(chkCtrlvB4,0,  wx.ALL, 3)
        vbox2Sizer.Add(chkCtrlvB5,0,  wx.ALL, 3)
        vbox2Sizer.Add(chkCtrlvB6,0,  wx.ALL, 3)
        vbox2Sizer.Add(chkCtrlvB7,0,  wx.ALL, 3)

        gridSizer.Add(vbox1Sizer, 0, wx.ALL, 5)
        gridSizer.Add(vbox2Sizer, 0, wx.ALL, 5)
        panel.sizer.Add(gridSizer)

        while panel.Affirmed():

            changeBits[0]  = chkCtrlcB0.GetValue()
            changeBits[1]  = chkCtrlcB1.GetValue()
            changeBits[2]  = chkCtrlcB2.GetValue()
            changeBits[3]  = chkCtrlcB3.GetValue()
            changeBits[4]  = chkCtrlcB4.GetValue()
            changeBits[5]  = chkCtrlcB5.GetValue()
            changeBits[6]  = chkCtrlcB6.GetValue()
            changeBits[7]  = chkCtrlcB7.GetValue()


            valBits[0]     = chkCtrlvB0.GetValue()
            valBits[1]     = chkCtrlvB1.GetValue()
            valBits[2]     = chkCtrlvB2.GetValue()
            valBits[3]     = chkCtrlvB3.GetValue()
            valBits[4]     = chkCtrlvB4.GetValue()
            valBits[5]     = chkCtrlvB5.GetValue()
            valBits[6]     = chkCtrlvB6.GetValue()
            valBits[7]     = chkCtrlvB7.GetValue()

            panel.SetResult( changeBits, valBits
            )

