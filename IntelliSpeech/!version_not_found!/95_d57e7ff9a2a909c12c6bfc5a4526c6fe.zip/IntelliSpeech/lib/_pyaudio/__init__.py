from pyaudio import __version__
from pyaudio import *