import eg
eg.RegisterPlugin(
    name = "Google Voice",
    author = 'cfull1',
    version = '0.1.1',
    kind = 'other',
    canMultiLoad = True,       #change to true
    description = (
        "Based on pygooglevoice google code. Scraps "
        "Google Voice webpage for data"
    ),
)

import sys
from voice import Voice
import BeautifulSoup
from threading import Thread, Event


class textThread(Thread):
    def __init__(self, voice, delay, prefix, verbose):
        self.threadFlag = Event()
        self.voice = voice
        self.delay = delay
        self.prefix = prefix
        self.verbose = verbose
        self.abort = False
        self.aborted = False
        Thread.__init__(self)
    def run(self):
        if self.verbose:
            print 'Starting SMS Observation'
        self.abort = False
        self.aborted = False
        while self.abort is False:
            try:
                self.voice.sms()
            except: #login timeout
                self.voice.login()
            mostRecent = None
            for msg in self.extractsms(self.voice.sms.html):
                msg['from'] = (msg['from'])[:-1]
                if msg ['text'] == 'Stop':
                    if self.verbose:
                        print 'SMS Obvseration aborted'
                    self.abortThread()
                # elif msg['from'] == ('Computer'):
                    # msg['instance'].delete()
                    # print 'deleting computer'
                elif msg['from'] == ('Me'):
                    msg['instance'].delete()
                    # print 'deleting me'
                else:
                    payload = msg.copy()
                    try:
                        del payload['instance']
                    except:
                        print 'Could not delete payload instance'
                    del payload['id']
                    del payload['text']
                    self.TriggerEvent(msg['text'], payload)
                    if msg['instance'] is not '':
                        msg['instance'].delete()
                    else:
                        print 'Could not delete'
                        print 'instance is empty'
            self.threadFlag.wait(self.delay)
            self.threadFlag.clear()
        if self.verbose:
            print 'SMS Obvseration aborted'
        self.aborted = True
        
    def abortThread(self):
        if self.aborted is False:
            self.abort = True
            self.threadFlag.set()
            
    def TriggerEvent(self, data, Payload):
        if(len(Payload) == 0):
            eg.TriggerEvent(data, prefix=self.prefix)
        else:
            eg.TriggerEvent(data, prefix=self.prefix, payload=Payload)
            
    def extractsms(self, htmlsms):
        """
        extractsms  --  extract SMS messages from BeautifulSoup tree of Google Voice SMS HTML.

        Output is a list of dictionaries, one per message.
        """
        msgitems = []										# accum message items here
        	# Extract all conversations by searching for a DIV with an ID at top level.
        tree = BeautifulSoup.BeautifulSoup(htmlsms)			# parse HTML into tree
        conversations = tree.findAll("div",attrs={"id" : True},recursive=False)
        for conversation in conversations :
            	# For each conversation, extract each row, which is one SMS message.
            rows = conversation.findAll(attrs={"class" : "gc-message-sms-row"})
            for row in rows :								# for all rows
                	# For each row, which is one message, extract all the fields.
                msgitem = {"id" : conversation["id"]}		# tag this message with conversation ID
                spans = row.findAll("span",attrs={"class" : True}, recursive=False)
                for span in spans :							# for all spans in row
                    cl = span["class"].replace('gc-message-sms-', '')
                    msgitem[cl] = (" ".join(span.findAll(text=True))).strip()	# put text in dict
                    try:
                        for message in self.voice.sms().messages:
                            if msgitem['id'] == message.id:
                                msgitem['number'] = message.phoneNumber         # put number in dict
                                msgitem['instance'] = message                    # put message instance in dict for deleting, etc.
                    except:
                        print 'could not put number or instance in dict'
                        msgitem['number'] = ''
                        msgitem['instance'] = ''
                msgitems.append(msgitem)					# add msg dictionary to list
        return msgitems
        
class Text:
    loginSettings = "Login Settings"
    username = "Email:"
    password = "Password:"
    otherSettings = "Other Settings"
    delay =  "Delay:"
    prefix = "Event Prefix:"
    verbose = "Verbose Mode:"
    autoStart = "Start SMS Observation Automatically:"
    class SendSMS:
        name = "Send SMS"
        description = "Send an SMS message"
        number = "Number"
        message = "Message"
    
class GoogleVoice(eg.PluginBase):
    text = Text
    def __init__(self):
        self.AddAction(SMSObservation)
        self.AddAction(AbortSMSObservation)
        self.AddAction(SendSMS)
        self.AddAction(DeleteAll)
        
    def __start__(
            self, 
            username, 
            password, 
            delay, 
            prefix, 
            verbose,
            autoStart,
            ):
        self.voice = Voice()
        self.delay = delay
        self.prefix = prefix
        self.verbose = verbose
        try:
            self.voice.login(username, password)
            if verbose:
                print 'Logged into Google Voice'
        except:
            print "OHHHHHH NOOOOOOOOOO!!!!"
        self.thread = None
        if autoStart:
            self.thread = textThread(
                self.voice,
                self.delay,
                self.prefix,
                self.verbose
                )
            self.thread.start()
        
    def __stop__(self):
        if self.thread is not None:
            self.thread.abortThread()
            self.thread = None
        self.voice.logout()
        if self.verbose:
            print 'Logged out of Google Voice'
        
    def Configure(self, username="", password="", delay=3, prefix="GV", verbose=True, autoStart=False):
        text = self.text
        panel = eg.ConfigPanel()
        userCtrl = panel.TextCtrl(username)
        passCtrl = panel.TextCtrl(password, style=wx.TE_PASSWORD)
        delayCtrl = panel.SpinIntCtrl(delay, min=1)
        prefixCtrl = panel.TextCtrl(prefix)
        verboseCtrl = panel.CheckBox(verbose)
        autoStartCtrl = panel.CheckBox(autoStart)
        loginBox = panel.BoxedGroup(
            text.loginSettings,
            (text.username, userCtrl),
            (text.password, passCtrl),
        )
        otherBox = panel.BoxedGroup(
            text.otherSettings,
            (text.delay, delayCtrl),
            (text.prefix, prefixCtrl),
            (text.verbose, verboseCtrl),
            (text.autoStart, autoStartCtrl),
        )
        eg.EqualizeWidths(loginBox.GetColumnItems(0))
        eg.EqualizeWidths((otherBox.GetColumnItems(0))[:-1])
        panel.sizer.Add(loginBox, 0, wx.EXPAND)
        panel.sizer.Add(otherBox, 0, wx.EXPAND)
        while panel.Affirmed():
            panel.SetResult(
                userCtrl.GetValue(),
                passCtrl.GetValue(),
                delayCtrl.GetValue(),
                prefixCtrl.GetValue(),
                verboseCtrl.GetValue(),
                autoStartCtrl.GetValue(),
            )
            
class SMSObservation(eg.ActionBase):
    name = "SMS Observation"
    def __call__(self):
        if self.plugin.thread is None:
            self.plugin.thread = textThread(
                        self.plugin.voice,
                        self.plugin.delay,
                        self.plugin.prefix,
                        self.plugin.verbose
                        )
            self.plugin.thread.start()
        else:
            if self.plugin.verbose:
                print "Thread already started"

class DeleteAll(eg.ActionBase):
    name = "Delete All"
    decriptiong = "Incase of loop"
    def __call__(self):            
        for message in self.plugin.voice.sms().messages:
            message.delete()
        
class AbortSMSObservation(eg.ActionBase):
    name = "Abort SMS Observation"
    def __call__(self):
        if self.plugin.thread is not None:
            self.plugin.thread.abortThread()
            self.plugin.thread = None
        
class SendSMS(eg.ActionBase):
    text = Text
    def __call__(self, number='', msg=''):
        try:
            self.plugin.voice.send_sms(number, msg)
        except Exception,e:
            print str(e)
            print "Number is not valid"
        
    def Configure(self, number="", msg=""):
        text = self.text
        panel = eg.ConfigPanel()
        numCtrl = panel.TextCtrl(number)
        msgCtrl = panel.TextCtrl(msg, style=wx.TE_MULTILINE)
        # msgCtrl.SetMinSize((-1, 100))
        msgCtrl.SetMaxSize((-1, 60))
        number = panel.StaticText(text.number)
        message = panel.StaticText(text.message)
        panel.sizer.Add(number, 0, wx.EXPAND)
        panel.sizer.Add((5, 5))
        panel.sizer.Add(numCtrl, 0, wx.EXPAND)
        panel.sizer.Add((5, 5))
        panel.sizer.Add(message, 0, wx.EXPAND)
        panel.sizer.Add((5, 5))
        panel.sizer.Add(msgCtrl, 0, wx.EXPAND)
        panel.sizer.Add((5, 5))
        while panel.Affirmed():
            panel.SetResult(
                numCtrl.GetValue(),
                msgCtrl.GetValue(),
            )