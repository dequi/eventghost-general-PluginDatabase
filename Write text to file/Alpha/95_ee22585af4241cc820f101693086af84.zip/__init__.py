version="Alpha" 
# This file is part of EventGhost.
# Copyright (C) 2005 Lars-Peter Voss <bitmonster@eventghost.org>
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#Last change: 2008-09-30 11:58

eg.RegisterPlugin(
    name = "Write text to file",
    author = "Pako",
    version = version,
    kind = "other",
    createMacrosOnAdd = False,
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAADAFBMVEX4/PjgtGjIlFDI"
        "kEjYsFjYqFDYpGjw4Mj44MjIlEDYvJDguCjw1KD44MDw2LjIkFD47MD44KjYrGjwzKDI"
        "mFj49LDw2GjwzGjQnFjYqHDw3GDw1ED47IjgtFjYjDi4kCC4iCDw5LjgyLDIqGCQbBj4"
        "5NCwfDDAmDDYxGjInEjAgDDoqGDomEDAZBCoYBCwdChYQBDozKjAiEiYaCDYwJAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVBa15AAAA"
        "AXRSTlMAQObYZgAAAAlwSFlzAAALEgAACxIB0t1+/AAAAGdJREFUeNpjYMADGJmYWZD5"
        "rGzsHJxcCD43Dy8HBx8/gi8gKCQszCeC4IuKiUtIMiPxpaRlZOVw8eXR+AqKaHwlZRS+"
        "CruqmrqGphbcASoc2jq6evoIFxpICBsaIfEZDAyM9U3weBkAHOgJw4bE4b0AAAAASUVO"
        "RK5CYII="
    ),
    description = (
        'Alpha version'
    ),
)

import os
import time
import codecs

def MyParseString(text, page, error):
    start = 0
    chunks = []
    last = len(text) - 1
    while 1:
        pos = text.find('{', start)
        if pos < 0:
            break
        if pos == last:
            break
        chunks.append(text[start:pos])
        if text[pos+1] == '{':
            chunks.append('{')
            start = pos + 2
        else:
            start = pos + 1
            end = text.find('}', start)
            if end == -1:
                raise SyntaxError("unmatched bracket")
            word = text[start:end]
            res = None
            if res is None:	
                res = eval(word, {}, eg.globals.__dict__)
            if page is None:
                chunks.append(unicode(res))
            else:
                chunks.append(res.decode(page,error))
            start = end + 1
    chunks.append(text[start:])
    return "".join(chunks)


def String2Hex(string):
    res = ""
    for i in string:
        res+="%02X " % ord(i)
    return res.rstrip()

#===============================================================================
class WriteTextToFile(eg.PluginClass):
    def __init__(self):
        self.AddAction(Write)


class Write(eg.ActionClass):
    name = "Write text to file"
    description = "Writes text to selected file."
    class text:
        label = "Write to this file: %s"
        TreeLabel = "Write %s to file: %s"
        FilePath = "Output file:"
        browseFileDialogTitle = "Choose the file"
        txtMode = "Mode of write"
        overwrite = "File overwrite"
        append = "Append to file"
        newLine = "Append to file with new line"
        writeToLog = "Write to EventGhost log too"
        error = "Could not open file %s"
        systemPage = "System code page (%s)"
        pageChoice = "Manual choice"
        defaultIn = "Default (without decoding)"
        defaultOut = "Unicode (UTF-8)"
        hex = "String write in the HexDump form"
        codePage = "Code page:"
        inString = "Input text:"
        logTimes = "Write Timestamp"
        inputPage = "Input data coding"
        outputPage = "Output data coding"
        txtEncodeMode = "Mode of error handling during encoding"
        txtDecodeMode = "Mode of error handling during decoding"
        strict = "Raise an exception"
        ignore = "Ignore (skip bad chars)"
        replace = "Replace bad chars"
    
    def __call__(
        self,
        string = "",
        fileName = '',
        mode = 0,
        decMode = 0,
        encMode = 0,
        log = False,
        times = False,
        inCoding = 0,
        outCoding = 1,
        inPage = "",
        outPage = "",
        hex = False
    ):
        modeStr='w' if mode==0 else 'a'
        stamp = time.strftime('%c')+'  ' if times else ''
        cr = '\r\n' if mode == 2 else ''        
        errorList = ('strict','ignore','replace')
        string = MyParseString(string,inPage,errorList[decMode])
        if not hex:
            try:
                file = codecs.open(fileName, modeStr, outPage,errorList[encMode])            
            except:
                raise
        else:
            string = string.encode(outPage,errorList[encMode])
            string = String2Hex(string)
            try:
                file = open(fileName,modeStr)
            except:
                raise
        try:
            file.write('%s%s%s' % (stamp, string, cr))
        except:
            raise
        try:    
            file.close()
        except:
            raise
        if log:
            print string

            
    def GetLabel(
        self,
        string,
        fileName,
        mode,
        decMode,
        encMode,
        log,
        times,
        inCoding,
        outCoding,
        inPage,
        outPage,
        hex
    ):
        return self.text.TreeLabel % (string, os.path.split(fileName)[1])

    def Configure(
        self,
        string = "",
        fileName = '',
        mode = 0,
        decMode = 0,
        encMode = 0,
        log = False,
        times = False,
        inCoding = 0,
        outCoding = 1,
        inPage="",
        outPage="",
        hex = False
    ):
        from codecsList import codecsList
        self.inCoding = inCoding
        self.outCoding = outCoding
        panel = eg.ConfigPanel(self)
        text = self.text
    #Controls    
        stringText = wx.StaticText(panel, -1, text.inString)
        stringCtrl = wx.TextCtrl(panel, -1, string, style=wx.TE_NOHIDESEL)
        fileText = wx.StaticText(panel, -1, text.FilePath)
        filepathCtrl = eg.FileBrowseButton(
            panel, 
            -1, 
            size=(420,-1),
            initialValue=fileName,
            labelText="",
            fileMask="*.*",
            buttonText=eg.text.General.browse,
            dialogTitle=text.browseFileDialogTitle
        )
        radioBoxMode = wx.RadioBox(
            panel, 
            -1, 
            text.txtMode,
            (0,0),
            choices=[text.overwrite, text.append, text.newLine],
            style=wx.RA_SPECIFY_ROWS
        )
        radioBoxEncodeMode = wx.RadioBox(
            panel, 
            -1, 
            text.txtEncodeMode,
            (0,0),
            choices=[text.strict, text.ignore, text.replace],
            style=wx.RA_SPECIFY_ROWS
        )
        radioBoxDecodeMode = wx.RadioBox(
            panel, 
            -1, 
            text.txtDecodeMode,
            (0,0),
            choices=[text.strict, text.ignore, text.replace],
            style=wx.RA_SPECIFY_ROWS
        )
        radioBoxMode.SetSelection(mode)
        radioBoxDecodeMode.SetSelection(decMode)
        radioBoxEncodeMode.SetSelection(encMode)
        rbi0 = panel.RadioButton(self.inCoding == 0, text.defaultIn, style=wx.RB_GROUP)
        rbi1 = panel.RadioButton(self.inCoding == 1, text.systemPage % eg.systemEncoding)                            
        rbi2 = panel.RadioButton(self.inCoding == 2, text.pageChoice)                            
        rbo0 = panel.RadioButton(self.outCoding == 0, text.defaultOut, style=wx.RB_GROUP)
        rbo1 = panel.RadioButton(self.outCoding == 1, text.systemPage % eg.systemEncoding)                            
        rbo2 = panel.RadioButton(self.outCoding == 2, text.pageChoice)                            
        writeToLogCheckBox = wx.CheckBox(panel, -1, text.writeToLog)
        writeToLogCheckBox.SetValue(log)
        timesCheckBox = wx.CheckBox(panel, -1, text.logTimes)
        timesCheckBox.SetValue(times)
        hexCheckBox = wx.CheckBox(panel, -1, text.hex)
        hexCheckBox.SetValue(hex)
        box1 = wx.StaticBox(panel,-1,text.inputPage)
        box2 = wx.StaticBox(panel,-1,text.outputPage)
        labelInCtrl = panel.StaticText(text.codePage)
        inPageCtrl = wx.ComboBox(panel,-1,choices=codecsList,size=(180,-1))
        labelOutCtrl = panel.StaticText(text.codePage)
        outPageCtrl = wx.ComboBox(panel,-1,choices=codecsList,size=(180,-1))
    #Sizers
        mainSizer=wx.BoxSizer(wx.VERTICAL)
        boxSizer1 = wx.StaticBoxSizer(box1,wx.HORIZONTAL)
        inputSizer = wx.BoxSizer(wx.VERTICAL)
        inPageSizer = wx.BoxSizer(wx.VERTICAL)
        boxSizer2 = wx.StaticBoxSizer(box2,wx.HORIZONTAL)
        outputSizer = wx.BoxSizer(wx.VERTICAL)
        bottomSizer = wx.GridSizer(1,2,1,10)
        outPageSizer = wx.BoxSizer(wx.VERTICAL)
        chkBoxSizer = wx.BoxSizer(wx.VERTICAL)
        #inputSizer.SetMinSize((250, -1))
        inputSizer.Add(rbi0)
        inputSizer.Add(rbi1, 0, wx.TOP,8)
        inputSizer.Add(rbi2, 0, wx.TOP,8)
        inPageSizer.Add(labelInCtrl, 0, wx.TOP,3)
        inPageSizer.Add(inPageCtrl, 0, wx.TOP|wx.RIGHT,2)
        boxSizer1.Add(inputSizer,1,wx.EXPAND)
        boxSizer1.Add(inPageSizer,1,wx.RIGHT,5)        
        #outputSizer.SetMinSize((250, -1))
        outputSizer.Add(rbo0)
        outputSizer.Add(rbo1, 0, wx.TOP,8)
        outputSizer.Add(rbo2, 0, wx.TOP,8)
        outPageSizer.Add(labelOutCtrl, 0, wx.TOP,3)
        outPageSizer.Add(outPageCtrl, 0, wx.TOP|wx.RIGHT,2)
        boxSizer2.Add(outputSizer,1,wx.EXPAND)
        boxSizer2.Add(outPageSizer,1,wx.RIGHT,5)
        chkBoxSizer.Add(writeToLogCheckBox,0,wx.TOP|wx.LEFT,12)        
        chkBoxSizer.Add(timesCheckBox,0,wx.TOP|wx.LEFT,12)     
        chkBoxSizer.Add(hexCheckBox,0,wx.TOP|wx.LEFT,12)     
        bottomSizer.Add(radioBoxMode,0,wx.TOP,5)
        bottomSizer.Add(chkBoxSizer)
        mainSizer.Add(stringText)
        mainSizer.Add(stringCtrl, 0, wx.EXPAND)
        mainSizer.Add(boxSizer1,0,wx.TOP|wx.EXPAND,5)
        mainSizer.Add(radioBoxDecodeMode,0,wx.TOP|wx.EXPAND,5)
        mainSizer.Add(fileText,0,wx.TOP,5)
        mainSizer.Add(filepathCtrl, 0, wx.EXPAND)
        mainSizer.Add(boxSizer2,0,wx.TOP|wx.EXPAND,5)
        mainSizer.Add(radioBoxEncodeMode,0,wx.TOP|wx.EXPAND,5)
        mainSizer.Add(bottomSizer)
        panel.sizer.Add(mainSizer)

        def onInCodingChange(event=None):
            indx = 0
            inPageList = (text.defaultIn,text.systemPage % eg.systemEncoding,'')
            for rbi in (rbi0,rbi1,rbi2):
                if rbi.GetValue():
                    break
                indx+=1
            self.inCoding = indx
            if indx == 2:
                if ((inPageCtrl.GetValue()==inPageList[0]) | (inPageCtrl.GetValue()==inPageList[1])):
                    inPageCtrl.SetValue('')
                else:
                    inPageCtrl.SetValue(inPage)
                labelInCtrl.Enable(True)
                inPageCtrl.Enable(True)
            else:
                inPageCtrl.SetValue(inPageList[indx])
                labelInCtrl.Enable(False)
                inPageCtrl.Enable(False)
            if event:
                event.Skip()
        rbi0.Bind(wx.EVT_RADIOBUTTON, onInCodingChange)
        rbi1.Bind(wx.EVT_RADIOBUTTON, onInCodingChange)
        rbi2.Bind(wx.EVT_RADIOBUTTON, onInCodingChange)
        onInCodingChange()

        def onOutCodingChange(event=None):
            indx = 0
            outPageList = (text.defaultOut,text.systemPage % eg.systemEncoding,'')
            for rbo in (rbo0,rbo1,rbo2):
                if rbo.GetValue():
                    break
                indx+=1
            self.outCoding = indx
            if indx == 2:
                if ((outPageCtrl.GetValue()==outPageList[0]) | (outPageCtrl.GetValue()==outPageList[1])):
                   outPageCtrl.SetValue('') 
                else:
                    outPageCtrl.SetValue(outPage)
                labelOutCtrl.Enable(True)
                outPageCtrl.Enable(True)
            else:
                outPageCtrl.SetValue(outPageList[indx])
                labelOutCtrl.Enable(False)
                outPageCtrl.Enable(False)
            if event:
                event.Skip()
        rbo0.Bind(wx.EVT_RADIOBUTTON, onOutCodingChange)
        rbo1.Bind(wx.EVT_RADIOBUTTON, onOutCodingChange)
        rbo2.Bind(wx.EVT_RADIOBUTTON, onOutCodingChange)
        onOutCodingChange()

        while panel.Affirmed():
            panel.SetResult(
                stringCtrl.GetValue(),
                filepathCtrl.GetValue(),
                radioBoxMode.GetSelection(),
                radioBoxDecodeMode.GetSelection(),
                radioBoxEncodeMode.GetSelection(),
                writeToLogCheckBox.IsChecked(),
                timesCheckBox.IsChecked(),
                self.inCoding,
                self.outCoding,
                inPageCtrl.GetValue() if self.inCoding == 2 else (None,eg.systemEncoding)[self.inCoding],
                outPageCtrl.GetValue() if self.outCoding == 2 else ('utf8',eg.systemEncoding)[self.outCoding],
                hexCheckBox.IsChecked(),
            )        
