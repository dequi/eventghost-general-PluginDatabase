version="0.1.0" 
# This file is part of EventGhost.
# Copyright (C)  2008 Pako  (lubos.ruckl@quick.cz)
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#Last change: 2008-10-03 19:38

eg.RegisterPlugin(
    name = "Write text to file",
    author = "Pako",
    version = version,
    kind = "other",
    createMacrosOnAdd = False,
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAADAFBMVEX4/PjgtGjIlFDI"
        "kEjYsFjYqFDYpGjw4Mj44MjIlEDYvJDguCjw1KD44MDw2LjIkFD47MD44KjYrGjwzKDI"
        "mFj49LDw2GjwzGjQnFjYqHDw3GDw1ED47IjgtFjYjDi4kCC4iCDw5LjgyLDIqGCQbBj4"
        "5NCwfDDAmDDYxGjInEjAgDDoqGDomEDAZBCoYBCwdChYQBDozKjAiEiYaCDYwJAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVBa15AAAA"
        "AXRSTlMAQObYZgAAAAlwSFlzAAALEgAACxIB0t1+/AAAAGdJREFUeNpjYMADGJmYWZD5"
        "rGzsHJxcCD43Dy8HBx8/gi8gKCQszCeC4IuKiUtIMiPxpaRlZOVw8eXR+AqKaHwlZRS+"
        "CruqmrqGphbcASoc2jq6evoIFxpICBsaIfEZDAyM9U3weBkAHOgJw4bE4b0AAAAASUVO"
        "RK5CYII="
    ),
    description = (
        "Writes text to selected file."
    ),
)

import time
import codecs

def MyParseString(text, page, error):
    start = 0
    chunks = []
    last = len(text) - 1
    while 1:
        pos = text.find('{', start)
        if pos < 0:
            break
        if pos == last:
            break
        chunks.append(text[start:pos])
        if text[pos+1] == '{':
            chunks.append('{')
            start = pos + 2
        else:
            start = pos + 1
            end = text.find('}', start)
            if end == -1:
                raise SyntaxError("unmatched bracket")
            word = text[start:end]
            res = None
            if res is None:	
                res = eval(word, {}, eg.globals.__dict__)
            chunks.append(res.decode(page,error))
            start = end + 1
    chunks.append(text[start:])
    return "".join(chunks)


def String2Hex(string,length='2'):
    tmp = []
    s2h="%0"+length+"X "
    for c in string:
        tmp.append( s2h % ord( c ) )    
    return ''.join( tmp ).strip()  

#===============================================================================
class WriteTextToFile(eg.PluginClass):
    def __init__(self):
        self.AddAction(Write)


class Write(eg.ActionClass):
    name = "Write text to file"
    description = "Writes text to selected file."
    class text:
        TreeLabel = "Write %s to file: %s"
        FilePath = "Output file:"
        browseFileDialogTitle = "Choose the file"
        txtMode = "Mode of write"
        overwrite = "File overwrite"
        append = "Append to file"
        newLine = "Append to file with new line"
        writeToLog = "Write to EventGhost log too"
        systemPage = "system code page (%s)"
        defaultOut = "unicode (UTF-8)"
        hexdump = "String write in the HexDump form"
        inString = "Input text:"
        logTimes = "Write Timestamp"
        inputPage = "Input data coding:"
        outputPage = "Output data coding:"
        txtDecErrMode = "Error handling during decoding:"
        txtEncErrMode = "Error handling during encoding:"
        strict = "Raise an exception"
        ignore = "Ignore (skip bad chars)"
        replace = "Replace bad chars"
        internal = 'unicode internal'
    
    def __call__(
        self,
        inCoding,
        outCoding,
        string = "",
        fileName = '',
        mode = 0,
        errDecMode = 0,
        errEncMode = 0,
        log = False,
        times = False,
        hex = False,
        inPage = "",
        outPage = "",
    ):
        modeStr='w' if mode==0 else 'a'
        stamp = time.strftime('%c')+'  ' if times else ''
        cr = '\r\n' if mode == 2 else ''        
        errorList = ('strict','ignore','replace')
        string = MyParseString(string,inPage,errorList[errDecMode])
        if hex:
            if outPage != 'unicode_internal':
                string = string.encode(outPage,errorList[errDecMode])
                string = String2Hex(string)
            else:
                string = String2Hex(string,'4')
            outPage = 'ascii'
            
        try:
            file = codecs.open(fileName, modeStr, outPage, errorList[errDecMode]) 
        except:
            raise
        try:
            file.write('%s%s%s' % (stamp, string, cr))
        except:
            raise
        try:    
            file.close()
        except:
            raise
        if log:
            print string
        return string
            
    def GetLabel(
        self,
        inCoding,
        outCoding,
        string,
        fileName,
        mode,
        errDecMode,
        errEncMode,
        log,
        times,
        hex,
        inPage,
        outPage,
    ):
        return self.text.TreeLabel % (string, fileName)

    def Configure(
        self,
        inCoding = 0,
        outCoding = 2,
        string = "{eg.result}",
        fileName = u'EG_WTTF.txt',
        mode = 2,
        errDecMode = 0,
        errEncMode = 0,
        log = False,
        times = False,
        hex = False,
        inPage="",
        outPage="",
    ):
        from codecsList import codecsList
        panel = eg.ConfigPanel(self)
        text = self.text
    #Controls    
        stringText = wx.StaticText(panel, -1, text.inString)
        inPageText = wx.StaticText(panel, -1, text.inputPage)
        outPageText = wx.StaticText(panel, -1, text.outputPage)
        labelDecErrMode = wx.StaticText(panel, -1, text.txtDecErrMode)
        labelEncErrMode = wx.StaticText(panel, -1, text.txtEncErrMode)
        fileText = wx.StaticText(panel, -1, text.FilePath)
        filepathCtrl = eg.FileBrowseButton(
            panel, 
            -1, 
            initialValue=fileName,
            labelText="",
            fileMask="*.*",
            buttonText=eg.text.General.browse,
            dialogTitle=text.browseFileDialogTitle
        )
        w1 = labelDecErrMode.GetTextExtent(text.txtDecErrMode)[0]
        w2 = labelEncErrMode.GetTextExtent(text.txtEncErrMode)[0]
        width = max(w1,w2)
        choiceDecErrMode = wx.Choice(
            panel,
            -1,
            size = ((width,-1)),
            choices=(text.strict, text.ignore, text.replace)
        )
        choiceEncErrMode = wx.Choice(
            panel,
            -1,
            size = ((width,-1)),
            choices=(text.strict, text.ignore, text.replace)
        )
        stringCtrl = wx.TextCtrl(panel, -1, string, style=wx.TE_NOHIDESEL)
        radioBoxMode = wx.RadioBox(
            panel, 
            -1, 
            text.txtMode,
            choices=[text.overwrite, text.append, text.newLine],
            style=wx.RA_SPECIFY_ROWS
        )
        radioBoxMode.SetSelection(mode)
        choiceDecErrMode.SetSelection(errDecMode)
        choiceEncErrMode.SetSelection(errEncMode)
        writeToLogCheckBox = wx.CheckBox(panel, -1, text.writeToLog)
        writeToLogCheckBox.SetValue(log)
        timesCheckBox = wx.CheckBox(panel, -1, text.logTimes)
        timesCheckBox.SetValue(times)
        hexCheckBox = wx.CheckBox(panel, -1, text.hexdump)
        hexCheckBox.SetValue(hex)
        choices = [text.internal, text.defaultOut, text.systemPage % eg.systemEncoding]
        choices.extend(codecsList)
        inPageCtrl = wx.Choice(panel,-1,choices=choices)
        inPageCtrl.SetSelection(inCoding)
        outPageCtrl = wx.Choice(panel,-1,choices=choices)
        outPageCtrl.SetSelection(outCoding)
    #Sizers
        topSizer = wx.FlexGridSizer(8,0,1,15)
        topSizer.AddGrowableCol(0,1)
        topSizer.AddGrowableCol(1,1)
        topSizer.Add(stringText,0,wx.EXPAND)
        topSizer.Add(fileText,0,wx.EXPAND)
        topSizer.Add(stringCtrl,0,wx.EXPAND)
        topSizer.Add(filepathCtrl,0,wx.EXPAND)
        topSizer.Add((1,7))
        topSizer.Add((1,7))
        topSizer.Add(inPageText,0,wx.EXPAND)
        topSizer.Add(outPageText,0,wx.EXPAND)
        topSizer.Add(inPageCtrl,0,wx.EXPAND)
        topSizer.Add(outPageCtrl,0,wx.EXPAND)
        topSizer.Add((1,7))
        topSizer.Add((1,7))
        topSizer.Add(labelDecErrMode,0,wx.EXPAND)
        topSizer.Add(labelEncErrMode,0,wx.EXPAND)
        topSizer.Add(choiceDecErrMode,0,wx.EXPAND)
        topSizer.Add(choiceEncErrMode,0,wx.EXPAND)
        chkBoxSizer = wx.BoxSizer(wx.VERTICAL)
        chkBoxSizer.Add(writeToLogCheckBox,0,wx.TOP|wx.LEFT,12)        
        chkBoxSizer.Add(timesCheckBox,0,wx.TOP|wx.LEFT,12)     
        chkBoxSizer.Add(hexCheckBox,0,wx.TOP|wx.LEFT,12)     
        bottomSizer = wx.GridSizer(1,2,1,10)
        bottomSizer.Add(radioBoxMode,0,wx.TOP|wx.EXPAND,5)
        bottomSizer.Add(chkBoxSizer,1,wx.EXPAND)
        mainSizer = wx.BoxSizer(wx.VERTICAL)
        mainSizer.Add(topSizer,0,wx.EXPAND)
        mainSizer.Add(bottomSizer,0,wx.TOP|wx.EXPAND,10)
        panel.sizer.Add(mainSizer,0,wx.EXPAND)

        while panel.Affirmed():
            inCoding = inPageCtrl.GetSelection()
            outCoding = outPageCtrl.GetSelection()
            pgTpl = ('unicode_internal', 'utf8', eg.systemEncoding)
            panel.SetResult(
                inCoding,
                outCoding,
                stringCtrl.GetValue(),
                filepathCtrl.GetValue(),
                radioBoxMode.GetSelection(),
                choiceDecErrMode.GetSelection(),
                choiceEncErrMode.GetSelection(),
                writeToLogCheckBox.IsChecked(),
                timesCheckBox.IsChecked(),
                hexCheckBox.IsChecked(),
                inPageCtrl.GetStringSelection() if inCoding > 1 else pgTpl[inCoding],
                outPageCtrl.GetStringSelection() if outCoding > 2 else pgTpl[outCoding],
            )        
