# This file is part of EventGhost.
# Copyright (C) 2005 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
# This Plugin is based on Bitmonsters's Network Event Sender version: 1083, reworked
# by Ebrus for usage with Global Cache Gateways 
#
import eg

eg.RegisterPlugin(
    name = 'Global Cache',
    author = 'Ebrus',
    version = '0.1',
    kind = 'remote',
    canMultiLoad = True,
    description = '''\
        Hardware plugin for 
        <a href="http://www.globalcache.com/">
            Global Cache
        </a>
        Gateways

        <p>
            <div align="center">
                <img src="iTachWF2IR-medtrans-150x128.png"/>
            </div>
        </p>

    ''',
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAALGPC/xhBQAAAAlwSFlz"
        "AAAOwgAADsIBFShKgAAAAzRJREFUOE9Nk0tIVFEYx899zsNxxnEEm9HC1HFGMxSbmabRHBWx1NQZ"
        "RzNIFz7KIMgeLlwYyfRQfPSUcKUQRhm4MHAR6CYpNyK0qnAb4iJq4QyRk/Pvu/cadOBwz+M7/3P+"
        "v++7HJLA970v7O2rjyyxl2CuAhezpJqZ1ZbBjEY9E0WeMcax/f0/LB7/xT5//srW1z+waDTKkskk"
        "Yzs/v+Ldp0dgjIes00GUdBB4keYcdXbQaczRmJMgiDI4XsLVimL82fkGFvv9Az3XmmiRo8N6EtGD"
        "4zh0XixHJORFe7sPFzr8SLelqmIC7UsUV+nOAd48BAO17MNHIMoGEpCRajbhypVatLV6cLz4CI4V"
        "HkZJSQ58ZUfh8RZAFHV0iQH+/Gzg9QNFIIksRxYkWlRsPH/Whe7uSpzyFyAYdCFY5cbpigLU1h5D"
        "OOKDwUAXUawoiHg/NQRGDJGZmQmd3kiH8uDMt+N820m0RfwINXvQ2uJBOORBVVUx3G47nM5MlQPP"
        "C7h9J6oJ2Kzp4EkxHPLhxvUzcBdlEwceeoMMU4oexhQZsiyrDLKybcSAxhQfjY5oDMxmM8rKchHw"
        "O5Fms6CvL4ieniBawz40nCtBqMWLDgLZ1VVOYx8JUZbogqePn2gCKSYT9GTB5bLj5Yt+siMg32lH"
        "c9MJXL5UTWKVaCErLrdDhS0pqeQETE1NaQImElDIcpyImppiNDZ6iTZPwTJs9KI0q5n2BXq6CEnW"
        "q7WiCNy9f08R2IfFkkYeKb/UdeQ7QrSfPOqEI8sGxyErDtmJEfmW6KB0UGwKsxu3bhJEophuS1fT"
        "KMhaJSoviYS9lBUnMjKsBJMsGozUU8ie9lqeqvFsfYNWBw6H47+y/Ve+2tdsMeNobh5KS0sRKA+g"
        "qLCQBLSMBAIVoJ9kHxsbG5iZmcHi4iLW1tawtbWFeDyORCKhIEJsd1f9/mvKeiwWU2OYMqmrq6Oa"
        "b8fQ0BBGR0dRXV2N4eFh9Pb2YnNzk0q5BLOzs+jv78fAwAAximB8fBz19fVaFgYHBzE/P4+FhQWs"
        "rq5iZGQEExMTmJubw/b2NiYnJ7GysoLp6Wn14NLSEpaXlzE2Noa/RDjeSf8tHQQAAAAASUVORK5C"
        "YII="
    ),
)

import wx
import asyncore, socket
import string


class Text:
    hostLbl = "Label:"
    host = "Host:"
    port = "Port:"
    portChoices = ["Command (4998)", "Serial 1 (4999)", "Serial 2 (5000)"]
    model = "Type:"
    modelChoices = ["GC-100-06", "GC-100-12", "GC-100-18", "IP2CC", "IP2IR", "IP2SL"]
    eventGeneration = "Behaviour:"
    eventChoices = ["Discrete", "Payload", "Both", "None"]
    mode = "Mode:"
    modeChoices = ["IR", "SENSOR", "SENSOR_NOTIFY", "IR_BLASTER"]
    modeBox = "Connector" 
    state = "Output State:"
    stateChoices = ["open", "close"]
    stateBox = "Relay" 
    modelBox = "Model"
    comBox = "Gateway"
    eventBox = "Event"
    address = "Select (Module:Connector):"
    addressBox = "Device Address"
    irMsgLbl = "Label:"
    irMsg = "Code:"
    irMsgBox = "IR Setup"


    class SendIrCmd:
        name = "Send IR Command"
        description = (
            "This command will Send an IR command.\n"
            "Since IR commands may take up to 100mS to complete, the Gateway\n"
            "provides a \"completeir\" acknowledgment to indicate when it is ready\n"
            "to accept the next IR command for the connector in use.\n"
            "\n\n<p>"
            "No events are generated as a result of this request."
        )


    class GetDevicesCmd:
        name = "Get Devices Command"
        description = (
            "Retrive Gateway Devices.\n"
            "This command is used to determine installed modules and capabilities.\n"
            "Each module responds with its address and type\n"
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    #
    # General Commands
    #
    class GetVersionCmd:
        name = "Get Version Command"
        description = (
            "Retrive Gateway Module Version(s)"
            "\n\n<p>"
            "No events are generated as a result of the status request."
        )


    class GetNetCmd:
        name = "Get Network Settings Command"
        description = (
            "Retrive the Gateways current network settings."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    #
    # Serial Commands
    #
    class SetSerialCmd:
        name = "Set Serial Command"
        description = (
            "Set serial configuration of the Module."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    class GetSerialCmd:
        name = "Get Serial Command"
        description = (
            "Get serial configuration of the Module."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    #
    # Relay Commands
    #
    class SetStateCmd:
        name = "Set Relay State"
        description = (
            "Relays state is set (0|1)."
            "Relay states are not preserved through a power cycle and all relays"
            "will go back to their inactive (open) state until a <1> state is"
            "restored via command."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    #
    # IR Commands
    #
    class SetIrCmd:
        name = "Set IR Mode"
        description = (
            "This command allows configuration of each IR connector to the desired"
            "mode of operation."
            "Note! The 'IR blaster' mode is only supported on the third IR connector."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    class GetIrCmd:
        name = "Get IR Mode"
        description = (
            "This command will retrieve the current mode setting for a designated"
            "connector."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    class StopIrCmd:
        name = "Stop IR transmission"
        description = (
            "The command is used to halt IR transmission.\n"
            "Any remaining <repeat> counts will be discarded. A stopir command sent\n"
            "to a connector configured as an input will return an error message."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    class StartIrLearnCmd:
        name = "Start IR Learn Mode"
        description = (
            "Enable IR learn mode. Each iTach unit contains an on-board"
            "IR learner, which is located in the small hole located below and"
            "to the right of the power connector."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    class StopIrLearnCmd:
        name = "Stop IR Learn Mode"
        description = (
            "Disable IR learn mode."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

    #
    # Sensor/Relay State Commands
    #
    class GetStateCmd:
        name = "Get Sensor/Relay State"
        description = (
            "The Gateway sends out notifications for digital sensor input"
            "state changes as well as allowing the inputs to be polled for their"
            "current state at any time. This command can also be used to poll"
            "the state of contact closure relays, with a value of <0> representing"
            "an open contact, and <1> representing a closed contact."
            "Digital input connectors are the same connectors used for IR output"
            "on IR modules. The connector configuration is determined by the Gateways"
            "configuration on an individual connector basis."
            "\n\n<p>"
            "No events are generated as a result of this request."
        )
        

class GlobalCache (eg.PluginBase):
    text = Text

    def __init__(self):
        self.AddAction(GetDevicesCmd)
        self.AddAction(GetVersionCmd)
        self.AddAction(GetNetCmd)
        self.AddAction(GetSerialCmd)
        self.AddAction(SetStateCmd)
        self.AddAction(SetIrCmd)
        self.AddAction(GetIrCmd)
        self.AddAction(StopIrCmd)
        self.AddAction(GetStateCmd)
        self.AddAction(SendIrCmd)
        self.serial1AddressMap = {
            0 : "1:1",
            1 : "1:1",
            2 : "1:1",
            3 : "",
            4 : "",
            5 : "1:1"
            }
        self.serial2AddressMap = {
            0 : "",
            1 : "2:1",
            2 : "2:1",
            3 : "",
            4 : "",
            5 : "" 
            }
        self.irAddressMap = {
            0 : ['2:1', '2:2', '2:3'],
            1 : ['4:1', '4:2', '4:3', '5:1', '5:2', '5:3'],
            2 : ['4:1', '4:2', '4:3', '5:1', '5:2', '5:3'],
            3 : "",
            4 : ['1:1', '1:2', '1:3'],
            5 : ""
            }
        self.stateAddressMap = {
            0 : ['2:1', '2:2', '2:3'],
            1 : ['3:1', '3:2', '3:3', '4:1', '4:2', '4:3', '5:1', '5:2', '5:3'],
            2 : ['3:1', '3:2', '3:3', '4:1', '4:2', '4:3', '5:1', '5:2', '5:3'],
            3 : ['1:1', '1:2', '1:3'],
            4 : ['1:1', '1:2', '1:3'],
            5 : ""
            }
        self.relayAddressMap = {
            0 : "",
            1 : ['3:1', '3:2', '3:3'],
            2 : ['3:1', '3:2', '3:3'],
            3 : ['1:1', '1:2', '1:3'],
            4 : "",
            5 : ""
            }
        self.portMap = {
            0 : 4998,
            1 : 4999,
            2 : 5000
            }
        self.errCodeMap = {
            "001" : "Invalid command. Command not found.",
            "002" : "Invalid module address (does not exist).",
            "003" : "Invalid connector address (does not exist).",
            "004" : "Invalid ID value.",
            "005" : "Invalid frequency value.",
            "006" : "Invalid repeat value.",
            "007" : "Invalid offset value.",
            "008" : "Invalid pulse count.",
            "009" : "Invalid pulse data.",
            "010" : "Uneven amount of <on|off> statements.",
            "011" : "No carriage return found.",
            "012" : "Repeat count exceeded.",
            "013" : "IR command sent to input connector.",
            "014" : "Blaster command sent to non-blaster connector.",
            "015" : "No carriage return before buffer full.",
            "016" : "No carriage return.",
            "017" : "Bad command syntax.",
            "018" : "Sensor command sent to non-input connector.",
            "019" : "Repeated IR transmission failure.",
            "020" : "Above designated IR <on|off> pair limit.",
            "021" : "Symbol odd boundary.",
            "022" : "Undefined symbol.",
            "023" : "Unknown option.",
            "024" : "Invalid baud rate setting.",
            "025" : "Invalid flow control setting.",
            "026" : "Invalid parity setting.",
            "027" : "Settings are locked."
            }
        self.gc100ErrCodeMap = {
            "1" : "Time out occurred because carriage return <CR> not received. The request was not processed.",
            "2" : "Invalid module address (module does not exist) received when attempting to ascertain the version number (getversion).",
            "3" : "Invalid module address (module does not exist).",
            "4" : "Invalid connector address.",
            "5" : "Connector address 1 is set up as \"sensor in\" when attempting to send an IR command.",
            "6" : "Connector address 2 is set up as \"sensor in\" when attempting to send an IR command.",
            "7" : "Connector address 3 is set up as \"sensor in\" when attempting to send an IR command.",
            "8" : "Offset is set to an even transition number, but should be set to an odd transition number in the IR command.",
            "9" : "Maximum number of transitions exceeded (256 total on/off transitions allowed).",
            "10" : "Number of transitions in the IR command is not even (the same number of on and off transitions is required).",
            "11" : "Contact closure command sent to a module that is not a relay..",
            "12" : "Missing carriage return. All commands must end with a carriage return.",
            "13" : "State was requested of an invalid connector address, or the connector is programmed as IR out and not sensor in.",
            "14" : "Command sent to the unit is not supported by the GC-100.",
            "15" : "Maximum number of IR transitions exceeded. (SM_IR_INPROCESS)",
            "16" : "Invalid number of IR transitions (must be an even number).",
            "21" : "Attempted to send an IR command to a non-IR module.",
            "23" : "Command sent is not supported by this type of module."
            }

    def __start__(self, hostLbl, host, port, model, eventGeneration):
        self.hostLbl = hostLbl
        self.host = host
        self.port = self.portMap[port]
        self.model = model
        self.eventGeneration = eventGeneration
        self.sensorPort = 9132 # UDP broadcast port
        self.svr = True
        if (self.svr):
            try:
                self.udpServer = UdpServer(self.sensorPort, self)
            except socket.error, exc:
                raise self.Exception(exc[1])
            
            
    def Configure(self, hostLbl="", host="192.168.1.70", port=0, model=5, eventGeneration=1):
        text = self.text
        panel = eg.ConfigPanel(self)
        hostLblCtrl = panel.TextCtrl(hostLbl)
        hostCtrl = panel.TextCtrl(host)
        portCtrl = panel.Choice(port, text.portChoices)
        modelCtrl = panel.Choice(model, text.modelChoices)
        eventCtrl = panel.Choice(eventGeneration, text.eventChoices)

        st1 = panel.StaticText(text.hostLbl)
        st2 = panel.StaticText(text.host)
        st3 = panel.StaticText(text.port)
        st4 = panel.StaticText(text.model)
        st5 = panel.StaticText(text.eventGeneration)
        eg.EqualizeWidths((st1, st2, st3, st4, st5))
        comBox = panel.BoxedGroup(
            text.comBox,
            (st1, hostLblCtrl),
            (st2, hostCtrl),
            (st3, portCtrl)
            )
        modelBox = panel.BoxedGroup(
            text.modelBox,
            (st4, modelCtrl)
            )
        eventBox = panel.BoxedGroup(
            text.eventBox,
            (st5, eventCtrl)
            )

        panel.sizer.Add(comBox, 0, wx.TOP|wx.EXPAND, 0)
        panel.sizer.Add(modelBox, 0, wx.TOP|wx.EXPAND, 10)
        panel.sizer.Add(eventBox, 0, wx.TOP|wx.EXPAND, 10)

        while panel.Affirmed():
            panel.SetResult(
                hostLblCtrl.GetValue(),
                hostCtrl.GetValue(),
                portCtrl.GetValue(),
                modelCtrl.GetValue(),
                eventCtrl.GetValue()
            )


    def Send(self, payload):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(5.0)
    
        try:
            # Connect & send
            sock.connect((self.host, self.port))
            sock.settimeout(1.0)
            sock.sendall(payload)
            
            # Get the answer & close
            answer = sock.recv(1024).strip()
            sock.close()

            # Manage "answer"
            if "ERR" in answer:
                errId = answer.rsplit(',')[0].rsplit('_')[1]
                errInfo = self.Lookup(self.errCodeMap, answer.rsplit(',')[1])
                self.GcErrPrint(errId + " - " + errInfo)
                return False
            elif "unknowncommand" in answer:
                errInfo = self.Lookup(self.gc100ErrCodeMap, answer.rsplit(' ')[1])
                self.GcPrint(errInfo)
                return False
            elif "completeir" in answer:
                if answer.rsplit(',')[2] != "1":
                    errInfo = "Faild to send IR Command"
                    self.GcPrint(errInfo)
                    return False
            elif "state" in answer:
                answerCmd = answer.rsplit(',')[0]
                answerAddr = answer.rsplit(',')[1]
                answerState = answer.rsplit(',')[2]
                self.GenerateEvent(self.hostLbl + '.' + answerCmd + '.' + answerAddr, answerState)
            else:
                self.GenerateEvent(self.hostLbl, answer)
                
            return sock

        except:
            if eg.debugLevel:
                eg.PrintTraceback()

            self.GcErrPrint("Communication Failure")
            return None


    def Lookup(self, map, value):
        for k in map.keys():
            if k == value:
                return map[k]
        return None        


    def GcErrPrint(self, errmesg):
        self.PrintError("Error: Global Cache, " + self.hostLbl + ": " + errmesg)

    def GcPrint(self, mesg):
        print("Global Cache, " + self.hostLbl + ": " + mesg)

    def GenerateEvent(self, eventKey, event):
        if self.eventGeneration in (0, 2):
            self.TriggerEvent(event)
        if self.eventGeneration in (1, 2):
            self.TriggerEvent(eventKey, event)



class UdpServer(asyncore.dispatcher):

    def __init__(self, port, handler):
        self.handler = handler
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.bind(('', port))
        self.add_channel()
        eg.RestartAsyncore()

    def handle_read(self):
        try:
            sensorNotify = self.socket.recv(1024).strip
            self.GenerateEvent(sensorNotify)
                
        except socket.timeout:
            pass

        except socket.error, (errno, strerror):
            if (errno == 10054):
                # this happens when we transmit from the server socket
                pass
            else:
                raise self.handler.Exception()

    def handle_accept(self):
        pass

    def handle_connect(self):
        pass

    def handle_close(self):
        pass

    def writable(self):
        return False


            
class GetDevicesCmd(eg.ActionClass):

    def __call__(self):

        sendCmd = "getdevices\r"

        self.plugin.Send(sendCmd)


class GetVersionCmd(eg.ActionClass):

    def __call__(self):

        sendCmd = "getversion\r"

        self.plugin.Send(sendCmd)


class GetNetCmd(eg.ActionClass):

    def __call__(self):

        sendCmd = "get_NET,0:1\r"

        self.plugin.Send(sendCmd)


class GetSerialCmd(eg.ActionClass):

    def __call__(self):

        serial1Address = self.plugin.serial1AddressMap[self.plugin.model]
        if serial1Address != '':
            sendCmd = "get_SERIAL," + serial1Address + "\r"
            self.plugin.Send(sendCmd)
            
            serial2Address = self.plugin.serial2AddressMap[self.plugin.model]
            if serial2Address != '':
                sendCmd = "get_SERIAL," + serial2Address + "\r"
                self.plugin.Send(sendCmd)
        else:
            self.plugin.GcErrPrint("No Serial Module in device")
            
class SetStateCmd(eg.ActionClass):


    def __call__(self, state, address):

            self.sendAddress = self.addressChoices[address]        
            self.sendCmd = "setstate," + self.sendAddress + "," + str(state) + "\r"

            self.plugin.Send(self.sendCmd)


    def GetLabel(self, state, address):
        return self.name


    def Configure(self, state=0, address=0):

        text = self.text
        panel = eg.ConfigPanel(self)
        self.addressChoices = self.plugin.relayAddressMap[self.plugin.model]
        stateCtrl = panel.Choice(state, self.plugin.text.stateChoices)
        addressCtrl = panel.Choice(address, self.addressChoices)
        
        st1 = panel.StaticText(self.plugin.text.state)
        st2 = panel.StaticText(self.plugin.text.address)
        
        stateBox = panel.BoxedGroup(
            self.plugin.text.stateBox,
            (st1, stateCtrl)
            )      
        addressBox = panel.BoxedGroup(
            self.plugin.hostLbl + ": " + self.plugin.text.addressBox,
            (st2, addressCtrl)
            )
        
        panel.sizer.Add(stateBox, 0, wx.TOP|wx.EXPAND, 0)
        panel.sizer.Add(addressBox, 0, wx.TOP|wx.EXPAND, 10)
        
        if self.plugin.relayAddressMap[self.plugin.model] != '':
            while panel.Affirmed():
                panel.SetResult(
                    stateCtrl.GetValue(),
                    addressCtrl.GetValue()
                    )
        else:
            self.plugin.GcErrPrint("No Relay Module in device")

                
class SetIrCmd(eg.ActionClass):

    def __call__(self, mode, address ):

        self.sendAddress = self.addressChoices[address]
        self.sendCmd = "set_IR," + self.sendAddress + "," + self.plugin.text.modeChoices[mode] + "\r"

        self.plugin.Send(self.sendCmd)


    def GetLabel(self, mode, address):
        return self.name


    def Configure(self,  mode=0, address=0):
        text = self.text
        panel = eg.ConfigPanel(self)
        self.addressChoices = self.plugin.irAddressMap[self.plugin.model]
        modeCtrl = panel.Choice(mode, self.plugin.text.modeChoices)
        addressCtrl = panel.Choice(address, self.addressChoices)

        st1 = panel.StaticText(self.plugin.text.mode)
        st2 = panel.StaticText(self.plugin.text.address)

        modeBox = panel.BoxedGroup(
            self.plugin.text.modeBox,
            (st1, modeCtrl)
            )      
        addressBox = panel.BoxedGroup(
            self.plugin.hostLbl + ": " + self.plugin.text.addressBox,
            (st2, addressCtrl)
            )
        
        panel.sizer.Add(modeBox, 0, wx.TOP|wx.EXPAND, 0)
        panel.sizer.Add(addressBox, 0, wx.TOP|wx.EXPAND, 10)
        
        while panel.Affirmed():
            panel.SetResult(
                modeCtrl.GetValue(),
                addressCtrl.GetValue()
                )


class GetIrCmd(eg.ActionClass):

    def __call__(self):

        addressList = self.plugin.irAddressMap[self.plugin.model]
        
        if addressList != '':
            for k in addressList[:]:
                sendCmd = "get_IR," + k + "\r"
                self.plugin.Send(sendCmd)
        else:
            self.plugin.GcErrPrint("No IR Module in device")


class StopIrCmd(eg.ActionClass):

    def __call__(self):

        addressList = self.plugin.irAddressMap[self.plugin.model]
        
        if addressList != '':
            for k in addressList[:]:
                sendCmd = "stopir," + k + "\r"
                self.plugin.Send(sendCmd)
        else:
            self.plugin.GcErrPrint("No IR Module in device")


class GetStateCmd(eg.ActionClass):

    def __call__(self):

        addressList = self.plugin.stateAddressMap[self.plugin.model]
        
        if addressList != '':
            for k in addressList[:]:
                sendCmd = "getstate," + k + "\r"
                self.plugin.Send(sendCmd)
        else:
            self.plugin.GcErrPrint("No Relay Module in device")
            

class SendIrCmd(eg.ActionClass):

    def __call__(self, label, mesg, address ):

        self.address = address
        self.mesg = mesg
        addressChoices = self.plugin.irAddressMap[self.plugin.model]
        self.sendAddress = addressChoices[self.address]
        self.sendCmd = "sendir," + self.sendAddress + ",1," + self.mesg + "\r"

        self.plugin.Send(self.sendCmd)


    def Configure(self, label="", mesg="", address=0):
        text = self.text
        panel = eg.ConfigPanel(self)
        addressChoices = self.plugin.irAddressMap[self.plugin.model]
        irMsgLblCtrl = panel.TextCtrl(label)
        irMsgCtrl = panel.TextCtrl(mesg)
        addressCtrl = panel.Choice(address, addressChoices)

        st1 = panel.StaticText(self.plugin.text.irMsgLbl)
        st2 = panel.StaticText(self.plugin.text.irMsg)
        st3 = panel.StaticText(self.plugin.text.address)

        irMsgBox = panel.BoxedGroup(
            self.plugin.text.irMsgBox,
            (st1, irMsgLblCtrl),
            (st2, irMsgCtrl)
            )      
        addressBox = panel.BoxedGroup(
            self.plugin.hostLbl + ": " + self.plugin.text.addressBox,
            (st3, addressCtrl)
            )
        
        panel.sizer.Add(irMsgBox, 0, wx.TOP|wx.EXPAND, 0)
        panel.sizer.Add(addressBox, 0, wx.TOP|wx.EXPAND, 10)
        
        while panel.Affirmed():
            panel.SetResult(
                irMsgLblCtrl.GetValue(),
                irMsgCtrl.GetValue(),
                addressCtrl.GetValue()
                )



    
