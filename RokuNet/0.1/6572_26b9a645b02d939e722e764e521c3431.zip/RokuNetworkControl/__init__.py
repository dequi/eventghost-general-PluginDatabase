import httplib
import urllib
import re
from time import sleep

# You're welcome to add more features to this plugin, just make sure to post it
# back to the EG forum thread for this plugin (see the url= parameter of the
# RegisterPlugin method below.  This plugin currently only sends "keypress"
# and "launch" commands to the Roku device.  It does not make use of the keydown and keyup commands
# (which could enable pressing and holding a key in order to repeat a command).
# The plugin only makes use of the launch command to launch a channel (numeric values only).
# It does not launch streaming video URL's in your own app, nor does it use SSDP in order
# to automatially discover Roku boxes on the LAN.  If you want to get real fancy, you could
# add the query/apps command to retrieve all the "channels" that are installed
# on the user's Roku box in order to automatically populate the actions for going
# directly to a channel.  However, app ID's (channel ID's) are universal
# (meaning that app 1234 is the same for everyone), so I don't know how useful
# it would be to automatically detect apps... but maybe someone would like that.
# If you want to be SUPER fancy, you could use the
# query/icon command to get the icon for those channels too!

# Roku network connection info is below.  You must change this value.  It is wise to
# configure your router so that the Roku always receives the same IP address
# and/or host name.
IP_ADDRESS = "192.168.1.112"
#
# The port number should always be 8060, per the Roku External Control Guide.
PORT = "8060"

# EventGhost Constants
ACTION_EXECBUILTIN = 0x01
ACTION_BUTTON = 0x02

eg.RegisterPlugin(
    name = "RokuNet",
    author = "barnabas1969",
    version = "0.1",
    kind = "external",
    createMacrosOnAdd = False,
    url = "http://www.eventghost.net/forum/viewtopic.php?f=9&t=5995",
    description = "Allows control of a Roku player over Ethernet or WiFi.",
)

class RokuAction(eg.ActionClass):
    def __call__(self):
        try:
            return self.plugin.roku.send_action(self.value, ACTION_BUTTON)
        except:
            raise self.Exceptions.ProgramNotRunning

class RokuNet(eg.PluginClass):
    def __init__(self):
        group1 = self.AddGroup("RemoteControl","Send commands as if pushing buttons on the IR/RF remote control.")
        group1.AddActionsFromList(REMOTE_ACTIONS, RokuAction)
        group2 = self.AddGroup("ChannelDirect", "Actions that directly start a channel.")
        group2.AddActionsFromList(CHANNEL_ACTIONS, RokuAction)
        group3 = self.AddGroup("Keyboard", "Send any key from a keyboard.  Use this to type a string into a search box, etc.")
        group3.AddActionsFromList(KEYBOARD_ACTIONS, RokuAction)
        self.roku = RokuNetClient()

def send_key(keycmd):
    conn = httplib.HTTPConnection("%s:%s" % ( IP_ADDRESS, PORT ))
    headers = { "Content-type": "text/html" }
    conn.request("POST", "/keypress/" + keycmd, "", headers)
    conn.close()

def launch_channel(appid):
    print "Channel number: " + appid
    conn = httplib.HTTPConnection("%s:%s" % ( IP_ADDRESS, PORT ))
    headers = { "Content-type": "text/html" }
    conn.request("POST", "/launch/" + appid, "", headers)
    conn.close()

def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

class RokuNetClient:
    def __init__(self):
        print "Init"

    def send_action(self, msg = '', type = ACTION_EXECBUILTIN):
        if is_number(msg) == True:
            launch_channel(msg)
        else:
            send_key(msg)
            sleep(0.1)

# The action lists below consist of the following structure:
#   ("class", "Command Name", "Command Description", "parameter"),
#
# Parameter values below may be any of the "Valid Keys", per the documentation at:
# http://sdkdocs.roku.com/display/sdkdoc/External+Control+Guide
#
# The parameter may also be "Lit_X" where X is a single keyboard key.  Special keys
# must be URL-encoded.  FYI, "Lit_" means "Literal string".
#
# Finally, the parameter may be a numeric app id, as found by going to:
# http://<your_roku_IP_address>:8060/query/apps
REMOTE_ACTIONS = (   
    ("Home", "Home", "Go to the home screen.", "home"),
    ("Back", "Back", "Go back to the previous screen", "back"),
    ("Left", "Left", "Move left", "left"),
    ("Right", "Right", "Move right", "right"),
    ("Down", "Down", "Move down", "down"),
    ("Up", "Up", "Move up", "up"),
    ("OK", "OK", "Select the currently highlighted channel or whatever.", "select"),
    ("Rewind", "Rewind", "Rewind the currently playing video.", "rev"),
    ("FastFwd", "Fast Forward", "Fast forward the currently playing video.", "fwd"),
    ("PlayPause", "PlayPause", "Play or Pause the currently playing video.", "play"),
    ("InstantReplay", "Instant Replay", "Skip back a few seconds", "instantreplay"),
    ("Option", "Option", "Sends the asterisk (*) key.", "Lit_*"),
    ("Info", "Info", "See more info?", "info"),
    ("Search", "Search", "Open a search dialog. See actions under Keyboard to enter text in the search box.", "search"),
)    

CHANNEL_ACTIONS = (   
    ("Netflix", "Netflix", "Start the Netflix channel.", "12"),
    ("Amazon", "Amazon Instant Video", "Start the Amazon Instant Video channel.", "13"),
    ("HuluPlus", "Hulu Plus", "Start the Hulu Plus channel.", "2285"),
    ("Crackle", "Crackle", "Start the Crackle channel.", "2016"),
    ("Pandora", "Pandora", "Start the Pandora channel.", "28"),
)    

KEYBOARD_ACTIONS = (   
    ("Enter", "Enter", "Sends the enter key after typing in a string in a search box.", "enter"),
    ("Backspace", "Backspace", "Sends a backspace keyboard key.", "backspace"),
    ("Space", "Space", "Sends a space keyboard key.", "Lit_+"),
    ("A", "A", "Letter a", "Lit_a"),
    ("B", "B", "Letter b", "Lit_b"),
    ("C", "C", "Letter c", "Lit_c"),
    ("D", "D", "Letter d", "Lit_d"),
    ("E", "E", "Letter e", "Lit_e"),
    ("F", "F", "Letter f", "Lit_f"),
    ("G", "G", "Letter g", "Lit_g"),
    ("H", "H", "Letter h", "Lit_h"),
    ("I", "I", "Letter i", "Lit_i"),
    ("J", "J", "Letter j", "Lit_j"),
    ("K", "K", "Letter k", "Lit_k"),
    ("L", "L", "Letter l", "Lit_l"),
    ("M", "M", "Letter m", "Lit_m"),
    ("N", "N", "Letter n", "Lit_n"),
    ("O", "O", "Letter o", "Lit_o"),
    ("P", "P", "Letter p", "Lit_p"),
    ("Q", "Q", "Letter q", "Lit_q"),
    ("R", "R", "Letter r", "Lit_r"),
    ("S", "S", "Letter s", "Lit_s"),
    ("T", "T", "Letter t", "Lit_t"),
    ("U", "U", "Letter u", "Lit_u"),
    ("V", "V", "Letter v", "Lit_v"),
    ("W", "W", "Letter w", "Lit_w"),
    ("X", "X", "Letter x", "Lit_x"),
    ("Y", "Y", "Letter y", "Lit_y"),
    ("Z", "Z", "Letter z", "Lit_z"),
    ("0", "0", "Number 0", "Lit_0"),
    ("1", "1", "Number 1", "Lit_1"),
    ("2", "2", "Number 2", "Lit_2"),
    ("3", "3", "Number 3", "Lit_3"),
    ("4", "4", "Number 4", "Lit_4"),
    ("5", "5", "Number 5", "Lit_5"),
    ("6", "6", "Number 6", "Lit_6"),
    ("7", "7", "Number 7", "Lit_7"),
    ("8", "8", "Number 8", "Lit_8"),
    ("9", "9", "Number 9", "Lit_9"),
    ("Plus", "Plus", "Character +", "Lit_%2B"),
    ("Minus", "Minus", "Character -", "Lit_-"),
    ("Slash", "Slash", "Character /", "Lit_%2F"),
    ("Asterisk", "Asterisk", "Character *", "Lit_*"),
)    
