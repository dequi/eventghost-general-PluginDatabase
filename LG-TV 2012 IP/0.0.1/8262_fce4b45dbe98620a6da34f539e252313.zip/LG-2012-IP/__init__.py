# -*- coding: utf-8 -*-
#
# This file is a plugin for EventGhost.
# Copyright (C) 2013 Peter Hjalmarsson <inkorg@peterhjalmarsson.com>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This plugin borrows heavily from a program called lgcommander at
# <https://github.com/ubaransel/lgcommander>

"""<rst>
**Adds actions to control LG "SMART" TV:s.**

The interface is designed to work with 2012 TV sets and up, but has only been confirmed to work with a 2013 set; specifically the author's 55LA667V-ZB.
However, there's no reason to suspect that it should not work on all 2012 and up LG SMART TV sets.

There is no specific settings to be made in the TV for it to respond to commands.

However, you need to configure the plugin with a Pairing Key from the TV. You can get the key in one of two different ways:

1. Get it from the TV settings.

2. Try to run a command from EventGhost. The code will be incorrect the first time, and then the TV will show the code on screen. Configure the plugin with this key to make it work.
"""

import eg
import wx
# Below imports for LG communication code
import httplib
import xml.etree.ElementTree as etree
import socket
import re
import sys

eg.RegisterPlugin(
    name = "LG-TV 2012 IP",
    description = __doc__,
    author = "Peter Hjalmarsson",
    version = "0.0.1",
    kind = "external",
    guid = "{F50CD825-3109-4D25-8FE1-3D978D0CBF9E}",
#    canMultiLoad = True,
#    createMacrosOnAdd = True,
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAA7DAAAOwwHH"
        "b6hkAAAC5ElEQVR4nIWTz08cZRjH5z/YmTnqoZvGm2cPiKEYzSZErTXFNrHUJt68tNmW"
        "BYpL2aQeZxqbGgikRhOqDRLLQYM/Q7pZ6bBIKLhWt8tu93UDCOv8WmbdsnRmPh5AWtDE"
        "T/K9PHm+3yfvm+eRpAPk4pHY4rmIfvdsxLh7NuLuylg8F9Fz8UjsYP8e97vlaC4e0X6J"
        "y15ptIW1qbepi6/YMhdprGSwFz5GjBxv5OIR7X63HN1nLnTL0Xvn5bHSaAsb33VSyxzn"
        "Ya4ff/1rAitL4BUIHm4QbNm4S59S0l6YLDwZkr8ga+L689jpk1THWyhfeQZzshN/eQQ2"
        "pgjtLGF9mXCrSug3qP38GfkLsiZJkiQVE3JsOSF79vQJtu4co6wfpmmVsDIfIoZaMafe"
        "xa9MgDMH9SJh0yRsuqx+1NkoJuSYVEzI+uonrTSMNwlmOyhcfpp/aFplrB+HEMMvYX7f"
        "i//HbfirTLht4+VuUEzIulTqkQ3ry1fYnj1GaMQoXH6KgzQtgTUzghh9FWfmA8JGhe2N"
        "nyj1yIYkemV3M32CIHsUZl/+z4C9IPt3xOhR2LyHv1lC9MquVOlT3HpmN2Cu438CBGKk"
        "g9A28J0lKn2KK61cVAzvm9cI5t6Ahbf2/cHjJzzAylxDDLXiTPcRVr+l+eALVi4qhrTW"
        "r+juzTaC+ZPw63kK7x96bDRLWGkNceUw5udt+Ln3YPUmYXmY+u1u1voVXVpPKrHqgOI9"
        "yp6CfBJx7bmdiWkdoR/CvPEsfroN5jshn4R8kkfZU1QHFG89qeysdnVA0erjRwgXTuNM"
        "9yCGX8ScfB1/rguW3oHfeqFyHdbGCRdOUx8/QnVA0fY20R5UotYlZawx0Q7zXfDnD+AY"
        "YN/ZkWPs1Oa7aEy0Y11SxuxBZf89uCk16gyqWi2les1b7QQzZwiLVwmLVwlmztC81U4t"
        "pXrOoKq5KXW/+UlqKTXmplS9llKNWkp1d2Xs1v51zn8D3aqe3eiSdiUAAAAASUVORK5C"
        "YII="
    ),
)

pairingKey = "xxxxxx"

class Text:
    pairingBox = "Pairing Settings"
    pairingKeyLabel = "Pairing Key:"

class LGTV2012IP(eg.PluginBase):
    text = Text

    def __init__(self):
        self.AddAction(sendCommand3)
        self.AddAction(sendCommand4)

    def __start__(
        self,
        configuredpairingKey,
    ):
        global pairingKey
        print "LG-TV 2012 IP using pairing key " + configuredpairingKey
        pairingKey = configuredpairingKey

    def Configure(
        self,
        pairingKey="xxxxxx",
    ):
        text = self.text
        panel = eg.ConfigPanel()
        pairingKeyCtrl = panel.TextCtrl(pairingKey)

        pairingBox = panel.BoxedGroup(
            text.pairingBox,
            (text.pairingKeyLabel, pairingKeyCtrl),
        )
        eg.EqualizeWidths(pairingBox.GetColumnItems(0))
        panel.sizer.Add(pairingBox, 0, wx.EXPAND)
        while panel.Affirmed():
            panel.SetResult(
                pairingKeyCtrl.GetValue(),
            )

#########################################
# Here is the code for LG communication #
#########################################
lgtv = {}
dialogMsg =""
headers = {"Content-Type": "application/atom+xml"}
lgtv["pairingKey"] = "xxxxxx"


class MyDialog:
    def __init__(self, parent, dialogMsg):
        top = self.top = Toplevel(parent)
        Label(top, text = dialogMsg, justify="left").pack()
        self.e = Entry(top)
        self.e.pack(padx=5)
        self.e.focus_set()
        b = Button(top, text="Ok", command=self.ok)
        b.pack(pady=5)
        top.bind("<Return>", self.ok)
        top.title("Lg Commander")
        top.geometry("410x280+10+10")
    def ok(self,dummy=None):
        global result
        result = self.e.get()
        self.top.destroy()


def getip():
    strngtoXmit =   'M-SEARCH * HTTP/1.1' + '\r\n' + \
                    'HOST: 239.255.255.250:1900'  + '\r\n' + \
                    'MAN: "ssdp:discover"'  + '\r\n' + \
                    'MX: 2'  + '\r\n' + \
                    'ST: urn:schemas-upnp-org:device:MediaRenderer:1'  + '\r\n' +  '\r\n'

    bytestoXmit = strngtoXmit.encode()
    sock = socket.socket( socket.AF_INET, socket.SOCK_DGRAM )
    sock.settimeout(3)
    found = False
    gotstr = 'notyet'
    i = 0
    ipaddress = None
    sock.sendto( bytestoXmit,  ('239.255.255.250', 1900 ) )
    while not found and i <= 5 and gotstr == 'notyet':
        try:
            gotbytes, addressport = sock.recvfrom(512)
            gotstr = gotbytes.decode()
        except:
            i += 1
            sock.sendto( bytestoXmit, ( '239.255.255.250', 1900 ) )
        if re.search('LG', gotstr):
            ipaddress, _ = addressport
            found = True
        else:
            gotstr = 'notyet'
        i += 1
    sock.close()
    if not found : sys.exit("Lg TV not found")
    return ipaddress


def displayKey():
    conn = http.client.HTTPConnection( lgtv["ipaddress"], port=8080)
    reqKey = "<?xml version=\"1.0\" encoding=\"utf-8\"?><auth><type>AuthKeyReq</type></auth>"
    conn.request("POST", "/roap/api/auth", reqKey, headers=headers)
    httpResponse = conn.getresponse()
    if httpResponse.reason != "OK" : sys.exit("Network error")
    return httpResponse.reason


def getSessionid():
    conn = httplib.HTTPConnection( lgtv["ipaddress"], port=8080)
    pairCmd = "<?xml version=\"1.0\" encoding=\"utf-8\"?><auth><type>AuthReq</type><value>" \
            + pairingKey + "</value></auth>"
# Old code using lgtv["pairingKey"]; I had problems getting this variable properly global,
# so I created and started to use "pairingKey" variable instead.
#    pairCmd = "<?xml version=\"1.0\" encoding=\"utf-8\"?><auth><type>AuthReq</type><value>" \
#            + lgtv["pairingKey"] + "</value></auth>"
    conn.request("POST", "/roap/api/auth", pairCmd, headers=headers)
    httpResponse = conn.getresponse()
    if httpResponse.reason != "OK" : return httpResponse.reason
    tree = etree.XML(httpResponse.read())
    return tree.find('session').text


def handleCommand(cmdcode):
    conn = httplib.HTTPConnection( lgtv["ipaddress"], port=8080)
    cmdText = "<?xml version=\"1.0\" encoding=\"utf-8\"?><command>" \
                + "<name>HandleKeyInput</name><value>" \
                + cmdcode \
                + "</value></command>"
    conn.request("POST", "/roap/api/command", cmdText, headers=headers)
    httpResponse = conn.getresponse()

def sendCommand(keyCode):
# Initializes communication and sends a single command to the TV. By Peter Hjalmarsson

#    print "sendCommand!"
    lgtv["ipaddress"] = getip()
#    print "  ipaddress in sendCommand:" + lgtv["ipaddress"]
#    print "  pairingKey in sendCommand:" + pairingKey
    theSessionid = getSessionid()
#    print "theSessionid in sendCommand:" + theSessionid
    if len(theSessionid) < 8 :
        print "LG-TV 2012 IP: Could not get session ID for IP communication with TV: " + theSessionid
        return("Could not get Session Id: " + theSessionid)
    if theSessionid == "Unauthorized" :
        print "LG-TV 2012 IP: Could not get session ID for IP communication with TV: " + theSessionid
        return("Could not get Session Id: " + theSessionid)
    lgtv["session"] = theSessionid
    handleCommand(keyCode)

class sendCommand3(eg.ActionBase):
# Sends a single command to the TV using sendCommand(). By Peter Hjalmarsson
    name = "Send Key Code"
    description = "Send a command using a key code 1...1024"
    def __call__(self, keyCode):
        sendCommand(keyCode)

    def Configure(self, keyCode=""):
        panel = eg.ConfigPanel()
        textControl = wx.TextCtrl(panel, -1, keyCode)
        panel.AddLine("Key code (1-1024):", textControl)
        while panel.Affirmed():
            panel.SetResult(textControl.GetValue())

class sendCommand4(eg.ActionBase):
# Sends a single command to the TV using sendCommand(). By Peter Hjalmarsson
    name = "Send Key From List"
    description = "Send a command using a key code 1...1024"
    def __call__(self, myString):
        keyCode = myString[0:myString.find(" ")]
        sendCommand(keyCode)

    def Configure(self, keyCode=""):
        panel = eg.ConfigPanel()
        sampleList = ['1 - POWER', '2 - Number 0', '3 - Number 1', '4 - Number 2',
                      '5 - Number 3', '6 - Number 4', '7 - Number 5', '8 - Number 6',
                      '9 - Number 7', '10 - Number 8', '11 - Number 9', '12 - UP key',
                      '13 - DOWN key', '14 - LEFT key', '15 - RIGHT key', '20 - OK',
                      '21 - Home menu', '22 - Menu key', '23 - Back', '24 - Volume up',
                      '25 - Volume down', '26 - Mute (toggle)', '27 - Channel UP',
                      '28 - Channel DOWN', '29 - Blue key', '30 - Green key',
                      '31 - Red key', '32 - Yellow key', '33 - Play', '34 - Pause',
                      '35 - Stop', '36 - Fast forward (FF)', '37 - Rewind (REW)',
                      '38 - Skip Forward', '39 - Skip Backward', '40 - Record',
                      '41 - Recording list', '42 - Repeat', '43 - Live TV', '44 - EPG',
                      '45 - Current program information', '46 - Aspect ratio',
                      '47 - External input', '48 - PIP secondary video',
                      '49 - Show / Change subtitle', '50 - Program list',
                      '51 - Tele Text', '52 - Mark', '400 - 3D Video', '401 - 3D L/R',
                      '402 - Dash (-)','403 - Previous channel (Flash back)',
                      '404 - Favorite channel', '405 - Quick menu',
                      '406 - Text Option', '407 - Audio Description',
                      '408 - NetCast key', '409 - Energy saving', '410 - A/V mode',
                      '411 - SIMPLINK', '412 - Exit',
                      '413 - Reservation programs list', '414 - PIP channel UP',
                      '415 - PIP channel DOWN',
                      '416 - Switching between primary/secondary video',
                      '417 - My Apps']
        comboControl = wx.ComboBox(panel, choices=sampleList, style=wx.CB_READONLY)
        panel.AddLine("Select key from list: ",comboControl)
        while panel.Affirmed():
            panel.SetResult(comboControl.GetValue())


######################################################################################################
# main() from original lgcommander code is commented out, since it disturbs EG when run as a plugin. #
# Works fine as a script though. Kept here for reference purposes only.                              #
######################################################################################################

#main()

#lgtv["ipaddress"] = getip()
#theSessionid = getSessionid()

#if len(theSessionid) < 8 : sys.exit("Could not get Session Id: " + theSessionid)
#if theSessionid == "Unauthorized" : sys.exit("Could not get Session Id: " + theSessionid)

#lgtv["session"] = theSessionid


#dialogMsg =""
#for lgkey in lgtv :
#    dialogMsg += lgkey + ": " + lgtv[lgkey] + "\n"

#dialogMsg += "Success in establishing command session\n"
#dialogMsg += "=" * 28 + "\n"
#dialogMsg += "Enter command code i.e. a number between 0 and 1024\n"
#dialogMsg += "Enter a number greater than 1024 to quit.\n"
#dialogMsg += "Some useful codes (not working with 2012 models):\n"
#dialogMsg += "for EZ_ADJUST     menu enter   255 \n"
#dialogMsg += "for IN START        menu enter   251 \n"
#dialogMsg += "for Installation     menu enter   207 \n"
#dialogMsg += "for POWER_ONLY mode enter   254 \n"
#dialogMsg += "Warning: do not enter 254 if you \ndo not know what POWER_ONLY mode is. "


#result = "91"
#handleCommand("22")
#while int(result) < 1024:
#    root = Tk()
#    root.withdraw()
#    d = MyDialog(root, dialogMsg)
#    root.wait_window(d.top)
#    handleCommand(result)
