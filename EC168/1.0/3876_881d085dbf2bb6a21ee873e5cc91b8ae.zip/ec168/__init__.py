"""<rst>
This plugin will generate events from EC168 (Easy Tv Remote) Keypresses.
Much like the remotes included with Gadget Geek TV dongles (A quick google shows
alot more using the same chipset)
"""

import eg
from eg import HasActiveHandler
from eg.cFunctions import SetKeyboardCallback

eg.RegisterPlugin(
    name = "EC168",
    author = "ikex Based on code from Bitmonster",
    version = "1.0.",
    kind = "remote",
    description = __doc__,
    icon = (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeT"
        "AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH1QQIDBMjdIFglwAAADV0RVh0Q29t"
        "bWVudAAoYykgMjAwNCBKYWt1YiBTdGVpbmVyCgpDcmVhdGVkIHdpdGggVGhlIEdJTVCQ"
        "2YtvAAABfklEQVQ4y6WSv0sCYRjHP2+IGlI0GOeN4WQJQnd/gENbRHtTji2NIkhTROLa"
        "EATh0hpE0OTmKNzgQUpDFEhdmosNVw3d2yB3+HYXRX3h5Xnf7/v8fh7BL1CrHywASSAN"
        "uMAAeK2Uq56IUFwFtoAH4BG4AZ6BJ+AF+KiUq55vE/sS7Ai4Ag6Bh0q5+vZTdqJWP1gD"
        "mj/oWYARwe/EgObG+qZMpxcFgBACKSVCKNUZ/t80ThsnxzEATcuIfr//bXjbtslmlxQu"
        "lZpTe2DbtqKgaRqDwUDhEokG7+8lEokGsKs6KBQKOI6Drus4jkMmk0FKGbxvb+/IZkt4"
        "nsR93WZ+kgAzvoNpY13XGY/HigSIx5Mkk7Pc390TGuO0cZQE6PV6of4EDjqdDgDD4TBS"
        "AuRyOSzLYnllOeCCEkzTxHVdTNNUDkA+n8d13ck8DYPudTecQavVUuQ02u32ZJssK7qE"
        "0WhEsVhESomUEiB09zwvWDKf9x3sX1ye7/E3nPFffAJVOqjtMbQazAAAAABJRU5ErkJg"
        "gg=="
    ),
)




    
class EC168(eg.PluginBase):
    
    # For some irratating reason, the HID 'keyboard' remote decides to send all buttons as
    # LCtrl
    # LShift+LCtrl
    # LShift+LCtrl+LAlt
    # LShift+LCtrl+LAlt+5
    # LShift+LAlt+5
    # LAlt+5
    # At first i thought of maybe blocking all of the above to stop programs running shortcuts when i changed
    # channels and the like but uh, that would stop them from being used as shortcuts from my proper keyboard
    # too :(
    # if anyone knows of a way to select a certain keyboard to only get keys from please contact me
    
    Keys = {'LShift+LCtrl+LAlt+M':'ec168.mute',
    'LShift+LCtrl+LAlt+G':'ec168.epg',
    'LShift+LCtrl+LAlt+N':'ec168.livetv',
    'LShift+LCtrl+LAlt+1':'ec168.1',
    'LShift+LCtrl+LAlt+2':'ec168.2',
    'LShift+LCtrl+LAlt+3':'ec168.3',
    'LShift+LCtrl+LAlt+4':'ec168.4',
    'LShift+LCtrl+LAlt+5':'ec168.5',
    'LShift+LCtrl+LAlt+6':'ec168.6',
    'LShift+LCtrl+LAlt+7':'ec168.7',
    'LShift+LCtrl+LAlt+8':'ec168.8',
    'LShift+LCtrl+LAlt+9':'ec168.9',
    'LShift+LCtrl+LAlt+0':'ec168.0',
    'LShift+LCtrl+LAlt+J':'ec168.recall',
    'LShift+LCtrl+LAlt+E':'ec168.teletext',
    'LShift+LCtrl+LAlt+O':'ec168.stop',
    'LShift+LCtrl+LAlt+R':'ec168.record',
    'LShift+LCtrl+LAlt+S':'ec168.pause',
    'LShift+LCtrl+LAlt+B':'ec168.rewind',
    'LShift+LCtrl+LAlt+F':'ec168.fastfoward',
    'LShift+LCtrl+LAlt+U':'ec168.chanup',
    'LShift+LCtrl+LAlt+D':'ec168.chandown',
    'LShift+LCtrl+LAlt+V':'ec168.volup',
    'LShift+LCtrl+LAlt+L':'ec168.voldown',
    'LShift+LCtrl+LAlt+X':'ec168.zoom',
    'LShift+LCtrl+LAlt+H':'ec168.snapshot',
    'LShift+LCtrl+LAlt+Q':'ec168.stereo',
    'LShift+LCtrl+LAlt+P':'ec168.power'}
	
	
	
    def __init__(self):
        eg.event.prefix = "EC168"
        #self.AddEvents()
        
    
    def __start__(self, *dummyArgs):
        SetKeyboardCallback(self.EC168Callback)
        
        
    def __stop__(self):
        SetKeyboardCallback(None)
        
        
    def EC168Callback(self, codes):
        if codes == "":
            self.EndLastEvent()
        else:
            # print codes
            if self.Keys.has_key(codes):
                shouldBlock = HasActiveHandler("Keyboard." + self.Keys[codes])
                self.TriggerEnduringEvent(self.Keys[codes])
                #self.TriggerEvent(self.Keys[codes])
                return shouldBlock
                
    