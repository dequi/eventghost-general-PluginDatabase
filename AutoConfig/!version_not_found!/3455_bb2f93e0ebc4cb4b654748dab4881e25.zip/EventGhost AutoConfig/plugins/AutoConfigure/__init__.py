#
# AutoConfigure V0.1
# ================
# Written by Brett Stottlemyer, <stottle@qadas.com>
# Public Domain
#
#
# Revision history:
# -----------------
# 0.1 - initial
version="0.1" 

# Plugins/Test/__init__.py

eg.RegisterPlugin(
    name = "AutoConfig",
    author = "Brett Stottlemyer",
    version = version,
    kind = "other",
    description = "Automatically create macros for event/actions of standard applications",
    createMacrosOnAdd = False,#Don't set this to True - That's what AutoConfig is for
)

from xml.etree import cElementTree as ElementTree
import fnmatch
import os

class AutoConfig(eg.PluginClass):

    def __init__(self):
        def ProcessXMLAppFile(file):
            try:
                xmlTree = ElementTree.parse(file)
                root = xmlTree.getroot()
                groupName = root.attrib["GroupName"]
                window = root.attrib["Window"]
                name = root.attrib["Name"]
                actions = root.getiterator("Action")
                find = eg.WindowMatcher(window,None, None, None, None, 1, False, 0.0, 0)
                group = self.AddGroup(groupName)
                for a in actions:
                    tmpName = a.attrib["Name"]
                    tmpDescription = a.attrib["Description"]
                    tmpHotKey = a.attrib["Command"]
                    tmpClassName = a.attrib["ClassName"]
                    class tmpActionClass(eg.ActionClass):
                        name = groupName + "_" + tmpName
                        description = tmpDescription
                        hotKey = tmpHotKey
                        event = tmpName
                        def __call__(self):
                            hwnds = find()
                            if len(hwnds) != 0:
                                eg.SendKeys(hwnds[0], self.hotKey, False)
                            else:
                                self.PrintError("Error: Unable to send to "+groupName+" window")
                                return	
                    tmpActionClass.__name__ = groupName + "_" + tmpClassName
                    group.AddAction(tmpActionClass)
            except:
                print "AutoConfig Error:  Failed to process " + file
        path = eg.__path__[0] + "\..\plugins\AutoConfigure"
        xmlFiles = fnmatch.filter(os.listdir(path),"*.xml")
        for file in xmlFiles:
            print os.path.join(path,file)
            ProcessXMLAppFile(os.path.join(path,file))
