class AutoConfig_AddActionGroup(eg.UndoHandler.NewItem):
    name = "Add all actions of plugin"

    def Unique(seq, keepstr=True): 
        t = type(seq) 
        if t in (unicode, str): 
            t = (list, t('').join)[bool(keepstr)] 
        seen = [] 
        return t(c for c in seq if not (c in seen or seen.append(c)))

    def GetEvents(self):
        list = []
        for p in eg.pluginList:
            if p.info.kind == "remote":
                for e in p.info.eventList:
                    list.append(e)				
        return list#self.Unique(list)

    def Do(self, document):
        def searchFunc(obj):
            if obj.__class__ == document.PluginItem:
                if obj.name == "Plugin: AutoConfig":
                    obj.Select()
                    return True
            return None
        if document.tree.root.Traverse(searchFunc) is None:
            print "AutoConfig Plugin is not loaded"
        item =   document.tree.GetSelection()
        pluginItem = document.tree.GetPyData(item)
        parentItem = eg.AddActionGroupDialog.GetModalResult(document.frame)
        if parentItem is None:
            return
        parentItem = parentItem[0][0]
        
        eventList = self.GetEvents()
        print eventList
			
        def Traverse(parentItem, actionGroup):
            folderItem = document.FolderItem.Create(
                parentItem, 
                name=actionGroup.name
            )
            for item in actionGroup.items:
                if isinstance(item, eg.ActionGroup):
                    Traverse(folderItem, item)
                else:
                    macroItem = document.MacroItem.Create(
                        folderItem, 
                        name=item.name
                    )
                    actionItem = document.ActionItem.Create(
                        macroItem,
                        text = "%s.%s()" % (item.plugin.info.evalName, item.name),
                    )
                    try:
                        event = item.event
                        index = eventList.index(event)
                        eventItem = document.EventItem.Create(macroItem,0,name = item.event)
                    except:
                        pass
            return folderItem
        actionGroup = pluginItem.executable.info.actionGroup
        folderItem = Traverse(parentItem,actionGroup)
        self.StoreItem(folderItem)
        folderItem.Select()
        folderItem.tree.Expand(folderItem.id)
		