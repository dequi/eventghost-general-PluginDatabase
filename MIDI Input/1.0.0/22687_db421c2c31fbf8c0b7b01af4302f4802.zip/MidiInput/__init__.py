import eg
import threading
import time
import pygame.midi
import winsound
import win32api
import win32con
from ctypes import windll
user = windll.user32

eg.RegisterPlugin(
  name = "MIDI Input",
  author = "Daniel Faust, refactored by Radoslaw Klocek",
  kind = "remote",
  version = "1.0.0",
  canMultiLoad = False,
  description = ("Receives events from MIDI devices"),
)

def get_devices():
  devices = []
  for i in range( pygame.midi.get_count() ):
    (interf, name, input, output, opened) = pygame.midi.get_device_info(i)
    if input:
      devices.append((i, name))
  return devices

def get_device_id(device_name):
  devices = get_devices()
  for device in devices:
    if device[1] == device_name:
      return device[0]
  return None


class MidiInput(eg.PluginClass):

  def __init__(self):
    pygame.midi.init()
    self.started = False
    self.stopped = True

  def __close__(self):
    pygame.midi.quit()

  def __start__(self, requests=[]):
    pygame.midi.init()
    if requests == None or len(requests) == 0:    
      print("Plugin not configured. Cannnot continue.")
    else:
      startupEvent = threading.Event()
      self.thread = threading.Thread(
        target=self.ThreadLoop,
        name="EventGhostMidiInThread",
        args=(startupEvent, requests)
      )
      self.thread.start()

  def ThreadLoop(self, startupEvent, requests):
    self.started = True
    self.stopped = False
    instances = []
    device_id = None
    try:
      while self.started:
        time.sleep(0.01)
        try:
          if len(instances) == 0:
            for request in requests:
              device_id = get_device_id(request)
              if device_id != None:
                instances.append([request, pygame.midi.Input(device_id)])
            if len(instances) == 0:
              startupEvent.wait(10)

          for instance in instances:
            if instance[1].poll():
              name = instance[0]
              midi_events = instance[1].read(10)
              (data1, data2, data3, data4) = midi_events[0][0]
              channel = data1 & 0x0F
              message = data1 & 0xF0
              if message == 0x80:
                self.TriggerEvent("%s | 8%x %02x" % (name, channel, data2))
              elif message == 0x90:
                if data3 == 0x00:
                  self.TriggerEvent("%s | 8%x %02x" % (name, channel, data2))
                else:
                  self.TriggerEvent("%s | 9%x %02x" % (name, channel, data2))
              else:
                self.TriggerEvent("%s | %02x %02x %02x" % (name, data1, data2, data3))
        except:
          for instance in instances:
            instance[1].close()
            del instance[1]
          instances = [];
      for instance in instances:
        instance[1].close()
        del instance[1]
      instances = [];
    finally:  
      self.stopped = True     
        
  def __stop__(self):
    self.started = False
    while not self.stopped:
      time.sleep(0.01)
    pygame.midi.quit()

  def Configure(self, requests=[]):
    devices = get_devices()
    panel = eg.ConfigPanel()
    checkboxes = []
    for device in devices:
      checkbox = panel.CheckBox(device[1] in requests, device[1])
      panel.AddLine(checkbox)
      checkboxes.append([checkbox, device[1]])

    while panel.Affirmed():
      time.sleep(0.1)
      result = []
      for checkbox in checkboxes:
        if checkbox[0].GetValue():
          result.append(checkbox[1])
      panel.SetResult(result)
