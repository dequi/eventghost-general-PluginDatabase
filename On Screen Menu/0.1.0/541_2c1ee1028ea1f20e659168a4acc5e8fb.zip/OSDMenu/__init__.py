# ==============================================================================
# On Screen v.0.1.0
# ==============================================================================
#
# Plugins/OSDMenu/__init__.py
#
# Copyright (C) 2007 Easy
#

from eg.WinAPI.Utils import GetMonitorDimensions

eg.RegisterPlugin(
    name = "On Screen Menu",
    author = "Easy",
    version = "0.1.0",
    description = (
                    'On screen menu.</p>\n\n<p>To get an onscreen menu generate events '
                    'You\'ll need to compose it using macros:<br> First, add macro called '
                    '"Add item - event" then specify the name wich will be shown in the menu '
                    'and the corresponding name of an event wich will be generated.<br>'
                    'Then add macros "Menu Up", "Menu Down", "Show", "Close" and assign '
                    'Your controls to them.<br>'
                    'Please keep in mind, that plugin is still verry, I mean it - <b>verry '
                    'experimental</b>.'
    ),
    kind = "other",
    icon= (
            "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0"
            "RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAD1SURBVHjapFNLDoIwEJ2GhgUJ"
            "lQRZsOAEnAXXLmQl13LvRnZyEC5hwhIjnzQBO1URMJAik0xJ08frmzdT0rYtrAl6TZLHKgJc"
            "dkFgMMZgrOaz738xy7IEXdfhEscFBUKgaRrwPA/SNL2p3EoIcauqeikgo0Nzf5r9+X4+/paA"
            "4TjOJGiOvCPIskxZReeRJBAeGIYBmqYpK0D8QMHWtqWrqgoQ/27Lt4Q5o5Q8WNKJIYGQsbGs"
            "zoOp2/uB+IEC3/flMEVR5KIXlFJJKAZGJp5hcs5lIr7rAo7mIQyLf98CUXmNeZ7jlDVCDRcl"
            "1yZj9SKCuXgKMACP5GZ5mVX+bAAAAABJRU5ErkJggg=="
    ),
)

class OSMenu(eg.PluginClass):
    class text:
        menuFont = "Select font:"
        display = "Select monitor:"
        activeItemColor = "Select active item color:"
        inactiveItemColor = "Select inactive item color:"
        backgroundColor = "Select menu background color:"

    def __init__(self):
        self.AddAction(AddEvent)
        self.AddAction(ShowMenu)
        self.AddAction(MenuDown)
        self.AddAction(MenuUp)
        self.AddAction(MenuExecute)
        self.AddAction(Close)
        self.AddAction(Clear)

    def __start__(self,fontInfo,displayNo,activeColor,inactiveColor,background):
        self.menuActions = []
        self.menuList=[]
        self.menuSelected = 0
        self.textFieldList=[]
        self.fontInfo=fontInfo
        self.displayNo=displayNo
        self.activeColor=activeColor
        self.inactiveColor=inactiveColor
        self.background=background
        
    def Configure(self, fontInfo=None, displayNo=0, activeColor=(0,255,255), inactiveColor=(255,255,255),background=(0,153,153)):
        panel = eg.ConfigPanel(self)
        text = self.text
        fontTxt = wx.StaticText(panel, -1, text.menuFont)
        fontCtrl = panel.FontSelectButton(fontInfo)
        displayTxt = wx.StaticText(panel, -1, text.display)
        displayCtrl = eg.DisplayChoice(panel, displayNo)
        activeColorTxt = wx.StaticText(panel, -1, text.activeItemColor)
        activeColorCtrl = panel.ColourSelectButton(activeColor)
        inactiveColorTxt = wx.StaticText(panel, -1, text.inactiveItemColor)
        inactiveColorCtrl = panel.ColourSelectButton(inactiveColor)
        backgroundTxt = wx.StaticText(panel, -1, text.backgroundColor)
        backgroundCtrl = panel.ColourSelectButton(background)
        myGrid = wx.GridBagSizer(10, 10)
        Add = myGrid.Add
        Add(fontTxt,(0, 0))
        Add(fontCtrl,(0, 1))
        Add(displayTxt,(1, 0))
        Add(displayCtrl,(1, 1))
        Add(activeColorTxt,(0, 3))
        Add(activeColorCtrl,(0, 4))
        Add(inactiveColorTxt,(1, 3))
        Add(inactiveColorCtrl,(1, 4))
        Add(backgroundTxt,(2, 3))
        Add(backgroundCtrl,(2, 4))
        myGrid.AddGrowableCol(2)
        panel.sizer.Add(myGrid,1,wx.EXPAND)

        while panel.Affirmed():
            panel.SetResult(
                fontCtrl.GetValue(),
                displayCtrl.GetValue(),
                activeColorCtrl.GetValue(),
                inactiveColorCtrl.GetValue(),
                backgroundCtrl.GetValue(),
            )

class Close(eg.ActionClass):
    name = "Close"
    description = "Close menu window."
    iconFile = 'icons/close'
    def __call__(self):
        try:
            if self.plugin.windowFrame.IsShown():
                self.plugin.windowFrame.Show(False)
            else:
                print "No window to close"
        except:
            print "There is no menu yet"

class Clear(eg.ActionClass):
    name = "Clear"
    description = "Delete all menu entries."
    iconFile = 'icons/close'
    def __call__(self):
        try:
            if self.plugin.windowFrame.IsShown():
                print "Can't clear while menu is on screen"
            elif len(self.plugin.menuActions) > 0:
                self.plugin.menuActions = []
                self.plugin.menuSelected = 0
                self.plugin.menuList=[]
                self.plugin.textFieldList=[]
                del(self.plugin.windowFrame)
            else:
                print "No menu to clear"
        except:
            print "There is no menu yet"

class AddEvent(eg.ActionClass):
    name = "Add item - event"
    description = "Adds an item wich, when selected, triggers an event."
    iconFile = 'icons/add'
    class text:
        label = 'Menu item: Event "%s"'
        menuItem = "Menu item name:"
        eventString = "Name of event to trigger:"

    def __call__(self, eventString, menuItem):
        try:
            if self.plugin.windowFrame.IsShown():
                print "Can't add events while menu on screen"
            else:
                tempVal=[menuItem,eventString]
                if tempVal not in self.plugin.menuActions: self.plugin.menuActions.append(tempVal)
        except:
            tempVal=[menuItem,eventString]
            if tempVal not in self.plugin.menuActions: self.plugin.menuActions.append(tempVal)

    def Configure(self, eventString="", menuItem=""):
        panel = eg.ConfigPanel(self)
        text = self.text
        menuItemTxt = wx.StaticText(panel, -1, text.menuItem)
        menuItemCtrl = wx.TextCtrl(panel, -1, menuItem, size=(250, -1))
        eventStringTxt = wx.StaticText(panel, -1, text.eventString)
        eventStringCtrl = wx.TextCtrl(panel, -1, eventString, size=(250, -1))
        lowerSizer = wx.GridBagSizer(0, 0)
        lowerSizer.AddGrowableCol(1)
        lowerSizer.AddGrowableCol(3)
        Add = lowerSizer.Add
        Add(eventStringTxt, (0, 0), flag=wx.ALIGN_BOTTOM)
        Add(eventStringCtrl, (1, 0))
        Add((1, 1), (0, 1), flag=wx.EXPAND)

        Add = panel.sizer.Add
        Add(menuItemTxt)
        Add(menuItemCtrl, 0, wx.EXPAND)
        Add((10,10))
        Add(eventStringTxt)
        Add(eventStringCtrl, 0, wx.EXPAND)

        while panel.Affirmed():
            panel.SetResult(
                eventStringCtrl.GetValue(),
                menuItemCtrl.GetValue(),
            )

class MenuDown(eg.ActionClass):
    name = "Menu Down"
    description = "Move selection down."
    iconFile = 'icons/menu_down'
    def __init__(self):
        return None
    
    def __call__(self):
        try:
            if self.plugin.windowFrame.IsShown():
                if len(self.plugin.textFieldList)==0:
                    return True
                elif self.plugin.menuSelected == len(self.plugin.textFieldList)-1:
                    return True
                else:
                    self.plugin.textFieldList[self.plugin.menuSelected].SetForegroundColour(self.plugin.inactiveColor)
                    self.plugin.menuSelected+=1
                    self.plugin.textFieldList[self.plugin.menuSelected].SetForegroundColour(self.plugin.activeColor)
                    wx.CallAfter(self.plugin.windowFrame.menuRefresh)
            else:
                print "No menu on screen"
        except:
            print "There is no menu yet"

class MenuUp(eg.ActionClass):
    name = "Menu Up"
    description = "Move selection up."
    iconFile = 'icons/menu_up'
    
    def __init__(self):
        return None
    
    def __call__(self):
        try:
            if self.plugin.windowFrame.IsShown():
                if self.plugin.menuSelected == 0:
                    return True
                else:
                    self.plugin.textFieldList[self.plugin.menuSelected].SetForegroundColour(self.plugin.inactiveColor)
                    self.plugin.menuSelected-=1
                    self.plugin.textFieldList[self.plugin.menuSelected].SetForegroundColour(self.plugin.activeColor)
                    wx.CallAfter(self.plugin.windowFrame.menuRefresh)
            else:
                print "No menu on screen"
        except:
            print "There is no menu yet"

class MenuExecute(eg.ActionClass):
    name = "Execute"
    description = "Triggers an event associated with current menu item."
    iconFile = 'icons/enter'

    def __call__(self):
        try:
            if self.plugin.windowFrame.IsShown():
                eg.TriggerEvent("OSMenu."+self.plugin.menuActions[self.plugin.menuSelected][1])
                self.plugin.windowFrame.Show(False)
            else:
                print "Can't execute while menu not on screen"
        except:
            print "There is no menu yet"

class ShowMenu(eg.ActionClass):
    name = "Show"
    description = "Show composed menu. This should be the last action in Your macro."
    iconFile = 'icons/plugin'

#    def __init__(self):
#        def makeFrame():
#            def closeOSD():
#                self.plugin.windowFrame.Close()
#            eg.app.onExitFuncs.append(closeOSD)
#        wx.CallAfter(makeFrame)

    def OnClose(self):
        self.plugin.windowFrame.Show(False)
        del(self.plugin.windowFrame)

    def __call__(self):
        if len(self.plugin.menuActions):
            try:
                self.plugin.windowFrame
            except:
                memoryDC = wx.MemoryDC()
                self.plugin.fontSize=12
                self.plugin.font=wx.Font(self.plugin.fontSize,wx.DEFAULT,wx.NORMAL,wx.BOLD)
                if self.plugin.fontInfo:
                    nativeFontInfo = wx.NativeFontInfo()
                    nativeFontInfo.FromString(self.plugin.fontInfo)
                    self.plugin.font.SetNativeFontInfo(nativeFontInfo)
                    self.plugin.fontSize=self.plugin.font.GetPointSize()
                memoryDC.SetFont(self.plugin.font)
                self.plugin.height=0
                self.plugin.width=0
                for k in range(len(self.plugin.menuActions)):
                    menuItem=self.plugin.menuActions[k][0]
                    w, h = memoryDC.GetTextExtent(menuItem)
                    if w>self.plugin.width: self.plugin.width=w
                    self.plugin.height += h
                    if k<len(self.plugin.menuActions) :  self.plugin.height += int(self.plugin.fontSize/6)
                    self.plugin.menuList.append([menuItem,w,h])
                del memoryDC
                self.plugin.height += 20
                self.plugin.width += 20
                self.plugin.windowFrame=OSMenuFrame(self.plugin.width,self.plugin.height)
            
                wx.CallAfter(self.plugin.windowFrame.addContent,
                            self,
                            self.plugin.menuList
                            )
            else:
                if not self.plugin.windowFrame.IsShown():
                    wx.CallAfter(self.plugin.windowFrame.Show, True)
                else:
                    print "Menu is on screen. Simply refreshing"
                    wx.CallAfter(self.plugin.windowFrame.menuRefresh)
        else: print "There is no menu yet"

class OSMenuFrame(wx.Frame):
    def __init__(self, w,h):
        wx.Frame.__init__(self, None,-1,"OSMenu",size=wx.Size(w, h),style=wx.FRAME_NO_TASKBAR|wx.STAY_ON_TOP)
        self.width=w
        self.height=h

    def __start__(self):
        return None

    def __stop__(self):
        return None

    def __close__(self):
        return None

    def addContent(self, parent, menuList):
        panel = wx.Panel(self, -1,(-1, -1),size=wx.Size(self.width, self.height))
        posY=10
        for k in range(len(menuList)):
            menuItem=menuList[k][0]
            textField=wx.StaticText(panel, -1, pos = (10,posY), size=wx.Size(menuList[k][1], menuList[k][2]))
            textField.SetLabel(menuItem)
            textField.SetFont(parent.plugin.font)
            posY+=menuList[k][2]+parent.plugin.fontSize/6
            if k == parent.plugin.menuSelected: textField.SetForegroundColour(parent.plugin.activeColor)
            else:  textField.SetForegroundColour(parent.plugin.inactiveColor)
            parent.plugin.textFieldList.append(textField)
        panel.SetBackgroundColour(parent.plugin.background)
        monitorDimensions = GetMonitorDimensions()
        try:
            d = monitorDimensions[parent.plugin.displayNo]
        except IndexError:
            d = monitorDimensions[0]
        x = d.x + ((d.width - self.width) / 2)
        y = d.y + ((d.height - self.height) / 2)
        self.SetPosition((x, y))
        self.Show(True)
        self.menuRefresh()

    def menuRefresh(self):
        self.Refresh()