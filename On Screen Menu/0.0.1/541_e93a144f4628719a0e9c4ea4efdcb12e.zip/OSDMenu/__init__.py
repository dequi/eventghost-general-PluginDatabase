from eg.WinAPI.Utils import GetMonitorDimensions

eg.RegisterPlugin(
    name = "On Screen Menu",
    author = "Easy",
    version = "0.0.1",
    description = (
                    'On screen menu.</p>\n\n<p>To get an onscreen menu generate events '
                    'You\'ll need to compose it using macros:<br> First, add macro called '
                    '"Add item - event" then specify the name wich will be shown in the menu '
                    'and the corresponding name of an event wich will be generated.<br>'
                    'Then add macros "Menu Up", "Menu Down", "Show", "Close" and assign '
                    'Your controls to them.<br>'
                    'Please keep in mind, that plugin is still verry, I mean it - <b>verry '
                    'experimental</b>.'
    ),
    kind = "other",
    icon= (
            "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0"
            "RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAD1SURBVHjapFNLDoIwEJ2GhgUJ"
            "lQRZsOAEnAXXLmQl13LvRnZyEC5hwhIjnzQBO1URMJAik0xJ08frmzdT0rYtrAl6TZLHKgJc"
            "dkFgMMZgrOaz738xy7IEXdfhEscFBUKgaRrwPA/SNL2p3EoIcauqeikgo0Nzf5r9+X4+/paA"
            "4TjOJGiOvCPIskxZReeRJBAeGIYBmqYpK0D8QMHWtqWrqgoQ/27Lt4Q5o5Q8WNKJIYGQsbGs"
            "zoOp2/uB+IEC3/flMEVR5KIXlFJJKAZGJp5hcs5lIr7rAo7mIQyLf98CUXmNeZ7jlDVCDRcl"
            "1yZj9SKCuXgKMACP5GZ5mVX+bAAAAABJRU5ErkJggg=="
    ),
)

class OSMenuFrame(wx.Frame):
    def __init__(self, parent,w,h):
        wx.Frame.__init__(self, parent,-1,"OSMenu",size=wx.Size(w, h),style=wx.FRAME_NO_TASKBAR|wx.STAY_ON_TOP)

    def __start__(self):
        return None

    def __stop__(self):
        return None

    def __close__(self):
        return None

    def AddContent(self):
        memoryDC = wx.MemoryDC()
        memoryDC.SetFont(eg.plugins.OSMenu.font)
        eg.plugins.OSMenu.menuSelected = 0
        panel = wx.Panel(self, -1,(-1, -1),size=wx.Size(eg.plugins.OSMenu.width, eg.plugins.OSMenu.height))
        posY=10
        eg.plugins.OSMenu.textFieldList=[]
        for k in range(len(eg.plugins.OSMenu.MenuActions)):
            menuItem=eg.plugins.OSMenu.MenuActions[k][0]
            eventString=eg.plugins.OSMenu.MenuActions[k][1]
            w, h = memoryDC.GetTextExtent(menuItem)
            textField=wx.StaticText(panel, -1, pos = (10,posY), size=wx.Size(w, h))
            textField.SetLabel(menuItem)
            textField.SetFont(eg.plugins.OSMenu.font)
            posY+=h+eg.plugins.OSMenu.fontSize/6
            if k == eg.plugins.OSMenu.menuSelected: textField.SetForegroundColour(eg.plugins.OSMenu.activeColor)
            else:  textField.SetForegroundColour(eg.plugins.OSMenu.inactiveColor)
            eg.plugins.OSMenu.textFieldList.append(textField)
        panel.SetBackgroundColour(eg.plugins.OSMenu.background)
        monitorDimensions = GetMonitorDimensions()
        try:
            d = monitorDimensions[eg.plugins.OSMenu.displayNo]
        except IndexError:
            d = monitorDimensions[0]
        x = d.x + ((d.width - eg.plugins.OSMenu.width) / 2)
        y = d.y + ((d.height - eg.plugins.OSMenu.height) / 2)
        self.SetPosition((x, y))
        self.Show(True)

    def menuRefresh(self):
        self.Refresh()

class OSMenu(eg.PluginClass):
    class text:
        menuFont = "Select font:"
        display = "Select monitor:"
        activeItemColor = "Select active item color:"
        inactiveItemColor = "Select inactive item color:"
        backgroundColor = "Select menu background color:"

    def __init__(self):
        eg.plugins.OSMenu.MenuActions = []
        self.AddAction(AddEvent)
        self.AddAction(ShowMenu)
        self.AddAction(MenuDown)
        self.AddAction(MenuUp)
        self.AddAction(MenuExecute)
        self.AddAction(Close)

    def __start__(self,fontInfo,displayNo,activeColor,inactiveColor,background):
        eg.plugins.OSMenu.fontInfo=fontInfo
        eg.plugins.OSMenu.displayNo=displayNo
        eg.plugins.OSMenu.activeColor=activeColor
        eg.plugins.OSMenu.inactiveColor=inactiveColor
        eg.plugins.OSMenu.background=background
        
    def __call__(self,eventString,menuItem):
        tempVal=[menuItem,eventString]
        if tempVal not in eg.plugins.OSMenu.MenuActions: eg.plugins.OSMenu.MenuActions.append([menuItem,eventString])

    def Configure(self, fontInfo=None, displayNo=0, activeColor=(0,255,255), inactiveColor=(255,255,255),background=(0,153,153)):
        panel = eg.ConfigPanel(self)
        text = self.text
        fontTxt = wx.StaticText(panel, -1, text.menuFont)
        fontCtrl = panel.FontSelectButton(fontInfo)
        displayTxt = wx.StaticText(panel, -1, text.display)
        displayCtrl = eg.DisplayChoice(panel, displayNo)
        activeColorTxt = wx.StaticText(panel, -1, text.activeItemColor)
        activeColorCtrl = panel.ColourSelectButton(activeColor)
        inactiveColorTxt = wx.StaticText(panel, -1, text.inactiveItemColor)
        inactiveColorCtrl = panel.ColourSelectButton(inactiveColor)
        backgroundTxt = wx.StaticText(panel, -1, text.backgroundColor)
        backgroundCtrl = panel.ColourSelectButton(background)
        myGrid = wx.GridBagSizer(10, 10)
        Add = myGrid.Add
        Add(fontTxt,(0, 0))
        Add(fontCtrl,(0, 1))
        Add(displayTxt,(1, 0))
        Add(displayCtrl,(1, 1))
        Add(activeColorTxt,(0, 3))
        Add(activeColorCtrl,(0, 4))
        Add(inactiveColorTxt,(1, 3))
        Add(inactiveColorCtrl,(1, 4))
        Add(backgroundTxt,(2, 3))
        Add(backgroundCtrl,(2, 4))
        myGrid.AddGrowableCol(2)
        panel.sizer.Add(myGrid,1,wx.EXPAND)

        while panel.Affirmed():
            panel.SetResult(
                fontCtrl.GetValue(),
                displayCtrl.GetValue(),
                activeColorCtrl.GetValue(),
                inactiveColorCtrl.GetValue(),
                backgroundCtrl.GetValue(),
            )

class Close(eg.ActionClass):
    name = "Close"
    description = "Close menu window."
    iconFile = 'icons/close'
    def __call__(self):
        eg.plugins.OSMenu.windowFrame.Show(False)
        eg.plugins.OSMenu.windowFrame.Close()
        eg.plugins.OSMenu.windowFrame = None

class AddEvent(eg.ActionClass):
    name = "Add item - event"
    description = "Adds an item wich, when selected, triggers an event."
    iconFile = 'icons/add'
    class text:
        label = 'Menu item: Event "%s"'
        menuItem = "Menu item name:"
        eventString = "Name of event to trigger:"

    def __call__(self, eventString, menuItem):
        tempVal=[menuItem,eventString]
        if tempVal not in eg.plugins.OSMenu.MenuActions: eg.plugins.OSMenu.MenuActions.append([menuItem,eventString])

    def Configure(self, eventString="", menuItem=""):
        panel = eg.ConfigPanel(self)
        text = self.text
        menuItemTxt = wx.StaticText(panel, -1, text.menuItem)
        menuItemCtrl = wx.TextCtrl(panel, -1, menuItem, size=(250, -1))
        eventStringTxt = wx.StaticText(panel, -1, text.eventString)
        eventStringCtrl = wx.TextCtrl(panel, -1, eventString, size=(250, -1))
        lowerSizer = wx.GridBagSizer(0, 0)
        lowerSizer.AddGrowableCol(1)
        lowerSizer.AddGrowableCol(3)
        Add = lowerSizer.Add
        Add(eventStringTxt, (0, 0), flag=wx.ALIGN_BOTTOM)
        Add(eventStringCtrl, (1, 0))
        Add((1, 1), (0, 1), flag=wx.EXPAND)

        Add = panel.sizer.Add
        Add(menuItemTxt)
        Add(menuItemCtrl, 0, wx.EXPAND)
        Add((10,10))
        Add(eventStringTxt)
        Add(eventStringCtrl, 0, wx.EXPAND)

        while panel.Affirmed():
            panel.SetResult(
                eventStringCtrl.GetValue(),
                menuItemCtrl.GetValue(),
            )

class MenuDown(eg.ActionClass):
    name = "Menu Down"
    description = "Move selection down."
    iconFile = 'icons/menu_down'
    def __init__(self):
        return None
    
    def __call__(self):
        if eg.plugins.OSMenu.menuSelected == len(eg.plugins.OSMenu.textFieldList)-1:
            return True
        else:
            eg.plugins.OSMenu.textFieldList[eg.plugins.OSMenu.menuSelected].SetForegroundColour(eg.plugins.OSMenu.inactiveColor)
            eg.plugins.OSMenu.menuSelected+=1
            eg.plugins.OSMenu.textFieldList[eg.plugins.OSMenu.menuSelected].SetForegroundColour(eg.plugins.OSMenu.activeColor)
            wx.CallAfter(eg.plugins.OSMenu.windowFrame.menuRefresh)

class MenuUp(eg.ActionClass):
    name = "Menu Up"
    description = "Move selection up."
    iconFile = 'icons/menu_up'
    
    def __init__(self):
        return None
    
    def __call__(self):
        if eg.plugins.OSMenu.menuSelected == 0:
            return True
        else:
            eg.plugins.OSMenu.textFieldList[eg.plugins.OSMenu.menuSelected].SetForegroundColour(eg.plugins.OSMenu.inactiveColor)
            eg.plugins.OSMenu.menuSelected-=1
            eg.plugins.OSMenu.textFieldList[eg.plugins.OSMenu.menuSelected].SetForegroundColour(eg.plugins.OSMenu.activeColor)
            wx.CallAfter(eg.plugins.OSMenu.windowFrame.menuRefresh)

class MenuExecute(eg.ActionClass):
    name = "Execute"
    description = "Triggers an event associated with current menu item."
    iconFile = 'icons/enter'
    
    def __init__(self):
        return None
    
    def __call__(self):
        eg.TriggerEvent("OSMenu."+eg.plugins.OSMenu.MenuActions[eg.plugins.OSMenu.menuSelected][1])
        eg.plugins.OSMenu.Close()

class ShowMenu(eg.ActionClass):
    name = "Show"
    description = "Show composed menu. This should be the last action in Your macro."
    iconFile = 'icons/plugin'

    def __init__(self):
        def makeFrame():
            def closeOSD():
                eg.plugins.OSMenu.windowFrame.Close()
            eg.app.onExitFuncs.append(closeOSD)
        wx.CallAfter(makeFrame)

    def OnClose(self):
        eg.plugins.OSMenu.windowFrame.Show(False)
        eg.plugins.OSMenu.windowFrame = None

    def __call__(self):
        memoryDC = wx.MemoryDC()
        eg.plugins.OSMenu.fontSize=12
        eg.plugins.OSMenu.font=wx.Font(eg.plugins.OSMenu.fontSize,wx.DEFAULT,wx.NORMAL,wx.BOLD)
        if eg.plugins.OSMenu.fontInfo:
            nativeFontInfo = wx.NativeFontInfo()
            nativeFontInfo.FromString(eg.plugins.OSMenu.fontInfo)
            eg.plugins.OSMenu.font.SetNativeFontInfo(nativeFontInfo)
            eg.plugins.OSMenu.fontSize=eg.plugins.OSMenu.font.GetPointSize()
        memoryDC.SetFont(eg.plugins.OSMenu.font)
        eg.plugins.OSMenu.height=0
        eg.plugins.OSMenu.width=0
        for k in range(len(eg.plugins.OSMenu.MenuActions)):
            menuItem=eg.plugins.OSMenu.MenuActions[k][0]
            w, h = memoryDC.GetTextExtent(menuItem)
            if w>eg.plugins.OSMenu.width: eg.plugins.OSMenu.width=w
            eg.plugins.OSMenu.height += h + int(eg.plugins.OSMenu.fontSize/6)
        eg.plugins.OSMenu.height += 20
        eg.plugins.OSMenu.width += 20
        eg.plugins.OSMenu.windowFrame=OSMenuFrame(None,eg.plugins.OSMenu.width,eg.plugins.OSMenu.height)
        wx.CallAfter(eg.plugins.OSMenu.windowFrame.AddContent)