import wx, LayeredWindow, time
# add this when porting to EG
#from eg.WinAPI.Utils import GetMonitorDimensions

class MenuDisplay(LayeredWindow.LayeredWindow):
    def __init__(self, alpha, menuList, font):
        LayeredWindow.LayeredWindow.__init__(self, alpha)
        self.menuList=menuList
        self.font=font
        self.sizeX, self.sizeY = self.DetermineSize()
        self.SetSize(wx.Size(self.sizeX, self.sizeY))
        
    def DetermineSize(self):
        limX=0
        sizeY=0
        memoryDC = wx.MemoryDC()
        memoryDC.SetFont(self.font)
        for item in self.menuList:
            w, h = memoryDC.GetTextExtent(item["txt"])
            if w>limX: limX=w
            sizeY+=h
        sizeX=limX + 40
        sizeY+=+40
        return (sizeX,sizeY)

    def GetStep(self):
        memoryDC = wx.MemoryDC()
        memoryDC.SetFont(self.font)
        w, h = memoryDC.GetTextExtent(self.menuList[0]["txt"])
        return h

    def DrawWindow(self):
        tmpDC = wx.MemoryDC()
        self.bmp = wx.EmptyBitmap(*self.GetClientSizeTuple())
        tmpDC.SelectObject(self.bmp)
        ## GetGCDC
        try:
            tmpDC = wx.GCDC(tmpDC)
        except:
            print "Can not get GCDC"
            
        # Background
        tmpDC.SetBrush(wx.Brush(wx.Colour(32, 32, 32, 200)))
        tmpDC.SetPen(wx.Pen(wx.Colour(32, 32, 32), 1))
        tmpDC.DrawRoundedRectangle(0, 0, self.sizeX, self.sizeY, 4)

        # Menu items
        tmpDC.SetFont(self.font)
        posY=20
        step=self.GetStep()
        for item in self.menuList:
            if item["selected"] : tmpDC.SetTextForeground("#FFFF00")
            else: tmpDC.SetTextForeground("#FFFFFF")
            tmpDC.DrawText(item["txt"], 20, posY)
            posY+=step  

        tmpDC.Destroy()
        del tmpDC