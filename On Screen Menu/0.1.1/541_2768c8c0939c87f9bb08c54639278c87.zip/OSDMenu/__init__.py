# ==============================================================================
# On Screen v.0.1.2
# ==============================================================================
#
# Plugins/OSDMenu/__init__.py
#
# Copyright (C) 2007 Easy
#
#Changelog:
# v0.1.2
#   Switched to Graphic Context drawing
#   Some visual improvements (transparency, background)
#   Window drawing is now Windows(R) job
#   More object oriented script
#   Now text entry can be not only strings, but also variables, like {eg.result}
#

from MenuDisplay import *
#from eg.WinAPI.Utils import GetMonitorDimensions

eg.RegisterPlugin(
    name = "On Screen Menu",
    author = "Easy",
    version = "0.1.1",
    description = (
                    'On screen menu.</p>\n\n<p>To get an onscreen menu generate events '
                    'You\'ll need to compose it using macros:<br> First, add macro called '
                    '"Add item - event" then specify the name wich will be shown in the menu '
                    'and the corresponding name of an event wich will be generated.<br>'
                    'Then add macros "Menu Up", "Menu Down", "Show", "Close" and assign '
                    'Your controls to them.<br>'
                    'Please keep in mind, that plugin is still verry, I mean it - <b>verry '
                    'experimental</b>.'
    ),
    kind = "other",
    icon= (
            "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0"
            "RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAD1SURBVHjapFNLDoIwEJ2GhgUJ"
            "lQRZsOAEnAXXLmQl13LvRnZyEC5hwhIjnzQBO1URMJAik0xJ08frmzdT0rYtrAl6TZLHKgJc"
            "dkFgMMZgrOaz738xy7IEXdfhEscFBUKgaRrwPA/SNL2p3EoIcauqeikgo0Nzf5r9+X4+/paA"
            "4TjOJGiOvCPIskxZReeRJBAeGIYBmqYpK0D8QMHWtqWrqgoQ/27Lt4Q5o5Q8WNKJIYGQsbGs"
            "zoOp2/uB+IEC3/flMEVR5KIXlFJJKAZGJp5hcs5lIr7rAo7mIQyLf98CUXmNeZ7jlDVCDRcl"
            "1yZj9SKCuXgKMACP5GZ5mVX+bAAAAABJRU5ErkJggg=="
    ),
)

class OSMenu(eg.PluginClass):
    class text:
        menuFont = "Select font:"
        display = "Select monitor:"
        fadeIn = "Window fade in steps:"
        fadeOut = "Window fade out steps:"

    def __init__(self):
        self.AddAction(AddEvent)
        self.AddAction(ShowMenu)
        self.AddAction(MenuDown)
        self.AddAction(MenuUp)
        self.AddAction(MenuExecute)
        self.AddAction(Close)
        self.AddAction(Clear)

    def __start__(self, fontInfo, displayNo, fadeIn, fadeOut):
        self.menuList=[]
        self.menuSelected = 0
        self.fontInfo=fontInfo
        self.displayNo=displayNo
        self.fadeIn=fadeIn
        self.fadeOut=fadeOut
        
    def Configure(self, fontInfo="0;-37;0;0;0;700;0;0;0;186;3;2;1;34;Arial", displayNo=0, fadeIn=20, fadeOut=50):
        panel = eg.ConfigPanel(self)
        text = self.text
        fontTxt = wx.StaticText(panel, -1, text.menuFont)
        fontCtrl = panel.FontSelectButton(fontInfo)
        displayTxt = wx.StaticText(panel, -1, text.display)
        displayCtrl = eg.DisplayChoice(panel, displayNo)
        fadeInTxt = wx.StaticText(panel, -1, text.fadeIn)
        fadeInCtrl = eg.SpinIntCtrl(panel, -1, fadeIn, 0, 500)
        fadeOutTxt = wx.StaticText(panel, -1, text.fadeOut)
        fadeOutCtrl = eg.SpinIntCtrl(panel,-1, fadeOut, 0, 500)
        myGrid = wx.GridBagSizer(10, 10)
        Add = myGrid.Add
        Add(fontTxt,(0, 0))
        Add(fontCtrl,(0, 1))
        Add(displayTxt,(1, 0))
        Add(displayCtrl,(1, 1))
        Add(fadeInTxt,(0, 3))
        Add(fadeInCtrl,(0, 4))
        Add(fadeOutTxt,(1, 3))
        Add(fadeOutCtrl,(1, 4))
        myGrid.AddGrowableCol(2)
        panel.sizer.Add(myGrid,1,wx.EXPAND)

        while panel.Affirmed():
            panel.SetResult(
                fontCtrl.GetValue(),
                displayCtrl.GetValue(),
                fadeInCtrl.GetValue(),
                fadeOutCtrl.GetValue(),
            )

class Close(eg.ActionClass):
    name = "Close"
    description = "Close menu window."
    iconFile = 'icons/close'
    def __call__(self):
        try:
            if self.plugin.windowFrame.IsShown():
                wx.CallAfter(self.plugin.windowFrame.FadeOut,self.plugin.fadeOut)
                del(self.plugin.windowFrame)
            else:
                print "No window to close"
        except:
            print "There is no menu yet"

class Clear(eg.ActionClass):
    name = "Clear"
    description = "Delete all menu entries."
    iconFile = 'icons/close'
    def __call__(self):
        try:
            self.plugin.windowFrame
        except:
            if len(self.plugin.menuList) > 0:
                self.plugin.menuSelected = 0
                self.plugin.menuList=[]
            else:
                print "No menu to clear"
        else:
            print "Not while menu on screen"

class AddEvent(eg.ActionClass):
    name = "Add item - event"
    description = "Adds an item wich, when selected, triggers an event."
    iconFile = 'icons/add'
    class text:
        label = 'Menu item: Event "%s"'
        menuItem = "Menu item name:"
        eventString = "Name of event to trigger:"

    def __call__(self, eventString, menuItem):
        try:
            if self.plugin.windowFrame.IsShown():
                print "Can't add events while menu on screen"
            else:
                parsedItem=eg.ParseString(menuItem)
#                parsedItem=menuItem
                tempVal={"txt": parsedItem, "selected": False, "event": eventString}
                if tempVal not in self.plugin.menuList: self.plugin.menuList.append(tempVal)
        except:
            parsedItem=eg.ParseString(menuItem)
#            parsedItem=menuItem
            tempVal={"txt": parsedItem, "selected": False, "event": eventString}
            if tempVal not in self.plugin.menuList: self.plugin.menuList.append(tempVal)

    def Configure(self, eventString="", menuItem=""):
        panel = eg.ConfigPanel(self)
        text = self.text
        menuItemTxt = wx.StaticText(panel, -1, text.menuItem)
        menuItemCtrl = wx.TextCtrl(panel, -1, menuItem, size=(250, -1))
        eventStringTxt = wx.StaticText(panel, -1, text.eventString)
        eventStringCtrl = wx.TextCtrl(panel, -1, eventString, size=(250, -1))
        lowerSizer = wx.GridBagSizer(0, 0)
        lowerSizer.AddGrowableCol(1)
        lowerSizer.AddGrowableCol(3)
        Add = lowerSizer.Add
        Add(eventStringTxt, (0, 0), flag=wx.ALIGN_BOTTOM)
        Add(eventStringCtrl, (1, 0))
        Add((1, 1), (0, 1), flag=wx.EXPAND)

        Add = panel.sizer.Add
        Add(menuItemTxt)
        Add(menuItemCtrl, 0, wx.EXPAND)
        Add((10,10))
        Add(eventStringTxt)
        Add(eventStringCtrl, 0, wx.EXPAND)

        while panel.Affirmed():
            panel.SetResult(
                eventStringCtrl.GetValue(),
                menuItemCtrl.GetValue(),
            )

class MenuDown(eg.ActionClass):
    name = "Menu Down"
    description = "Move selection down."
    iconFile = 'icons/menu_down'
    def __init__(self):
        return None
    
    def __call__(self):
        try:
            self.plugin.windowFrame
        except:
            print "No menu on screen"
        else:
                if len(self.plugin.menuList)==0:
                    return True
                elif self.plugin.menuSelected == len(self.plugin.menuList)-1:
                    return True
                else:
                    self.plugin.menuList[self.plugin.menuSelected]["selected"]=False
                    self.plugin.menuSelected+=1
                    self.plugin.menuList[self.plugin.menuSelected]["selected"]=True
                    def DoIt():
                        self.plugin.windowFrame.DrawWindow()
                        self.plugin.windowFrame.UpdateWindow()
                    wx.CallAfter(DoIt)

class MenuUp(eg.ActionClass):
    name = "Menu Up"
    description = "Move selection up."
    iconFile = 'icons/menu_up'
    
    def __init__(self):
        return None
    
    def __call__(self):
        try:
            self.plugin.windowFrame
        except:
            print "No menu on screen"
        else:
                if len(self.plugin.menuList)==0:
                    return True
                elif self.plugin.menuSelected == 0:
                    return True
                else:
                    self.plugin.menuList[self.plugin.menuSelected]["selected"]=False
                    self.plugin.menuSelected-=1
                    self.plugin.menuList[self.plugin.menuSelected]["selected"]=True
                    def DoIt():
                        self.plugin.windowFrame.DrawWindow()
                        self.plugin.windowFrame.UpdateWindow()
                    wx.CallAfter(DoIt)

class MenuExecute(eg.ActionClass):
    name = "Execute"
    description = "Triggers an event associated with current menu item."
    iconFile = 'icons/enter'

    def __call__(self):
        try:
            if self.plugin.windowFrame.IsShown():
                eg.TriggerEvent("OSMenu."+self.plugin.menuList[self.plugin.menuSelected]["event"])
                wx.CallAfter(self.plugin.info.actions["Close"])
            else:
                print "Can't execute while menu not on screen"
        except:
            print "There is no menu yet"

class ShowMenu(eg.ActionClass):
    name = "Show"
    description = "Show composed menu. This should be the last action in Your macro."
    iconFile = 'icons/plugin'

    def OnClose(self):
        self.plugin.windowFrame.Show(False)
        del(self.plugin.windowFrame)

    def __call__(self):
#        self.plugin.menuList=self.PrepareString(self.plugin.menuList)
        if len(self.plugin.menuList):
            try:
                self.plugin.windowFrame
            except:
                self.plugin.menuList[self.plugin.menuSelected]["selected"] = True
                self.plugin.font=wx.Font(18, wx.FONTFAMILY_TELETYPE,wx.NORMAL,wx.BOLD, faceName="Arial")
                if self.plugin.fontInfo:
                    nativeFontInfo = wx.NativeFontInfo()
                    nativeFontInfo.FromString(self.plugin.fontInfo)
                    self.plugin.font.SetNativeFontInfo(nativeFontInfo)
                def DoIt():
                    self.plugin.windowFrame=MenuDisplay(220, self.plugin.menuList, self.plugin.font)
                    self.plugin.windowFrame.Center(wx.BOTH)
                    self.plugin.windowFrame.FadeIn(self.plugin.fadeIn)
                wx.CallAfter(DoIt)
            else:
                if not self.plugin.windowFrame.IsShown():
                    def DoIt():
                        self.plugin.windowFrame.FadeIn(self.plugin.fadeIn)
                        self.plugin.windowFrame.UpdateWindow()
                    wx.CallAfter(DoIt)
                else:
                    print "Menu is on screen. Simply refreshing"
                    wx.CallAfter(self.plugin.windowFrame.UpdateWindow)
        else: print "Nothing to show - menu empty"

    def PrepareString(self, list):
        for k in range(0, len(list)):
            list[k]["txt"]=eg.ParseString(list[k]["txt"])
            # self.menuList[k]["txt"]=self.menuList[k]["txt"].replace("\n", " ")
            # self.menuList[k]["txt"]=self.menuList[k]["txt"].replace(u"\n", u" ")
        return list