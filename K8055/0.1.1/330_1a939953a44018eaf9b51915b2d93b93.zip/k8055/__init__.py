#
# plugins/k8055/__init__.py
#
# Copyright (C) 2008
# Walter Kraembring
#
##############################################################################
# Revision history:
#
# 2008-03-01  The first stumbling version
##############################################################################

eg.RegisterPlugin(
    name = "K8055",
    author = "Walter Kraembring",
    version = "0.1.1",
    canMultiLoad = False,
    kind = "external",
    url = "http://www.velleman.be/ot/en/product/view/?id=351346",
    description = (
        '<p>Plugin to control Welleman K8055 VM110 USB Experiment Interface Board</p>'
        '\n\n<p><a href="http://www.velleman.be/ot/en/product/view/?id=351346">Product details...</a></p>'
        '<center><img src="k8055.png" /></center>'
    ),
)

import os, pickle
from ctypes import windll, c_char_p
from threading import Event, Thread

# Initialization...
try:
    dummy
except NameError:
    dummy = 0

    #Default settings
    thread_wait = 0.5
    b_nbr = 0
    counter_1_threshold = 5
    counter_2_threshold = 5
    ai_1_event_trigger = 254
    ai_2_event_trigger = 254
    di_1_event_trigger = 0
    di_2_event_trigger = 0
    di_3_event_trigger = 0
    di_4_event_trigger = 0
    di_5_event_trigger = 0

    #Event memory
    ai_1_event_memory = 0
    ai_2_event_memory = 0
    di_1_event_memory = 0
    di_2_event_memory = 0
    di_3_event_memory = 0
    di_4_event_memory = 0
    di_5_event_memory = 0

    #Generate a global number list
    nbr_list = []
    for i in range(255):
        nbr_list.append(str(i))



class k8055(eg.PluginClass):

    def Configure(self, boardctrl = 0):
        global b_nbr
        panel = eg.ConfigPanel(self)
        boardctrl = panel.Choice(b_nbr, choices=['0', '1', '2', '3'])
        panel.AddLine("Board Number", boardctrl)
        while panel.Affirmed():
            panel.SetResult(boardctrl.GetValue())
            b_nbr = boardctrl.GetValue()


    def __init__(self):
        print "K8055 is initiated"
        self.AddAction(SetDigitalChannel)
        self.AddAction(ClearDigitalChannel)
        self.AddAction(SetAnalogChannel_Low)
        self.AddAction(SetAnalogChannel_High)
        self.AddAction(ClearAnalogChannel)
        self.AddAction(ReadDigitalChannel)
        self.AddAction(ReadAnalogChannel)
        self.AddAction(Counter)
        self.AddAction(Info)
   
        
    def __start__(self, detect_board):
        global b_nbr
        global counter_1_threshold
        global counter_2_threshold
        global ai_1_event_trigger
        global ai_2_event_trigger
        global di_1_event_trigger
        global di_2_event_trigger
        global di_3_event_trigger
        global di_4_event_trigger
        global di_5_event_trigger
        if os.path.isfile('plugins/k8055/k8055_p_'+str(b_nbr)):
            print "Reading K8055 configuration data from file..."
            f = open ('plugins/k8055/k8055_p_'+str(b_nbr), 'r')
            b_nbr = int(pickle.load(f))
            counter_1_threshold = int(pickle.load(f))
            counter_2_threshold = int(pickle.load(f))
            ai_1_event_trigger = int(pickle.load(f))
            ai_2_event_trigger = int(pickle.load(f))
            di_1_event_trigger = int(pickle.load(f))
            di_2_event_trigger = int(pickle.load(f))
            di_3_event_trigger = int(pickle.load(f))
            di_4_event_trigger = int(pickle.load(f))
            di_5_event_trigger = int(pickle.load(f))
            f.close()
        #Load the dll
        self.dll = None
        try:
            self.dll = windll.LoadLibrary("K8055D_C.dll")
        except: 
            raise eg.Exception("K8055 dll not found")
            print "K8055 dll is loaded"
        #Try to find the board...
        detect_board = self.dll.OpenDevice(b_nbr)
        if detect_board == -1:
            raise eg.Exception(
                "K8055 Board nbr: "+str(b_nbr)+" cannot be found"
                )
        else:
            print "K8055 Board nbr: "+str(b_nbr)+" is found"
            print "K8055 Board nbr: "+str(b_nbr)+" is started"
            self.dll.SetCurrentDevice(b_nbr)
            self.dll.ClearAllDigital()
            self.dll.ClearAllAnalog()
            self.stopThreadEvent = Event()
            thread = Thread(
                        target=self.ThreadWorker,
                        args=(self.stopThreadEvent,)
                        )
            thread.start()
   
        
    def __stop__(self):
        global b_nbr
        global counter_1_threshold
        global counter_2_threshold
        global ai_1_event_trigger
        global ai_2_event_trigger
        global di_1_event_trigger
        global di_2_event_trigger
        global di_3_event_trigger
        global di_4_event_trigger
        global di_5_event_trigger
        print "Writing K8055 configuration data to file..."
        f = open ('plugins/k8055/k8055_p_'+str(b_nbr), 'w')
        pickle.dump(str(b_nbr), f)
        pickle.dump(str(counter_1_threshold), f)
        pickle.dump(str(counter_2_threshold), f)
        pickle.dump(str(ai_1_event_trigger), f)
        pickle.dump(str(ai_2_event_trigger), f)
        pickle.dump(str(di_1_event_trigger), f)
        pickle.dump(str(di_2_event_trigger), f)
        pickle.dump(str(di_3_event_trigger), f)
        pickle.dump(str(di_4_event_trigger), f)
        pickle.dump(str(di_5_event_trigger), f)
        f.close()
        self.dll.CloseDevice()
        self.stopThreadEvent.set()
        print "K8055 Board nbr: "+str(b_nbr)+" is stopped"
    

    def __close__(self):
        self.dll.CloseDevice()
        print "K8055 Board nbr: "+str(b_nbr)+" is deleted"


    def ReadCounter(self, nbr, counter_limit):
            ret = self.dll.ReadCounter(nbr)
            if ret>counter_limit and ret < 255:
                self.TriggerEvent("Counter_"+str(nbr)+" Value: "+str(ret))
                self.dll.ResetCounter(nbr)


    def ReadAnalogIn(self, nbr, trig_level):
            global ai_1_event_memory
            global ai_2_event_memory
        
            ret = self.dll.ReadAnalogChannel(nbr)
            if ret>trig_level:
                if nbr == 1:
                    if ai_1_event_memory != ret:
                        self.TriggerEvent(
                            "Analog Channel IN_"+str(nbr)+" Value: "+str(ret)
                            )
                        ai_1_event_memory = ret
                if nbr == 2:
                    if ai_2_event_memory != ret:
                        self.TriggerEvent(
                            "Analog Channel IN_"+str(nbr)+" Value: "+str(ret)
                            )
                        ai_2_event_memory = ret
   
                
    def ReadDigitalIn(self, nbr, trig_level):
            global di_1_event_memory
            global di_2_event_memory
            global di_3_event_memory
            global di_4_event_memory
            global di_5_event_memory
            ret = self.dll.ReadDigitalChannel(nbr)
            if nbr == 1:
                if ret != trig_level:
                    if di_1_event_memory != ret:
                        self.TriggerEvent(
                            "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                            )
                        di_1_event_memory = ret
                if ret != di_1_event_memory:
                    di_1_event_memory = ret
                    self.TriggerEvent(
                        "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                        )
            if nbr == 2:
                if ret != trig_level:
                    if di_2_event_memory != ret:
                        self.TriggerEvent(
                            "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                            )
                        di_2_event_memory = ret
                if ret != di_2_event_memory:
                    di_2_event_memory = ret
                    self.TriggerEvent(
                        "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                        )
            if nbr == 3:
                if ret != trig_level:
                    if di_3_event_memory != ret:
                        self.TriggerEvent(
                            "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                        )
                        di_3_event_memory = ret
                if ret != di_3_event_memory:
                    di_3_event_memory = ret
                    self.TriggerEvent(
                        "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                        )
            if nbr == 4:
                if ret != trig_level:
                    if di_4_event_memory != ret:
                        self.TriggerEvent(
                            "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                            )
                        di_4_event_memory = ret
                if ret != di_4_event_memory:
                    di_4_event_memory = ret
                    self.TriggerEvent(
                        "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                        )
            if nbr == 5:
                if ret != trig_level:
                    if di_5_event_memory != ret:
                        self.TriggerEvent(
                            "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                            )
                        di_5_event_memory = ret
                if ret != di_5_event_memory:
                    di_5_event_memory = ret
                    self.TriggerEvent(
                            "Digital Channel IN_"+str(nbr)+" State: "+str(ret)
                            )


    def ThreadWorker(self, stopThreadEvent):
        global counter_1_threshold
        global counter_2_threshold
        global ai_1_event_trigger
        global ai_2_event_trigger
        global di_1_event_trigger
        global di_2_event_trigger
        global di_3_event_trigger
        global di_4_event_trigger
        global di_5_event_trigger
        while not stopThreadEvent.isSet():
            self.ReadCounter(1, counter_1_threshold)
            self.ReadCounter(2, counter_2_threshold)
            self.ReadAnalogIn(1, ai_1_event_trigger)
            self.ReadAnalogIn(2, ai_2_event_trigger)
            self.ReadDigitalIn(1,di_1_event_trigger)
            self.ReadDigitalIn(2,di_2_event_trigger)
            self.ReadDigitalIn(3,di_3_event_trigger)
            self.ReadDigitalIn(4,di_4_event_trigger)
            self.ReadDigitalIn(5,di_5_event_trigger)
            stopThreadEvent.wait(thread_wait)



class DeviceDO(object):

    #Digital outputs on the board, 8 in total
    def Configure(self, do = 1):
        panel = eg.ConfigPanel(self)
        digitalOut_ctrl = panel.Choice(
                                do,
                                choices=[
                                    '', '1', '2', '3', '4', '5', '6', '7', '8'
                                ]
                            )
        panel.AddLine("Digital Output Channel", digitalOut_ctrl)
        while panel.Affirmed():
            panel.SetResult(digitalOut_ctrl.GetValue())



class SetDigitalChannel(DeviceDO, eg.ActionClass):
    name = "Digital Channel OUT ON"
    description = "Turns on a digital channel on K8055"
    iconFile = "digital-out-on"


    def __call__(self, do):
        ret = self.plugin.dll.SetDigitalChannel(do)



class ClearDigitalChannel(DeviceDO, eg.ActionClass):
    name = "Digital Channel OUT OFF"
    description = "Turns off a digital channel on K8055"
    iconFile = "digital-out-off"


    def __call__(self, do):
        ret = self.plugin.dll.ClearDigitalChannel(do)



class DeviceAO_high(object):

    #Analog outputs on the port, 2 in total
    def Configure(self, ao = 1, av = 254):
        global nbr_list
        panel = eg.ConfigPanel(self)
        analogOut_ctrl = panel.Choice(ao, choices=['', '1', '2'])
        panel.AddLine("Analog Output Channel", analogOut_ctrl)
        analogOut_value = panel.Choice(av, choices=nbr_list)
        panel.AddLine("Analog value", analogOut_value)
        while panel.Affirmed():
            panel.SetResult(
                analogOut_ctrl.GetValue(),
                analogOut_value.GetValue()
            )



class SetAnalogChannel_High(DeviceAO_high, eg.ActionClass):
    name = "Analog Channel OUT HIGH"
    description = "Sets a value on an analog channel on K8055"
    iconFile = "analog-out-on"


    def __call__(self, ao, av):
        ret = self.plugin.dll.OutputAnalogChannel(ao, av)



class DeviceAO_low(object):

    #Analog outputs on the port, 2 in total
    def Configure(self, ao = 1, av = 128):
        global nbr_list
        panel = eg.ConfigPanel(self)
        analogOut_ctrl = panel.Choice(ao, choices=['', '1', '2'])
        panel.AddLine("Analog Output Channel", analogOut_ctrl)
        analogOut_value = panel.Choice(av, choices=nbr_list)
        panel.AddLine("Analog value", analogOut_value)
        while panel.Affirmed():
            panel.SetResult(
                analogOut_ctrl.GetValue(),
                analogOut_value.GetValue()
            )



class SetAnalogChannel_Low(DeviceAO_low, eg.ActionClass):
    name = "Analog Channel OUT LOW"
    description = "Sets a value on an analog channel on K8055"
    iconFile = "analog-out-on"


    def __call__(self, ao, av):
        ret = self.plugin.dll.OutputAnalogChannel(ao, av)



class ClearAnalogChannel(DeviceAO_low, eg.ActionClass):
    name = "Analog Channel OUT OFF"
    description = "Turns off an analog channel on K8055"
    iconFile = "analog-out-off"


    def __call__(self, ao, av):
        ret = self.plugin.dll.ClearAnalogChannel(ao)



class DeviceDI(object):

    #Digital inputs on the board, 5 in total
    def Configure(self, di = 1, el = 0):
        global di_1_event_trigger
        global di_2_event_trigger
        global di_3_event_trigger
        global di_4_event_trigger
        global di_5_event_trigger
        panel = eg.ConfigPanel(self)
        digitalIn_ctrl = panel.Choice(
                            di,
                            choices=['', '1', '2', '3', '4', '5']
                         )
        panel.AddLine("Digital Input Channel", digitalIn_ctrl)
        digital_level = panel.Choice(el, choices=['0', '1'])
        panel.AddLine("Value for event", digital_level)
        while panel.Affirmed():
            panel.SetResult(
                digitalIn_ctrl.GetValue(),
                digital_level.GetValue()
            )
            #Save event trigger levels
            param_1 = digitalIn_ctrl.GetValue()
            if param_1 == 1:
                di_1_event_trigger = digital_level.GetValue()
            elif param_1 == 2:
                di_2_event_trigger = digital_level.GetValue()
            elif param_1 == 2:
                di_3_event_trigger = digital_level.GetValue()
            elif param_1 == 2:
                di_4_event_trigger = digital_level.GetValue()
            elif param_1 == 2:
                di_5_event_trigger = digital_level.GetValue()



class ReadDigitalChannel(DeviceDI, eg.ActionClass):
    name = "Digital Channel IN"
    description = "A digital input channel on K8055"
    iconFile = "digital-in"


    def __call__(self, di, el):
        ret = self.plugin.dll.ReadDigitalChannel(di)
        print ret



class DeviceAI(object):

    #Analog inputs on the board, 2 in total
    def Configure(self, ai = 1, lv = 128):
        global nbr_list
        global ai_1_event_trigger
        global ai_2_event_trigger
        panel = eg.ConfigPanel(self)
        analogIn_ctrl = panel.Choice(ai, choices=['', '1', '2'])
        panel.AddLine("Analog Input Channel", analogIn_ctrl)
        value_limit = panel.Choice(lv, choices=nbr_list)
        panel.AddLine("Value limit", value_limit)
        while panel.Affirmed():
            panel.SetResult(
                analogIn_ctrl.GetValue(),
                value_limit.GetValue()
            )
            #Save event trigger levels
            param_1 = analogIn_ctrl.GetValue()
            if param_1 == 1:
                ai_1_event_trigger = value_limit.GetValue()
            elif param_1 == 2:
                ai_2_event_trigger = value_limit.GetValue()



class ReadAnalogChannel(DeviceAI, eg.ActionClass):
    name = "Analog Channel IN"
    description = "An analog input channel on K8055"
    iconFile = "analog-in"


    def __call__(self, ai, lv):
        ret = self.plugin.dll.ReadAnalogChannel(ai)
        print ret



class DeviceCT(object):

    #Counters on the board, 2 in total
    def Configure(self, ct = 1, ctl = 5, cdb = 2):
        global nbr_list
        global counter_1_threshold
        global counter_2_threshold
        panel = eg.ConfigPanel(self)
        counter_ctrl = panel.Choice(ct, choices=['', '1', '2'])
        panel.AddLine("Counter", counter_ctrl)
        counter_limit = panel.Choice(ctl, choices=nbr_list)
        panel.AddLine("Counter limit", counter_limit)
        ctr_debounce = panel.Choice(cdb, choices=['0', '2', '10', '1000'])
        panel.AddLine("Counter debounce (ms)", ctr_debounce)
        while panel.Affirmed():
            panel.SetResult(
                counter_ctrl.GetValue(),
                counter_limit.GetValue(),
                ctr_debounce.GetValue()
            )
            #Configure the debounce
            dbv = ctr_debounce.GetValue()
            param_1 = counter_ctrl.GetValue()
            param_2 = 0
            if dbv == 0:
                param_2 = 0
            elif dbv == 1:
                param_2 = 2
            elif dbv == 2:
                param_2 = 10
            elif dbv == 3:
                param_2 = 1000
            self.plugin.dll.SetCounterDebounceTime(param_1, param_2)
            #Save counter thresholds
            if param_1 == 1:
                counter_1_threshold = counter_limit.GetValue()
            elif param_1 == 2:
                counter_2_threshold = counter_limit.GetValue()



class Counter(DeviceCT, eg.ActionClass):
    name = "Counter"
    description = "Holds a counter in K8055"
    iconFile = "counter"


    def __call__(self, ct, ctl, cdb):
        ret = self.plugin.dll.ReadCounter(ct)
        print ret
 
        
        
class Info(eg.ActionClass):
    name = "Information"
    description = "Shows version information of the K8055-dll"
    iconFile = "info"


    def __call__(self):
        self.plugin.dll.Version()
        