#
# plugins/k8055/__init__.py
#
# Copyright (C) 2008
# Walter Kraembring
#
##############################################################################
# Revision history:
#
# 2008-03-09  Some further modifications and clean-up
# 2008-03-05  Now with support for multiple boards (0-3)
# 2008-03-01  The first stumbling version
##############################################################################

eg.RegisterPlugin(
    name = "K8055",
    author = "Walter Kraembring",
    version = "0.1.3",
    canMultiLoad = True,
    kind = "external",
    url = "http://www.velleman.be/ot/en/product/view/?id=351346",
    description = (
        '<p>Plugin to control Welleman K8055 VM110 USB Experiment Interface Board</p>'
        '\n\n<p><a href="http://www.velleman.be/ot/en/product/view/?id=351346">Product details...</a></p>'
        '<center><img src="k8055.png" /></center>'
    ),
)

import os, pickle, sys
from ctypes import windll, c_char_p
from threading import Event, Thread



class case_selector(Exception):
   def __init__(self, value):
      Exception.__init__(self, value)


def switch(variable):
   raise case_selector(variable)


def case(value):
   exclass, exobj, tb = sys.exc_info()
   if exclass is case_selector and exobj.args[0] == value: return exclass
   return None



class k8055(eg.PluginClass):

    def Configure(self, boardctrl = 0, thread_wait = 0.5):
        panel = eg.ConfigPanel(self)
        boardctrl = panel.SpinIntCtrl(boardctrl, 0, 3)
        boardctrl.SetInitialSize((40,-1))
        panel.AddLine("K8055 Board Number", boardctrl)
        thread_wait = panel.SpinNumCtrl(
                                thread_wait,
                                decimalChar = '.',
                                fractionWidth = 1,
                                integerWidth = 2,
                                min = 0.1
                                )
        thread_wait.SetInitialSize((60,-1))
        panel.AddLine("Thread wait time (x.y s)", thread_wait)
        while panel.Affirmed():
            panel.SetResult(
                    boardctrl.GetValue(),
                    thread_wait.GetValue()
                    )


    def __init__(self):
        self.AddAction(SetDigitalChannel)
        self.AddAction(ClearDigitalChannel)
        self.AddAction(SetAnalogChannel_Low)
        self.AddAction(SetAnalogChannel_High)
        self.AddAction(ClearAnalogChannel)
        self.AddAction(ReadDigitalChannel)
        self.AddAction(ReadAnalogChannel)
        self.AddAction(Counter)
        self.AddAction(Info)
        print "K8055 is initiated"
   
        
    def __start__(self, detect_board, thread_wait):
        self.counter_threshold = [5]*2
        self.ai_event_trigger = [128]*2
        self.di_event_trigger = [0]*5
        self.di_event_memory = [0]*5
        self.ai_event_memory = [0]*2
        self.b_nbr = detect_board
        self.thread_wait = thread_wait
        
        #Get persistent configuration data
        if not os.path.exists('k8055 data')and not os.path.isdir('k8055 data'):
            os.mkdir('k8055 data')
        if os.path.isfile('k8055 data/k8055_p_'+str(self.b_nbr)):
            print "Reading K8055 configuration data from file..."
            f = open ('k8055 data/k8055_p_'+str(self.b_nbr), 'r')
            self.counter_threshold = pickle.load(f)
            self.ai_event_trigger = pickle.load(f)
            self.di_event_trigger = pickle.load(f)
            f.close()
        
        #Load the dll
        self.dll = None
        try:
            self.dll = windll.LoadLibrary("K8055D_C.dll")
        except: 
            raise eg.Exception("K8055 dll not found")
            print "K8055 dll is loaded"
        
        #Try to find the board...
        detect_board = self.dll.OpenDevice(self.b_nbr)
        if detect_board == -1:
            raise eg.Exception(
                "K8055 Board nbr: "+str(self.b_nbr)+" cannot be found"
                )
        else:
            print "K8055 Board nbr: "+str(self.b_nbr)+" is found and started"
            self.stopThreadEvent = Event()
            thread = Thread(
                        target=self.ThreadWorker,
                        args=(self.stopThreadEvent,)
                        )
            thread.start()
   
        
    def __stop__(self):
        #Making configuration data persistent
        print "Writing K8055 configuration data to file..."
        f = open ('k8055 data/k8055_p_'+str(self.b_nbr), 'w')
        pickle.dump(self.counter_threshold, f)
        pickle.dump(self.ai_event_trigger, f)
        pickle.dump(self.di_event_trigger, f)
        f.close()
        self.dll.CloseDevice()
        self.stopThreadEvent.set()
        print "K8055 Board nbr: "+str(self.b_nbr)+" is stopped"
    

    def __close__(self):
        self.dll.CloseDevice()
        print "K8055 Board nbr: "+str(self.b_nbr)+" is deleted"


    def ReadCounter(self, b, nbr, counter_limit):
            self.dll.SetCurrentDevice(b)
            ret = self.dll.ReadCounter(nbr)
            if ret>counter_limit and ret < 255:
                self.TriggerEvent(" Counter:"+str(nbr)+" Value:"+str(ret))
                self.dll.ResetCounter(nbr)


    def ReadAnalogIn(self, b, nbr, trig_level):
            self.dll.SetCurrentDevice(b)
            ret = self.dll.ReadAnalogChannel(nbr)
            if ret>trig_level:
                for i in range (0, 2):
                    if nbr == i+1:
                        if self.ai_event_memory[i] != ret:
                            self.TriggerEvent(
                                " AI:"+str(nbr)+" Value:"+str(ret)
                                )
                            del self.ai_event_memory[i]
                            self.ai_event_memory.insert(i, ret)
   
                
    def ReadDigitalIn(self, b, nbr, trig_level):
            self.dll.SetCurrentDevice(b)
            ret = self.dll.ReadDigitalChannel(nbr)
            for i in range (0, 5):
                if nbr == i+1:
                    if ret != trig_level:
                        if self.di_event_memory[i] != ret:
                            self.TriggerEvent(
                                " DI:"+str(nbr)+" State:"+str(ret)
                                )
                            del self.di_event_memory[i]
                            self.di_event_memory.insert(i, ret)
                    if self.di_event_memory[i] != ret:
                        self.TriggerEvent(
                            " DI:"+str(nbr)+" State:"+str(ret)
                            )
                        del self.di_event_memory[i]
                        self.di_event_memory.insert(i, ret)


    def ThreadWorker(self, stopThreadEvent):
        while not stopThreadEvent.isSet():
            b = self.b_nbr
            for j in range(0, 2):
                self.ReadCounter(b, j+1, self.counter_threshold[j])
            for j in range(0, 2):
                self.ReadAnalogIn(b, j+1, self.ai_event_trigger[j])
            for j in range(0, 5):
                self.ReadDigitalIn(b, j+1, self.di_event_trigger[j])
                    
#            print b, self.counter_threshold
#            print b, self.ai_event_trigger
#            print b, self.di_event_trigger
#            print b, self.di_event_memory
#            print b, self.ai_event_memory

            stopThreadEvent.wait(self.thread_wait)


class DeviceDO(object):

    #Digital outputs on the board, 8 in total
    def Configure(self, b = 0, do = 1):
        panel = eg.ConfigPanel(self)
        board_n = self.plugin.b_nbr
        digitalOut_ctrl = panel.SpinIntCtrl(do, 1, 8)
        digitalOut_ctrl.SetInitialSize((40,-1))
        panel.AddLine("Digital Output Channel (1-8)", digitalOut_ctrl)
        while panel.Affirmed():
            panel.SetResult(
                board_n,
                digitalOut_ctrl.GetValue()
            )



class SetDigitalChannel(DeviceDO, eg.ActionClass):
    name = "Digital Channel OUT ON"
    description = "Turns on a digital channel on K8055"
    iconFile = "digital-out-on"

    def __call__(self, b, do):
        self.plugin.dll.SetCurrentDevice(b)
        ret = self.plugin.dll.SetDigitalChannel(do)



class ClearDigitalChannel(DeviceDO, eg.ActionClass):
    name = "Digital Channel OUT OFF"
    description = "Turns off a digital channel on K8055"
    iconFile = "digital-out-off"

    def __call__(self, b, do):
        self.plugin.dll.SetCurrentDevice(b)
        ret = self.plugin.dll.ClearDigitalChannel(do)



class DeviceAO_high(object):

    #Analog outputs on the board, 2 in total
    def Configure(self, b = 0, ao = 1, av = 254):
        panel = eg.ConfigPanel(self)
        board_n = self.plugin.b_nbr
        analogOut_ctrl = panel.SpinIntCtrl(ao, 1, 2)
        analogOut_ctrl.SetInitialSize((40,-1))
        panel.AddLine("Analog Output Channel (1-2)", analogOut_ctrl)
        analogOut_value = panel.SpinIntCtrl(av, 0, 254)
        analogOut_value.SetInitialSize((50,-1))
        panel.AddLine("Analog value (0-254)", analogOut_value)
        while panel.Affirmed():
            panel.SetResult(
                board_n,
                analogOut_ctrl.GetValue(),
                analogOut_value.GetValue()
            )



class SetAnalogChannel_High(DeviceAO_high, eg.ActionClass):
    name = "Analog Channel OUT HIGH"
    description = "Sets a value on an analog channel on K8055"
    iconFile = "analog-out-on"

    def __call__(self, b, ao, av):
        self.plugin.dll.SetCurrentDevice(b)
        ret = self.plugin.dll.OutputAnalogChannel(ao, av)



class DeviceAO_low(object):

    #Analog outputs on the board, 2 in total
    def Configure(self, b = 0, ao = 1, av = 128):
        panel = eg.ConfigPanel(self)
        board_n = self.plugin.b_nbr
        analogOut_ctrl = panel.SpinIntCtrl(ao, 1, 2)
        analogOut_ctrl.SetInitialSize((40,-1))
        panel.AddLine("Analog Output Channel (1-2)", analogOut_ctrl)
        analogOut_value = panel.SpinIntCtrl(av, 0, 254)
        analogOut_value.SetInitialSize((50,-1))
        panel.AddLine("Analog value (0-254)", analogOut_value)
        while panel.Affirmed():
            panel.SetResult(
                board_n,
                analogOut_ctrl.GetValue(),
                analogOut_value.GetValue()
            )



class SetAnalogChannel_Low(DeviceAO_low, eg.ActionClass):
    name = "Analog Channel OUT LOW"
    description = "Sets a value on an analog channel on K8055"
    iconFile = "analog-out-on"

    def __call__(self, b, ao, av):
        self.plugin.dll.SetCurrentDevice(b)
        ret = self.plugin.dll.OutputAnalogChannel(ao, av)



class ClearAnalogChannel(DeviceAO_low, eg.ActionClass):
    name = "Analog Channel OUT OFF"
    description = "Turns off an analog channel on K8055"
    iconFile = "analog-out-off"

    def __call__(self, b, ao, av):
        self.plugin.dll.SetCurrentDevice(b)
        ret = self.plugin.dll.ClearAnalogChannel(ao)



class DeviceDI(object):

    #Digital inputs on the board, 5 in total
    def Configure(self, b = 0, di = 1, el = 0):
        panel = eg.ConfigPanel(self)
        board_n = self.plugin.b_nbr
        digitalIn_ctrl = panel.SpinIntCtrl(di, 1, 5)
        digitalIn_ctrl.SetInitialSize((40,-1))
        panel.AddLine("Digital Input Channel (1-5)", digitalIn_ctrl)
        digital_level = panel.SpinIntCtrl(el, 0, 1)
        digital_level.SetInitialSize((40,-1))
        panel.AddLine("Value for event (0-1)", digital_level)
        while panel.Affirmed():
            panel.SetResult(
                board_n,
                digitalIn_ctrl.GetValue(),
                digital_level.GetValue()
            )
            #Save event trigger levels
            param_1 = digitalIn_ctrl.GetValue()
            for i in range(0, 5):
                if param_1 == i+1:
                    dl = digital_level.GetValue()
                    del self.plugin.di_event_trigger[i]
                    self.plugin.di_event_trigger.insert(i, dl)



class ReadDigitalChannel(DeviceDI, eg.ActionClass):
    name = "Digital Channel IN"
    description = "A digital input channel on K8055"
    iconFile = "digital-in"

    def __call__(self, b, di, el):
        self.plugin.dll.SetCurrentDevice(b)
        ret = self.plugin.dll.ReadDigitalChannel(di)
        print ret



class DeviceAI(object):

    #Analog inputs on the board, 2 in total
    def Configure(self, b = 0, ai = 1, lv = 128):
        panel = eg.ConfigPanel(self)
        board_n = self.plugin.b_nbr
        analogIn_ctrl = panel.SpinIntCtrl(ai, 1, 2)
        analogIn_ctrl.SetInitialSize((40,-1))
        panel.AddLine("Analog Input Channel (1-2)", analogIn_ctrl)
        value_limit = panel.SpinIntCtrl(lv, 0, 254)
        value_limit.SetInitialSize((50,-1))
        panel.AddLine("Value limit (0-254)", value_limit)
        while panel.Affirmed():
            panel.SetResult(
                board_n,
                analogIn_ctrl.GetValue(),
                value_limit.GetValue()
            )
            #Save event trigger levels
            param_1 = analogIn_ctrl.GetValue()
            for i in range(0, 2):
                if param_1 == i+1:
                    al = value_limit.GetValue()
                    del self.plugin.ai_event_trigger[i]
                    self.plugin.ai_event_trigger.insert(i, al)



class ReadAnalogChannel(DeviceAI, eg.ActionClass):
    name = "Analog Channel IN"
    description = "An analog input channel on K8055"
    iconFile = "analog-in"

    def __call__(self, b, ai, lv):
        self.plugin.dll.SetCurrentDevice(b)
        ret = self.plugin.dll.ReadAnalogChannel(ai)
        print ret



class DeviceCT(object):

    #Counters on the board, 2 in total
    def Configure(self, b = 0, ct = 1, ctl = 5, cdb = 2):
        panel = eg.ConfigPanel(self)
        board_n = self.plugin.b_nbr
        counter_ctrl = panel.SpinIntCtrl(ct, 1, 2)
        counter_ctrl.SetInitialSize((40,-1))
        panel.AddLine("Counter (1-2)", counter_ctrl)
        counter_limit = panel.SpinIntCtrl(ctl, 0, 254)
        counter_limit.SetInitialSize((50,-1))
        panel.AddLine("Counter limit (0-254)", counter_limit)
        ctr_debounce = panel.Choice(cdb, choices=['0', '2', '10', '1000'])
        panel.AddLine("Counter debounce (0, 2, 10, 1000 ms)", ctr_debounce)
        while panel.Affirmed():
            panel.SetResult(
                board_n,
                counter_ctrl.GetValue(),
                counter_limit.GetValue(),
                ctr_debounce.GetValue()
            )
            #Configure the debounce
            dbv = ctr_debounce.GetValue()
            param_1 = counter_ctrl.GetValue()
            param_2 = 0
            cl = counter_limit.GetValue()
            try:
                switch(dbv)
            except case(0):
                param_2 = 0
            except case(1):
                param_2 = 2
            except case(2):
                param_2 = 10
            except case(3):
                param_2 = 1000
            self.plugin.dll.SetCounterDebounceTime(param_1, param_2)
            #Save counter thresholds
            try:
                switch(param_1)
            except case(1):
                del self.plugin.counter_threshold[0]
                self.plugin.counter_threshold.insert(0, cl)
            except case(2):
                del self.plugin.counter_threshold[1]
                self.plugin.counter_threshold.insert(1, cl)



class Counter(DeviceCT, eg.ActionClass):
    name = "Counter"
    description = "Holds a counter in K8055"
    iconFile = "counter"

    def __call__(self, b, ct, ctl, cdb):
        self.plugin.dll.SetCurrentDevice(b)
        ret = self.plugin.dll.ReadCounter(ct)
        print ret
 
        
        
class Info(eg.ActionClass):
    name = "Information"
    description = "Shows version information of the K8055-dll"
    iconFile = "info"

    def __call__(self):
        self.plugin.dll.Version()
        