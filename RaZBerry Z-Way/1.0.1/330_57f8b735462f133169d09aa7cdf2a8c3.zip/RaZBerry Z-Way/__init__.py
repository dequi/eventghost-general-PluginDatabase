# -*- coding: utf-8 -*-
#
# This file is a plugin for EventGhost.
# Copyright (C) 2013 Walter Kraembring <krambriw>.
#
###############################################################################
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
#
# Acknowledgement: Part of code is originating from the broadcaster plugin
#
##############################################################################
# Revision history:
#
# 2013-07-01  Bug fix: initial configuration and startup did not work
# 2013-05-20  Supports the following Z-Wave classes and features:
#               - SwitchBinary (commands and events as callbacks)
#               - SwitchMultilevel (commands and events as callbacks)
#               - Sensor Multilevel (events as callbacks)
#               - Online/offline monitoring of AC powered switches and sensors
##############################################################################

eg.RegisterPlugin(
    name = "RaZBerry Z-Way",
    author = "krambriw",
    version = "1.0.1",
    kind = "other",
    canMultiLoad = True,
    url = "http://www.eventghost.org/forum",
    description = "RaZBerry Z-Way, control of devices in your Z-Wave network",
    guid = "{FC11ED2E-2623-4C66-A69F-D7D87CD73576}",
    help = """
        <a href="http://razberry.z-wave.me/index.php">Z-Wave on Raspberry</a>
        
        <center><img src="RaZBerry.png" /></center>
    """
)

import eg
import devices_in_state_memory
import os
import sys
import pickle
import httplib
import socket
import asyncore
from threading import Event, Thread



class Text:
    raZBerry_ip = "IP address of the RaZBerry"
    raZBerry_port = "IP port of the RaZBerry"
    eventPrefix = "Received event prefix:"
    b_port = "UDP port:"
    listenAddr = "UDP listening address:"
    delim = "Payload delimiter"
    delay_repeat = "Delay between repeated events (0.0-15.0 s)"
    message_1 = "Z-Way event listener started on"
    monitoring = 'The Z-Wave device seems not to be on-line'
    threadStopped = "Receiving thread is stopped..."
    hbStopped = "Heartbeat thread is stopped..."



class Server(asyncore.dispatcher):

    def __init__(
        self,
        port,
        listenAddr,
        payDelim,
        plugin
    ):
        self.plugin=plugin
        self.addresses = socket.gethostbyname_ex(socket.gethostname())[2]
        self.addresses.sort(key=lambda a: [int(b) for b in a.split('.', 4)])
        self.port=port
        self.payDelim=payDelim
        self.old_bits_collection = []
        self.old_devices_collection = {}

        if listenAddr in self.addresses:
            self.listenAddr = listenAddr
        else:
            addrs = socket.gethostbyname_ex(socket.gethostname())[2]
            self.listenAddr = addrs[0]
        
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_DGRAM)
        eg.RestartAsyncore()
        self.set_reuse_addr()
        self.bind((self.listenAddr, self.port))


    def handle_connect(self):
        print "%s %s:%s"  % (
            self.plugin.text.message_1,
            self.listenAddr,
            str(self.port)
        )
        pass


    def RemoveFromCollection(self, item):
        try:
            self.old_bits_collection.remove(item)
        except:
            pass


    def handle_read(self):
        data, addr = self.recvfrom(1024)
        # Check if the sending address is any of our interfaces
        my_addr = addr[0] in self.addresses

        if (not my_addr):
            if data.find('Device_')<>-1 and data.find('Instance_')<>-1:
                tr_e = False
                bits = data.split(str(self.payDelim))
                msg_base = bits[0].split('_')
                msg_addr = msg_base[1]+'_'+msg_base[3]
                msg_value = bits[1]
    
                if msg_addr not in self.plugin.device_state_memory:
                    if bits not in self.old_bits_collection:
                        self.old_bits_collection.append(bits)
                        #Schedule the event removal task
                        self.taskObj = eg.scheduler.AddTask(
                            self.plugin.delayRepeat,
                            self.RemoveFromCollection,
                            bits
                        )
                        commandSize=len(bits)
                        if commandSize==1:
                            self.plugin.TriggerEvent(bits[0])
                        if commandSize==2:
                            self.plugin.TriggerEvent(bits[0],bits[1])
                        if commandSize>2:
                            self.plugin.TriggerEvent(bits[0],bits[1:])  
                    else:
                        return
    
                if msg_addr in self.plugin.device_state_memory:
                    try:
                        if msg_value <> self.old_devices_collection[msg_addr]:
                            self.old_devices_collection[msg_addr] = msg_value
                            tr_e = True
                    except KeyError:
                        self.old_devices_collection[msg_addr] = msg_value
                        tr_e = True
                    if tr_e:
                        commandSize=len(bits)
                        if commandSize==1:
                            self.plugin.TriggerEvent(bits[0])
                        if commandSize==2:
                            self.plugin.TriggerEvent(bits[0],bits[1])
                        if commandSize>2:
                            self.plugin.TriggerEvent(bits[0],bits[1:])
            else:  
                print data


    def writable(self):
        return False  # we don't have anything to send !



class RaZBerry_Z_Way(eg.PluginBase):
    text = Text
    b_started = False

    def __init__(self):
        self.AddAction(SetSwitchPower)
        self.AddAction(SetDimming)
        self.AddAction(SensorMonitor)
        pass
        

    def __start__(
        self,
        ip,
        port,
        prefix,
        b_port,
        payDelim,
        listenAddr,
        delayRepeat
    ):
        self.zwave_devices = []
        self.device_state_memory = devices_in_state_memory.devices_supported()
        self.ip = ip
        self.port = port
        self.HTTP_API = ZWAY_HTTP_API(self.ip, self.port)
        self.info.eventPrefix = prefix
        self.b_port = b_port
        self.payDelim=payDelim
        self.listenAddr = listenAddr
        self.delayRepeat = delayRepeat
        b_started = True

        f = None
        progData = eg.configDir + '\plugins\Razberry'
        if (
            not os.path.exists(progData)
            and not os.path.isdir(progData)
        ):
            os.makedirs(progData)

        try:
            f = open (
                progData+'/'+'Razberry.txt', 'r'
            )
            self.zwave_devices = pickle.load(f)
            f.close()
        except IOError:
            f = open (
                progData+'/'+'Razberry.txt', 'w'
            )
            self.zwave_devices = []
            f.close()
       
        if self.zwave_devices == None:
            self.zwave_devices = []

        self.finished = Event()
        self.receiveThread = Thread(
            target=self.ReceiveThread,
            name="ZwayThread"
        )
        if not self.finished.isSet():
            self.receiveThread.start()

        self.hbThreadEvent = Event()
        self.hbThread = Thread(
            target=self.HeartbeatThread,
            name="hbThread"
        )
        if not self.hbThreadEvent.isSet():
            self.hbThread.start()


    def __stop__(self):
        self.finished.set()
        self.hbThreadEvent.set()
        self.b_started = False 

        f = None
        progData = eg.configDir + '\plugins\Razberry'
        if (
            not os.path.exists(progData)
            and not os.path.isdir(progData)
        ):
            os.makedirs(progData)

        f = open (
            progData+'/'+'Razberry.txt', 'w'
        )
        pickle.dump(self.zwave_devices, f)
        f.close()


    def __close__(self):
        pass            
       

    def ReceiveThread(self):
        try:
            self.server = Server(
                self.b_port,
                self.listenAddr,
                self.payDelim,
                self
            )
        except socket.error, exc:
            raise self.Exception(exc[1].decode(eg.systemEncoding))

        while not self.finished.isSet():
            self.finished.wait(0.2)

        print self.text.threadStopped
        if self.server:
            self.server.close()
        self.server = None


    def HeartbeatThread(self):
        while not self.hbThreadEvent.isSet():
            o_m_name = ''
            for deviceName in self.zwave_devices:
                found = False
                for m_name in eg.document.__dict__['root'].childs:
                    #print m_name.name
                    self.hbThreadEvent.wait(1.0)
                    if(
                        m_name.name.find(deviceName)!= -1
                    ):
                        found = True
                        if m_name.name <> o_m_name:
                            url = "/ZWaveAPI/Run/devices["
                            url += str(deviceName.split('|')[1])
                            url += "].data.isFailed.value"
                            response = self.HTTP_API.send(url)
                            #print m_name.name, deviceName, response
                            if str(response) <> 'false':
                                eg.TriggerEvent(
                                    str(deviceName)+
                                    '|'+
                                    self.text.monitoring
                                )
                                eg.PrintError(
                                    str(deviceName)+
                                    '|'+
                                    self.text.monitoring
                                )
                            o_m_name = m_name.name
                if not found:
                    self.zwave_devices.remove(deviceName)
            self.hbThreadEvent.wait(120.0)
        print self.text.hbStopped


    def Configure(
        self,
        ip="192.168.10.248",
        port="8083",
        prefix="ZWAY",
        b_port=33333,
        payDelim="&&",
        listenAddr="192.168.0.100",
        delayRepeat=0.3
    ):
        if self.b_started:
            self.__stop__()
        text = self.text
        panel = eg.ConfigPanel()
        textControl = panel.TextCtrl(ip)
        textControl2 = panel.TextCtrl(port)
        panel.AddLine(text.raZBerry_ip, textControl)
        panel.AddLine(text.raZBerry_port, textControl2)
        addrs = socket.gethostbyname_ex(socket.gethostname())[2]
        addrs.sort(key=lambda a: [int(b) for b in a.split('.', 4)])

        try:
            addr = addrs.index(listenAddr)
        except ValueError:
            addr = 0

        editCtrl = panel.TextCtrl(prefix)
        portCtrl = panel.SpinIntCtrl(b_port)        
        listenAddrCtrl = panel.Choice(addr, addrs)
        payDelimCtrl = panel.TextCtrl(payDelim)
        
        delayRepeatCtrl = panel.SpinNumCtrl(
            delayRepeat,
            decimalChar = '.',                 # by default, use '.' for decimal point
            groupChar = ',',                   # by default, use ',' for grouping
            fractionWidth = 1,
            integerWidth = 2,
            min = 0.0,
            max = 15.0,
            increment = 0.1
        )
        delayRepeatCtrl.SetValue(delayRepeat)

        panel.AddLine(text.eventPrefix, editCtrl)
        panel.AddLine(text.listenAddr, listenAddrCtrl)
        panel.AddLine(text.b_port, portCtrl)
        panel.AddLine(text.delim, payDelimCtrl)
        panel.AddLine(text.delay_repeat, delayRepeatCtrl)

        def OnOkButton(event): 
            event.Skip()
            self.OkButtonClicked = True
           
        panel.dialog.buttonRow.okButton.Bind(wx.EVT_BUTTON, OnOkButton)

        while panel.Affirmed():
            panel.SetResult(
                textControl.GetValue(),
                textControl2.GetValue(),
                editCtrl.GetValue(),
                portCtrl.GetValue(),
                payDelimCtrl.GetValue(),
                addrs[listenAddrCtrl.GetValue()],
                delayRepeatCtrl.GetValue(),
            )



class ZWAY_HTTP_API:

    def __init__(self, ip, port):
        self.address = ip+':'+port
        
    def send(self, requestString):
        response = None
        try:
            self.conn = httplib.HTTPConnection(self.address)
            self.conn.request('GET', requestString)
            res = self.conn.getresponse()
        except:
            print 'ERROR: __performGetRequest'
            res = None
        if res:
            if res.status == 200:
                response = res.read()
            else:
                print 'ERROR:', res.status, res.reason
        return response


        
class SetDimming(eg.ActionBase):

    class text:
        device_txt = "Set Device"
        instance_txt = "Set Instance"
        name_txt_dim = "Set Light Level"
        description_txt_dim = "Sets a light to a dim level"
        dim_txt_1 = "Dim to"
        dim_txt_2 = "level"


    name = text.name_txt_dim
    description = text.description_txt_dim


    def __call__(self, d_name, the_device, instance, level):
        url = "/ZWaveAPI/Run/devices["
        url += str(the_device)
        url += "].instances["
        url += str(instance)
        url += "].SwitchMultilevel.Set("
        url += str(level)
        url += ")"
        print url
        response = self.plugin.HTTP_API.send(url)


    def Configure(self, d_name='', the_device=5, instance=1, level=0):
        text = self.text
        panel = eg.ConfigPanel()
        deviceCtrl = panel.SpinIntCtrl(the_device)
        instanceCtrl = panel.SpinIntCtrl(instance)
        valueCtrl = panel.SpinIntCtrl(level, min=0, max=255)
        panel.AddLine(text.device_txt, deviceCtrl)
        panel.AddLine(text.instance_txt, instanceCtrl)
        panel.AddLine(text.dim_txt_1, valueCtrl, text.dim_txt_2)
        while panel.Affirmed():
            d_name = (
                'ZWAY|'+
                str(deviceCtrl.GetValue())
            )
            if d_name in self.plugin.zwave_devices:
                pass
            else:
                self.plugin.zwave_devices.append(d_name)

            panel.SetResult(
                d_name,
                deviceCtrl.GetValue(),
                instanceCtrl.GetValue(),
                valueCtrl.GetValue()
            )
        
        
class SetSwitchPower(eg.ActionBase):
    
    class text:
        device_txt = "Set Device"
        instance_txt = "Set Instance"
        name_txt_binary = "Set Binary Power"
        description_txt_binary = "Turn a switch on or off"
        value_txt = "Value"
        
        
    name = text.name_txt_binary
    description = text.description_txt_binary
    functionList = ["0", "255"]


    def __call__(self, d_name, the_device, instance, value):
        url = "/ZWaveAPI/Run/devices["
        url += str(the_device)
        url += "].instances["
        url += str(instance)
        url += "].SwitchBinary.Set("
        url += str(value)
        url += ")"
        response = self.plugin.HTTP_API.send(url)


    def Configure(self, d_name='', the_device=2, instance=1, value=0):
        text = self.text
        panel = eg.ConfigPanel()
        deviceCtrl = panel.SpinIntCtrl(the_device)
        instanceCtrl = panel.SpinIntCtrl(instance)
        functionCtrl = wx.Choice(panel, -1, choices=self.functionList)
        functionCtrl.SetSelection(value)
        panel.AddLine(text.device_txt, deviceCtrl)
        panel.AddLine(text.instance_txt, instanceCtrl)
        panel.AddLine(text.value_txt, functionCtrl)
        while panel.Affirmed():
            d_name = (
                'ZWAY|'+
                str(deviceCtrl.GetValue())
            )
            if d_name in self.plugin.zwave_devices:
                pass
            else:
                self.plugin.zwave_devices.append(d_name)

            panel.SetResult(
                d_name,
                deviceCtrl.GetValue(),
                instanceCtrl.GetValue(),
                functionCtrl.GetSelection()
            )



class SensorMonitor(eg.ActionBase):
    
    class text:
        device_txt = "Set Device"
        name_txt_sensor = "Monitor a sensor"
        description_txt_sensor = "Monitors if the sensor is online or not"
        
        
    name = text.name_txt_sensor
    description = text.description_txt_sensor


    def __call__(self, d_name, the_device):
        pass

    def Configure(self, d_name='', the_device=2):
        text = self.text
        panel = eg.ConfigPanel()
        deviceCtrl = panel.SpinIntCtrl(the_device)
        panel.AddLine(text.device_txt, deviceCtrl)
        while panel.Affirmed():
            d_name = (
                'ZWAY|'+
                str(deviceCtrl.GetValue())
            )
            if d_name in self.plugin.zwave_devices:
                pass
            else:
                self.plugin.zwave_devices.append(d_name)

            panel.SetResult(
                d_name,
                deviceCtrl.GetValue()
            )
