# Simple place holder for device states to be monitored 
# by the RaZBerry Z-Way plugin.
#
# States of devices listed below will be kept in memory.
# All other devices will not be monitored.
#
# Remove or add devices in the list below. Use the name as
# it is seen in incoming events. 

# Setting up the filtering:

# This is the default that will capture
# states of the listed devices(by default none):

def devices_supported():
    list = [
        "2_1"
    ]
    return list

# You have to enter devices with the device and
# instance id's like in the sample below.
# This filter would capture the state for listed
# devices and instancies:

#def sensors_supported():
#    list = [
#        "6_3",
#        "2_1"
#    ]
#    return list
#

