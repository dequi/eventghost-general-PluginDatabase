Copy Homeseer folder to /plugins folder inside the installation directory of EventGhost.
Restart EventGhost and add/configure plugin.

Have fun!