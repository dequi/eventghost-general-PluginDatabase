# this plugin triggers events on pressing the multimedia-control keys on your
# keyboard.
# these are: volume up, volume down, volume mute, play/pause, stop, next track,
# previous track
#
# It's very similar to the Keyboard-Plugin, but it doesn't use the
# eg.cFunction.SetKeyboardCallback, cause that doesn't react on the
# multimedia-keys. I use a Dll compiled in vc++ 2008 to provide the
# Hook-functions. A special *.pyd file surely would be better to do this job,
# but I'm not able to write one at the moment. (interopability is easier to do
# using python for now - easy interface ctypes is available)
# Also it uses an improved HasActiveHandler, that checks also for wildcards.

import eg

eg.RegisterPlugin(
    name="MMKeyHook",
    author="Marc A. W.",
    version="1.0.0.5",
    kind="remote",
    description = "Plugin for the Multimedia-Keys on your keyboard",
)


from ctypes import CFUNCTYPE,c_bool,c_uint8,POINTER
from os.path import abspath, join, dirname
from eg.WinApi.Dynamic import CDLL
from HAHEX import HasActiveHandlerEx
from threading import Thread, Event


HKFUNCTYPE=CFUNCTYPE(c_bool,c_uint8,c_bool)

KEYNAMES=[
    "Mute",
    "VolumeDown",
    "VolumeUp",
    "Next",
    "Previous",
    "Stop",
    "PlayPause"
]

class MMKeyHook(eg.PluginBase):
        
    def __init__(self):
        self.AddEvents()
        self.info.eventPrefix="MMKey"
        self.hklib=CDLL(abspath(join(dirname(__file__), "hkdll.dll")))
        self.HKFUNC=HKFUNCTYPE(self.HKCallback)
        
    def __start__(self):
        self.hklib.InstallHook(self.HKFUNC)

    def __stop__(self):
        self.hklib.RemoveHook()
        
    def HKCallback(self,keycode,release):
        if release:
            self.EndLastEvent()
        else:
            self.TriggerEnduringEvent(KEYNAMES[keycode])
        return HasActiveHandlerEx("MMKey."+KEYNAMES[keycode])
