# this is an improved Has Active Handler from core.py that also checks for
# wildcards
# Version 1.0.0.2

import eg

def HasActiveHandlerEx(eventstring):
    def HAH(eventstring):
        for eventHandler in eg.eventTable.get(eventstring, []):
            obj = eventHandler
            while obj:
                if not obj.isEnabled:
                    break
                obj = obj.parent
            else:
                return True
        return False
    
    eventstringc=eventstring
    eventstringc2=eventstring
    while True:
        if HAH(eventstring):
            return True
        eventstringc = eventstringc.rpartition('.')[0]
        if eventstringc is "":
            break
        eventstring = eventstringc + ".*"

    eventstring=eventstringc2
    while True:
        if HAH(eventstring):
            return True
        eventstring = eventstring.partition('.')[-1]
        if eventstringc is "":
            return False
        
