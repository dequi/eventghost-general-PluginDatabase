#include <windows.h>
#include <cstdio>
#include <time.h>

#define HK_SET 1
#define HK_RELEASE 2
#define END_THREAD -1
#define WM_UTHREAD WM_USER+1

HMODULE hDll=NULL;
HHOOK hHook=NULL;
HANDLE hHookThread=NULL;
DWORD ThreadComVar=0;
HANDLE hThreadEvent=NULL;
DWORD ThreadID=0;

typedef bool (*HookCallbackT)(BYTE,bool);
HookCallbackT HookCallback=NULL;
DWORD APIENTRY ThreadProc(PVOID lpParam);

bool APIENTRY DllMain(HINSTANCE hinstDll,DWORD fdwReason,LPVOID lpvReserved)
{
	switch (fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		hDll=hinstDll;
		if(hThreadEvent==NULL)hThreadEvent=CreateEvent(NULL,true,false,NULL);
		if(hHookThread!=NULL)break;
		hHookThread=CreateThread(NULL,0,ThreadProc,NULL,NULL,&ThreadID);
		break;
	case DLL_PROCESS_DETACH:
		if(hThreadEvent!=NULL)CloseHandle(hThreadEvent);
		if(hHookThread==NULL||ThreadID==0)break;
		PostThreadMessage(ThreadID,WM_UTHREAD,END_THREAD,NULL);
		WaitForSingleObject(hHookThread,INFINITE);
		CloseHandle(hHookThread);
	}
	return true;
}

LRESULT CALLBACK HookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if(nCode == HC_ACTION)
	{
		
		PKBDLLHOOKSTRUCT hs=(PKBDLLHOOKSTRUCT) lParam;
		if(hs->vkCode>=0xAD&&hs->vkCode<=0xB3)
		{
			if(HookCallback((BYTE)hs->vkCode-0xAD,(hs->flags&128)>>7?true:false))return 1;
		}
	}
	return CallNextHookEx(NULL,nCode,wParam,lParam);
}

extern "C" __declspec(dllexport) bool InstallHook(HookCallbackT HookCallback)
{
	if(::HookCallback!=NULL||HookCallback==NULL||hDll==0||hHook!=0||ThreadID==0)return false;
	::HookCallback=HookCallback;
	PostThreadMessage(ThreadID,WM_UTHREAD,HK_SET,NULL);
	WaitForSingleObject(hThreadEvent,INFINITE);
	return ThreadComVar?true:false;
}

extern "C" __declspec(dllexport) bool RemoveHook()
{
	if(hHook==0)return false;
	PostThreadMessage(ThreadID,WM_UTHREAD,HK_RELEASE,NULL);
	WaitForSingleObject(hThreadEvent,INFINITE);
	return ThreadComVar?true:false;
}


bool _InstallHook(void)
{
	if(hDll==0||hHook!=0)return false;
	hHook=SetWindowsHookEx(WH_KEYBOARD_LL,HookProc,hDll, NULL);
	return hHook==0?false:true;
}
bool _RemoveHook(void)
{
	if(hHook==0)return false;
	UnhookWindowsHookEx(hHook);
	hHook=0;
	return true;
}


DWORD APIENTRY ThreadProc(PVOID lpParam)
{
	MSG msg;
	while (true)
	{
		GetMessage(&msg,NULL,0,0);
		switch (msg.message)
		{
		case WM_QUIT:
			return 0;
		case WM_UTHREAD:
			switch (msg.wParam)
			{
			case HK_SET:
				ThreadComVar=_InstallHook();
				SetEvent(hThreadEvent);
				break;
			case HK_RELEASE:
				ThreadComVar=_RemoveHook();
				SetEvent(hThreadEvent);
				break;
			case END_THREAD:
				return 0;
			}
		}
	}
}