from comtypes.gen import _001000AF_1DEF_0010_10B6_DC5BA692C858_0_1_0
globals().update(_001000AF_1DEF_0010_10B6_DC5BA692C858_0_1_0.__dict__)
__name__ = 'comtypes.gen.ActiveHomeScriptLib'