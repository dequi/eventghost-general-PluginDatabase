typelib_path = u'C:\\Program Files\\Common Files\\X10\\Common\\ahscript.dll'
_lcid = 0 # change this if required
from ctypes import *
import comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0
from comtypes import GUID
from comtypes.automation import VARIANT
from ctypes import HRESULT
from comtypes import helpstring
from comtypes import COMMETHOD
from comtypes import dispid
from comtypes import DISPMETHOD, DISPPROPERTY, helpstring
from comtypes import CoClass
from comtypes.automation import IDispatch


class _IActiveHomeEvents(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IUnknown):
    _case_insensitive_ = True
    u'_IActiveHomeEvents Interface'
    _iid_ = GUID('{001000AF-3DEF-0912-10B6-DC5BA692C858}')
    _idlflags_ = []
_IActiveHomeEvents._methods_ = [
    COMMETHOD([helpstring(u'method RecvAction - Called when commands have been received')], HRESULT, 'RecvAction',
              ( ['in'], VARIANT, 'bszAction' ),
              ( ['in'], VARIANT, 'bszParm1' ),
              ( ['in'], VARIANT, 'bszParm2' ),
              ( ['in'], VARIANT, 'bszParm3' ),
              ( ['in'], VARIANT, 'bszParm4' ),
              ( ['in'], VARIANT, 'bszParm5' ),
              ( ['in'], VARIANT, 'bszReserved' )),
]
################################################################
## code template for _IActiveHomeEvents implementation
##class _IActiveHomeEvents_Impl(object):
##    def RecvAction(self, bszAction, bszParm1, bszParm2, bszParm3, bszParm4, bszParm5, bszReserved):
##        u'method RecvAction - Called when commands have been received'
##        #return 
##

class _DIActiveHomeEvents(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    '_DIActiveHomeEvents Interface'
    _iid_ = GUID('{001000AF-3DEF-0911-10B6-DC5BA692C858}')
    _idlflags_ = []
    _methods_ = []
_DIActiveHomeEvents._disp_methods_ = [
    DISPMETHOD([dispid(0), helpstring(u'method RecvAction - Called when commands have been received')], HRESULT, 'RecvAction',
               ( ['in'], VARIANT, 'bszAction' ),
               ( ['in'], VARIANT, 'bszParm1' ),
               ( ['in'], VARIANT, 'bszParm2' ),
               ( ['in'], VARIANT, 'bszParm3' ),
               ( ['in'], VARIANT, 'bszParm4' ),
               ( ['in'], VARIANT, 'bszParm5' ),
               ( ['in'], VARIANT, 'bszReserved' )),
]
class ActiveHome(CoClass):
    u'ActiveHome Class'
    _reg_clsid_ = GUID('{001000AF-2DEF-0208-10B6-DC5BA692C858}')
    _idlflags_ = []
    _typelib_path_ = typelib_path
    _reg_typelib_ = ('{001000AF-1DEF-0010-10B6-DC5BA692C858}', 1, 0)
class IActiveHome(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    u'IActiveHome Interface'
    _iid_ = GUID('{001000AF-3DEF-0910-10B6-DC5BA692C858}')
    _idlflags_ = ['nonextensible', 'dual', 'oleautomation']
ActiveHome._com_interfaces_ = [IActiveHome]
ActiveHome._outgoing_interfaces_ = [_DIActiveHomeEvents, _IActiveHomeEvents]

IActiveHome._methods_ = [
    COMMETHOD([dispid(0), helpstring(u'method SendAction - use to send commands')], HRESULT, 'SendAction',
              ( ['in'], VARIANT, 'bszAction' ),
              ( ['in', 'optional'], VARIANT, 'bstrParam', 0 ),
              ( ['in', 'optional'], VARIANT, 'vReserved1', 0 ),
              ( ['in', 'optional'], VARIANT, 'vReserved2', 0 ),
              ( ['retval', 'out'], POINTER(VARIANT), 'vReturn' )),
    COMMETHOD([dispid(1), 'propput'], HRESULT, 'OnRecvAction',
              ( ['in'], POINTER(IDispatch), 'rhs' )),
]
################################################################
## code template for IActiveHome implementation
##class IActiveHome_Impl(object):
##    def _set(self, rhs):
##        '-no docstring-'
##    OnRecvAction = property(fset = _set, doc = _set.__doc__)
##
##    def SendAction(self, bszAction, bstrParam, vReserved1, vReserved2):
##        u'method SendAction - use to send commands'
##        #return vReturn
##

class Library(object):
    u'ActiveHomeScript 1.0 Type Library'
    name = u'ActiveHomeScriptLib'
    _reg_typelib_ = ('{001000AF-1DEF-0010-10B6-DC5BA692C858}', 1, 0)

__all__ = ['IActiveHome', '_IActiveHomeEvents', '_DIActiveHomeEvents',
           'ActiveHome']
