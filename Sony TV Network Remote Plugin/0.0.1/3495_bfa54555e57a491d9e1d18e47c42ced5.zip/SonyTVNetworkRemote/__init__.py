import urllib2

# TV network connection info is below.  You MUST change this value to your TV's IP address.
# (Thus, you probably should configure the TV or your router so that the TV always receives the same IP address).
IP_ADDRESS = '192.168.100.15'

# The port number should (apparently) always be 80.
PORT = '80'

eg.RegisterPlugin(
    name = "Sony TV Network Remote Plugin",
    author = "Toby Gerenger",
    version = "0.0.1",
    kind = "external",
    description = "This plugin connects to the network control interface for certain Sony TVs."
)

class SonyTVNetworkPlugin(eg.PluginBase):
	def __init__(self):
		group1 = self.AddGroup("RemoteControl","Send commands as if pushing buttons on the remote control.")
		group1.AddActionsFromList(REMOTE_ACTIONS, TVRemoteAction)
		self.AddAction(SendCommand)
	
	def __start__(self):
		print("Started")

	def __close__(self):
		print("Closed")

class TVRemoteAction(eg.ActionClass):
	def __call__(self):
		SendIRCC(self.value)

class SendCommand(eg.ActionBase):
	name = "Send Command"
	description = "Sends an IRCC code to the TV."

	def __call__(self, commandString):
		SendIRCC(commandString)
		
	def Configure(self, commandString=""):
		panel = eg.ConfigPanel()
		textControl = wx.TextCtrl(panel, -1, commandString)
		panel.sizer.Add(textControl, 1, wx.EXPAND)
		while panel.Affirmed():
			panel.SetResult(textControl.GetValue())
		
def SendIRCC(commandString):
	ConnectionStrings = SOAPStrings
	try:
		conn=urllib2.Request('http://' + IP_ADDRESS + '/sony/IRCC', ConnectionStrings.contentStart + commandString + ConnectionStrings.contentEnd, ConnectionStrings.headers)
		urllib2.urlopen(conn, timeout=.5)
	except:
		print("Generic exception in SendIRCC.  Is the TV on?")
		
class SOAPStrings:
	headers = {
		'User-Agent': 'TVSideView/2.0.1 CFNetwork/672.0.8 Darwin/14.0.0',
		'Content-Type': 'text/xml; charset=UTF-8',
		'SOAPACTION': '"urn:schemas-sony-com:service:IRCC:1#X_SendIRCC"',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Host': IP_ADDRESS,
		'Connection': 'close',}

	contentStart = """<?xml version="1.0"?>
		<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
		<s:Body>
		<u:X_SendIRCC xmlns:u="urn:schemas-sony-com:service:IRCC:1">
		<IRCCCode>"""

	contentEnd = """</IRCCCode>
		</u:X_SendIRCC>
		</s:Body>
		</s:Envelope>"""
	
# The action list below consists of the following structure:
# ("class", "Command Name", "Command Description", "parameter"),
REMOTE_ACTIONS = (   
	("PowerOff","PowerOff","PowerOff","AAAAAQAAAAEAAAAvAw=="),
	("GGuide","GGuide","GGuide","AAAAAQAAAAEAAAAOAw=="),
	("EPG","EPG","EPG","AAAAAgAAAKQAAABbAw=="),
	("Favorites","Favorites","Favorites","AAAAAgAAAHcAAAB2Aw=="),
	("Display","Display","Display","AAAAAQAAAAEAAAA6Aw=="),
	("Home","Home","Home","AAAAAQAAAAEAAABgAw=="),
	("Options","Options","Options","AAAAAgAAAJcAAAA2Aw=="),
	("Return","Return","Return","AAAAAgAAAJcAAAAjAw=="),
	("Up","Up","Up","AAAAAQAAAAEAAAB0Aw=="),
	("Down","Down","Down","AAAAAQAAAAEAAAB1Aw=="),
	("Right","Right","Right","AAAAAQAAAAEAAAAzAw=="),
	("Left","Left","Left","AAAAAQAAAAEAAAA0Aw=="),
	("Confirm","Confirm","Confirm","AAAAAQAAAAEAAABlAw=="),
	("Red","Red","Red","AAAAAgAAAJcAAAAlAw=="),
	("Green","Green","Green","AAAAAgAAAJcAAAAmAw=="),
	("Yellow","Yellow","Yellow","AAAAAgAAAJcAAAAnAw=="),
	("Blue","Blue","Blue","AAAAAgAAAJcAAAAkAw=="),
	("Num1","Num1","Num1","AAAAAQAAAAEAAAAAAw=="),
	("Num2","Num2","Num2","AAAAAQAAAAEAAAABAw=="),
	("Num3","Num3","Num3","AAAAAQAAAAEAAAACAw=="),
	("Num4","Num4","Num4","AAAAAQAAAAEAAAADAw=="),
	("Num5","Num5","Num5","AAAAAQAAAAEAAAAEAw=="),
	("Num6","Num6","Num6","AAAAAQAAAAEAAAAFAw=="),
	("Num7","Num7","Num7","AAAAAQAAAAEAAAAGAw=="),
	("Num8","Num8","Num8","AAAAAQAAAAEAAAAHAw=="),
	("Num9","Num9","Num9","AAAAAQAAAAEAAAAIAw=="),
	("Num0","Num0","Num0","AAAAAQAAAAEAAAAJAw=="),
	("Num11","Num11","Num11","AAAAAQAAAAEAAAAKAw=="),
	("Num12","Num12","Num12","AAAAAQAAAAEAAAALAw=="),
	("VolumeUp","VolumeUp","VolumeUp","AAAAAQAAAAEAAAASAw=="),
	("VolumeDown","VolumeDown","VolumeDown","AAAAAQAAAAEAAAATAw=="),
	("Mute","Mute","Mute","AAAAAQAAAAEAAAAUAw=="),
	("ChannelUp","ChannelUp","ChannelUp","AAAAAQAAAAEAAAAQAw=="),
	("ChannelDown","ChannelDown","ChannelDown","AAAAAQAAAAEAAAARAw=="),
	("SubTitle","SubTitle","SubTitle","AAAAAgAAAJcAAAAoAw=="),
	("ClosedCaption","ClosedCaption","ClosedCaption","AAAAAgAAAKQAAAAQAw=="),
	("Enter","Enter","Enter","AAAAAQAAAAEAAAALAw=="),
	("DOT","DOT","DOT","AAAAAgAAAJcAAAAdAw=="),
	("Analog","Analog","Analog","AAAAAgAAAHcAAAANAw=="),
	("Teletext","Teletext","Teletext","AAAAAQAAAAEAAAA/Aw=="),
	("Exit","Exit","Exit","AAAAAQAAAAEAAABjAw=="),
	("Analog2","Analog2","Analog2","AAAAAQAAAAEAAAA4Aw=="),
	("*AD","*AD","*AD","AAAAAgAAABoAAAA7Aw=="),
	("Digital","Digital","Digital","AAAAAgAAAJcAAAAyAw=="),
	("Analog?","Analog?","Analog?","AAAAAgAAAJcAAAAuAw=="),
	("BS","BS","BS","AAAAAgAAAJcAAAAsAw=="),
	("CS","CS","CS","AAAAAgAAAJcAAAArAw=="),
	("BSCS","BSCS","BSCS","AAAAAgAAAJcAAAAQAw=="),
	("Ddata","Ddata","Ddata","AAAAAgAAAJcAAAAVAw=="),
	("PicOff","PicOff","PicOff","AAAAAQAAAAEAAAA+Aw=="),
	("Tv_Radio","Tv_Radio","Tv_Radio","AAAAAgAAABoAAABXAw=="),
	("Theater","Theater","Theater","AAAAAgAAAHcAAABgAw=="),
	("SEN","SEN","SEN","AAAAAgAAABoAAAB9Aw=="),
	("InternetWidgets","InternetWidgets","InternetWidgets","AAAAAgAAABoAAAB6Aw=="),
	("InternetVideo","InternetVideo","InternetVideo","AAAAAgAAABoAAAB5Aw=="),
	("Netflix","Netflix","Netflix","AAAAAgAAABoAAAB8Aw=="),
	("SceneSelect","SceneSelect","SceneSelect","AAAAAgAAABoAAAB4Aw=="),
	("Mode3D","Mode3D","Mode3D","AAAAAgAAAHcAAABNAw=="),
	("iManual","iManual","iManual","AAAAAgAAABoAAAB7Aw=="),
	("Audio","Audio","Audio","AAAAAQAAAAEAAAAXAw=="),
	("Wide","Wide","Wide","AAAAAgAAAKQAAAA9Aw=="),
	("Jump","Jump","Jump","AAAAAQAAAAEAAAA7Aw=="),
	("PAP","PAP","PAP","AAAAAgAAAKQAAAB3Aw=="),
	("MyEPG","MyEPG","MyEPG","AAAAAgAAAHcAAABrAw=="),
	("ProgramDescription","ProgramDescription","ProgramDescription","AAAAAgAAAJcAAAAWAw=="),
	("WriteChapter","WriteChapter","WriteChapter","AAAAAgAAAHcAAABsAw=="),
	("TrackID","TrackID","TrackID","AAAAAgAAABoAAAB+Aw=="),
	("TenKey","TenKey","TenKey","AAAAAgAAAJcAAAAMAw=="),
	("AppliCast","AppliCast","AppliCast","AAAAAgAAABoAAABvAw=="),
	("acTVila","acTVila","acTVila","AAAAAgAAABoAAAByAw=="),
	("DeleteVideo","DeleteVideo","DeleteVideo","AAAAAgAAAHcAAAAfAw=="),
	("PhotoFrame","PhotoFrame","PhotoFrame","AAAAAgAAABoAAABVAw=="),
	("TvPause","TvPause","TvPause","AAAAAgAAABoAAABnAw=="),
	("KeyPad","KeyPad","KeyPad","AAAAAgAAABoAAAB1Aw=="),
	("Media","Media","Media","AAAAAgAAAJcAAAA4Aw=="),
	("SyncMenu","SyncMenu","SyncMenu","AAAAAgAAABoAAABYAw=="),
	("Forward","Forward","Forward","AAAAAgAAAJcAAAAcAw=="),
	("Play","Play","Play","AAAAAgAAAJcAAAAaAw=="),
	("Rewind","Rewind","Rewind","AAAAAgAAAJcAAAAbAw=="),
	("Prev","Prev","Prev","AAAAAgAAAJcAAAA8Aw=="),
	("Stop","Stop","Stop","AAAAAgAAAJcAAAAYAw=="),
	("Next","Next","Next","AAAAAgAAAJcAAAA9Aw=="),
	("Rec","Rec","Rec","AAAAAgAAAJcAAAAgAw=="),
	("Pause","Pause","Pause","AAAAAgAAAJcAAAAZAw=="),
	("Eject","Eject","Eject","AAAAAgAAAJcAAABIAw=="),
	("FlashPlus","FlashPlus","FlashPlus","AAAAAgAAAJcAAAB4Aw=="),
	("FlashMinus","FlashMinus","FlashMinus","AAAAAgAAAJcAAAB5Aw=="),
	("TopMenu","TopMenu","TopMenu","AAAAAgAAABoAAABgAw=="),
	("PopUpMenu","PopUpMenu","PopUpMenu","AAAAAgAAABoAAABhAw=="),
	("RakurakuStart","RakurakuStart","RakurakuStart","AAAAAgAAAHcAAABqAw=="),
	("OneTouchTimeRec","OneTouchTimeRec","OneTouchTimeRec","AAAAAgAAABoAAABkAw=="),
	("OneTouchView","OneTouchView","OneTouchView","AAAAAgAAABoAAABlAw=="),
	("OneTouchRec","OneTouchRec","OneTouchRec","AAAAAgAAABoAAABiAw=="),
	("OneTouchStop","OneTouchStop","OneTouchStop","AAAAAgAAABoAAABjAw=="),
) 