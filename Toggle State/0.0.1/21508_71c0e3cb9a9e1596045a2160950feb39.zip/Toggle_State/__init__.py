import eg

eg.RegisterPlugin(
    name = "Toggle State",
    author = "Right.Hook@live.com",
    version = "0.0.1",
    kind = "other",
    description = "Toggle between true and false",
    canMultiLoad = True
)

class Toggle_State(eg.PluginBase):

    def __init__(self):
        self.state = False
        self.AddAction(Toggle)    #Toggle Between True / False
        self.AddAction(setToTrue)   # Set to True
        self.AddAction(setToFalse)   # Set to False
        self.AddAction(GetState)   # Set to False

    def __start__(self, state = False):
        self.state = state
        return state

    def Configure(self, state =  False):
        panel = eg.ConfigPanel(self)
        stateCtrl  = panel.Choice(state,["False","True"])
        panel.AddLine(u'Set initial state:', stateCtrl)

        while panel.Affirmed():
            panel.SetResult(bool(stateCtrl.GetValue()))

class Toggle(eg.ActionBase):
    name = "Toggle State"
    description = "Toggle State"

    def __call__(self):
        self.plugin.state = not self.plugin.state
        print self.plugin.state
        return self.plugin.state

class setToTrue(eg.ActionBase):
    name = "Set State To True"
    description = "Set State To True"
    def __call__(self):
        self.plugin.state = True
        print self.plugin.state

class setToFalse(eg.ActionBase):
    name = "Set State To False"
    description = "Set State To False"
    def __call__(self):
        self.plugin.state = False
        print self.plugin.state

            
class GetState(eg.ActionBase):
    name = "Get Current State"
    description = "Get Current State"
    def __call__(self):

        print self.plugin.state
        return self.plugin.state
