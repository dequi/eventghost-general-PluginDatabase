This is an alternate driver and plugin to use with some remote control receivers sold on ebay. They usually go for around $15 and include a usb ir receiver and remote. I'm not sure who the manufacturer is, but the usb vendor id is 06B4 and the product id is 1C70 (VID_06B4&PID_1C70). By default, no driver is required for the receiver as it uses the standard HID driver to emulate keyboard key presses and mouse movements. Unfortunately this makes it less than ideal for use with EventGhost as we don't want extraneous keyboard press and mouse movements.

Attached is an alternate driver, along with a EventGhost plugin that makes the receiver much more suitable for our needs. The alternate driver / plugin disables the standard processing and instead only sends events to EventGhost which is perfect for our needs.

To Install:

1) Start device manager, expand "Human Interface Devices" and locate an entry for "USB Human Interface Device".
2) Open it, and look in the "Details" tab, and look at the "Hardware Ids" property. Make sure it says "USB\VID_06B4&PID_1C70&REV_0200". The alternate driver is only designed to work with this particular model.
3) Go to the "Driver" tab, then click on "Update Driver"
4) Browse / Let me pick / Have Disk / point to the "driver" folder.
5) After you install the alternate driver, you should see a new entry under "Human Interface Devices" called "PC Remote Controller"
6) Install the EventGhost plugin, and you should be all set.

*DISCLAIMER* 

This works for me (tested under Vista). It may not work for you. Use at your own risk.