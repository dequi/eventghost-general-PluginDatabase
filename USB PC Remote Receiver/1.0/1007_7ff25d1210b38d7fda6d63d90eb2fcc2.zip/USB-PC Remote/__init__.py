eg.RegisterPlugin(
    name = "USB PC Remote Receiver",
    author = "srs",
    version = "1.0.",
    kind = "remote",
    description = 'Plugin for generic USB PC Remote Receiver.',
    help = """
        <center><img src="remote.jpg"/></center>
    """,
)


import os
import _winreg as reg
from threading import Timer
from msvcrt import get_osfhandle

from eg.WinApi.Dynamic import (
    WinDLL,
    byref,
    WinError,
    GetModuleHandle,
    CreateWindowEx,
    DestroyWindow,
    RegisterClass,
    UnregisterClass,
    LoadCursor,
    WNDCLASS,
    WNDPROC,
    WM_USER,
    WS_OVERLAPPEDWINDOW,
    CW_USEDEFAULT,
)


PLUGIN_DIR = os.path.abspath(os.path.split(__file__)[0])


class GenMessageReceiver(eg.ThreadWorker):
    """
    A thread with a hidden window to receive win32 messages from the driver
    """
    def Setup(self, plugin):
        """
        This will be called inside the thread at the beginning.
        """
        self.plugin = plugin
        
        wc = WNDCLASS()
        wc.hInstance = GetModuleHandle(None)
        wc.lpszClassName = "HiddenGenMessageReceiver"
        wc.lpfnWndProc = WNDPROC(self.MyWndProc)
        if not RegisterClass(byref(wc)):
            raise WinError()
        self.hwnd = CreateWindowEx(
            0,
            wc.lpszClassName,
            "Gen Remote Message Receiver",
            WS_OVERLAPPEDWINDOW,
            CW_USEDEFAULT, 
            CW_USEDEFAULT,
            CW_USEDEFAULT, 
            CW_USEDEFAULT,
            0, 
            0,
            wc.hInstance, 
            None
        )
        if not self.hwnd:
            raise WinError()
        self.wc = wc
        self.hinst = wc.hInstance
        
        self.dll = WinDLL(os.path.join(PLUGIN_DIR, "USB-PC-Remote.dll"))
        if not self.dll.Start(self.hwnd):
            raise self.plugin.Exceptions.DeviceNotFound
        
        
    @eg.LogIt
    def Finish(self):
        """
        This will be called inside the thread when it finishes. It will even
        be called if the thread exits through an exception.
        """
        self.dll.End()
        DestroyWindow(self.hwnd)
        UnregisterClass(self.wc.lpszClassName, self.hinst)
        self.Stop() # is this needed?
        
        
    #@eg.LogIt
    def MyWndProc(self, hwnd, mesg, wParam, lParam):
        if mesg == WM_USER:
            eventString = unicode(lParam)
            if wParam == 0:
                self.plugin.TriggerEnduringEvent(eventString)
            if wParam == 1:
                self.plugin.EndLastEvent()
            if wParam == 2:
                self.plugin.TriggerEvent(eventString)
        return 1



class MceRemote(eg.PluginClass):
    
    #def __init__(self):            
            
    @eg.LogIt
    def __start__(self):
        self.msgThread = GenMessageReceiver(self)
        self.msgThread.Start()          
                        
    def __stop__(self):
        self.msgThread.Stop()
        
