# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005-2009 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 as published by the
# Free Software Foundation;
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

r"""<rst>
Plugin for the Dell Premium Remote.

|

.. image:: picture.jpg
   :align: center
"""


import eg

eg.RegisterPlugin(
    name="Dell Premium Remote (WinUSB)",
    description=__doc__,
    url="",
    author="FoLLgoTT",
    version="1.0.0",
    kind="remote",
    hardwareId = "USB\\VID_0C16&PID_0002&REV_0220",
    guid="{6260b83e-45ba-4146-9151-48b79aa36eaa}",
)

from math import atan2, pi
from eg.WinApi.Dynamic import mouse_event
    

CODES = {
    (2, 181, 0, 0, 0, 0, 0, 0): ("NextTrack", 1),
    (2, 182, 0, 0, 0, 0, 0, 0): ("PreviousTrack", 1),
    (2, 180, 0, 0, 0, 0, 0, 0): ("Rewind", 1), 
    (2, 179, 0, 0, 0, 0, 0, 0): ("Forward", 1),
    (2, 176, 0, 0, 0, 0, 0, 0): ("Play", 0),
    (2, 178, 0, 0, 0, 0, 0, 0): ("Record", 0),
    (2, 183, 0, 0, 0, 0, 0, 0): ("Stop", 0),
    (2, 177, 0, 0, 0, 0, 0, 0): ("Pause", 0),
    (2, 36, 2, 0, 0, 0, 0, 0): ("Previous", 0),
    (2, 9, 2, 0, 0, 0, 0, 0): ("Information", 0),
    (2, 141, 0, 0, 0, 0, 0, 0): ("Playlist", 0),
    (1, 0, 0, 40, 0, 0, 0, 0): ("Ok", 0),
    (1, 0, 0, 82, 0, 0, 0, 0): ("Up", 1),
    (1, 0, 0, 81, 0, 0, 0, 0): ("Down", 1),
    (1, 0, 0, 80, 0, 0, 0, 0): ("Left", 1),
    (1, 0, 0, 79, 0, 0, 0, 0): ("Right", 1),
    (2, 233, 0, 0, 0, 0, 0, 0): ("VolumeUp", 1),
    (2, 234, 0, 0, 0, 0, 0, 0): ("VolumeDown", 1),
    (2, 156, 0, 0, 0, 0, 0, 0): ("ChannelUp", 1),
    (2, 157, 0, 0, 0, 0, 0, 0): ("ChannelDown", 1),
    (2, 226, 0, 0, 0, 0, 0, 0): ("Mute", 0),
    (1, 0, 0, 30, 0, 0, 0, 0): ("Num1", 0),
    (1, 0, 0, 31, 0, 0, 0, 0): ("Num2", 0),
    (1, 0, 0, 32, 0, 0, 0, 0): ("Num3", 0),
    (1, 0, 0, 33, 0, 0, 0, 0): ("Num4", 0),
    (1, 0, 0, 34, 0, 0, 0, 0): ("Num5", 0),
    (1, 0, 0, 35, 0, 0, 0, 0): ("Num6", 0),
    (1, 0, 0, 36, 0, 0, 0, 0): ("Num7", 0),
    (1, 0, 0, 37, 0, 0, 0, 0): ("Num8", 0),
    (1, 0, 0, 38, 0, 0, 0, 0): ("Num9", 0),
    (1, 0, 0, 39, 0, 0, 0, 0): ("Num0", 0),
    (1, 2, 0, 37, 0, 0, 0, 0): ("Asterisk", 0),
    (1, 2, 0, 32, 0, 0, 0, 0): ("Hash", 0),
    (1, 0, 0, 41, 0, 0, 0, 0): ("Clear", 0)
}

STOP_CODES = set([
    (1, 0, 0, 0, 0, 0, 0, 0),
    (2, 0, 0, 0, 0, 0, 0, 0)
])


class DellPremiumRemote(eg.PluginBase):

    def __start__(self):
        self.usb = eg.WinUsb(self)
        self.usb.AddDevice(
            "Dell Premium Remote (Buttons)",
            "USB\\VID_0C16&PID_0003&REV_0260&MI_00",
            "{6260b83e-45ba-4146-9151-48b79aa36eaa}",
            self.Callback,
            8
        )
        self.usb.Open()
        self.lastButton = None
        self.timer = eg.ResettableTimer(self.OnTimeOut)


    def __stop__(self):
        self.timer.Stop()
        self.usb.Close()


    def Callback(self, data):
        if data in CODES:
            code, type = CODES[data]
            if type:
               self.timer.Reset(175)
               if code != self.lastButton:
                   self.TriggerEnduringEvent(code)
            else:
               self.timer.Reset(None)
               self.TriggerEvent(code)
            self.lastButton = code
        elif data in STOP_CODES:
            self.timer.Reset(175)
        else:
            print data

    @eg.LogIt
    def OnTimeOut(self):
        self.lastButton = None
        self.EndLastEvent()
