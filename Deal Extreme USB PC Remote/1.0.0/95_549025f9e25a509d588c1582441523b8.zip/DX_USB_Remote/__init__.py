# This file is part of EventGhost.
# Copyright (C) 2008 Lars-Peter Voss <bitmonster@eventghost.org>
# 
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

ur"""<rst>
Plugin for the **Deal Extreme USB PC Remote**.

|

.. image:: DXusbPCR.jpg
   :align: center

You can choose, whether *Numlock* is ignored or not.
If ignored, numpad-keys will always send digits,
regardless of the state of *Numlock*.

**Notice:** You need a special driver to use the remote with this plugin. 
Please `download it here`__ and install it while the device is connected.

__ http://www.eventghost.org/downloads/USB-Remote-Driver.exe
"""

import eg

eg.RegisterPlugin(
    name = "Deal Extreme USB PC Remote",
    author = "Bitmonster & Pako",
    version = "1.0.0",
    kind = "remote",
    description = __doc__,
)

CODES = (
    ((263425,1967364,3802373,1,4,5,),(1,4,5), "Hotkey_A", "Hotkey_A"),
    ((328961,2032900,3867909,1,4,5,),(1,4,5), "Hotkey_B", "Hotkey_B"),
    ((394497,2098436,3933445,1,4,5,),(1,4,5), "Hotkey_C", "Hotkey_C"),
    ((460033,2163972,3998981,1,4,5,),(1,4,5), "Hotkey_D", "Hotkey_D"),
    ((33030,),(6,), "Power", "Power"),
    ((100867,3,),(3,), "E-mail", "E-mail"),
    ((140035,3,),(3,), "WWW", "WWW"),
    ((3998721,1,),(1,), "Close", "Close"),
    ((8194,),(2,), "MouseLeft", "MouseLeft"),
    ((16386,),(2,), "MouseRight", "MouseRight"),
    ((46595,3,),(3,), "|<", "|<"),
    ((52483,3,),(3,), "Play/Pause", "Play/Pause"),
    ((46339,3,),(3,), ">|", ">|"),
    ((51971,5242881,5243140,328453,),(3,1,4,5,), "<<", "<<"),
    ((46851,3,),(3,), "Stop", "Stop"),
    ((51715,5177345,5177604,590597,),(3,1,4,5,), ">>", ">>"),
    ((59651,),(3,), "Volume+", "Volume+"),
    ((59907,),(3,), "Volume-", "Volume-"),
    ((143363,2622465,2097409,3,1,1,),(3,1,1,), "Full Screen", "Full Screen"),
    ((4915201,),(1,), "Page+", "Page+"),
    ((5111809,),(1,), "Page-", "Page-"),
    ((57859,3,),(3,), "Mute", "Mute"),
    ((526337,1,),(1,), "MyPC", "MyPC"),
    ((2752513,),(1,), "Backspace", "Backspace"),
    ((1966081,),(1,), "Num1", "Num1"),
    ((2031617,),(1,), "Num2", "Num2"),
    ((2097153,),(1,), "Num3", "Num3"),
    ((2162689,),(1,), "Num4", "Num4"),
    ((2228225,),(1,), "Num5", "Num5"),
    ((2293761,),(1,), "Num6", "Num6"),
    ((2359297,),(1,), "Num7", "Num7"),
    ((2424833,),(1,), "Num8", "Num8"),
    ((2490369,),(1,), "Num9", "Num9"),
    ((2555905,),(1,), "Num0", "Num0"),
    ((2818049,),(1,), "Tab", "Num1"),
    ((5373953,),(1,), "Up_arrow", "Num2"),
    ((2049,1,),(1,), "Start", "Num3"),
    ((5242881,),(1,), "Left_arrow", "Num4"),
    ((2621441,),(1,), "Enter", "Num5"),
    ((5177345,),(1,), "Right_arrow", "Num6"),
    ((1179905,),(1,), "Open", "Num7"),
    ((5308417,),(1,), "Down_arrow", "Num8"),
    ((2686977,),(1,), "Escape", "Num9"),
    ((2819073,1,),(1,), "SwitchWindows", "Num0"),
    ((460801,1,),(1,), "Desktop", "Desktop"),
)
 
    
class Text:
    ignoreNumlock = "Ignore button Numlock"
    tooltip = """If this option is checked,
events from the Numpad-buttons of remote control
are always sent as a digits
(regardless of the state of Num Lock)."""
    
class DXusbPCR(eg.PluginBase):
    text = Text
                
    @eg.LogIt
    def __start__(self, ignoreNumLock):
        self.ignoreNumLock = ignoreNumLock
        self.status = 0
        self.tableIx = 0
        self.codesIx = 0
        self.usb = eg.WinUsbRemote(
            "{72679574-1865-499d-B182-4B099D6D1391}",
            self.Callback,
            4,
            False,
         )
        if not self.usb.IsOk():
            raise self.Exceptions.DeviceNotFound

         
    def __stop__(self):
        self.usb.Close()


#Status variable definition:
#---------------------------    
#Status 0 = idle
#Status 1 = receive key-down code
#Status 2 = (waiting for or) receive key-up code

    def Callback(self, data):
        value = (data[3] << 24) + (data[2] << 16) + (data[1] << 8) + data[0]
        if self.status == 0:
            if value in [item[0][0] for item in CODES]:
                self.tableIx = [item[0][0] for item in CODES].index(value)
                self.status = 1
            else: #flush
                return
        keyData = CODES[self.tableIx]
        if self.status == 1:        
            if value == keyData[0][self.codesIx]:
                self.codesIx += 1
                if self.codesIx == len(keyData[0]):
                    keyName = keyData[3] if self.ignoreNumLock else keyData[2]
                    self.TriggerEnduringEvent(keyName)
                    self.status = 2
                    self.codesIx = 0
            else: #flush
                self.status = 0
                self.codesIx = 0
        else: #self.status == 2
            try:
                if value == keyData[1][self.codesIx]:
                    self.codesIx += 1
                    if self.codesIx == len(keyData[1]):
                        self.EndLastEvent()
                        self.status = 0
                        self.codesIx = 0
                else: #flush
                    self.status = 0
                    self.codesIx = 0
            except:
                if value in [item[0][0] for item in CODES]:
                    self.tableIx = [item[0][0] for item in CODES].index(value)
                    #self.status = 1
                    keyData = CODES[self.tableIx]
                    if value == keyData[0][self.codesIx]:
                        self.codesIx += 1
                        if self.codesIx == len(keyData[0]):
                            keyName = keyData[3] if self.ignoreNumLock else keyData[2]
                            self.TriggerEnduringEvent(keyName)
                            self.status = 2
                            self.codesIx = 0
                    else: #flush
                        self.status = 0
                        self.codesIx = 0
                else:
                    self.status = 0
                    self.codesIx = 0
            
                
    def Configure(self, ignoreNumLock=False):
        panel = eg.ConfigPanel()
        ignoreNumLock = panel.CheckBox(ignoreNumLock, self.text.ignoreNumlock)
        toolTip = wx.ToolTip(self.text.tooltip)
        ignoreNumLock.SetToolTip(toolTip)
        #toolTip.SetDelay(10000)

        panel.AddLine(ignoreNumLock)

        while panel.Affirmed():
            panel.SetResult(
                ignoreNumLock.GetValue(),
            )
                