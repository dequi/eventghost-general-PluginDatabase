# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright (C) 2005 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
# This plugin stops eventghost from automatically jumping to the bottom of the log
# when a log entry is made while you are scrolled up in the log

import eg
import wx

eg.RegisterPlugin(
	name="EventGhost Log Scroll Lock",
	description="This plugin stops eventghost from automatically\n"
				"jumping to the bottom of the log when a log entry\n"
				"is made while you are scrolled up in the log.",
	author="K",
	version="0.5b",
	canMultiLoad=False,
	createMacrosOnAdd=False,
	kind="other",
	guid="{96D41CFB-E756-4412-AD1A-C0E46904CFC9}"
)


class ScrollLock(eg.PluginBase):

	def __init__(self):
		self.savedshowframe = eg.document.ShowFrame
		self.savedhideframe = eg.document.HideFrame

	def __start__(self):
		eg.document.ShowFrame = self.ShowFrame
		eg.document.HideFrame = self.HideFrame
		
		if eg.document.frame is not None and eg.document.frame.IsShown():
			self.savedwriteline = eg.document.frame.logCtrl.WriteLine
			self.savedsetdata = eg.document.frame.logCtrl.SetData
			eg.document.frame.logCtrl.WriteLine = self.WriteLine
			eg.document.frame.logCtrl.SetData = self.SetData
			
			eg.PrintNotice('LogScrollLock: Restarting EventGhost GUI')
			wx.CallAfter(self.HideFrame)
			eg.PrintNotice('LogScrollLock: Enabled')
			wx.CallAfter(self.ShowFrame)
		else:
			self.savedwriteline = None
			self.savedsetdata = None
			eg.PrintNotice('LogScrollLock: Enabled')

	def __stop__(self):
		if eg.document.frame is not None and eg.document.frame.IsShown():
			eg.PrintNotice('LogScrollLock: Restarting EventGhost GUI')
			wx.CallAfter(self.savedhideframe)
			
			eg.PrintNotice('LogScrollLock: Disabled')
			wx.CallAfter(self.savedshowframe)

		if self.savedwriteline is not None:
			try:
				eg.document.frame.logCtrl.WriteLine = self.savedwriteline
			except:
				pass
			self.savedwriteline = None
		if self.savedsetdata is not None:
			try:
				eg.document.frame.logCtrl.SetData = self.savedsetdata
			except:
				pass
			self.savedsetdata = None

		if self.savedshowframe is not None:
			try:
				eg.document.ShowFrame = self.savedshowframe
			except:
				pass

		if self.savedhideframe is not None:
			try:
				eg.document.HideFrame = self.savedhideframe
			except:
				pass

	def __close__(self):
		pass

	def ShowFrame(self):
		if eg.document.reentrantLock.acquire(False):
			if eg.document.frame is None:
				eg.document.frame = eg.MainFrame(eg.document)
				eg.document.frame.Show()
				eg.document.frame.statusBar.scrollCheckBox.Hide()
			eg.document.frame.Raise()
			eg.document.reentrantLock.release()

		if self.savedwriteline is None:
			self.savedwriteline = eg.document.frame.logCtrl.WriteLine
			eg.document.frame.logCtrl.WriteLine = self.WriteLine

		if self.savedsetdata is None:
			self.savedsetdata = eg.document.frame.logCtrl.SetData
			eg.document.frame.logCtrl.SetData = self.SetData

	def HideFrame(self):
		if eg.document.reentrantLock.acquire(False):
			if eg.document.frame is not None:
				if len(eg.document.frame.openDialogs) == 0:
					eg.document.frame.Destroy()
					eg.document.frame = None
			eg.document.reentrantLock.release()
			self.savedwriteline = None
			self.savedsetdata = None
		else:
			wx.CallLater(100, self.HideFrame)

	def SetData(self, data):
		logctrl = eg.document.frame.logCtrl
		# self.Freeze()
		logctrl.data = logctrl.collections.deque(data)
		logctrl.SetItemCount(len(data))
		# self.Thaw()
		self.SetLogPosition(logctrl)
		#logctrl.ScrollList(0, 1000000)

	def SetLogPosition(self, logctrl):
		listtotal = logctrl.GetItemCount()
		listtop = logctrl.GetTopItem()
		listpp = logctrl.GetCountPerPage()
		listbottom = min(listtop + listpp, listtotal - 1)
		if (listbottom-listtotal)+1 == 0:
			logctrl.ScrollList(0, 1000000)
		else:
			logctrl.EnsureVisible((listbottom - 1))

	def WriteLine(self, line, icon, wRef, when, indent):
		logctrl = eg.document.frame.logCtrl
		data = logctrl.data
		if len(data) >= logctrl.maxlength:
			logctrl.Freeze()
			for _ in range(logctrl.removeOnMax):
				logctrl.DeleteItem(0)
				data.popleft()
			logctrl.Thaw()
		data.append((line, icon, wRef, when, indent))
		logctrl.SetItemCount(len(data))
		if eg.config.scrollLog:
			self.SetLogPosition(logctrl)
			#logctrl.ScrollList(0, 1000000)
		logctrl.Update()
