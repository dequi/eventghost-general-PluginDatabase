# This file is part of EventGhost.
# Copyright (C) 2005 Lars-Peter Voss <bitmonster@eventghost.org>
#
# EventGhost is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# EventGhost is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with EventGhost; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#

import eg
import wx
import thread
import xmlrpclib
import socket
#import traceback
from SimpleXMLRPCServer import SimpleXMLRPCServer

eg.RegisterPlugin(
    name = "Emesene",
    version = "0.1",
    author = "topix",
    kind = "program",
    description = (
        "Sends Instant-Messages through Emesene."
    ),
    # icon = (    ),
)

DEFAULT_PORT_SVR = 54095
DEFAULT_PORT_CLT = 54096
DEFAULT_PREFIX = "IM"

class Text:
    port_svr = "Server Port:"
    port_clt = "Client Port:"
    portBox = "Ports"
    buddyBox = "Buddies"
    buddy = "Recipient(s):"
    message = "Message:"
    prefix = "Event prefix:"
    failure = "Failure"
    msnNoConnection = "Could not connect to Emesene!"
    class GetBuddies:
        name = "Get Buddies"
        description = "Get a list with all buddies."
    class SendMsg:
        name = "Send Message"
        description = "Send a message to one or more buddies."

class Emesene(eg.PluginBase):
    canMultiLoad = False
    text = Text

    def __init__(self):
        self.AddAction(SendMsg)
        self.AddAction(GetBuddies)

    def __start__(self, port_svr, port_clt, prefix):
        self.info.eventPrefix = DEFAULT_PREFIX
        self.im_client = xmlrpclib.ServerProxy(("http://localhost:%d" % port_clt))

        self.im_server = SimpleXMLRPCServer(("localhost", port_svr), logRequests=False, allow_none=True)
        self.im_server.register_function(self.GenerateEvent)
        thread.start_new_thread(self.runServer, ('',) )
        try:
            self.buddies = self.im_client.GetBuddies()
        except socket.error, err:
            self.buddies = []
            self.PrintError((self.name + "-Plugin: " + self.text.msnNoConnection))
            
    def __stop__(self):
        if self.im_server != None:
            #self.im_server.shutdown()
            self.im_server = None

    def __close__(self):
        if self.im_server != None:
            #self.im_server.shutdown()
            self.im_server = None
        
    def runServer(self, b):
        self.im_server.serve_forever()

    def Configure(self, port_svr=DEFAULT_PORT_SVR, port_clt=DEFAULT_PORT_CLT, prefix=DEFAULT_PREFIX):
        text = self.text
        panel = eg.ConfigPanel(self)

        portCtrl1 = panel.SpinIntCtrl(port_svr, max=65535)
        portCtrl2 = panel.SpinIntCtrl(port_clt, max=65535)
        prefixCtrl = panel.TextCtrl(prefix)

        st1 = panel.StaticText(text.port_svr)
        st2 = panel.StaticText(text.port_clt)
        st3 = panel.StaticText(text.prefix)
        eg.EqualizeWidths((st1, st2, st3))
        box1 = panel.BoxedGroup(text.portBox,
            (st1, portCtrl1),
            (st2, portCtrl2),
        )
        box2 = panel.BoxedGroup("", (st3, prefixCtrl))
        panel.sizer.AddMany([
            (box1, 0, wx.EXPAND),
            (box2, 0, wx.EXPAND|wx.TOP, 10),
        ])

        while panel.Affirmed():
            panel.SetResult(
                portCtrl1.GetValue(),
                portCtrl2.GetValue(),
                prefixCtrl.GetValue()
            )
    
    def GenerateEvent(self, prefix=DEFAULT_PREFIX, suffix="Emesene", payload=None):
        ''' GenerateEvent(prefix, suffix, payload) '''
        self.info.eventPrefix = prefix
        self.TriggerEvent(suffix, payload)

class GetBuddies(eg.ActionClass):
    ''' get a list with buddies '''
    def __call__(self):
        return self.plugin.buddies
                   
class SendMsg(eg.ActionClass):
    ''' send a message '''
    def __call__(self, im_to, im_msg):
        for i in im_to:
            self.plugin.im_client.SendMsg(self.plugin.buddies[i], im_msg)
        
    def Configure(self, im_to=[], im_msg=""):
        panel = eg.ConfigPanel(self)
        
        hbox = wx.BoxSizer(wx.HORIZONTAL)
        buddyCtrl = wx.ListBox(panel, choices=self.plugin.buddies, style=wx.LB_MULTIPLE)
        msgCtrl = wx.TextCtrl(panel, value=im_msg, style=wx.TE_MULTILINE)
        hbox.Add(buddyCtrl, 1, wx.EXPAND)
        hbox.Add(msgCtrl, 1, wx.EXPAND)
        panel.sizer.Add(hbox, 1, wx.EXPAND)

        if len(self.plugin.buddies) >= len(im_to):
            for i in im_to:
                buddyCtrl.Select(i)
        
        while panel.Affirmed():
            panel.SetResult(
                buddyCtrl.GetSelections(),
                msgCtrl.GetValue()
            )
            
            