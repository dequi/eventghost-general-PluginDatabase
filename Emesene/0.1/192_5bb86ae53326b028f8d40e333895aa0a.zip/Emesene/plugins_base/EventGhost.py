#   This file is part of emesene.
#
#    EventGhost plugin is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    EventGhost plugin is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with emesene; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#   EventGhost is Copyright (C) 2005 Lars-Peter Voss <bitmonster@eventghost.org>


VERSION = '0.1'
import Plugin
import thread 
import xmlrpclib
from SimpleXMLRPCServer import SimpleXMLRPCServer

class Text:
    # used for Translating
    port_svr = "Server Port:"
    port_svr_hlp = "Set the port corresponding to the server port in EventGhost."
    port_clt = "Client Port:"
    port_clt_hlp = "Set the port corresponding to the client port in EventGhost."
    prefix = "Event prefix:"
    prefix_hlp = "This will be used as first part of events in EventGhost (event = prefix.suffix)"

class MainClass(Plugin.Plugin):
    '''Main plugin class'''
    
    description = _('Send messages from EventGhost and use messages as events in EventGhost')
    authors = { 'topix' : 'topix'}
    website = 'emesene.org'
    displayName = _('EventGhost')
    name = 'EventGhost'
    
    text = Text
    
    def __init__(self, controller, msn):
        ''' Contructor '''
        Plugin.Plugin.__init__(self, controller, msn)
        self.description = _('Send messages from EventGhost and use messages as events in EventGhost')
        self.authors = { 'topix' : 'topix'}
        self.website = 'emesene.org'
        self.displayName = _('EventGhost')
        self.name = 'EventGhost'
        self.controller = controller
        self.conversationManager = self.controller.conversationManager
        self.port_svr = 54096
        self.port_clt = 54095
        self.prefix = "IM"
        self.config = controller.config
        self.config.readPluginConfig(self.name)

    def start(self):
        ''' start the plugin and get the things rollin' '''
        # register slash commands in Emesene
        self.controller.Slash.register('eg', self.eg_event,_('Generate an event in EventGhost\nUsage: /eg event[ ~ payload]'))

        # register with some signals from Emesene
        self.newConversationWindowId = self.conversationManager.connect('new-conversation-ui', self.eventOnNewConversationWindow)
        self.closeConversationWindowId = self.conversationManager.connect('close-conversation-ui', self.eventOnConversationWindowClose)
        self.sendMessageId = self.conversationManager.connect('send-message', self.eventOnSendMessage)
        self.receiveMessageId = self.conversationManager.connect('receive-message', self.eventOnReceiveMessage)
        # more signals:
        # 'avatar-changed'
        # 'preferences-changed'
        # 'user-list-change'
        # 'message-received'
        # 'connection-problem'
        # 'disconnected'
        # 'connection-closed'
        # 'status-change'
        # 'personal-message-changed'
        # 'user-disconnected'
        # 'logout'
        # 'self-nick-changed'
        # 'self-status-changed'
        # 'self-personal-message-changed'
        # 'new-conversation'
        # 'new-switchboard'
        # 'new-mail-notification'
        # 'nick-changed'
        # 'contact-status-change'
        # 'offline-message-waiting'
        # 'offline-message-received'
        # 'display-picture-changed'
        # 'custom-emoticon-transfered'
        # 'login-successful'
        # 'switchboard'
        # 'message-sent'
        # 'user-join'
        # 'user-leave'
        # 'status-change'
        # --------------------------

        # get plugin config
        self.port_svr = int(self.config.getPluginValue( self.name, 'port_svr', 54096 ))
        self.port_clt = int(self.config.getPluginValue( self.name, 'port_clt', 54095 ))
        self.use_conversation = None

        # let's go
        self.startServer()
        self.enabled = True


    def startServer(self):
        # create XML-RPC server & client
        self.im_server = SimpleXMLRPCServer(("localhost", self.port_svr), logRequests=False, allow_none=True)
        self.im_client = xmlrpclib.ServerProxy(("http://localhost:%d" %  self.port_clt))

        # register XML-RPC functions
        self.im_server.register_function(self.SendMsg)
        self.im_server.register_function(self.GetAccounts)
        self.im_server.register_function(self.GetBuddies)
        self.im_server.register_function(self.GetBuddiesStatus)
        self.im_server.register_function(self.GetBuddiesOnline)
        self.im_server.register_function(self.GetStatus)

        # start the server with helper function (see below)
        thread.start_new_thread(self.runServer, ('',) )

    def stop(self):
        ''' stop the plugin and clean up '''
        self.enabled = False
        self.conversationManager.disconnect(self.newConversationWindowId)
        self.conversationManager.disconnect(self.closeConversationWindowId)
        self.conversationManager.disconnect(self.sendMessageId)
        self.conversationManager.disconnect(self.receiveMessageId)
        self.controller.Slash.unregister('eg_event')
        self.use_conversation = None
        self.stopServer()

    def stopServer(self):
        if self.im_server != None:
            #self.im_server.shutdown()
            self.im_server = None

    def check(self):
        ''' hmm, what should I do here ??? '''
        return (True, 'Ok')

    def configure(self):
        conf = []
        conf.append( Plugin.Option( 'port_svr', int, self.text.port_svr, self.text.port_svr_hlp, self.config.getPluginValue( self.name, 'port_svr', self.port_svr )) )
        conf.append( Plugin.Option( 'port_clt', int, self.text.port_clt, self.text.port_clt_hlp, self.config.getPluginValue( self.name, 'port_clt', self.port_clt )) )
        conf.append( Plugin.Option( 'prefix', str, self.text.prefix, self.text.prefix_hlp, self.config.getPluginValue( self.name, 'pass', self.prefix )) )
        configWindow = Plugin.ConfigWindow( 'EventGhost', conf )

        response = configWindow.run()
        if response != None:
            self.stopServer()
            if response.has_key( 'port_svr' ):
                self.port_svr =  response[ 'port_svr' ].value
                self.config.setPluginValue( self.name, 'port_svr', self.port_svr )
            if response.has_key( 'port_clt' ):
                self.port_clt =  response[ 'port_clt' ].value
                self.config.setPluginValue( self.name, 'port_clt', self.port_clt )
            if response.has_key( 'prefix' ):
                self.prefix = response[ 'prefix' ].value
                self.config.setPluginValue( self.name, 'prefix', self.prefix )
            self.startServer()

    def runServer(self, b):
        # helper function,  because "thread.start_new_thread(self.im_server.serve_forever(), ('',) )" seems not to work
        self.im_server.serve_forever()

    def eg_event(self, slash_action):
        event = slash_action.params
        suffix, d, payload = event.partition('~')
        try:
            self.im_client.GenerateEvent(self.prefix, suffix.strip(), payload.strip())
        except:
            pass

    def SendMsg(self, im_to, im_msg):
        ''' Sends the Message to the recipient '''
        switchboard = self.controller.msn.newSwitchboard()
        onl = self.controller.contacts.get_online_list()
        off = True
        for i in onl:
            if (i.account).upper() == im_to.upper():
                off = False
        if off == False:
            switchboard.invite(im_to)
            switchboard.sendMessage(im_msg)
        else:
           switchboard.msn.msnOIM.send(im_to, im_msg)
          
        switchboard.leaveChat()
        self.controller.msn.removeClosedSwitchboards()

    def GetAccounts(self):
        ''' Returns a list with registered accounts '''
        pass
        
    def GetBuddies(self):
        ''' Returns a list with the buddies '''
        ul = (self.controller.contacts.contacts).keys()
        return ul
        
    def GetBuddiesStatus(self, account):
        ''' Returns a list with the buddies and his/her online status for the given account '''
        pass
    
    def GetBuddiesOnline(self):
        ''' Returns a list with online buddies '''
        pass
        
    def GetStatus(self):
        ''' Returns the own current status '''
        # return onlineStatus, usedAccount, usedNick, availableAccounts
        pass

    def eventOnNewConversationWindow(self, conversationmanager, conversation, win):
        ''' Send an event when a new conversation starts '''
        self.use_conversation = conversation
        self.use_conversationmanager = conversationmanager
        try:
            self.im_client.GenerateEvent(self.prefix ,"NewConversationWindow", conversation.title)
        except:
            pass

    def eventOnConversationWindowClose(self, conversationManager, conversation, win):
        '''Send an event when a conversation is closed '''
        self.use_conversation = None
        self.use_conversationmanager = None
        try:
            self.im_client.GenerateEvent(self.prefix,"ConversationWindowClosed", conversation.title)
        except:
            pass

    def eventOnSendMessage(self, conversationManager, conversation, message):
        ''' when a message is send, send an event to EventhGost (payload = message) '''
        try:
            self.im_client.GenerateEvent(self.prefix,"MessageSend", message)
        except:
            pass

    def eventOnReceiveMessage(self, conersationManager, conversation, from_account, from_nick, message, font_format, charset):
        ''' if we receive a message, first check, if it is a special eg-command. In this case send the special event,
            otherwise send "MessageReceived" event with the message as payload '''
        if message[:3].upper() == "\EG":
            suffix, d, payload = message[4:].partition('~')
            try:
                self.im_client.GenerateEvent(self.prefix, suffix.strip(), payload.strip())
            except:
                pass
        else:
            try:
                self.im_client.GenerateEvent(self.prefix, "MessageReceived", (from_account, from_nick, charset, message))
            except:
                pass

