
eg.RegisterPlugin(
    name = "SunTracker",
    author = "Walter Kraembring",
    version = "1.1.3",
    description = (
        "Triggers an event at sunset/sunrise and configurable dates & times"
        '<br\n><br\n>'
        '<center><img src="suntracker_plugin.png" /></center>'
    ),
    url = "http://www.eventghost.org/forumThread",
)

##############################################################################
# Revision history:
#
# 2009-05-22  Introduced eg.global variable to indicate if sun is up or down
# 2009-04-16  Fix for logging in Vista (/ProgramData/EventGhost/Log)
# 2009-03-19  Fix for SpinNumCtrl, many thanks to jinxdone
# 2009-02-22  Moving Ghost settings moved back to the action settings ;) 
# 2009-01-26  Re-designed, moved some action variables to common plugin
#             variables with configuration settings in the plugin dialog
#             Changed the behaviour of buttons in action and plugin dialogs
# 2008-12-12  Bug fix for functions "EveningLightOFF" and "NightLightON" when
#             using negativ offset settings
# 2008-09-24  Individual settings for bursts (ON/OFF) added
# 2008-09-17  Bugfix in string conversion
#             Bugfix in synchronization routine
# 2008-09-03  Added function for random control (Moving Ghost)
# 2008-05-13  Added individual log files for each thread
# 2008-04-28  Still stumbling, had to add better string control (StrCheck)
# 2008-04-25  A "little" Bug fix
# 2008-04-22  First version published
##############################################################################
import time, datetime, math, string, sys, os, random
from threading import Thread, Event



class Text:
    started = "Plugin started"
    suntrackerFinished = "SunTracker finished"
    listhl = "Currently active SunTrackers:"
    colLabels = (
        "SunTracker Name",
        "Event Name ON",
        "Event Name OFF"
    )
    #Buttons
    b_abort = "Abort"
    b_abortAll = "Abort all"
    b_refresh = "Refresh"
    b_restartAll = "Restart All"
    
    #Thread
    n_SuntrackerThread = "SunTrackerThread"
    nd_mo = "Monday"
    nd_tu = "Tuesday"
    nd_we = "Wednesday"
    nd_th = "Thursday"
    nd_fr = "Friday"
    nd_sa = "Saturday"
    nd_su = "Sunday"
    nd_vc = "Vacation"
    nxt_1 = "Next execution of "
    nxt_2 = " will start in "
    nxt_3 = " seconds"
    txt_dls_true = "Daylight saving is TRUE"
    txt_dls_false = "Daylight saving is FALSE"
    txt_tz = " - Timezone"
    lg_today = "Today is "
    lg_sunrise_sunset_1 = ". Sunrise will be at "
    lg_sunrise_sunset_2 = " and Sunset at "
    lg_dayOfWeek = "Normal scheduling would have followed settings for "
    lg_holiday_1 = "Due to holidays, scheduling of "
    lg_holiday_2 = "will instead follow "
    lg_holiday_3 = "your settings for "
    lg_vacation_1 = "Due to vacation mode, scheduling of "
    lg_vacation_2 = "will instead follow "
    lg_vacation_3 = "your settings for "
    lg_movingG_1 = "Moving Ghost with random control is enabled for "
    thr_abort = "Thread is terminating: "
    txtFixedHolidays = "Fixed Public Holidays:"
    txtVariableHolidays = "Variable Public Holidays:"
    txtVacation_m = "Vacation mode"
    txtMyLongitude = "My Longitude"
    txtMyLatitude = "My Latitude"

    class SuntrackerAction:
        name = "Start new or control running SunTracker"
        description = (
            "Allows starting, stopping or resetting SunTrackers, which "+
            "triggers an event at sunset/sunrise and a given date & time"
        )
        suntrackerName = "SunTracker name:"
        eventNameOn = "Event name ON:"
        eventNameOff = "Event name OFF:"
        labelStart = ' "%s"'
        txt_moNightOFF = "Monday Night OFF"
        txt_moMorningON = "Monday Morning ON"
        txt_moEveningOFF = "Monday Evening OFF"
        txt_tuNightOFF = "Tuesday Night OFF"
        txt_tuMorningON = "Tuesday Morning ON"
        txt_tuEveningOFF = "Tuesday Evening OFF"
        txt_weNightOFF = "Wednesday Night OFF"
        txt_weMorningON = "Wednesday Morning ON"
        txt_weEveningOFF = "Wednesday Evening OFF"
        txt_thNightOFF = "Thursday Night OFF"
        txt_thMorningON = "Thursday Morning ON"
        txt_thEveningOFF = "Thursday Evening OFF"
        txt_frNightOFF = "Friday Night OFF"
        txt_frMorningON = "Friday Morning ON"
        txt_frEveningOFF = "Friday Evening OFF"
        txt_saNightOFF = "Saturday Night OFF"
        txt_saMorningON = "Saturday Morning ON"
        txt_saEveningOFF = "Saturday Evening OFF"
        txt_suNightOFF = "Sunday Night OFF"
        txt_suMorningON = "Sunday Morning ON"
        txt_suEveningOFF = "Sunday Evening OFF"
        txt_vaNightOFF = "Vacation Night OFF"
        txt_vaMorningON = "Vacation Morning ON"
        txt_vaEveningOFF = "Vacation Evening OFF"
        txtNbrBursts = "Number of events per control (1-10 bursts)"
        txtON = " ON"
        txtOFF = " OFF"
        txtCmdDelay = "Delay between the events (0.5-5.0 s)"
        doLogLoopsText = "Print normal loop info (Y/N)"
        txtMoving_Ghost = "Enable Moving Ghost"
        txtMoving_Ghost_r_1 = "Moving Ghost: Random intervals BEFORE midnight"
        txtMoving_Ghost_r_2 = "Moving Ghost: Random intervals AFTER midnight"
        txtMoving_Ghost_ON_min = "ON min"
        txtMoving_Ghost_ON_max = "ON max"
        txtMoving_Ghost_OFF_min = "OFF min"
        txtMoving_Ghost_OFF_max = "OFF max"
        txtMinOnPeriod = "Minimum ON period required (0-60 min)"
        txtDoSynch = "Synchronization activated (Y/N)"
        txtSynchInterval = "Synch interval (6-600 min)"
        txtOffset = "Set offset for this control (-120...120 min)"



class SuntrackerThread(Thread):
    text = Text
    
    def __init__(
        self,
        dayTimeSettings,
        name,
        eventNameOn,
        eventNameOff,
        fixedHolidays,
        variableHolidays,
        iNbrOfBurstsON,
        iNbrOfBurstsOFF,
        cmdDelay,
        doLogLoops,
        vacation_m,
        moving_Ghost,
        moving_Ghost_r1,
        moving_Ghost_r2,
        moving_Ghost_r3,
        moving_Ghost_r4,
        moving_Ghost_r5,
        moving_Ghost_r6,
        moving_Ghost_r7,
        moving_Ghost_r8,
        bDoSynch,
        iOffset,
        iMinOnPeriod,
        myLongitude,
        myLatitude,
        iSynchInterval
    ):
        Thread.__init__(self, name=self.text.n_SuntrackerThread)
        if not eventNameOn:
            eventNameOn = name
        if not eventNameOff:
            eventNameOff = name
        self.name = name
        self.dayTimeSettings =  dayTimeSettings[:]
        self.eventNameOn = eventNameOn
        self.eventNameOff = eventNameOff
        self.finished = Event()
        self.abort = False
        self.fixedHolidays = fixedHolidays
        self.variableHolidays = variableHolidays
        self.iNbrOfBurstsON = iNbrOfBurstsON
        self.iNbrOfBurstsOFF = iNbrOfBurstsOFF
        self.cmdDelay = cmdDelay
        self.doLogLoops = doLogLoops
        self.vacation_m = vacation_m
        self.moving_Ghost = moving_Ghost
        self.moving_Ghost_r1 = moving_Ghost_r1
        self.moving_Ghost_r2 = moving_Ghost_r2
        self.moving_Ghost_r3 = moving_Ghost_r3
        self.moving_Ghost_r4 = moving_Ghost_r4
        self.moving_Ghost_r5 = moving_Ghost_r5
        self.moving_Ghost_r6 = moving_Ghost_r6
        self.moving_Ghost_r7 = moving_Ghost_r7
        self.moving_Ghost_r8 = moving_Ghost_r8
        self.bDoSynch = bDoSynch 
        self.iOffset = iOffset
        self.iMinOnPeriod = iMinOnPeriod
        self.myLongitude = myLongitude
        self.myLatitude = myLatitude
        self.iSynchInterval = iSynchInterval

   
    def run(self):
        try:
            dummy
        except NameError:
            dummy = 0
            prevDate = 0
            initsynch = 1
            iSynchLight = 1      
            prevDate = 0
            lightON = False
            iRndm = 0
            bToggle = False
            eg.globals.sunIsUp = True
            
        majorVersion, minorVersion = sys.getwindowsversion()[0:2]
        
        def Check_for_holidays():
            currDate = time.strftime("%m/%d/%Y", time.localtime())
            date = time.strftime("%m%d", time.localtime())
            dateTmw = time.strftime(
                "%m%d",
                time.localtime(time.time() + 60*60*24)
            )
            dw = GetDayOfWeek(currDate)
            if dw < 6:
                dwt = dw + 1
            else:
                dwt = 0
            nDw = dw
            
            if (
                self.fixedHolidays.find(date) != -1
                or self.variableHolidays.find(date) != -1
            ):
                nDw = 5
                if dwt < 5:
                    nDw = 6
                if (
                    self.fixedHolidays.find(dateTmw) != -1 
                    or self.variableHolidays.find(dateTmw) != -1
                ):
                    nDw = 5
            if (
                self.fixedHolidays.find(dateTmw) != -1
                or self.variableHolidays.find(dateTmw) != -1
            ):
                if nDw > 4:
                    nDw = 5
                else:
                    nDw = 4
            if self.vacation_m:
                nDw = 7
                                    
            return(nDw)
        
        
        def GetDayOfWeek(dateString):
            # day of week (monday = 0) of a given month/day/year
            time.sleep(.2)
            t1 = time.strptime(dateString,"%m/%d/%Y")
            # year in time_struct t1 can not go below 1970 (start of epoch)!
            t2 = time.mktime(t1)
            return(time.localtime(t2)[6])
        
        
        def GetNameOfDay(dt):
            nd = ""
            if dt == "0":
                nd = self.text.nd_mo
            if dt == "1":
                nd = self.text.nd_tu
            if dt == "2":
                nd = self.text.nd_we
            if dt == "3":
                nd = self.text.nd_th
            if dt == "4":
                nd = self.text.nd_fr
            if dt == "5":
                nd = self.text.nd_sa
            if dt == "6":
                nd = self.text.nd_su
            if dt == "7":
                nd = self.text.nd_vc
            return(nd)


        def Check_for_daylight_saving():
            iDLS = 0
            iDLS = time.localtime()[-1]
            if iDLS == 1:
                if initsynch == 1:
                    msg = "SunTracker "+self.name+": "+self.text.txt_dls_true
                    LogToFile(msg)
                    print msg
                    msg = time.strftime(
                        ("%Z"+self.text.txt_tz),
                        time.localtime()
                    )
                    LogToFile(msg)
                    print msg
            else:
                if initsynch == 1:
                    msg = "SunTracker "+self.name+": "+self.text.txt_dls_false
                    LogToFile(msg)
                    print msg
                    msg = time.strftime(
                        ("%Z"+self.text.txt_tz),
                        time.localtime()
                    )
                    LogToFile(msg)
                    print msg
            return(iDLS)
        

        def CheckIfLog(lightOld, light, iSynch, label):       
            if (
                light != lightOld
                or iSynch == 1
            ):
                LogToFile(label)
        
        
        def LogToFile(s):
            timeStamp = str(
                time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            )
            logStr = timeStamp+"\t"+s+"<br\n>"
            
            if majorVersion > 5:
                progData = os.environ['ALLUSERSPROFILE']
                if not os.path.exists(progData+"/EventGhost/Log") and not os.path.isdir(progData+"/EventGhost/Log"):
                    os.makedirs(progData+"/EventGhost/Log")
                fileHandle = open (progData+'/EventGhost/Log/Suntracker_'+self.name+'.html', 'a' )
                fileHandle.write ( logStr )
                fileHandle.close ()
            else:
                if not os.path.exists('Log') and not os.path.isdir('Log'):
                    os.mkdir('Log')
                fileHandle = open ( 'Log/Suntracker_'+self.name+'.html', 'a' )
                fileHandle.write ( logStr )
                fileHandle.close ()


        def GetOffsetTimeSR(iO):
            if iO > 120:
                iO = 120
            if iO < -120:
                iO = -120
            now = datetime.datetime.now()
            diff = datetime.timedelta(minutes=abs(iO))
            if iO<0:
                corr = now - diff
            else:
                corr = now + diff   
            s = corr.strftime("%H%M")
            return(s)
                
        
        def GetOffsetTimeSS(iO):
            if iO > 120:
                iO = 120
            if iO < -120:
                iO = -120
            now = datetime.datetime.now()
            diff = datetime.timedelta(minutes=abs(iO))
            if iO<0:
                corr = now + diff
            else:
                corr = now - diff   
            s = corr.strftime("%H%M")
            return(s)
        
        
        def CalcNbrOfMinutes(s):
            iHour = int(s[0:2])
            iMin = int(s[2:4])
            iTotMin = iHour*60 + iMin
            return(iTotMin)
       
       
        def StrCheck(s):
            if s == "----":
                s = "0000"
            return(s)

       
        def NightLightON(
            night_OFF, 
            trigTimeSR,
            trigTime, 
            csSR,
            light,
            lightON
        ):
            if (
                night_OFF != "----"
                and (
                    lightON == False
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTime) < int(StrCheck(night_OFF))
                    and int(csSR) >= int(StrCheck(night_OFF))
                    and int(trigTime) < 0600
                    and (
                    		int(trigTimeSR) < int(csSR)
                    		or int(trigTime) < int(csSR)
                    )
                ):
                    light = 1;
                    if self.iMinOnPeriod > 0:
                        if (
                            CalcNbrOfMinutes(csSR) -
                            CalcNbrOfMinutes(trigTimeSR) < self.iMinOnPeriod
                        ):
                            light = 10;
                        if (
                            CalcNbrOfMinutes(StrCheck(night_OFF)) -
                            CalcNbrOfMinutes(trigTime) < self.iMinOnPeriod
                        ):
                            light = 10;
            return(light)
        
        
        def NightLightOFF( 
            night_OFF,
            evening_OFF,
            morning_ON, 
            trigTime,
            light, 
            lightON 
        ):
            if (
                night_OFF != "----"
                and (
                    lightON == True
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTime) >= int(StrCheck(night_OFF))
                    and int(StrCheck(night_OFF)) < 0600
                    and int(trigTime) < int(StrCheck(morning_ON))
                ):
                    light = 0
                if (
                    int(trigTime) >= int(StrCheck(night_OFF))
                    and int(StrCheck(night_OFF)) < 0600
                    and morning_ON == "----"
                    and int(trigTime) < 0600
                ):
                    light = 0
            if (
                night_OFF == "----" 
                and evening_OFF != "----"
                and (
                    lightON == True
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTime) > 0000
                    and int(trigTime) < 0600
                    and (
                        int(trigTime) < int(StrCheck(morning_ON))
                        or morning_ON == "----"
                    )
                ):
                    light = 0
            return(light)
        
        
        def MorningLightON( 
            morning_ON,
            trigTimeSR,
            trigTime,
            csSR,
            light,
            lightON 
        ):
            if (
                morning_ON != "----"
                and (
                    lightON == False
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTime) >= int(StrCheck(morning_ON))
                    and int(csSR) >= int(StrCheck(morning_ON))
                    and int(trigTime) < 1200
                    and int(trigTimeSR) < int(csSR)
                ):
                    light = 1
                    if self.iMinOnPeriod > 0:
                        if (
                            CalcNbrOfMinutes(csSR) -
                            CalcNbrOfMinutes(trigTimeSR) < self.iMinOnPeriod
                        ):
                            light = 10
            return(light)
        
        
        def MorningLightOFF(
            morning_ON,
            trigTimeSR,
            trigTimeSS,
            trigTime,
            csSR,
            csSS,
            light,
            lightON
        ):
            if (
                morning_ON != "----"
                and (
                    lightON == True
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTimeSR) >= int(trigTime)
                    and int(trigTimeSR) >= int(csSR)
                    and int(trigTime) < 1800
                ):
                    if int(trigTimeSR) < int(csSS):
                        light = 0
                if (
                    int(trigTimeSR) < int(trigTime)
                    and int(trigTimeSR) >= int(csSR)
                    and int(trigTime) < 1800
                ):
                    if int(trigTimeSS) < int(csSS):
                        light = 0
        
            if (
                morning_ON == "----"
                and (
                    lightON == True
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTimeSR) >= int(trigTime)
                    and int(trigTimeSR) >= int(csSR)
                    and int(trigTime) < 1800
                ):
                    if int(trigTimeSR) < int(csSS):
                        light = 0
                if (
                    int(trigTimeSR) < int(trigTime)
                    and int(trigTimeSR) >= int(csSR)
                    and int(trigTime) < 1800
                ):
                    if int(trigTimeSS) < int(csSS):
                        light = 0
            return(light)
        
        
        def EveningLightON(
            morning_ON,
            evening_OFF,
            night_OFF,
            trigTimeSS,
            trigTime,
            csSS,
            light,
            lightON 
        ):
            if (
                evening_OFF != "----"
                and (
                    lightON == False
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTimeSS) >= int(csSS)
                    and int(csSS) > 1200
                ):
                    if (
                        int(csSS) <= int(StrCheck(evening_OFF))
                        and int(trigTimeSS) > 1200
                        and int(trigTime) > 1200
                        and int(trigTime) < int(StrCheck(evening_OFF))
                    ):
                        light = 1
                        if self.iMinOnPeriod > 0:
                            if (
                                CalcNbrOfMinutes(StrCheck(evening_OFF)) -
                                CalcNbrOfMinutes(trigTimeSS) <
                                self.iMinOnPeriod
                            ):
                                light = 10
            if (
                evening_OFF == "----"
                and night_OFF != "----"
                and (
                    lightON == False
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTimeSS) >= int(csSS)
                    and int(csSS) > 1200
                ):
                    if (
                        int(csSS) <= 2359
                        and int(trigTimeSS) > 1200
                        and int(trigTime) > 1200
                        and int(trigTime) <= 2359
                    ):
                        light = 1
                        if self.iMinOnPeriod > 0:
                            # 23 hours 59 minutes == 1439 minutes
                            if (
                                (1439 - CalcNbrOfMinutes(trigTimeSS) +
                                CalcNbrOfMinutes(StrCheck(night_OFF))) <
                                self.iMinOnPeriod
                            ):
                                light = 10
            if (
                evening_OFF == "----"
                and night_OFF == "----" 
                and morning_ON != "----" 
                and (
                    lightON == False
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTimeSS) >= int(csSS)
                    and int(csSS) > 1200
                ):
                    if (
                        int(csSS) <= 2359
                        and int(trigTimeSS) > 1200
                        and int(trigTime) > 1200
                        and int(trigTime) <= 2359
                    ):
                        light = 1
                        if self.iMinOnPeriod > 0:
                            # 23 hours 59 minutes == 1439 minutes
                            if (
                                (1439 - CalcNbrOfMinutes(trigTimeSS) +
                                CalcNbrOfMinutes(StrCheck(night_OFF))) <
                                self.iMinOnPeriod
                            ):
                                light = 10
            return(light)
        
        
        def EveningLightOFF( 
            morning_ON,
            evening_OFF,
            trigTimeSS, 
            trigTime, 
            csSS, 
            light, 
            lightON 
        ):
            if (
                evening_OFF != "----"
                and (
                    lightON == True
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTime) > 1800
                    and int(StrCheck(evening_OFF)) > 1800
                    and int(trigTime) >= int(StrCheck(evening_OFF))
                ):
                    light = 0
            if (
                morning_ON != "----"
                and (
                    lightON == True
                    or iSynchLight == self.iSynchInterval
                    or initsynch == 1
                )
            ):
                if (
                    int(trigTime) > 1800
                    and int(trigTimeSS) > 1800
                    and int(trigTimeSS) < int(csSS)
                ):
                    light = 0
            return(light)
        
        
        def CheckNightLightOn(
            dayType,
            trigTimeSR,
            trigTime,
            csSR,
            light,
            lightON
        ):
            for i in range(0,8):
                if dayType == str(i):
                    light = NightLightON( 
                        self.dayTimeSettings[i*3],
                        trigTimeSR,
                        trigTime,
                        csSR, 
                        light,
                        lightON
                    )
            return(int(light))
        
        
        def CheckNightLightOff(
            dayType,
            trigTime,
            light,
            lightON
        ):
            for i in range(0,8):
                if dayType == str(i):
                    j = i*3-1
                    if j == -1:
                        j = 20
                    if j == 20:
                        j = 23    
                    light = NightLightOFF(
                        self.dayTimeSettings[i*3],
                        self.dayTimeSettings[j],
                        self.dayTimeSettings[i*3+1],
                        trigTime, 
                        light, 
                        lightON 
                    )
            return(int(light))
        
        
        def CheckMorningLightOn(
            dayType,
            trigTimeSR,
            trigTime,
            csSR,
            light,
            lightON
        ):
            for i in range(0,8):
                if dayType == str(i):
                    light = MorningLightON(
                        self.dayTimeSettings[i*3+1],
                        trigTimeSR, 
                        trigTime,
                        csSR, 
                        light, 
                        lightON
                    )
            return(int(light))
        
        
        def CheckMorningLightOff(
            dayType,
            trigTimeSR,
            trigTimeSS,
            trigTime,
            csSR,
            csSS,
            light,
            lightON
        ):
            for i in range(0,8):
                if dayType == str(i):
                    light = MorningLightOFF( 
                        self.dayTimeSettings[i*3+1],
                        trigTimeSR, 
                        trigTimeSS, 
                        trigTime,
                        csSR, 
                        csSS,
                        light, 
                        lightON 
                    )
            return(int(light))
        
        
        def CheckEveningLightOn(
            dayType,
            trigTimeSS,
            trigTime,
            csSS,
            light,
            lightON
        ):

            for i in range(0,8):
                if dayType == str(i):
                    j = i*3+3
                    if j == 21:
                        j = 0
                    if j == 24:
                        j = 21
                    light = EveningLightON( 
                        self.dayTimeSettings[i*3+1],
                        self.dayTimeSettings[i*3+2],
                        self.dayTimeSettings[j],
                        trigTimeSS, 
                        trigTime, 
                        csSS, 
                        light, 
                        lightON
                    )
            return(int(light))
        
        
        def CheckEveningLightOff(
            dayType,
            trigTimeSS,
            trigTime,
            csSS,
            light,
            lightON
        ):
            for i in range(0,8):
                if dayType == str(i):
                    light = EveningLightOFF(
                        self.dayTimeSettings[i*3+1],
                        self.dayTimeSettings[i*3+2],
                        trigTimeSS, 
                        trigTime,
                        csSS, 
                        light, 
                        lightON 
                    )
            return(int(light))


        def CreateEvent_ON(
            light,
            bDoSynch,
            lightON,
        ):
            if light == 1 and bDoSynch:
                lightOld = lightON
                lightON = True
                CheckIfLog(
                    lightOld,
                    lightON,
                    initsynch,
                    self.eventNameOn
                )
                for i in range(self.iNbrOfBurstsON):
                    eg.TriggerEvent(self.eventNameOn)
                    time.sleep(self.cmdDelay)
            if light == 1 and bDoSynch == False:
                if(
                    lightON == False
                    or initsynch == 1
                ):
                    lightON = True
                    LogToFile(self.eventNameOn)
                    for i in range(self.iNbrOfBurstsON):
                        eg.TriggerEvent(self.eventNameOn)
                        time.sleep(self.cmdDelay)
            return(lightON) 
    
        
        def CreateEvent_OFF(
            light,
            bDoSynch,
            lightON,
        ):
            if light == 0 and bDoSynch:
                lightOld = lightON
                lightON = False
                CheckIfLog(
                    lightOld,
                    lightON,
                    initsynch,
                    self.eventNameOff
                )
                for i in range(self.iNbrOfBurstsOFF):
                    eg.TriggerEvent(self.eventNameOff) 
                    time.sleep(self.cmdDelay)
            if light == 0 and bDoSynch == False:
                if (
                    lightON == True
                    or initsynch == 1
                ):
                    lightON = False
                    LogToFile(self.eventNameOff)
                    for i in range(self.iNbrOfBurstsOFF):
                        eg.TriggerEvent(self.eventNameOff) 
                        time.sleep(self.cmdDelay)
            return(lightON) 


        while (self.abort == False):
            remain = 61 - int(time.strftime("%S", time.localtime()))
#            remain = 10
            self.finished.wait(remain)
            self.finished.clear()
            if self.abort:
                break

            if self.bDoSynch:
                if iSynchLight >= int(self.iSynchInterval):
                    iSynchLight = 1
                else:
                    iSynchLight += 1

            # Get the current date & time now, check if it has changed
            trigTime = str(time.strftime("%H%M", time.localtime()))
            currDate = str(time.strftime("%m/%d/%Y", time.localtime()))
            if currDate != prevDate:
                prevDate = 0

            # Adjust the sunrise/sunset trig times with defined offset
            trigTimeSR = GetOffsetTimeSR(self.iOffset)
            trigTimeSS = GetOffsetTimeSS(self.iOffset)

            # Get day of week and check for holidays
            odayType = str(GetDayOfWeek(currDate))
            dayType = str(Check_for_holidays())
        
            # Check if we are in daylight savings
            idLS = Check_for_daylight_saving()
            
            # Calculate Sunrise/Sunset times at your geographical position
            year = int(time.strftime("%Y", time.localtime()))
            month = int(time.strftime("%m", time.localtime()))
            day = int(time.strftime("%d", time.localtime()))
             
            # Get the sunrise/sunset times in UT and fix the format
            st = str(sunRiseSet(
                year,
                month,
                day,
                float(self.myLongitude),
                float(self.myLatitude))
            )
            st = st.replace("(", "")
            st = st.replace(")", "")
            st = st.replace(",", "")
            
            # Split and extract the data
            data = st.split()
            t1 = data[0]
            t2 = data[1]
            dat1 = t1.split(".")
            dat2 = t2.split(".")
            
            # Adjust the times according to your timezone and daylight savings
            tZ = int(time.timezone/3600)
            
            h1 = int(int(dat1[0])+idLS-tZ)
            m1 = float("."+dat1[1])
            m1 = int(m1*60)
            if m1 < 0:
                h1 -= 1
                m1 = 60+m1
            if h1 > 23:
                h1 = abs(24-h1)
            sh1 = str(h1)
            if h1 < 10:
                sh1 = "0" + sh1
                
            sm1 = str(m1)
            if m1 < 10:
                sm1 = "0" + sm1
                
            h2 = int(int(dat2[0])+idLS-tZ)
            m2 = float("."+dat2[1])
            m2 = int(m2*60)
            if m2 < 0:
                h2 -= 1
                m2 = 60+m2
            if h2 > 23:
                h2 = abs(24-h2)
            sh2 = str(h2)
            if h2 < 10:
                sh2 = "0" + sh2
                
            sm2 = str(m2)
            if m2 < 10:
                sm2 = "0" + sm2
          
            # Finally, the time strings are composed
            csSR = sh1+sm1
            csSS = sh2+sm2

            # Set an eg global flag for sun status
            if trigTime > csSS or trigTime < csSR:
                if eg.globals.sunIsUp:
                    eg.globals.sunIsUp = False
            else:
                if not eg.globals.sunIsUp:
                    eg.globals.sunIsUp = True
            
            #print csSR, csSS, trigTime, eg.globals.sunIsUp, trigTimeSR, trigTimeSS
    
            # Initial logging when a new day begins
            if prevDate == 0:
                prevDate = currDate
                od = GetNameOfDay(odayType)
                nd = GetNameOfDay(dayType)
                lg = (self.text.lg_today+
                    od+
                    self.text.lg_sunrise_sunset_1+
                    csSR+
                    self.text.lg_sunrise_sunset_2+
                    csSS
                )
                LogToFile(lg)
                print lg
                if nd != od  and self.moving_Ghost == False:
                    lg = self.text.lg_dayOfWeek+od
                    print lg
                    LogToFile(lg)
                    if dayType == "7":
                        lg = (
                            self.text.lg_vacation_1+
                            self.name+
                            " "+
                            self.text.lg_vacation_2+
                            self.text.lg_vacation_3+
                            nd
                        )
                        LogToFile(lg)
                        print self.text.lg_vacation_1+self.name
                        print (
                            self.text.lg_vacation_2+
                            self.text.lg_vacation_3+
                            nd
                        )
                    else:
                        lg = (
                            self.text.lg_holiday_1+
                            self.name+
                            " "+
                            self.text.lg_holiday_2+
                            self.text.lg_holiday_3+
                            nd
                        )
                        LogToFile(lg)
                        print self.text.lg_holiday_1+self.name
                        print (
                            self.text.lg_holiday_2+
                            self.text.lg_holiday_3+
                            nd
                        )

            # Initial logging when Moving Ghost is activated
            if self.moving_Ghost and initsynch == 1:
                LogToFile(self.text.lg_movingG_1+self.name)
                print self.text.lg_movingG_1+self.name

            # Restoring to initial value
            light = 10

            # Night Light On
            light = CheckNightLightOn( 
                dayType, 
                trigTimeSR, 
                trigTime, 
                csSR, 
                light,
                lightON 
            )
            
            # Night Light Off
            light = CheckNightLightOff( 
                dayType, 
                trigTime,
                light, 
                lightON
            ) 
        
            # Morning Light On
            light = CheckMorningLightOn( 
                dayType, 
                trigTimeSR,
                trigTime, 
                csSR, 
                light,
                lightON
            )
        
            # Morning Light Off
            light = CheckMorningLightOff(
                dayType, 
                trigTimeSR, 
                trigTimeSS, 
                trigTime,
                csSR,
                csSS, 
                light, 
                lightON 
            )

            # Evening Light On
            light = CheckEveningLightOn( 
                dayType, 
                trigTimeSS,
                trigTime, 
                csSS, 
                light, 
                lightON 
            )
        
            # Evening Light Off
            light = CheckEveningLightOff( 
                dayType, 
                trigTimeSS,
                trigTime, 
                csSS, 
                light, 
                lightON 
            )

            # Moving Ghost...
            if initsynch == 1:
                random.seed(self.name)
                random.jumpahead(int(len(self.name)))
                if self.moving_Ghost:
                    self.bDoSynch = False
                if (
                    self.moving_Ghost
                    and (trigTime > csSS
                    or trigTime < csSR)
                ):
                    light = 1
            else:
                if (
                    self.moving_Ghost
                    and (trigTime > csSS
                    or trigTime < csSR)
                ):
                    light = 10
                    if iRndm == 0:
                        # Get random number
                        if lightON == False:
                            if trigTime > csSS:
                                iRndm = random.randint(
                                    self.moving_Ghost_r3,
                                    self.moving_Ghost_r4
                                )
                            else:
                                iRndm = random.randint(
                                    self.moving_Ghost_r6,
                                    self.moving_Ghost_r8
                                )
    
                        if lightON == True:
                            if trigTime > csSS:
                                iRndm = random.randint(
                                    self.moving_Ghost_r1,
                                    self.moving_Ghost_r2
                                )
                            else:
                                iRndm = random.randint(
                                    self.moving_Ghost_r5,
                                    self.moving_Ghost_r6
                                )
                    
                    if iRndm == 1:
                        iRndm -= 1
                        if lightON == False:
                            light = 1
                        if lightON == True:
                            light = 0

                    if iRndm > 1:
                        iRndm -= 1
            
            #Print basic loop info
            if self.doLogLoops and initsynch == 0:
                print (
                    self.text.nxt_1+
                    self.name+
                    self.text.nxt_2+
                    str(remain)+
                    self.text.nxt_3
                )

            lightON = CreateEvent_ON(
                    light,
                    self.bDoSynch,
                    lightON,
                )
         
            lightON = CreateEvent_OFF(
                    light,
                    self.bDoSynch,
                    lightON,
                )
        
            initsynch = 0
 
        
    def AbortSuntracker(self):
        self.abort = True
        print self.text.thr_abort, self.name
        self.finished.set()
       
  

class Suntracker(eg.PluginClass):
    iconFile = "suntracker_plugin"
    text = Text
    
    def __init__(self):
        self.AddAction(SuntrackerAction)
        self.AllsuntrackerNames = []
        self.AlldayTimeSettings = []
        self.AlleventNameOn = []
        self.AlleventNameOff = []
        self.AlliNbrOfBurstsON = []
        self.AlliNbrOfBurstsOFF = []
        self.AllcmdDelay = []
        self.AlldoLogLoops = []
        self.AllbDoSynch = []
        self.AlliSynchInterval = []
        self.AlliOffset = []
        self.AlliMinOnPeriod = []
        self.Allmoving_Ghost = []
        self.AllMoving_Ghost_r1 = []
        self.AllMoving_Ghost_r2 = []
        self.AllMoving_Ghost_r3 = []
        self.AllMoving_Ghost_r4 = []
        self.AllMoving_Ghost_r5 = []
        self.AllMoving_Ghost_r6 = []
        self.AllMoving_Ghost_r7 = []
        self.AllMoving_Ghost_r8 = []
        self.lastSuntrackerName = ""
        self.suntrackerThreads = {}
        self.OkButtonClicked = False
        self.started = False


    def __start__(
        self,
        myLongitude,
        myLatitude,
        fixedHolidays,
        variableHolidays,
        vacation_m
    ):
        print self.text.started
        self.myLongitude = myLongitude
        self.myLatitude = myLatitude
        self.fixedHolidays = fixedHolidays
        self.variableHolidays = variableHolidays
        self.vacation_m = vacation_m
        self.started = True
        if self.OkButtonClicked:
            self.OkButtonClicked = False
            self.RestartAllSuntrackers()
        majorVersion, minorVersion = sys.getwindowsversion()[0:2]
        if majorVersion > 5:
            progData = os.environ['ALLUSERSPROFILE']
            if not os.path.exists(progData+"/EventGhost/Log") and not os.path.isdir(progData+"/EventGhost/Log"):
                os.makedirs(progData+"/EventGhost/Log")
        else:
            if not os.path.exists('Log') and not os.path.isdir('Log'):
                os.mkdir('Log')


    def __stop__(self):
        self.AbortAllSuntrackers()
        self.started = False


    def __close__(self):
        self.AbortAllSuntrackers()
        self.started = False


    #methods to Control suntrackers
    def StartSuntracker(
        self,
        dayTimeSettings,
        suntrackerName,
        eventNameOn,
        eventNameOff,
        fixedHolidays,
        variableHolidays,
        iNbrOfBurstsON,
        iNbrOfBurstsOFF,
        cmdDelay,
        doLogLoops,
        vacation_m,
        moving_Ghost,
        moving_Ghost_r1,
        moving_Ghost_r2,
        moving_Ghost_r3,
        moving_Ghost_r4,
        moving_Ghost_r5,
        moving_Ghost_r6,
        moving_Ghost_r7,
        moving_Ghost_r8,
        bDoSynch,
        iOffset,
        iMinOnPeriod,
        myLongitude,
        myLatitude,
        iSynchInterval
    ):

        if self.suntrackerThreads.has_key(suntrackerName):
            t = self.suntrackerThreads[suntrackerName]
            if t.isAlive():
                t.AbortSuntracker()
            del self.suntrackerThreads[suntrackerName]
        t = SuntrackerThread(
            dayTimeSettings,
            suntrackerName,
            eventNameOn,
            eventNameOff,
            fixedHolidays,
            variableHolidays,
            iNbrOfBurstsON,
            iNbrOfBurstsOFF,
            cmdDelay,
            doLogLoops,
            vacation_m,
            moving_Ghost,
            moving_Ghost_r1,
            moving_Ghost_r2,
            moving_Ghost_r3,
            moving_Ghost_r4,
            moving_Ghost_r5,
            moving_Ghost_r6,
            moving_Ghost_r7,
            moving_Ghost_r8,
            bDoSynch,
            iOffset,
            iMinOnPeriod,
            myLongitude,
            myLatitude,
            iSynchInterval
        )
        t.start()
        self.suntrackerThreads[suntrackerName] = t


    def AbortSuntracker(self, suntracker):
        if self.suntrackerThreads.has_key(suntracker):
            t = self.suntrackerThreads[suntracker]
            t.AbortSuntracker()
            del self.suntrackerThreads[suntracker]


    def AbortAllSuntrackers(self):
        for i, item in enumerate(self.suntrackerThreads):
            t = self.suntrackerThreads[item]
            t.AbortSuntracker()
            del t
        self.suntrackerThreads = {}


    def RestartAllSuntrackers(self, startNewIfNotAlive = True):
        for i, item in enumerate(self.GetAllsuntrackerNames()):
            if startNewIfNotAlive:
                self.StartSuntracker(
                    self.GetAlldayTimeSettings()[i],
                    self.GetAllsuntrackerNames()[i],
                    self.GetAlleventNameOn()[i],
                    self.GetAlleventNameOff()[i],
                    self.fixedHolidays,
                    self.variableHolidays,
                    self.GetAlliNbrOfBurstsON()[i],
                    self.GetAlliNbrOfBurstsOFF()[i],
                    self.GetAllcmdDelay()[i],
                    self.GetAlldoLogLoops()[i],
                    self.vacation_m,
                    self.GetAllmoving_Ghost()[i],
                    self.GetAllMoving_Ghost_r1()[i],
                    self.GetAllMoving_Ghost_r2()[i],
                    self.GetAllMoving_Ghost_r3()[i],
                    self.GetAllMoving_Ghost_r4()[i],
                    self.GetAllMoving_Ghost_r5()[i],
                    self.GetAllMoving_Ghost_r6()[i],
                    self.GetAllMoving_Ghost_r7()[i],
                    self.GetAllMoving_Ghost_r8()[i],
                    self.GetAllbDoSynch()[i],
                    self.GetAlliOffset()[i],
                    self.GetAlliMinOnPeriod()[i],
                    self.myLongitude,
                    self.myLatitude,
                    self.GetAlliSynchInterval()[i]
                )


    def Configure(
        self,
        myLongitude = "18.0000",
        myLatitude = "59.2500",
        fixedHolidays = "0101,0501,0606,1224,1225,1226,1231",
        variableHolidays = "0106,0321,0324,0620",
        vacation_m = False,
        *args
    ):
        
        panel = eg.ConfigPanel(self, resizable=True)
        
        panel.sizer.Add(
            wx.StaticText(panel, -1, self.text.listhl),
            flag = wx.ALIGN_CENTER_VERTICAL
        )

        mySizer = wx.GridBagSizer(5, 5)
        mySizer.AddGrowableRow(0)
        mySizer.AddGrowableCol(1)
        mySizer.AddGrowableCol(2)
        mySizer.AddGrowableCol(3)
       
        suntrackerListCtrl = wx.ListCtrl(
            panel,
            -1,
            style=wx.LC_REPORT | wx.VSCROLL | wx.HSCROLL
        )
       
        for i, colLabel in enumerate(self.text.colLabels):
            suntrackerListCtrl.InsertColumn(i, colLabel)

        #setting col width to fit label
        suntrackerListCtrl.InsertStringItem(0, "Test Suntracker Name")
        suntrackerListCtrl.SetStringItem(0, 1, "Test EventName On")

        size = 0
        for i in range(2):
            suntrackerListCtrl.SetColumnWidth(
                i,
                wx.LIST_AUTOSIZE_USEHEADER
            ) #wx.LIST_AUTOSIZE
            size += suntrackerListCtrl.GetColumnWidth(i)
       
        suntrackerListCtrl.SetMinSize((size, -1))
       
        mySizer.Add(suntrackerListCtrl, (0,0), (1, 5), flag = wx.EXPAND)

        #buttons
        abortButton = wx.Button(panel, -1, self.text.b_abort)
        mySizer.Add(abortButton, (1,0))
       
        abortAllButton = wx.Button(panel, -1, self.text.b_abortAll)
        mySizer.Add(abortAllButton, (1,1), flag = wx.ALIGN_RIGHT)
       
        restartAllButton = wx.Button(panel, -1, self.text.b_restartAll)
        mySizer.Add(restartAllButton, (1,2), flag = wx.ALIGN_RIGHT)

        refreshButton = wx.Button(panel, -1, self.text.b_refresh)
        mySizer.Add(refreshButton, (1,4), flag = wx.ALIGN_RIGHT)

        f_myLongitude = float(myLongitude)
        myLongitudeCtrl = panel.SpinNumCtrl(
            f_myLongitude,
            decimalChar = '.',                 # by default, use '.' for decimal point
            groupChar = ',',                   # by default, use ',' for grouping
            fractionWidth = 4,
            integerWidth = 3,
            min = -128.0000,
            max = 128.0000,
            increment = 0.0050
        )
        myLongitudeCtrl.SetInitialSize((90,-1))
        mySizer.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMyLongitude
            ),
            (2,0)
        )
        mySizer.Add(myLongitudeCtrl, (2,1))

        f_myLatitude = float(myLatitude)
        myLatitudeCtrl = panel.SpinNumCtrl(
            f_myLatitude,
            decimalChar = '.',                 # by default, use '.' for decimal point
            groupChar = ',',                   # by default, use ',' for grouping
            fractionWidth = 4,
            integerWidth = 2,
            min = -90.0000,
            max = 90.0000,
            increment = 0.0050
        )
        myLatitudeCtrl.SetInitialSize((90,-1))
        mySizer.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMyLatitude
            ),
            (3,0)
        )
        mySizer.Add(myLatitudeCtrl, (3,1))

        fixedHolidaysCtrl = wx.TextCtrl(panel, -1, fixedHolidays)
        fixedHolidaysCtrl.SetInitialSize((300,-1))
        mySizer.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtFixedHolidays
            ),
            (4,0)
        )
        mySizer.Add(fixedHolidaysCtrl,(4,1))

        variableHolidaysCtrl = wx.TextCtrl(panel, -1, variableHolidays)
        variableHolidaysCtrl.SetInitialSize((300,-1))
        mySizer.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtVariableHolidays
            ),
            (5,0)
        )
        mySizer.Add(variableHolidaysCtrl,(5,1))

        vacation_mCtrl = wx.CheckBox(panel, -1, self.text.txtVacation_m)
        vacation_mCtrl.SetValue(vacation_m)
        mySizer.Add(vacation_mCtrl,(6,0))
       
        panel.sizer.Add(mySizer, 1, flag = wx.EXPAND)

       
        def PopulateList (event):
            suntrackerListCtrl.DeleteAllItems()
            row = 0
            for i, item in enumerate(self.suntrackerThreads):
                t = self.suntrackerThreads[item]
                if t.isAlive():
                    suntrackerListCtrl.InsertStringItem(row, t.name)
                    suntrackerListCtrl.SetStringItem(row,
                        1, t.eventNameOn)
                    suntrackerListCtrl.SetStringItem(row,
                        2, t.eventNameOff)
                    row += 1
            ListSelection(wx.CommandEvent())


        def OnAbortButton(event):
            item = suntrackerListCtrl.GetFirstSelected()
            while item != -1:
                name = suntrackerListCtrl.GetItemText(item)
                self.AbortSuntracker(name)
                item = suntrackerListCtrl.GetNextSelected(item)
            PopulateList(wx.CommandEvent())
            event.Skip()


        def OnAbortAllButton(event):
            self.AbortAllSuntrackers()
            PopulateList(wx.CommandEvent())
            event.Skip()


        def OnRestartAllButton(event):
            self.RestartAllSuntrackers()
            PopulateList(wx.CommandEvent())
            event.Skip()


        def ListSelection(event):
            flag = suntrackerListCtrl.GetFirstSelected() != -1
            abortButton.Enable(flag)
            event.Skip()

           
        def OnSize(event):
            suntrackerListCtrl.SetColumnWidth(
                6,
                wx.LIST_AUTOSIZE_USEHEADER
            ) #wx.LIST_AUTOSIZE
            event.Skip()


        def OnApplyButton(event): 
            event.Skip()
            self.RestartAllSuntrackers()
            PopulateList(wx.CommandEvent())


        def OnOkButton(event): 
            event.Skip()
            self.OkButtonClicked = True
            if not self.started:    
                self.RestartAllSuntrackers()
            PopulateList(wx.CommandEvent())
            

        PopulateList(wx.CommandEvent())
       
        abortButton.Bind(wx.EVT_BUTTON, OnAbortButton)
        abortAllButton.Bind(wx.EVT_BUTTON, OnAbortAllButton)
        restartAllButton.Bind(wx.EVT_BUTTON, OnRestartAllButton)
        refreshButton.Bind(wx.EVT_BUTTON, PopulateList)
        suntrackerListCtrl.Bind(wx.EVT_LIST_ITEM_SELECTED, ListSelection)
        suntrackerListCtrl.Bind(wx.EVT_LIST_ITEM_DESELECTED, ListSelection)
        panel.Bind(wx.EVT_SIZE, OnSize)
        panel.dialog.buttonRow.applyButton.Bind(wx.EVT_BUTTON, OnApplyButton)
        panel.dialog.buttonRow.okButton.Bind(wx.EVT_BUTTON, OnOkButton)

        while panel.Affirmed():
            myLongitude = str(myLongitudeCtrl.GetValue())
            myLatitude = str(myLatitudeCtrl.GetValue())
            fixedHolidays = fixedHolidaysCtrl.GetValue()
            variableHolidays = variableHolidaysCtrl.GetValue()
            vacation_m = vacation_mCtrl.GetValue()
            panel.SetResult(
                        myLongitude,
                        myLatitude,
                        fixedHolidays,
                        variableHolidays,
                        vacation_m,
                        *args
            )

           
    def GetAllsuntrackerNames(self):
        return self.AllsuntrackerNames


    def GetAlldayTimeSettings(self):
        return self.AlldayTimeSettings


    def GetAlleventNameOn(self):
        return self.AlleventNameOn


    def GetAlleventNameOff(self):
        return self.AlleventNameOff


    def GetAlliNbrOfBurstsON(self):
        return self.AlliNbrOfBurstsON


    def GetAlliNbrOfBurstsOFF(self):
        return self.AlliNbrOfBurstsOFF


    def GetAllcmdDelay(self):
        return self.AllcmdDelay


    def GetAlldoLogLoops(self):
        return self.AlldoLogLoops


    def GetAllbDoSynch(self):
        return self.AllbDoSynch


    def GetAlliSynchInterval(self):
        return self.AlliSynchInterval


    def GetAlliOffset(self):
        return self.AlliOffset


    def GetAlliMinOnPeriod(self):
        return self.AlliMinOnPeriod


    def GetAllmoving_Ghost(self):
        return self.Allmoving_Ghost


    def GetAllMoving_Ghost_r1(self):
        return self.AllMoving_Ghost_r1


    def GetAllMoving_Ghost_r2(self):
        return self.AllMoving_Ghost_r2


    def GetAllMoving_Ghost_r3(self):
        return self.AllMoving_Ghost_r3


    def GetAllMoving_Ghost_r4(self):
        return self.AllMoving_Ghost_r4


    def GetAllMoving_Ghost_r5(self):
        return self.AllMoving_Ghost_r5


    def GetAllMoving_Ghost_r6(self):
        return self.AllMoving_Ghost_r6


    def GetAllMoving_Ghost_r7(self):
        return self.AllMoving_Ghost_r7


    def GetAllMoving_Ghost_r8(self):
        return self.AllMoving_Ghost_r8


    def AddSuntrackerName(self, suntrackerName):
        if not suntrackerName in self.AllsuntrackerNames:
            self.AllsuntrackerNames.append(suntrackerName)
        return self.AllsuntrackerNames.index(suntrackerName)

        
    def AddDayTimeSettings(self, dayTimeSettings, indx):
        try:
            del self.AlldayTimeSettings[indx]
        except IndexError:
            i = -1 # no match
        self.AlldayTimeSettings.insert(indx, dayTimeSettings)
 
            
    def AddEventNameOn(self, eventNameOn, indx):
        try:
            del self.AlleventNameOn[indx]
        except IndexError:
            i = -1 # no match
        self.AlleventNameOn.insert(indx, eventNameOn)

            
    def AddEventNameOff(self, eventNameOff, indx):
        try:
            del self.AlleventNameOff[indx]
        except IndexError:
            i = -1 # no match
        self.AlleventNameOff.insert(indx, eventNameOff)

            
    def AddInbrOfBurstsON(self, iNbrOfBurstsON, indx):
        try:
            del self.AlliNbrOfBurstsON[indx]
        except IndexError:
            i = -1 # no match
        self.AlliNbrOfBurstsON.insert(indx, iNbrOfBurstsON)

            
    def AddInbrOfBurstsOFF(self, iNbrOfBurstsOFF, indx):
        try:
            del self.AlliNbrOfBurstsOFF[indx]
        except IndexError:
            i = -1 # no match
        self.AlliNbrOfBurstsOFF.insert(indx, iNbrOfBurstsOFF)


    def AddCmdDelay(self, cmdDelay, indx):
        try:
            del self.AllcmdDelay[indx]
        except IndexError:
            i = -1 # no match
        self.AllcmdDelay.insert(indx, cmdDelay)
            

    def AddDoLogLoops(self, doLogLoops, indx):
        try:
            del self.AlldoLogLoops[indx]
        except IndexError:
            i = -1 # no match
        self.AlldoLogLoops.insert(indx, doLogLoops)

            
    def AddBdoSynch(self, bDoSynch, indx):
        try:
            del self.AllbDoSynch[indx]
        except IndexError:
            i = -1 # no match
        self.AllbDoSynch.insert(indx, bDoSynch)

            
    def AddIsynchInterval(self, iSynchInterval, indx):
        try:
            del self.AlliSynchInterval[indx]
        except IndexError:
            i = -1 # no match
        self.AlliSynchInterval.insert(indx, iSynchInterval)


    def AddiOffset(self, iOffset, indx):
        try:
            del self.AlliOffset[indx]
        except IndexError:
            i = -1 # no match
        self.AlliOffset.insert(indx, iOffset)


    def AddiMinOnPeriod(self, iMinOnPeriod, indx):
        try:
            del self.AlliMinOnPeriod[indx]
        except IndexError:
            i = -1 # no match
        self.AlliMinOnPeriod.insert(indx, iMinOnPeriod)


    def AddMoving_Ghost(self, moving_Ghost, indx):
        try:
            del self.Allmoving_Ghost[indx]
        except IndexError:
            i = -1 # no match
        self.Allmoving_Ghost.insert(indx, moving_Ghost)

            
    def AddMoving_Ghost_r1(self, moving_Ghost_r1, indx):
        try:
            del self.AllMoving_Ghost_r1[indx]
        except IndexError:
            i = -1 # no match
        self.AllMoving_Ghost_r1.insert(indx, moving_Ghost_r1)


    def AddMoving_Ghost_r2(self, moving_Ghost_r2, indx):
        try:
            del self.AllMoving_Ghost_r2[indx]
        except IndexError:
            i = -1 # no match
        self.AllMoving_Ghost_r2.insert(indx, moving_Ghost_r2)


    def AddMoving_Ghost_r3(self, moving_Ghost_r3, indx):
        try:
            del self.AllMoving_Ghost_r3[indx]
        except IndexError:
            i = -1 # no match
        self.AllMoving_Ghost_r3.insert(indx, moving_Ghost_r3)


    def AddMoving_Ghost_r4(self, moving_Ghost_r4, indx):
        try:
            del self.AllMoving_Ghost_r4[indx]
        except IndexError:
            i = -1 # no match
        self.AllMoving_Ghost_r4.insert(indx, moving_Ghost_r4)


    def AddMoving_Ghost_r5(self, moving_Ghost_r5, indx):
        try:
            del self.AllMoving_Ghost_r5[indx]
        except IndexError:
            i = -1 # no match
        self.AllMoving_Ghost_r5.insert(indx, moving_Ghost_r5)


    def AddMoving_Ghost_r6(self, moving_Ghost_r6, indx):
        try:
            del self.AllMoving_Ghost_r6[indx]
        except IndexError:
            i = -1 # no match
        self.AllMoving_Ghost_r6.insert(indx, moving_Ghost_r6)


    def AddMoving_Ghost_r7(self, moving_Ghost_r7, indx):
        try:
            del self.AllMoving_Ghost_r7[indx]
        except IndexError:
            i = -1 # no match
        self.AllMoving_Ghost_r7.insert(indx, moving_Ghost_r7)


    def AddMoving_Ghost_r8(self, moving_Ghost_r8, indx):
        try:
            del self.AllMoving_Ghost_r8[indx]
        except IndexError:
            i = -1 # no match
        self.AllMoving_Ghost_r8.insert(indx, moving_Ghost_r8)



class SuntrackerAction(eg.ActionClass):
    iconFile = "suntracker"

    def __call__(
        self,
        dayTimeSettings,
        suntrackerName,
        eventNameOn,
        eventNameOff,
        moNight_OFF,
        moMorning_ON,
        moEvening_OFF,
        tuNight_OFF,
        tuMorning_ON,
        tuEvening_OFF,
        weNight_OFF,
        weMorning_ON,
        weEvening_OFF,
        thNight_OFF,
        thMorning_ON,
        thEvening_OFF,
        frNight_OFF,
        frMorning_ON,
        frEvening_OFF,
        saNight_OFF,
        saMorning_ON,
        saEvening_OFF,
        suNight_OFF,
        suMorning_ON,
        suEvening_OFF,
        vaNight_OFF,
        vaMorning_ON,
        vaEvening_OFF,
        fixedHolidays,
        variableHolidays,
        iNbrOfBurstsON,
        iNbrOfBurstsOFF,
        cmdDelay,
        doLogLoops,
        vacation_m,
        moving_Ghost,
        moving_Ghost_r1,
        moving_Ghost_r2,
        moving_Ghost_r3,
        moving_Ghost_r4,
        moving_Ghost_r5,
        moving_Ghost_r6,
        moving_Ghost_r7,
        moving_Ghost_r8,
        bDoSynch,
        iOffset,
        iMinOnPeriod,
        myLongitude,
        myLatitude,
        iSynchInterval
    ):
        self.plugin.StartSuntracker(
            dayTimeSettings,
            suntrackerName,
            eventNameOn,
            eventNameOff,
            self.plugin.fixedHolidays,
            self.plugin.variableHolidays,
            iNbrOfBurstsON,
            iNbrOfBurstsOFF,
            cmdDelay,
            doLogLoops,
            self.plugin.vacation_m,
            moving_Ghost,
            moving_Ghost_r1,
            moving_Ghost_r2,
            moving_Ghost_r3,
            moving_Ghost_r4,
            moving_Ghost_r5,
            moving_Ghost_r6,
            moving_Ghost_r7,
            moving_Ghost_r8,
            bDoSynch,
            iOffset,
            iMinOnPeriod,
            self.plugin.myLongitude,
            self.plugin.myLatitude,
            iSynchInterval
        )


    def GetLabel(
        self,
        dayTimeSettings,
        suntrackerName,
        eventNameOn,
        eventNameOff,
        moNight_OFF,
        moMorning_ON,
        moEvening_OFF,
        tuNight_OFF,
        tuMorning_ON,
        tuEvening_OFF,
        weNight_OFF,
        weMorning_ON,
        weEvening_OFF,
        thNight_OFF,
        thMorning_ON,
        thEvening_OFF,
        frNight_OFF,
        frMorning_ON,
        frEvening_OFF,
        saNight_OFF,
        saMorning_ON,
        saEvening_OFF,
        suNight_OFF,
        suMorning_ON,
        suEvening_OFF,
        vaNight_OFF,
        vaMorning_ON,
        vaEvening_OFF,
        fixedHolidays,
        variableHolidays,
        iNbrOfBurstsON,
        iNbrOfBurstsOFF,
        cmdDelay,
        doLogLoops,
        vacation_m,
        moving_Ghost,
        moving_Ghost_r1,
        moving_Ghost_r2,
        moving_Ghost_r3,
        moving_Ghost_r4,
        moving_Ghost_r5,
        moving_Ghost_r6,
        moving_Ghost_r7,
        moving_Ghost_r8,
        bDoSynch,
        iOffset,
        iMinOnPeriod,
        myLongitude,
        myLatitude,
        iSynchInterval
    ):
        indx = self.plugin.AddSuntrackerName(suntrackerName)
        self.plugin.AddDayTimeSettings(dayTimeSettings, indx)
        self.plugin.AddEventNameOn(eventNameOn, indx)
        self.plugin.AddEventNameOff(eventNameOff, indx)
        self.plugin.AddInbrOfBurstsON(iNbrOfBurstsON, indx)
        self.plugin.AddInbrOfBurstsOFF(iNbrOfBurstsOFF, indx)
        self.plugin.AddCmdDelay(cmdDelay, indx)
        self.plugin.AddDoLogLoops(doLogLoops, indx)
        self.plugin.AddBdoSynch(bDoSynch, indx)
        self.plugin.AddIsynchInterval(iSynchInterval, indx)
        self.plugin.AddiOffset(iOffset, indx)
        self.plugin.AddiMinOnPeriod(iMinOnPeriod, indx)
        self.plugin.AddMoving_Ghost(moving_Ghost, indx)
        self.plugin.AddMoving_Ghost_r1(moving_Ghost_r1, indx)
        self.plugin.AddMoving_Ghost_r2(moving_Ghost_r2, indx)
        self.plugin.AddMoving_Ghost_r3(moving_Ghost_r3, indx)
        self.plugin.AddMoving_Ghost_r4(moving_Ghost_r4, indx)
        self.plugin.AddMoving_Ghost_r5(moving_Ghost_r5, indx)
        self.plugin.AddMoving_Ghost_r6(moving_Ghost_r6, indx)
        self.plugin.AddMoving_Ghost_r7(moving_Ghost_r7, indx)
        self.plugin.AddMoving_Ghost_r8(moving_Ghost_r8, indx)
        
        return self.text.labelStart % (suntrackerName)


    def timeFormat(self, theString):
        if theString == "----":
            return theString 
        if (
            theString == "0000"
            or theString == "000"
            or theString == "00"
            or theString == "0"
            or theString == ""
        ):
            return "----" 
        if len(theString) != 4:
            return "----" 
        dat1 = theString[:2]
        dat2 = theString[2:]
        if int(dat1)>23:
            dat1 = "23"
        if int(dat2)>59:
            dat2 = "59"
        return(dat1+dat2)


    def nightOffFormat(self, theString):
        if theString == "----":
            return theString 
        elif int(theString) < int("0001"):
            return "0001"
        elif int(theString) > int("0559"):
            return "0559"
        return theString
        
            
    def morningOnFormat(self, theString):
        if theString == "----":
            return theString 
        elif int(theString) < int("0001"):
            return "0001"
        elif int(theString) > int("1159"):
            return "1159"
        return theString
        
            
    def eveningOffFormat(self, theString):
        if theString == "----":
            return theString 
        elif int(theString) <= int("1800"):
            return "1801"
        elif int(theString) > int("2359"):
            return "2359"
        return theString


    def Configure(
        self,
        dayTimeSettings = [],
        suntrackerName = "Give suntracker a name",
        eventNameOn = "nn ON",
        eventNameOff = "nn OFF",
        moNight_OFF = "----",
        moMorning_ON = "----",
        moEvening_OFF = "----",
        tuNight_OFF = "----",
        tuMorning_ON = "----",
        tuEvening_OFF = "----",
        weNight_OFF = "----",
        weMorning_ON = "----",
        weEvening_OFF = "----",
        thNight_OFF = "----",
        thMorning_ON = "----",
        thEvening_OFF = "----",
        frNight_OFF = "----",
        frMorning_ON = "----",
        frEvening_OFF = "----",
        saNight_OFF = "----",
        saMorning_ON = "----",
        saEvening_OFF = "----",
        suNight_OFF = "----",
        suMorning_ON = "----",
        suEvening_OFF = "----",
        vaNight_OFF = "----",
        vaMorning_ON = "----",
        vaEvening_OFF = "----",
        fixedHolidays = "0101,0501,0606,1224,1225,1226,1231",
        variableHolidays = "0106,0321,0324,0620",
        iNbrOfBurstsON = 1,
        iNbrOfBurstsOFF = 1,
        cmdDelay = 1.5,
        doLogLoops = True,
        vacation_m = False,
        moving_Ghost = False,
        moving_Ghost_r1 = 10,
        moving_Ghost_r2 = 40,
        moving_Ghost_r3 = 10,
        moving_Ghost_r4 = 40,
        moving_Ghost_r5 = 3,
        moving_Ghost_r6 = 10,
        moving_Ghost_r7 = 40,
        moving_Ghost_r8 = 80,
        bDoSynch = True,
        iOffset = 0,
        iMinOnPeriod = 10,
        myLongitude = "18.0000",
        myLatitude = "59.2500",
        iSynchInterval = 30
    ):
        plugin = self.plugin
        panel = eg.ConfigPanel(self)
        mySizer_1 = wx.GridBagSizer(5, 5)
        mySizer_2 = wx.GridBagSizer(5, 5)
        mySizer_3 = wx.GridBagSizer(5, 5)
        mySizer_4 = wx.GridBagSizer(5, 5)

        #name
        suntrackerNameCtrl = wx.TextCtrl(panel, -1, suntrackerName)
        suntrackerNameCtrl.SetInitialSize((250,-1))
        mySizer_1.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.suntrackerName
            ),
            (0,0)
        )
        mySizer_1.Add(suntrackerNameCtrl, (0,1))
      
        #eventName ON
        eventNameOnCtrl = wx.TextCtrl(panel, -1, eventNameOn)
        eventNameOnCtrl.SetInitialSize((150,-1))
        mySizer_1.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.eventNameOn
            ),
            (1,0)
        )
        mySizer_1.Add(eventNameOnCtrl, (1,1))

        #eventName OFF
        eventNameOffCtrl = wx.TextCtrl(panel, -1, eventNameOff)
        eventNameOffCtrl.SetInitialSize((150,-1))
        mySizer_1.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.eventNameOff
            ),
            (2,0)
        )
        mySizer_1.Add(eventNameOffCtrl, (2,1))

        moNight_OFFCtrl = wx.TextCtrl(panel, -1, moNight_OFF)
        moNight_OFFCtrl.SetInitialSize((35,-1))
        moMorning_ONCtrl = wx.TextCtrl(panel, -1, moMorning_ON)
        moMorning_ONCtrl.SetInitialSize((35,-1))
        moEvening_OFFCtrl = wx.TextCtrl(panel, -1, moEvening_OFF)
        moEvening_OFFCtrl.SetInitialSize((35,-1))

        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_moNightOFF
            ),
            (1,0)
        )
        mySizer_2.Add(moNight_OFFCtrl, (1,1))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_moMorningON
            ),
            (1,2)
        )
        mySizer_2.Add(moMorning_ONCtrl, (1,3))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_moEveningOFF
            ),
            (1,4)
        )
        mySizer_2.Add(moEvening_OFFCtrl, (1,5))

        tuNight_OFFCtrl = wx.TextCtrl(panel, -1, tuNight_OFF)
        tuNight_OFFCtrl.SetInitialSize((35,-1))
        tuMorning_ONCtrl = wx.TextCtrl(panel, -1, tuMorning_ON)
        tuMorning_ONCtrl.SetInitialSize((35,-1))
        tuEvening_OFFCtrl = wx.TextCtrl(panel, -1, tuEvening_OFF)
        tuEvening_OFFCtrl.SetInitialSize((35,-1))

        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_tuNightOFF
            ),
            (2,0)
        )
        mySizer_2.Add(tuNight_OFFCtrl, (2,1))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_tuMorningON
            ),
            (2,2)
        )
        mySizer_2.Add(tuMorning_ONCtrl, (2,3))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_tuEveningOFF
            ),
            (2,4)
        )
        mySizer_2.Add(tuEvening_OFFCtrl, (2,5))

        weNight_OFFCtrl = wx.TextCtrl(panel, -1, weNight_OFF)
        weNight_OFFCtrl.SetInitialSize((35,-1))
        weMorning_ONCtrl = wx.TextCtrl(panel, -1, weMorning_ON)
        weMorning_ONCtrl.SetInitialSize((35,-1))
        weEvening_OFFCtrl = wx.TextCtrl(panel, -1, weEvening_OFF)
        weEvening_OFFCtrl.SetInitialSize((35,-1))

        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_weNightOFF
            ),
            (3,0)
        )
        mySizer_2.Add(weNight_OFFCtrl, (3,1))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_weMorningON
            ),
            (3,2)
        )
        mySizer_2.Add(weMorning_ONCtrl, (3,3))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_weEveningOFF
            ),
            (3,4)
        )
        mySizer_2.Add(weEvening_OFFCtrl, (3,5))

        thNight_OFFCtrl = wx.TextCtrl(panel, -1, thNight_OFF)
        thNight_OFFCtrl.SetInitialSize((35,-1))
        thMorning_ONCtrl = wx.TextCtrl(panel, -1, thMorning_ON)
        thMorning_ONCtrl.SetInitialSize((35,-1))
        thEvening_OFFCtrl = wx.TextCtrl(panel, -1, thEvening_OFF)
        thEvening_OFFCtrl.SetInitialSize((35,-1))

        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_thNightOFF
            ),
            (4,0)
        )
        mySizer_2.Add(thNight_OFFCtrl, (4,1))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_thMorningON
            ),
            (4,2)
        )
        mySizer_2.Add(thMorning_ONCtrl, (4,3))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_thEveningOFF
            ),
            (4,4)
        )
        mySizer_2.Add(thEvening_OFFCtrl, (4,5))

        frNight_OFFCtrl = wx.TextCtrl(panel, -1, frNight_OFF)
        frNight_OFFCtrl.SetInitialSize((35,-1))
        frMorning_ONCtrl = wx.TextCtrl(panel, -1, frMorning_ON)
        frMorning_ONCtrl.SetInitialSize((35,-1))
        frEvening_OFFCtrl = wx.TextCtrl(panel, -1, frEvening_OFF)
        frEvening_OFFCtrl.SetInitialSize((35,-1))

        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_frNightOFF
            ),
            (5,0)
        )
        mySizer_2.Add(frNight_OFFCtrl, (5,1))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_frMorningON
            ),
            (5,2)
        )
        mySizer_2.Add(frMorning_ONCtrl, (5,3))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_frEveningOFF
            ),
            (5,4)
        )
        mySizer_2.Add(frEvening_OFFCtrl, (5,5))

        saNight_OFFCtrl = wx.TextCtrl(panel, -1, saNight_OFF)
        saNight_OFFCtrl.SetInitialSize((35,-1))
        saMorning_ONCtrl = wx.TextCtrl(panel, -1, saMorning_ON)
        saMorning_ONCtrl.SetInitialSize((35,-1))
        saEvening_OFFCtrl = wx.TextCtrl(panel, -1, saEvening_OFF)
        saEvening_OFFCtrl.SetInitialSize((35,-1))

        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_saNightOFF
            ),
            (6,0)
        )
        mySizer_2.Add(saNight_OFFCtrl, (6,1))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_saMorningON
            ),
            (6,2)
        )
        mySizer_2.Add(saMorning_ONCtrl, (6,3))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_saEveningOFF
            ),
            (6,4)
        )
        mySizer_2.Add(saEvening_OFFCtrl, (6,5))

        suNight_OFFCtrl = wx.TextCtrl(panel, -1, suNight_OFF)
        suNight_OFFCtrl.SetInitialSize((35,-1))
        suMorning_ONCtrl = wx.TextCtrl(panel, -1, suMorning_ON)
        suMorning_ONCtrl.SetInitialSize((35,-1))
        suEvening_OFFCtrl = wx.TextCtrl(panel, -1, suEvening_OFF)
        suEvening_OFFCtrl.SetInitialSize((35,-1))

        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_suNightOFF
            ),
            (7,0)
        )
        mySizer_2.Add(suNight_OFFCtrl, (7,1))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_suMorningON
            ),
            (7,2)
        )
        mySizer_2.Add(suMorning_ONCtrl, (7,3))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_suEveningOFF
            ),
            (7,4)
        )
        mySizer_2.Add(suEvening_OFFCtrl, (7,5))

        vaNight_OFFCtrl = wx.TextCtrl(panel, -1, vaNight_OFF)
        vaNight_OFFCtrl.SetInitialSize((35,-1))
        vaMorning_ONCtrl = wx.TextCtrl(panel, -1, vaMorning_ON)
        vaMorning_ONCtrl.SetInitialSize((35,-1))
        vaEvening_OFFCtrl = wx.TextCtrl(panel, -1, vaEvening_OFF)
        vaEvening_OFFCtrl.SetInitialSize((35,-1))

        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_vaNightOFF
            ),
            (8,0)
        )
        mySizer_2.Add(vaNight_OFFCtrl, (8,1))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_vaMorningON
            ),
            (8,2)
        )
        mySizer_2.Add(vaMorning_ONCtrl, (8,3))
        mySizer_2.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txt_vaEveningOFF
            ),
            (8,4)
        )
        mySizer_2.Add(vaEvening_OFFCtrl, (8,5))

        iNbrOfBurstsCtrlON = panel.SpinIntCtrl(iNbrOfBurstsON, 1, 10)
        iNbrOfBurstsCtrlON.SetInitialSize((45,-1))

        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtNbrBursts
            ),
            (1,0)
        )
        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtON
            ),
            (1,1)
        )
        mySizer_3.Add(iNbrOfBurstsCtrlON, (1,2))

        iNbrOfBurstsCtrlOFF = panel.SpinIntCtrl(iNbrOfBurstsOFF, 1, 10)
        iNbrOfBurstsCtrlOFF.SetInitialSize((45,-1))

        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtNbrBursts
            ),
            (2,0)
        )
        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtOFF
            ),
            (2,1)
        )
        mySizer_3.Add(iNbrOfBurstsCtrlOFF, (2,2))

        cmdDelayCtrl = panel.SpinNumCtrl(
            cmdDelay,
            decimalChar = '.',                 # by default, use '.' for decimal point
            groupChar = ',',                   # by default, use ',' for grouping
            fractionWidth = 1,
            integerWidth = 2,
            min = 0.5,
            max = 5.0,
            increment = 0.5
        )
        cmdDelayCtrl.SetInitialSize((45,-1))

        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtCmdDelay
            ),
            (3,0)
        )
        mySizer_3.Add(cmdDelayCtrl, (3,1))

        iMinOnPeriodCtrl = panel.SpinIntCtrl(iMinOnPeriod, 0, 60)
        iMinOnPeriodCtrl.SetInitialSize((40,-1))

        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMinOnPeriod
            ),
            (4,0)
        )
        mySizer_3.Add(iMinOnPeriodCtrl, (4,1))

        bDoSynchCtrl = wx.CheckBox(panel, -1, "")
        bDoSynchCtrl.SetValue(bDoSynch)

        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtDoSynch
            ),
            (5,0)
        )
        mySizer_3.Add(bDoSynchCtrl, (5,1))

        iSynchIntervalCtrl = panel.SpinIntCtrl(iSynchInterval, 6, 600)
        iSynchIntervalCtrl.SetInitialSize((50,-1))

        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtSynchInterval
            ),
            (5,2)
        )
        mySizer_3.Add(iSynchIntervalCtrl, (5,3))

        iOffsetCtrl = panel.SpinIntCtrl(iOffset, -120, 120)
        iOffsetCtrl.SetInitialSize((50,-1))
        
        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtOffset
            ),
            (6,0)
        )
        mySizer_3.Add(iOffsetCtrl, (6,1))

        doLogLoopsCtrl = wx.CheckBox(panel, -1, "")
        doLogLoopsCtrl.SetValue(doLogLoops)

        mySizer_3.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.doLogLoopsText
            ),
            (7,0)
        )
        mySizer_3.Add(doLogLoopsCtrl, (7,1))
        
        moving_GhostCtrl = wx.CheckBox(panel, -1, "")
        moving_GhostCtrl.SetValue(moving_Ghost)

        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost
            ),
            (1,0)
        )
        mySizer_4.Add(moving_GhostCtrl, (1,1))

        moving_Ghost_r1Ctrl = panel.SpinIntCtrl(moving_Ghost_r1, 1, 99)
        moving_Ghost_r1Ctrl.SetInitialSize((45,-1))
        moving_Ghost_r2Ctrl = panel.SpinIntCtrl(moving_Ghost_r2, 1, 99)
        moving_Ghost_r2Ctrl.SetInitialSize((45,-1))
        moving_Ghost_r3Ctrl = panel.SpinIntCtrl(moving_Ghost_r3, 1, 99)
        moving_Ghost_r3Ctrl.SetInitialSize((45,-1))
        moving_Ghost_r4Ctrl = panel.SpinIntCtrl(moving_Ghost_r4, 1, 99)
        moving_Ghost_r4Ctrl.SetInitialSize((45,-1))

        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_r_1
            ),
            (2,0)
        )
        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_ON_min
            ),
            (2,1)
        )
        mySizer_4.Add(moving_Ghost_r1Ctrl, (2,2))
        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_ON_max
            ),
            (2,3)
        )
        mySizer_4.Add(moving_Ghost_r2Ctrl, (2,4))
        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_OFF_min
            ),
            (2,5)
        )
        mySizer_4.Add(moving_Ghost_r3Ctrl, (2,6))
        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_OFF_max
            ),
            (2,7)
        )
        mySizer_4.Add(moving_Ghost_r4Ctrl, (2,8))

        moving_Ghost_r5Ctrl = panel.SpinIntCtrl(moving_Ghost_r5, 1, 99)
        moving_Ghost_r5Ctrl.SetInitialSize((45,-1))
        moving_Ghost_r6Ctrl = panel.SpinIntCtrl(moving_Ghost_r6, 1, 99)
        moving_Ghost_r6Ctrl.SetInitialSize((45,-1))
        moving_Ghost_r7Ctrl = panel.SpinIntCtrl(moving_Ghost_r7, 1, 99)
        moving_Ghost_r7Ctrl.SetInitialSize((45,-1))
        moving_Ghost_r8Ctrl = panel.SpinIntCtrl(moving_Ghost_r8, 1, 99)
        moving_Ghost_r8Ctrl.SetInitialSize((45,-1))

        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_r_2
            ),
            (3,0)
        )
        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_ON_min
            ),
            (3,1)
        )
        mySizer_4.Add(moving_Ghost_r5Ctrl, (3,2))
        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_ON_max
            ),
            (3,3)
        )
        mySizer_4.Add(moving_Ghost_r6Ctrl, (3,4))
        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_OFF_min
            ),
            (3,5)
        )
        mySizer_4.Add(moving_Ghost_r7Ctrl, (3,6))
        mySizer_4.Add(
            wx.StaticText(
                panel,
                -1,
                self.text.txtMoving_Ghost_OFF_max
            ),
            (3,7)
        )
        mySizer_4.Add(moving_Ghost_r8Ctrl, (3,8))

        panel.sizer.Add(mySizer_1, 0, flag = wx.EXPAND)
        panel.sizer.Add(mySizer_2, 0, flag = wx.EXPAND)
        panel.sizer.Add(mySizer_3, 0, flag = wx.EXPAND)
        panel.sizer.Add(mySizer_4, 0, flag = wx.EXPAND)
        
        def OnButton(event): 
            # re-assign the OK button
            
            event.Skip()
            
            dayTimeSettings = []
            suntrackerName = suntrackerNameCtrl.GetValue()
            plugin.lastSuntrackerName = suntrackerName
            indx = plugin.AddSuntrackerName(suntrackerName)
            eventNameOn = eventNameOnCtrl.GetValue()
            plugin.AddEventNameOn(eventNameOn, indx)
            eventNameOff = eventNameOffCtrl.GetValue()
            plugin.AddEventNameOff(eventNameOff, indx)
            iNbrOfBurstsON = iNbrOfBurstsCtrlON.GetValue()
            plugin.AddInbrOfBurstsON(iNbrOfBurstsON, indx)
            iNbrOfBurstsOFF = iNbrOfBurstsCtrlOFF.GetValue()
            plugin.AddInbrOfBurstsOFF(iNbrOfBurstsOFF, indx)
            cmdDelay = cmdDelayCtrl.GetValue()
            plugin.AddCmdDelay(cmdDelay, indx)
            doLogLoops = doLogLoopsCtrl.GetValue()
            plugin.AddDoLogLoops(doLogLoops, indx)
            bDoSynch = bDoSynchCtrl.GetValue()
            plugin.AddBdoSynch(bDoSynch, indx)
            iSynchInterval = iSynchIntervalCtrl.GetValue()
            plugin.AddIsynchInterval(iSynchInterval, indx)
            iOffset = iOffsetCtrl.GetValue()
            plugin.AddiOffset(iOffset, indx)
            iMinOnPeriod = iMinOnPeriodCtrl.GetValue()
            plugin.AddiMinOnPeriod(iMinOnPeriod, indx)
            moving_Ghost = moving_GhostCtrl.GetValue()
            plugin.AddMoving_Ghost(moving_Ghost, indx)

            moving_Ghost_r1 = moving_Ghost_r1Ctrl.GetValue()
            plugin.AddMoving_Ghost_r1(moving_Ghost_r1, indx)
            moving_Ghost_r2 = moving_Ghost_r2Ctrl.GetValue()
            plugin.AddMoving_Ghost_r2(moving_Ghost_r2, indx)
            moving_Ghost_r3 = moving_Ghost_r3Ctrl.GetValue()
            plugin.AddMoving_Ghost_r3(moving_Ghost_r3, indx)
            moving_Ghost_r4 = moving_Ghost_r4Ctrl.GetValue()
            plugin.AddMoving_Ghost_r4(moving_Ghost_r4, indx)
            moving_Ghost_r5 = moving_Ghost_r5Ctrl.GetValue()
            plugin.AddMoving_Ghost_r5(moving_Ghost_r5, indx)
            moving_Ghost_r6 = moving_Ghost_r6Ctrl.GetValue()
            plugin.AddMoving_Ghost_r6(moving_Ghost_r6, indx)
            moving_Ghost_r7 = moving_Ghost_r7Ctrl.GetValue()
            plugin.AddMoving_Ghost_r7(moving_Ghost_r7, indx)
            moving_Ghost_r8 = moving_Ghost_r8Ctrl.GetValue()
            plugin.AddMoving_Ghost_r8(moving_Ghost_r8, indx)
 
            moNight_OFF = self.timeFormat(moNight_OFFCtrl.GetValue())
            moNight_OFF = self.nightOffFormat(moNight_OFF)
            dayTimeSettings.append(moNight_OFF)
            moMorning_ON = self.timeFormat(moMorning_ONCtrl.GetValue())
            moMorning_ON = self.morningOnFormat(moMorning_ON)
            dayTimeSettings.append(moMorning_ON)
            moEvening_OFF = self.timeFormat(moEvening_OFFCtrl.GetValue())
            moEvening_OFF = self.eveningOffFormat(moEvening_OFF)
            dayTimeSettings.append(moEvening_OFF)

            tuNight_OFF = self.timeFormat(tuNight_OFFCtrl.GetValue())
            tuNight_OFF = self.nightOffFormat(tuNight_OFF)
            dayTimeSettings.append(tuNight_OFF)
            tuMorning_ON = self.timeFormat(tuMorning_ONCtrl.GetValue())
            tuMorning_ON = self.morningOnFormat(tuMorning_ON)
            dayTimeSettings.append(tuMorning_ON)
            tuEvening_OFF = self.timeFormat(tuEvening_OFFCtrl.GetValue())
            tuEvening_OFF = self.eveningOffFormat(tuEvening_OFF)
            dayTimeSettings.append(tuEvening_OFF)

            weNight_OFF = self.timeFormat(weNight_OFFCtrl.GetValue())
            weNight_OFF = self.nightOffFormat(weNight_OFF)
            dayTimeSettings.append(weNight_OFF)
            weMorning_ON = self.timeFormat(weMorning_ONCtrl.GetValue())
            weMorning_ON = self.morningOnFormat(weMorning_ON)
            dayTimeSettings.append(weMorning_ON)
            weEvening_OFF = self.timeFormat(weEvening_OFFCtrl.GetValue())
            weEvening_OFF = self.eveningOffFormat(weEvening_OFF)
            dayTimeSettings.append(weEvening_OFF)

            thNight_OFF = self.timeFormat(thNight_OFFCtrl.GetValue())
            thNight_OFF = self.nightOffFormat(thNight_OFF)
            dayTimeSettings.append(thNight_OFF)
            thMorning_ON = self.timeFormat(thMorning_ONCtrl.GetValue())
            thMorning_ON = self.morningOnFormat(thMorning_ON)
            dayTimeSettings.append(thMorning_ON)
            thEvening_OFF = self.timeFormat(thEvening_OFFCtrl.GetValue())
            thEvening_OFF = self.eveningOffFormat(thEvening_OFF)
            dayTimeSettings.append(thEvening_OFF)

            frNight_OFF = self.timeFormat(frNight_OFFCtrl.GetValue())
            frNight_OFF = self.nightOffFormat(frNight_OFF)
            dayTimeSettings.append(frNight_OFF)
            frMorning_ON = self.timeFormat(frMorning_ONCtrl.GetValue())
            frMorning_ON = self.morningOnFormat(frMorning_ON)
            dayTimeSettings.append(frMorning_ON)
            frEvening_OFF = self.timeFormat(frEvening_OFFCtrl.GetValue())
            frEvening_OFF = self.eveningOffFormat(frEvening_OFF)
            dayTimeSettings.append(frEvening_OFF)

            saNight_OFF = self.timeFormat(saNight_OFFCtrl.GetValue())
            saNight_OFF = self.nightOffFormat(saNight_OFF)
            dayTimeSettings.append(saNight_OFF)
            saMorning_ON = self.timeFormat(saMorning_ONCtrl.GetValue())
            saMorning_ON = self.morningOnFormat(saMorning_ON)
            dayTimeSettings.append(saMorning_ON)
            saEvening_OFF = self.timeFormat(saEvening_OFFCtrl.GetValue())
            saEvening_OFF = self.eveningOffFormat(saEvening_OFF)
            dayTimeSettings.append(saEvening_OFF)

            suNight_OFF = self.timeFormat(suNight_OFFCtrl.GetValue())
            suNight_OFF = self.nightOffFormat(suNight_OFF)
            dayTimeSettings.append(suNight_OFF)
            suMorning_ON = self.timeFormat(suMorning_ONCtrl.GetValue())
            suMorning_ON = self.morningOnFormat(suMorning_ON)
            dayTimeSettings.append(suMorning_ON)
            suEvening_OFF = self.timeFormat(suEvening_OFFCtrl.GetValue())
            suEvening_OFF = self.eveningOffFormat(suEvening_OFF)
            dayTimeSettings.append(suEvening_OFF)

            vaNight_OFF = self.timeFormat(vaNight_OFFCtrl.GetValue())
            vaNight_OFF = self.nightOffFormat(vaNight_OFF)
            dayTimeSettings.append(vaNight_OFF)
            vaMorning_ON = self.timeFormat(vaMorning_ONCtrl.GetValue())
            vaMorning_ON = self.morningOnFormat(vaMorning_ON)
            dayTimeSettings.append(vaMorning_ON)
            vaEvening_OFF = self.timeFormat(vaEvening_OFFCtrl.GetValue())
            vaEvening_OFF = self.eveningOffFormat(vaEvening_OFF)
            dayTimeSettings.append(vaEvening_OFF)

            plugin.AddDayTimeSettings(dayTimeSettings, indx)

            self.plugin.StartSuntracker(
                dayTimeSettings,
                suntrackerName,
                eventNameOn,
                eventNameOff,
                self.plugin.fixedHolidays,
                self.plugin.variableHolidays,
                iNbrOfBurstsON,
                iNbrOfBurstsOFF,
                cmdDelay,
                doLogLoops,
                self.plugin.vacation_m,
                moving_Ghost,
                moving_Ghost_r1,
                moving_Ghost_r2,
                moving_Ghost_r3,
                moving_Ghost_r4,
                moving_Ghost_r5,
                moving_Ghost_r6,
                moving_Ghost_r7,
                moving_Ghost_r8,
                bDoSynch,
                iOffset,
                iMinOnPeriod,
                self.plugin.myLongitude,
                self.plugin.myLatitude,
                iSynchInterval
            )
                        
        panel.dialog.buttonRow.okButton.Bind(wx.EVT_BUTTON, OnButton)

        while panel.Affirmed():
            dayTimeSettings = []
            suntrackerName = suntrackerNameCtrl.GetValue()
            plugin.lastSuntrackerName = suntrackerName
            indx = plugin.AddSuntrackerName(suntrackerName)
            eventNameOn = eventNameOnCtrl.GetValue()
            plugin.AddEventNameOn(eventNameOn, indx)
            eventNameOff = eventNameOffCtrl.GetValue()
            plugin.AddEventNameOff(eventNameOff, indx)
            iNbrOfBurstsON = iNbrOfBurstsCtrlON.GetValue()
            plugin.AddInbrOfBurstsON(iNbrOfBurstsON, indx)
            iNbrOfBurstsOFF = iNbrOfBurstsCtrlOFF.GetValue()
            plugin.AddInbrOfBurstsOFF(iNbrOfBurstsOFF, indx)
            cmdDelay = cmdDelayCtrl.GetValue()
            plugin.AddCmdDelay(cmdDelay, indx)
            doLogLoops = doLogLoopsCtrl.GetValue()
            plugin.AddDoLogLoops(doLogLoops, indx)
            bDoSynch = bDoSynchCtrl.GetValue()
            plugin.AddBdoSynch(bDoSynch, indx)
            iSynchInterval = iSynchIntervalCtrl.GetValue()
            plugin.AddIsynchInterval(iSynchInterval, indx)
            iOffset = iOffsetCtrl.GetValue()
            plugin.AddiOffset(iOffset, indx)
            iMinOnPeriod = iMinOnPeriodCtrl.GetValue()
            plugin.AddiMinOnPeriod(iMinOnPeriod, indx)

            fixedHolidays = self.plugin.fixedHolidays
            variableHolidays = self.plugin.variableHolidays
            myLongitude = str(self.plugin.myLongitude)
            myLatitude = str(self.plugin.myLatitude)
            vacation_m = self.plugin.vacation_m

            moving_Ghost = moving_GhostCtrl.GetValue()
            plugin.AddMoving_Ghost(moving_Ghost, indx)
            moving_Ghost_r1 = moving_Ghost_r1Ctrl.GetValue()
            plugin.AddMoving_Ghost_r1(moving_Ghost_r1, indx)
            moving_Ghost_r2 = moving_Ghost_r2Ctrl.GetValue()
            plugin.AddMoving_Ghost_r2(moving_Ghost_r2, indx)
            moving_Ghost_r3 = moving_Ghost_r3Ctrl.GetValue()
            plugin.AddMoving_Ghost_r3(moving_Ghost_r3, indx)
            moving_Ghost_r4 = moving_Ghost_r4Ctrl.GetValue()
            plugin.AddMoving_Ghost_r4(moving_Ghost_r4, indx)
            moving_Ghost_r5 = moving_Ghost_r5Ctrl.GetValue()
            plugin.AddMoving_Ghost_r5(moving_Ghost_r5, indx)
            moving_Ghost_r6 = moving_Ghost_r6Ctrl.GetValue()
            plugin.AddMoving_Ghost_r6(moving_Ghost_r6, indx)
            moving_Ghost_r7 = moving_Ghost_r7Ctrl.GetValue()
            plugin.AddMoving_Ghost_r7(moving_Ghost_r7, indx)
            moving_Ghost_r8 = moving_Ghost_r8Ctrl.GetValue()
            plugin.AddMoving_Ghost_r8(moving_Ghost_r8, indx)
 
            moNight_OFF = self.timeFormat(moNight_OFFCtrl.GetValue())
            moNight_OFF = self.nightOffFormat(moNight_OFF)
            dayTimeSettings.append(moNight_OFF)
            moMorning_ON = self.timeFormat(moMorning_ONCtrl.GetValue())
            moMorning_ON = self.morningOnFormat(moMorning_ON)
            dayTimeSettings.append(moMorning_ON)
            moEvening_OFF = self.timeFormat(moEvening_OFFCtrl.GetValue())
            moEvening_OFF = self.eveningOffFormat(moEvening_OFF)
            dayTimeSettings.append(moEvening_OFF)

            tuNight_OFF = self.timeFormat(tuNight_OFFCtrl.GetValue())
            tuNight_OFF = self.nightOffFormat(tuNight_OFF)
            dayTimeSettings.append(tuNight_OFF)
            tuMorning_ON = self.timeFormat(tuMorning_ONCtrl.GetValue())
            tuMorning_ON = self.morningOnFormat(tuMorning_ON)
            dayTimeSettings.append(tuMorning_ON)
            tuEvening_OFF = self.timeFormat(tuEvening_OFFCtrl.GetValue())
            tuEvening_OFF = self.eveningOffFormat(tuEvening_OFF)
            dayTimeSettings.append(tuEvening_OFF)

            weNight_OFF = self.timeFormat(weNight_OFFCtrl.GetValue())
            weNight_OFF = self.nightOffFormat(weNight_OFF)
            dayTimeSettings.append(weNight_OFF)
            weMorning_ON = self.timeFormat(weMorning_ONCtrl.GetValue())
            weMorning_ON = self.morningOnFormat(weMorning_ON)
            dayTimeSettings.append(weMorning_ON)
            weEvening_OFF = self.timeFormat(weEvening_OFFCtrl.GetValue())
            weEvening_OFF = self.eveningOffFormat(weEvening_OFF)
            dayTimeSettings.append(weEvening_OFF)

            thNight_OFF = self.timeFormat(thNight_OFFCtrl.GetValue())
            thNight_OFF = self.nightOffFormat(thNight_OFF)
            dayTimeSettings.append(thNight_OFF)
            thMorning_ON = self.timeFormat(thMorning_ONCtrl.GetValue())
            thMorning_ON = self.morningOnFormat(thMorning_ON)
            dayTimeSettings.append(thMorning_ON)
            thEvening_OFF = self.timeFormat(thEvening_OFFCtrl.GetValue())
            thEvening_OFF = self.eveningOffFormat(thEvening_OFF)
            dayTimeSettings.append(thEvening_OFF)

            frNight_OFF = self.timeFormat(frNight_OFFCtrl.GetValue())
            frNight_OFF = self.nightOffFormat(frNight_OFF)
            dayTimeSettings.append(frNight_OFF)
            frMorning_ON = self.timeFormat(frMorning_ONCtrl.GetValue())
            frMorning_ON = self.morningOnFormat(frMorning_ON)
            dayTimeSettings.append(frMorning_ON)
            frEvening_OFF = self.timeFormat(frEvening_OFFCtrl.GetValue())
            frEvening_OFF = self.eveningOffFormat(frEvening_OFF)
            dayTimeSettings.append(frEvening_OFF)

            saNight_OFF = self.timeFormat(saNight_OFFCtrl.GetValue())
            saNight_OFF = self.nightOffFormat(saNight_OFF)
            dayTimeSettings.append(saNight_OFF)
            saMorning_ON = self.timeFormat(saMorning_ONCtrl.GetValue())
            saMorning_ON = self.morningOnFormat(saMorning_ON)
            dayTimeSettings.append(saMorning_ON)
            saEvening_OFF = self.timeFormat(saEvening_OFFCtrl.GetValue())
            saEvening_OFF = self.eveningOffFormat(saEvening_OFF)
            dayTimeSettings.append(saEvening_OFF)

            suNight_OFF = self.timeFormat(suNight_OFFCtrl.GetValue())
            suNight_OFF = self.nightOffFormat(suNight_OFF)
            dayTimeSettings.append(suNight_OFF)
            suMorning_ON = self.timeFormat(suMorning_ONCtrl.GetValue())
            suMorning_ON = self.morningOnFormat(suMorning_ON)
            dayTimeSettings.append(suMorning_ON)
            suEvening_OFF = self.timeFormat(suEvening_OFFCtrl.GetValue())
            suEvening_OFF = self.eveningOffFormat(suEvening_OFF)
            dayTimeSettings.append(suEvening_OFF)

            vaNight_OFF = self.timeFormat(vaNight_OFFCtrl.GetValue())
            vaNight_OFF = self.nightOffFormat(vaNight_OFF)
            dayTimeSettings.append(vaNight_OFF)
            vaMorning_ON = self.timeFormat(vaMorning_ONCtrl.GetValue())
            vaMorning_ON = self.morningOnFormat(vaMorning_ON)
            dayTimeSettings.append(vaMorning_ON)
            vaEvening_OFF = self.timeFormat(vaEvening_OFFCtrl.GetValue())
            vaEvening_OFF = self.eveningOffFormat(vaEvening_OFF)
            dayTimeSettings.append(vaEvening_OFF)

            plugin.AddDayTimeSettings(dayTimeSettings, indx)

            panel.SetResult(
                dayTimeSettings,
                suntrackerName,
                eventNameOn,
                eventNameOff,
                moNight_OFF,
                moMorning_ON,
                moEvening_OFF,
                tuNight_OFF,
                tuMorning_ON,
                tuEvening_OFF,
                weNight_OFF,
                weMorning_ON,
                weEvening_OFF,
                thNight_OFF,
                thMorning_ON,
                thEvening_OFF,
                frNight_OFF,
                frMorning_ON,
                frEvening_OFF,
                saNight_OFF,
                saMorning_ON,
                saEvening_OFF,
                suNight_OFF,
                suMorning_ON,
                suEvening_OFF,
                vaNight_OFF,
                vaMorning_ON,
                vaEvening_OFF,
                fixedHolidays,
                variableHolidays,
                iNbrOfBurstsON,
                iNbrOfBurstsOFF,
                cmdDelay,
                doLogLoops,
                vacation_m,
                moving_Ghost,
                moving_Ghost_r1,
                moving_Ghost_r2,
                moving_Ghost_r3,
                moving_Ghost_r4,
                moving_Ghost_r5,
                moving_Ghost_r6,
                moving_Ghost_r7,
                moving_Ghost_r8,
                bDoSynch,
                iOffset,
                iMinOnPeriod,
                myLongitude,
                myLatitude,
                iSynchInterval
            )


             
class Sun:
#All credits to Henrik Haerkoenen for code parts in this class
    
    def __init__(self):

	# Some conversion factors between radians and degrees
	self.PI = 3.1415926535897932384
	self.RADEG = 180.0 / self.PI
	self.DEGRAD = self.PI / 180.0
	self.INV360 = 1.0 / 360.0
	

    def daysSince2000Jan0(self, y, m, d):
	"""A macro to compute the number of days elapsed since 2000 Jan 0.0
	   (which is equal to 1999 Dec 31, 0h UT)"""
	return (367*(y)-((7*((y)+(((m)+9)/12)))/4)+((275*(m))/9)+(d)-730530)
  

    # The trigonometric functions in degrees
    def sind(self, x):
	"""Returns the sin in degrees"""
	return math.sin(x * self.DEGRAD)


    def cosd(self, x):
	"""Returns the cos in degrees"""
	return math.cos(x * self.DEGRAD)


    def tand(self, x):
	"""Returns the tan in degrees"""
	return math.tan(x * self.DEGRAD)


    def atand(self, x):
	"""Returns the arc tan in degrees"""
	return math.atan(x) * self.RADEG

    
    def asind(self, x):
	"""Returns the arc sin in degrees"""
	return math.asin(x) * self.RADEG


    def acosd(self, x):
	"""Returns the arc cos in degrees"""
	return math.acos(x) * self.RADEG


    def atan2d(self, y, x):
	"""Returns the atan2 in degrees"""
	return math.atan2(y, x) * self.RADEG


    # Following are some macros around the "workhorse" function __daylen__ 
    # They mainly fill in the desired values for the reference altitude    
    # below the horizon, and also selects whether this altitude should     
    # refer to the Sun's center or its upper limb.                         

    def dayLength(self, year, month, day, lon, lat):
	"""
	This macro computes the length of the day, from sunrise to sunset.
	Sunrise/set is considered to occur when the Sun's upper limb is
	35 arc minutes below the horizon (this accounts for the refraction
	of the Earth's atmosphere).
	"""
	return self.__daylen__(year, month, day, lon, lat, -35.0/60.0, 1)

    
    def dayCivilTwilightLength(self, year, month, day, lon, lat):
	"""
	This macro computes the length of the day, including civil twilight.
	Civil twilight starts/ends when the Sun's center is 6 degrees below
	the horizon. 
	"""
	return self.__daylen__(year, month, day, lon, lat, -6.0, 0)


    def dayNauticalTwilightLength(self, year, month, day, lon, lat):
	"""
	This macro computes the length of the day, incl. nautical twilight.
	Nautical twilight starts/ends when the Sun's center is 12 degrees
	below the horizon.
	"""
	return self.__daylen__(year, month, day, lon, lat, -12.0, 0)


    def dayAstronomicalTwilightLength(self, year, month, day, lon, lat):
	"""
	This macro computes the length of the day, incl. astronomical twilight.
	Astronomical twilight starts/ends when the Sun's center is 18 degrees 
	below the horizon. 
	"""
	return self.__daylen__(year, month, day, lon, lat, -18.0, 0)

    
    def sunRiseSet(self, year, month, day, lon, lat):
	"""
	This macro computes times for sunrise/sunset.
	Sunrise/set is considered to occur when the Sun's upper limb is
	35 arc minutes below the horizon (this accounts for the refraction
	of the Earth's atmosphere).
	"""
	return self.__sunriset__(year, month, day, lon, lat, -35.0/60.0, 1)

    
    def civilTwilight(self, year, month, day, lon, lat):
	"""
	This macro computes the start and end times of civil twilight. 
	Civil twilight starts/ends when the Sun's center is 6 degrees below 
	the horizon.
	"""
	return self.__sunriset__(year, month, day, lon, lat, -6.0, 0)

    
    def nauticalTwilight(self, year, month, day, lon, lat):
	"""
	This macro computes the start and end times of nautical twilight.
	Nautical twilight starts/ends when the Sun's center is 12 degrees
	below the horizon.
	"""
	return self.__sunriset__(year, month, day, lon, lat, -12.0, 0)

    
    def astronomicalTwilight(self, year, month, day, lon, lat):
	"""
	This macro computes the start and end times of astronomical twilight.
	Astronomical twilight starts/ends when the Sun's center is 18 degrees
	below the horizon.
	"""
	return self.__sunriset__(year, month, day, lon, lat, -18.0, 0)

    
    # The "workhorse" function for sun rise/set times
    def __sunriset__(self, year, month, day, lon, lat, altit, upper_limb):

	# Compute d of 12h local mean solar time
	d = self.daysSince2000Jan0(year,month,day) + 0.5 - (lon/360.0)
	
	# Compute local sidereal time of this moment 
	sidtime = self.revolution(self.GMST0(d) + 180.0 + lon)
	
	# Compute Sun's RA + Decl at this moment 
	res = self.sunRADec(d)
	sRA = res[0]
	sdec = res[1]
	sr = res[2]
	
	# Compute time when Sun is at south - in hours UT 
	tsouth = 12.0 - self.rev180(sidtime - sRA)/15.0;
	
	# Compute the Sun's apparent radius, degrees 
	sradius = 0.2666 / sr;
	
	# Do correction to upper limb, if necessary 
	if upper_limb:
	    altit = altit - sradius
	
	# Compute the diurnal arc that the Sun traverses to reach 
	# the specified altitude altit: 
	
	cost = (self.sind(altit) - self.sind(lat) * self.sind(sdec))/\
               (self.cosd(lat) * self.cosd(sdec))

	if cost >= 1.0:
	    rc = -1 
	    t = 0.0           # Sun always below altit
	    
	elif cost <= -1.0:
	    rc = +1 
	    t = 12.0;         # Sun always above altit

	else:
	    t = self.acosd(cost)/15.0   # The diurnal arc, hours

	# Store rise and set times - in hours UT 
	return (tsouth-t, tsouth+t)


    def __daylen__(self, year, month, day, lon, lat, altit, upper_limb):
	
	# Compute d of 12h local mean solar time 
	d = self.daysSince2000Jan0(year,month,day) + 0.5 - (lon/360.0)
		 
	# Compute obliquity of ecliptic (inclination of Earth's axis) 
	obl_ecl = 23.4393 - 3.563E-7 * d
	
	# Compute Sun's position 
	res = self.sunpos(d)
	slon = res[0]
	sr = res[1]
	
	# Compute sine and cosine of Sun's declination 
	sin_sdecl = self.sind(obl_ecl) * self.sind(slon)
	cos_sdecl = math.sqrt(1.0 - sin_sdecl * sin_sdecl)
	
	# Compute the Sun's apparent radius, degrees 
	sradius = 0.2666 / sr
	
	# Do correction to upper limb, if necessary 
	if upper_limb:
	    altit = altit - sradius
	    
	cost = (self.sind(altit) - self.sind(lat) * sin_sdecl) / (self.cosd(lat) * cos_sdecl)
	if cost >= 1.0:
	    t = 0.0             # Sun always below altit
	
	elif cost <= -1.0:
	    t = 24.0      # Sun always above altit
	
	else:
	    t = (2.0/15.0) * self.acosd(cost);     # The diurnal arc, hours
	    
	return t

    
    def sunpos(self, d):
	"""
	Computes the Sun's ecliptic longitude and distance 
	at an instant given in d, number of days since     
	2000 Jan 0.0.  The Sun's ecliptic latitude is not  
	computed, since it's always very near 0.           
	"""

	# Compute mean elements 
	M = self.revolution(356.0470 + 0.9856002585 * d)
	w = 282.9404 + 4.70935E-5 * d
	e = 0.016709 - 1.151E-9 * d
	
	# Compute true longitude and radius vector 
	E = M + e * self.RADEG * self.sind(M) * (1.0 + e * self.cosd(M))
	x = self.cosd(E) - e
	y = math.sqrt(1.0 - e*e) * self.sind(E)
	r = math.sqrt(x*x + y*y)              #Solar distance 
	v = self.atan2d(y, x)                 # True anomaly 
	lon = v + w                        # True solar longitude 
	if lon >= 360.0:
	    lon = lon - 360.0   # Make it 0..360 degrees
	    
	return (lon,r)
    

    def sunRADec(self, d):
	""""""
	
	# Compute Sun's ecliptical coordinates 
	res = self.sunpos(d)
	lon = res[0]
	r = res[1]
	
	# Compute ecliptic rectangular coordinates (z=0) 
	x = r * self.cosd(lon)
	y = r * self.sind(lon)
	
	# Compute obliquity of ecliptic (inclination of Earth's axis) 
	obl_ecl = 23.4393 - 3.563E-7 * d
	
	# Convert to equatorial rectangular coordinates - x is unchanged 
	z = y * self.sind(obl_ecl)
	y = y * self.cosd(obl_ecl)

	# Convert to spherical coordinates 
	RA = self.atan2d(y, x)
	dec = self.atan2d(z, math.sqrt(x*x + y*y))

	return (RA, dec, r)


    def revolution(self, x):
	"""
	This function reduces any angle to within the first revolution 
	by subtracting or adding even multiples of 360.0 until the     
	result is >= 0.0 and < 360.0
	
	Reduce angle to within 0..360 degrees
	"""
	return (x - 360.0 * math.floor(x * self.INV360))

    
    def rev180(self, x):
	"""
	Reduce angle to within +180..+180 degrees
	""" 
	return (x - 360.0 * math.floor(x * self.INV360 + 0.5))


    def GMST0(self, d):
	# Sidtime at 0h UT = L (Sun's mean longitude) + 180.0 degr  
	# L = M + w, as defined in sunpos().  Since I'm too lazy to 
	# add these numbers, I'll let the C compiler do it for me.  
	# Any decent C compiler will add the constants at compile   
	# time, imposing no runtime or code overhead.               
						
	sidtim0 = self.revolution((180.0 + 356.0470 + 282.9404) +
	                             (0.9856002585 + 4.70935E-5) * d)
	return sidtim0;


    def solar_altitude(self, latitude, year, month, day):

        # Compute declination
        N = self.daysSince2000Jan0(year, month, day)
        res =  self.sunRADec(N)
        declination = res[1]
        sr = res[2]

        # Compute the altitude
        altitude = 90.0 - latitude  + declination

        # In the tropical and  in extreme latitude, values over 90 may occurs.
        if altitude > 90:
            altitude = 90 - (altitude-90)

        if altitude < 0:
            altitude = 0

        return altitude

# Modification for export of function when used in EG
# 2008-04-22 krambriw
k = Sun()
sunRiseSet = k.sunRiseSet



  
