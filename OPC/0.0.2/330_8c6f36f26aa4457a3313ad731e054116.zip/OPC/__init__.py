# -*- coding: utf-8 -*-
#
# Copyright (c) 2009, Walter Kraembring
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. Neither the name of Walter Kraembring nor the names of its contributors may
#    be used to endorse or promote products derived from this software without
#    specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


##############################################################################
# Revision history:
#
# 2011-05-27  Experimental change of SetProcessWorkingSetSize call
# 2011-05-25  First version, thanks to Barry Barnreiter for OpenOPC
# (barry_b@users.sourceforge.net) 
##############################################################################

eg.RegisterPlugin(
    name = "OPC",
    guid = '{3ABF9B84-1C04-42F0-81FE-69F29309DFC3}',
    author = "Walter Kraembring",
    version = "0.0.2",
    kind = "other",
    canMultiLoad = True,
    createMacrosOnAdd = False,
    url = "http://www.eventghost.net/forum/",
    description = (
        '<p>Plugin to connect to '
        'OPC DA Servers</a></p>'
        '\n\n<p>'
        '<center><img src="opc.png" /></center>'
    ),
)

import eg
import OpenOPC
import time
from eg.WinApi.Dynamic import (
    OpenProcess,
    PROCESS_SET_QUOTA,
    SetProcessWorkingSetSize,
    FormatError,
)
from threading import Event, Thread


 
class OPC_Client(eg.PluginClass):

    class text:
        infoOpcServerObject = "OPC object created"
        infoPlugin = "OPC plugin stopped" 
        infoStatus = "OPC is not found"
        infoNoDevice = "OPC was not found"
        infoThreadStopped = "OPC monitor thread has stopped"
        threadWaitTime = "Thread wait time (x.y s): "
        memoryLimit = "Set maximum amount of memory that EG may use (4-999 Mbytes): "
        selectBoxOpcServer = "Select the OPC server to connect to: "
        
    
    def __init__(self):
        self.q = 0
            
            
    def __start__(
            self,
            OPC_name,
            tw,
            limitMemorySize
        ):
        self.bOpcObjectCreated = False
        self.OPC_name = OPC_name
        self.opc = OpenOPC.client()
        self.iDelay = tw
        self.limitMemorySize = limitMemorySize
        
        self.stopThreadEvent = Event()
        thread = Thread(
            target=self.ThreadWorker,
            args=(self.stopThreadEvent,)
        )
        thread.start()


    def __stop__(self):
        if self.stopThreadEvent:
            self.stopThreadEvent.set()
        print self.text.infoPlugin

      
    def __close__(self):
        print self.text.infoPlugin


    def ThreadWorker(self, stopThreadEvent):
        self.hHandle = OpenProcess(PROCESS_SET_QUOTA, 0, eg.processId)
        while not stopThreadEvent.isSet():
            stopThreadEvent.wait(self.iDelay)
            if not self.bOpcObjectCreated:
                self.findOpcServer()
            for i in range (0,len(self.tags)):
                tag = str(self.tags[i])
                #print tag
                tag_items = self.items[i]
                #print tag_items
                for j in range (0,len(tag_items)):
                    value, quality, time = self.opc.read(tag_items[j])
                    print tag_items[j], "Value: ", value
            #print self.q
            if self.q > 20 or self.q == 0:
                eg.config.limitMemorySize = self.limitMemorySize
                SetProcessWorkingSetSize(
                    self.hHandle,
                    3670016,
                    eg.config.limitMemorySize * 1048576
                )
                self.q = 1
            self.q += 1
            
        self.opc.close()
        self.bOpcObjectCreated = False
        print self.text.infoThreadStopped


    def findOpcServer(self):
        self.tags = []
        self.items = []
        try:
            self.opc.connect(self.OPC_name)
            print self.opc.info()
            self.tags = self.opc.list()
            for i in range (0,len(self.tags)):
                tag = str(self.tags[i])
                self.items.append(self.opc.list(tag))
            self.bOpcObjectCreated = True
            print self.text.infoOpcServerObject
        except:
            self.bOpcObjectCreated = False
            eg.PrintError(self.text.infoStatus)


    # Get the choice from dropdown and perform some action
    def OnChoice(self, event):
        choice = event.GetSelection()
        event.Skip()
        return choice


    def Configure(
        self,
        OPC_name = "Select OPC server to control",
        tw = 0.5,
        limitMemorySize = 32,
        *args
     ):
        if self.stopThreadEvent:
            self.stopThreadEvent.set()

        panel = eg.ConfigPanel(self, resizable=True)
        mySizer = wx.GridBagSizer(5, 5)

        #Find installed OPC servers
        find_opc = OpenOPC.client()
        list = find_opc.servers()
        find_opc.close()
        del find_opc
        
        # Create a dropdown for selection of OPC server
        opcServerCtrl = wx.Choice(parent=panel, pos=(10,10))
        opcServerCtrl.AppendItems(strings=list) 
        if list.count(OPC_name)==0:
            opcServerCtrl.Select(n=0)
        else:
            opcServerCtrl.SetSelection(int(list.index(OPC_name)))
        mySizer.Add(wx.StaticText(panel, -1, self.text.selectBoxOpcServer), (1,0))
        mySizer.Add(opcServerCtrl, (1,1))
        opcServerCtrl.Bind(wx.EVT_CHOICE, self.OnChoice)

        thread_wait = panel.SpinNumCtrl(
            tw,
            decimalChar = '.',                 # by default, use '.' for decimal point
            groupChar = ',',                   # by default, use ',' for grouping
            fractionWidth = 2,
            integerWidth = 2,
            increment = 0.01,
            min = 0.10,
            max = 5.0
        )
        thread_wait.SetInitialSize((60,-1))
        mySizer.Add(wx.StaticText(panel, -1, self.text.threadWaitTime), (2,0))
        mySizer.Add(thread_wait, (2,1))

        memoryLimitCtrl = panel.SpinIntCtrl(
            limitMemorySize,
            min=4,
            max=999
        )
        memoryLimitCtrl.SetInitialSize((40,-1))
        mySizer.Add(wx.StaticText(panel, -1, self.text.memoryLimit), (3,0))
        mySizer.Add(memoryLimitCtrl, (3,1))
        panel.sizer.Add(mySizer, 1, flag = wx.EXPAND)


        def OnButton(event): 
            event.Skip()
            if self.stopThreadEvent:
                self.stopThreadEvent.set()
            self.__start__(
                OPC_name,
                tw,
                limitMemorySize
            )


        panel.dialog.buttonRow.okButton.Bind(wx.EVT_BUTTON, OnButton)
        panel.dialog.buttonRow.cancelButton.Bind(wx.EVT_BUTTON, OnButton)

        while panel.Affirmed():
            OPC_name = opcServerCtrl.GetStringSelection()
            tw = thread_wait.GetValue()
            limitMemorySize = memoryLimitCtrl.GetValue()
            
            panel.SetResult(
                        OPC_name,
                        tw,
                        limitMemorySize,
                        *args
            )



