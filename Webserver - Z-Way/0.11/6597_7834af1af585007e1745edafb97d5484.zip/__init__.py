# -*- coding: utf-8 -*-
#
# plugins/Webserver - Z-Way/__init__.py
#
# This file is a plugin for EventGhost.

eg.RegisterPlugin(
    name = "Webserver - Z-Way",
    author = "Sem;colon",
    version = "0.11",
    kind = "external",
    description = u"""Plugin to control Z-WAVE devices.\n Prerequisites: Raspberry PI with RaZberry module (or another Z-Way controller), EventGhost Webserver plugin""",
    createMacrosOnAdd = False,
    canMultiLoad = False,
    url="http://www.eventghost.net/forum/viewtopic.php?f=9&t=6867",
)

import json
import socket
from urllib import quote

class WebZWay(eg.PluginBase):
            
    class Text:
        file  = "File that should be requested when doing post request from Z-Way:"
        switchGroupName = "SwitchBinary"
        switchGroupDescription = "Actions for CommandClass 37: SwitchBinary (Binary/Normal Switches)"
        dimGroupName = "SwitchMultilevel"
        dimGroupDescription = "Actions for CommandClass 38: SwitchMultilevel (Dimmer)"
    
    def __init__(self):
        self.hosts={}
        self.AddAction(AddHost)
        self.AddAction(RemoveHost)
        self.AddAction(GetDeviceData)
        self.AddAction(GetAllDeviceData)
        self.AddAction(CustomCommand)
        
        switchGroup = self.AddGroup(
            self.Text.switchGroupName,
            self.Text.switchGroupDescription
        )
        switchGroup.AddAction(SwitchBinary)
        
        dimGroup = self.AddGroup(
            self.Text.dimGroupName,
            self.Text.dimGroupDescription
        )
        dimGroup.AddAction(SwitchMultilevelOnOff)
        dimGroup.AddAction(SwitchMultilevel)
        dimGroup.AddAction(StartLevelChange)
        
        self.thisPcName=socket.gethostname()
        tmp = [a for a in socket.gethostbyname_ex(self.thisPcName)[2]]
        addresses = []
        for a in tmp:
            if a.startswith("127.") or a.startswith("169."):
                continue
            addresses.append(a)
        self.thisPcIPs=addresses


    def __stop__(self):
        eg.TriggerEvent(prefix='Webserver - Z-Way', suffix='Plugin.Stopped')
        
             
    def __start__(self, file):
        self.callFile=file
        preReqsLoaded=True
        pluginList=["Webserver"]
        for i in pluginList:
            if i not in eg.plugins.__dict__:
                eg.PrintError('Webserver - Z-WAY Start ERROR: Plugin "'+i+'" could not be found in your configuration!')
                preReqsLoaded = False
            elif not eg.plugins.__dict__[i].plugin.info.isStarted:
                eg.PrintError('Webserver - Z-Way Start ERROR: Plugin "'+i+'" is not started! (it has to start before the Z-Way plugin starts, please move this plugin above the Z-Way plugin, save your configuration and restart EventGhost!)')
                preReqsLoaded = False
        if not preReqsLoaded:
            return False
        eg.TriggerEvent(prefix='Webserver - Z-Way', suffix='Plugin.Started', payload=self.info.version)
        
        
    def Configure(self, file="/empty"):
        text = self.Text
        panel = eg.ConfigPanel(self)
        fileCtrl = panel.TextCtrl(file)
        st1 = panel.StaticText(text.file)
        panel.AddLine(st1, fileCtrl)
        while panel.Affirmed():
            panel.SetResult(
                fileCtrl.GetValue(),
            )
        

class AddHost(eg.ActionBase):
    name = "Add a Z-Way host"
    
    class Text:
        ip = 'IP Addess:'
        user = 'Username:'
        alias  = "Unique identifier for this host:"
        file  = "File that should be requested when doing post request from Z-Way:"
        port    = "Network Port:"
        password= "Password:"
    
    def __call__(self,alias,ip, port=8083, user="", password=""):
        try:
            protocol="http"
            if eg.plugins.Webserver.plugin.info.args[10]!="":
                protocol="https"
            params=quote(json.dumps([alias,self.plugin.thisPcIPs,eg.plugins.Webserver.plugin.info.args[1],self.plugin.callFile.replace("/","~fs~").replace("\\","~bs~"),eg.plugins.Webserver.plugin.info.args[4],eg.plugins.Webserver.plugin.info.args[5],protocol]))
            devices=eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+ip+':'+str(port)+'/JS/Run/initEG(\''+params+'\')', user, password)
        except:
            eg.PrintError('Webserver - Z-Way ERROR: Host "'+alias+'" can\'t be added!(connection not possible)')
            return False
        self.plugin.hosts[alias]={}
        self.plugin.hosts[alias]["ip"]=ip
        self.plugin.hosts[alias]["port"]=str(port)
        self.plugin.hosts[alias]["user"]=user
        self.plugin.hosts[alias]["password"]=password
        self.plugin.hosts[alias]["devices"]={}
        self.plugin.hosts[alias]["devicesPerClass"]={}#37:SwitchBinary,38:SwitchMultilevel,48:SensorBinary,49:SensorMultilevel,50:Meter
        devices=json.loads(devices)
        for device in devices:
            if device[0] not in self.plugin.hosts[alias]["devices"]:
                self.plugin.hosts[alias]["devices"][device[0]]={device[1]:[device[2]]}
            elif device[1] not in self.plugin.hosts[alias]["devices"][device[0]]:
                self.plugin.hosts[alias]["devices"][device[0]][device[1]]=[device[2]]
            elif device[2] not in self.plugin.hosts[alias]["devices"][device[0]][device[1]]:
                self.plugin.hosts[alias]["devices"][device[0]][device[1]].append(device[2])
            if device[2] not in self.plugin.hosts[alias]["devicesPerClass"]:
                self.plugin.hosts[alias]["devicesPerClass"][device[2]]={}
            if device[0] not in self.plugin.hosts[alias]["devicesPerClass"][device[2]]:
                self.plugin.hosts[alias]["devicesPerClass"][device[2]][device[0]]=[device[1]]
            elif device[1] not in self.plugin.hosts[alias]["devicesPerClass"][device[2]][device[0]]:
                self.plugin.hosts[alias]["devicesPerClass"][device[2]][device[0]].append(device[1])
        eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+ip+':'+str(port)+'/JS/Run/getAllStates(\''+alias+'\')', user, password)
            
    def Configure(self,alias="Z-Way1", ip="", port=8083, user="", password=""):
        text = self.Text
        panel = eg.ConfigPanel(self)
        ipCtrl = panel.TextCtrl(ip)
        st1 = panel.StaticText(text.ip)
        portCtrl = panel.SpinIntCtrl(port, min=0, max=65535)
        st2 = panel.StaticText(text.port)
        aliasCtrl = panel.TextCtrl(alias)
        st3 = panel.StaticText(text.alias)
        userCtrl = panel.TextCtrl(user)
        st4 = panel.StaticText(text.user)
        passwordCtrl = panel.TextCtrl(password)
        st5 = panel.StaticText(text.password)
        eg.EqualizeWidths((st1,st2,st3,st4,st5))
        panel.AddLine(st3, aliasCtrl)
        panel.AddLine(st1, ipCtrl)
        panel.AddLine(st2, portCtrl)
        panel.AddLine(st4, userCtrl)
        panel.AddLine(st5, passwordCtrl)
        while panel.Affirmed():
            panel.SetResult(
                aliasCtrl.GetValue(),
                ipCtrl.GetValue(),
                portCtrl.GetValue(),
                userCtrl.GetValue(),
                passwordCtrl.GetValue(),
            )

            
class RemoveHost(eg.ActionBase):
    name = "Remove a Z-Way host"
    
    class Text:
        alias  = "Unique identifier for this host:"
    
    def __call__(self,alias):
        result= eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/JS/Run/removeHost(\''+alias+'\')', self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
        del self.plugin.hosts[alias]
        return result
            
    def Configure(self, alias=""):
        text = self.Text
        hostList=list(self.plugin.hosts.keys())
        panel = eg.ConfigPanel(self)
        aliasCtrl = wx.Choice(panel, -1, choices=hostList)
        if alias in hostList:
            aliasCtrl.SetSelection(hostList.index(alias))
        st1 = panel.StaticText(text.alias)
        panel.AddLine(st1, aliasCtrl)
        while panel.Affirmed():
            panel.SetResult(
                aliasCtrl.GetStringSelection(),
            )
            

class SwitchBinary(eg.ActionBase):
    name = "ON/OFF"
    
    class Text:
        host = "Host:"
        deviceid = "Device ID:"
        instanceid = "Instance ID:"
        targetState  = "Target State:"
        
    def __call__(self,deviceid,instanceid,alias,targetState):
        if targetState=="ON":
            targetState="255"
        else:
            targetState="0"
        command="devices["+deviceid+"].instances["+instanceid+"].commandClasses[37].Set("+targetState+")"
        return eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/ZWaveAPI/Run/'+command, self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
            
    def Configure(self,deviceid="",instanceid="",alias="",targetState="ON"):
        text = self.Text
        statesList=["ON","OFF"]
        hostList=list(self.plugin.hosts.keys())
        panel = eg.ConfigPanel(self)
        aliasCtrl = wx.Choice(panel, -1, choices=hostList)
        if alias in hostList:
            aliasCtrl.SetSelection(hostList.index(alias))
        else:
            aliasCtrl.SetSelection(0)
        deviceList=list(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["37"].keys())
        st3 = panel.StaticText(text.host)
        deviceidCtrl = wx.Choice(panel, -1, choices=deviceList)
        if deviceid in deviceList:
            deviceidCtrl.SetSelection(deviceList.index(deviceid))
        else:
            deviceidCtrl.SetSelection(0)
        st1 = panel.StaticText(text.deviceid)
        instanceidCtrl = wx.Choice(panel, -1, choices=self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["37"][deviceidCtrl.GetStringSelection()])
        if instanceid in self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["37"][deviceidCtrl.GetStringSelection()]:
            instanceidCtrl.SetSelection(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["37"][deviceidCtrl.GetStringSelection()].index(instanceid))
        else:
            instanceidCtrl.SetSelection(0)
        st2 = panel.StaticText(text.instanceid)
        targetStateCtrl = wx.Choice(panel, -1, choices=statesList)
        targetStateCtrl.SetSelection(statesList.index(targetState))
        st4 = panel.StaticText(text.targetState)
        eg.EqualizeWidths((st1,st2,st3,st4))
        panel.AddLine(st3, aliasCtrl)
        panel.AddLine(st1, deviceidCtrl)
        panel.AddLine(st2, instanceidCtrl)
        panel.AddLine(st4, targetStateCtrl)
        while panel.Affirmed():
            panel.SetResult(
                deviceidCtrl.GetStringSelection(),
                instanceidCtrl.GetStringSelection(),
                aliasCtrl.GetStringSelection(),
                targetStateCtrl.GetStringSelection(),
            )
            
            
class SwitchMultilevel(eg.ActionBase):
    name = "Set Level"
    description = u"""Meaning of the "Duration Value" field:  0 instantly.  1-127 in seconds.  128-254 in minutes mapped to 1-127 (value 128 is 1 minute).  255 use device factory default."""
    
    class Text:
        host = "Host:"
        deviceid = "Device ID:"
        instanceid = "Instance ID:"
        targetLevel  = "Target Level:"
        duration  = "Duration Value:"
        
    def __call__(self,deviceid,instanceid,alias,targetLevel,duration=255):
        command="devices["+deviceid+"].instances["+instanceid+"].commandClasses[38].Set("+str(targetLevel)+","+str(duration)+")"
        return eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/ZWaveAPI/Run/'+command, self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
            
    def Configure(self,deviceid="",instanceid="",alias="",targetLevel=99,duration=255):
        text = self.Text
        hostList=list(self.plugin.hosts.keys())
        panel = eg.ConfigPanel(self)
        aliasCtrl = wx.Choice(panel, -1, choices=hostList)
        if alias in hostList:
            aliasCtrl.SetSelection(hostList.index(alias))
        else:
            aliasCtrl.SetSelection(0)
        deviceList=list(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"].keys())
        st3 = panel.StaticText(text.host)
        deviceidCtrl = wx.Choice(panel, -1, choices=deviceList)
        if deviceid in deviceList:
            deviceidCtrl.SetSelection(deviceList.index(deviceid))
        else:
            deviceidCtrl.SetSelection(0)
        st1 = panel.StaticText(text.deviceid)
        instanceidCtrl = wx.Choice(panel, -1, choices=self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()])
        if instanceid in self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()]:
            instanceidCtrl.SetSelection(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()].index(instanceid))
        else:
            instanceidCtrl.SetSelection(0)
        st2 = panel.StaticText(text.instanceid)
        targetLevelCtrl = panel.SpinIntCtrl(targetLevel, min=0, max=99)
        st4 = panel.StaticText(text.targetLevel)
        durationCtrl = panel.SpinIntCtrl(duration, min=0, max=255)
        st5 = panel.StaticText(text.duration)
        eg.EqualizeWidths((st1,st2,st3,st4,st5))
        panel.AddLine(st3, aliasCtrl)
        panel.AddLine(st1, deviceidCtrl)
        panel.AddLine(st2, instanceidCtrl)
        panel.AddLine(st4, targetLevelCtrl)
        panel.AddLine(st5, durationCtrl)
        while panel.Affirmed():
            panel.SetResult(
                deviceidCtrl.GetStringSelection(),
                instanceidCtrl.GetStringSelection(),
                aliasCtrl.GetStringSelection(),
                targetLevelCtrl.GetValue(),
                durationCtrl.GetValue(),
            )

            
class SwitchMultilevelOnOff(eg.ActionBase):
    name = "ON/OFF (Previous Value)"
    description = u"""Meaning of the "Duration Value" field:  0 instantly.  1-127 in seconds.  128-254 in minutes mapped to 1-127 (value 128 is 1 minute).  255 use device factory default."""
    
    class Text:
        host = "Host:"
        deviceid = "Device ID:"
        instanceid = "Instance ID:"
        targetState  = "Target State:"
        duration  = "Duration Value:"
        
    def __call__(self,deviceid,instanceid,alias,targetState,duration=255):
        if targetState=="ON":
            targetState="100"
        else:
            targetState="0"
        command="devices["+deviceid+"].instances["+instanceid+"].commandClasses[38].Set("+targetState+","+str(duration)+")"
        return eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/ZWaveAPI/Run/'+command, self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
            
    def Configure(self,deviceid="",instanceid="",alias="",targetState="ON",duration=255):
        text = self.Text
        statesList=["ON","OFF"]
        hostList=list(self.plugin.hosts.keys())
        panel = eg.ConfigPanel(self)
        aliasCtrl = wx.Choice(panel, -1, choices=hostList)
        if alias in hostList:
            aliasCtrl.SetSelection(hostList.index(alias))
        else:
            aliasCtrl.SetSelection(0)
        deviceList=list(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"].keys())
        st3 = panel.StaticText(text.host)
        deviceidCtrl = wx.Choice(panel, -1, choices=deviceList)
        if deviceid in deviceList:
            deviceidCtrl.SetSelection(deviceList.index(deviceid))
        else:
            deviceidCtrl.SetSelection(0)
        st1 = panel.StaticText(text.deviceid)
        instanceidCtrl = wx.Choice(panel, -1, choices=self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()])
        if instanceid in self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()]:
            instanceidCtrl.SetSelection(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()].index(instanceid))
        else:
            instanceidCtrl.SetSelection(0)
        st2 = panel.StaticText(text.instanceid)
        targetStateCtrl = wx.Choice(panel, -1, choices=statesList)
        targetStateCtrl.SetSelection(statesList.index(targetState))
        st4 = panel.StaticText(text.targetState)
        durationCtrl = panel.SpinIntCtrl(duration, min=0, max=255)
        st5 = panel.StaticText(text.duration)
        eg.EqualizeWidths((st1,st2,st3,st4,st5))
        panel.AddLine(st3, aliasCtrl)
        panel.AddLine(st1, deviceidCtrl)
        panel.AddLine(st2, instanceidCtrl)
        panel.AddLine(st4, targetStateCtrl)
        panel.AddLine(st5, durationCtrl)
        while panel.Affirmed():
            panel.SetResult(
                deviceidCtrl.GetStringSelection(),
                instanceidCtrl.GetStringSelection(),
                aliasCtrl.GetStringSelection(),
                targetStateCtrl.GetStringSelection(),
                durationCtrl.GetValue(),
            )


class StartLevelChange(eg.ActionBase):
    name = "Change Level UP/DOWN"
    description = u"""Meaning of the "Duration Value" field:  0 instantly.  1-127 in seconds.  128-254 in minutes mapped to 1-127 (value 128 is 1 minute).  255 use device factory default."""
    
    class Text:
        host = "Host:"
        deviceid = "Device ID:"
        instanceid = "Instance ID:"
        direction = "Direction:"
        duration = "Duration Value:"
        ignoreStartLevel = "Ignore Start Level:"
        startLevel = "Start Level:"
        indec = "indec:"
        step = "Step in %:"
        
    def __call__(self,deviceid,instanceid,alias,direction,duration=255,ignoreStartLevel=True,startLevel=50,indec=0,step=255):
        def UpFunc():
            command="devices["+deviceid+"].instances["+instanceid+"].commandClasses[38].StopLevelChange()"
            eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/ZWaveAPI/Run/'+command, self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
        if direction=="UP":
            direction="0"
        else:
            direction="1"
        if ignoreStartLevel:
            ignoreStartLevel="true"
        else:
            ignoreStartLevel="false"
        step-=1
        command="devices["+deviceid+"].instances["+instanceid+"].commandClasses[38].StartLevelChange("+direction+","+str(duration)+","+ignoreStartLevel+","+str(startLevel)+","+str(indec)+","+str(step)+")"
        eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/ZWaveAPI/Run/'+command, self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
        eg.event.AddUpFunc(UpFunc)
            
    def Configure(self,deviceid="",instanceid="",alias="",direction="UP",duration=255):
        text = self.Text
        directionsList=["UP","DOWN"]
        hostList=list(self.plugin.hosts.keys())
        panel = eg.ConfigPanel(self)
        aliasCtrl = wx.Choice(panel, -1, choices=hostList)
        if alias in hostList:
            aliasCtrl.SetSelection(hostList.index(alias))
        else:
            aliasCtrl.SetSelection(0)
        deviceList=list(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"].keys())
        st3 = panel.StaticText(text.host)
        deviceidCtrl = wx.Choice(panel, -1, choices=deviceList)
        if deviceid in deviceList:
            deviceidCtrl.SetSelection(deviceList.index(deviceid))
        else:
            deviceidCtrl.SetSelection(0)
        st1 = panel.StaticText(text.deviceid)
        instanceidCtrl = wx.Choice(panel, -1, choices=self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()])
        if instanceid in self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()]:
            instanceidCtrl.SetSelection(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devicesPerClass"]["38"][deviceidCtrl.GetStringSelection()].index(instanceid))
        else:
            instanceidCtrl.SetSelection(0)
        st2 = panel.StaticText(text.instanceid)
        targetStateCtrl = wx.Choice(panel, -1, choices=directionsList)
        targetStateCtrl.SetSelection(directionsList.index(direction))
        st4 = panel.StaticText(text.direction)
        durationCtrl = panel.SpinIntCtrl(duration, min=0, max=255)
        st5 = panel.StaticText(text.duration)
        eg.EqualizeWidths((st1,st2,st3,st4,st5))
        panel.AddLine(st3, aliasCtrl)
        panel.AddLine(st1, deviceidCtrl)
        panel.AddLine(st2, instanceidCtrl)
        panel.AddLine(st4, targetStateCtrl)
        panel.AddLine(st5, durationCtrl)
        while panel.Affirmed():
            panel.SetResult(
                deviceidCtrl.GetStringSelection(),
                instanceidCtrl.GetStringSelection(),
                aliasCtrl.GetStringSelection(),
                targetStateCtrl.GetStringSelection(),
                durationCtrl.GetValue(),
            )
            
            
class GetDeviceData(eg.ActionBase):
    name = "Get data from one device"
    
    class Text:
        host = "Host:"
        deviceid = "Device ID:"
        
    def __call__(self,deviceid,alias):
        for instance in self.plugin.hosts[alias]["devices"][deviceid]:
            for commandClass in self.plugin.hosts[alias]["devices"][deviceid][instance]:
                command="devices["+deviceid+"].instances["+instance+"].commandClasses["+commandClass+"].Get()"
                print command
                eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/ZWaveAPI/Run/'+command, self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
        return True
            
    def Configure(self,deviceid="",alias=""):
        text = self.Text
        hostList=list(self.plugin.hosts.keys())
        panel = eg.ConfigPanel(self)
        aliasCtrl = wx.Choice(panel, -1, choices=hostList)
        if alias in hostList:
            aliasCtrl.SetSelection(hostList.index(alias))
        else:
            aliasCtrl.SetSelection(0)
        st3 = panel.StaticText(text.host)
        deviceList=list(self.plugin.hosts[aliasCtrl.GetStringSelection()]["devices"])
        deviceidCtrl = wx.Choice(panel, -1, choices=deviceList)
        if deviceid in deviceList:
            deviceidCtrl.SetSelection(deviceList.index(deviceid))
        else:
            deviceidCtrl.SetSelection(0)
        st1 = panel.StaticText(text.deviceid)
        eg.EqualizeWidths((st1,st3))
        panel.AddLine(st3, aliasCtrl)
        panel.AddLine(st1, deviceidCtrl)
        while panel.Affirmed():
            panel.SetResult(
                deviceidCtrl.GetStringSelection(),
                aliasCtrl.GetStringSelection(),
            )
            
            
class GetAllDeviceData(eg.ActionBase):
    name = "Get data from all devices"
    
    class Text:
        host = "Host:"
        
    def __call__(self,alias):
        return eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/JS/Run/getAllStates(\''+alias+'\')', self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
            
    def Configure(self,alias=""):
        text = self.Text
        hostList=list(self.plugin.hosts.keys())
        panel = eg.ConfigPanel(self)
        aliasCtrl = wx.Choice(panel, -1, choices=hostList)
        if alias in hostList:
            aliasCtrl.SetSelection(hostList.index(alias))
        else:
            aliasCtrl.SetSelection(0)
        st3 = panel.StaticText(text.host)
        panel.AddLine(st3, aliasCtrl)
        while panel.Affirmed():
            panel.SetResult(
                aliasCtrl.GetStringSelection(),
            )
            
            
class CustomCommand(eg.ActionBase):
    name = "Custom Command (JS)"
    
    class Text:
        host = "Host:"
        command  = "Command to send:"
        
    def __call__(self,command,alias):
        return eg.plugins.Webserver.SendEventExt(u'dummy', 'http://'+self.plugin.hosts[alias]["ip"]+':'+self.plugin.hosts[alias]["port"]+'/JS/Run/'+command, self.plugin.hosts[alias]["user"], self.plugin.hosts[alias]["password"])
            
    def Configure(self,command="",alias=""):
        text = self.Text
        hostList=list(self.plugin.hosts.keys())
        panel = eg.ConfigPanel(self)
        commandCtrl = panel.TextCtrl(command)
        st1 = panel.StaticText(text.command)
        aliasCtrl = wx.Choice(panel, -1, choices=hostList)
        if alias in hostList:
            aliasCtrl.SetSelection(hostList.index(alias))
        st2 = panel.StaticText(text.host)
        eg.EqualizeWidths((st1,st2))
        panel.AddLine(st1, commandCtrl)
        panel.AddLine(st2, aliasCtrl)
        while panel.Affirmed():
            panel.SetResult(
                commandCtrl.GetValue(),
                aliasCtrl.GetStringSelection(),
            )