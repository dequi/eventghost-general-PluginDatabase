
import eg

eg.RegisterPlugin(
    name = "PLCBUS",
    author = "Pastis",
    version = "0.1." + "$LastChangedRevision: 1489 $".split()[1],
    canMultiLoad = True,
    description = "To use with PLCBUS 1141 Interface.",
)

class Text:
    port = "Port:"
    baudrate = "Baudrate:"
    bytesize = "Number of bits:"
    parity = "Parity:"
    parities = ['No parity', 'Odd', 'Even'] #, 'Mark', 'Space']
    stopbits = "Stopbits:"
    flowcontrol = "Flow control:"
    handshakes = ['None', 'Xon / Xoff', 'Hardware']
    generateEvents = "Generate events on incoming data"
    terminator = "Terminator:"
    eventPrefix = "Event prefix:"
    encoding = "Encoding:"
    codecChoices = [
        "System code page",
        "HEX",
        "Latin-1",
        "UTF-8",
        "UTF-16",
        "Python string escape",
    ]
    class AddApp:
        name = "Add Appliance"
        description = (
            "Turn On/Off a PLCBUS module."
        )
    class AddLamp:
        name = "Add Lamp"
        description = (
            "Turn On/Off a PLCBUS Dimmer module. Set Dim level and rate."
        )
    class Read:
        name = "Read"
        description = (
            "Reads data from the serial port."
            "\n\n<p>"
            "This action returns the data through <i>eg.result</i>, as any "
            "action does that is returning data. So you have to use "
            '<a href="http://www.eventghost.net/wiki/Scripting">'
            "Python scripting</a> to do anything with the result."
            "<p>"
            "Using this action and enabling event generation in the plugin "
            "cannot be used at the same time, as one of it will always eat "
            "the data away from the other."
        )
        read_all = "Read as many bytes as are currently available"
        read_some = "Read exactly this number of bytes:"
        read_time = "and wait this maximum number of milliseconds for them:"


import wx
import threading
import win32event
import win32file
import codecs
import binascii

BAUDRATES = [
    '110', '300', '600', '1200', '2400', '4800', '9600', '14400', '19200',
    '38400', '57600', '115200', '128000', '256000'
]
HOMECODE = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
    'J', 'K', 'L', 'M', 'N'
]
ADDRESSCODE = [
    '1', '2', '3', '4', '5', '6', '7', '8', '9',
    '10', '11', '12', '13', '14'
]

def MyHexDecoder(input):
    return (binascii.b2a_hex(input).upper(), len(input))


DECODING_FUNCS = [
    codecs.getdecoder(eg.systemEncoding),
    MyHexDecoder,
    codecs.getdecoder("latin1"),
    codecs.getdecoder("utf8"),
    codecs.getdecoder("utf16"),
    codecs.getencoder("string_escape"),
]


class PLCBUSSerial(eg.RawReceiverPlugin):
    text = Text

    def __init__(self):
        eg.RawReceiverPlugin.__init__(self)
        self.AddAction(AddApp)
        self.AddAction(AddLamp)
        self.AddAction(Write)
        self.AddAction(Read)
        self.serial = None
        self.buffer = ""


    def __start__(
        self,
        port,
        baudrate,
        bytesize=8,
        parity=0,
        stopbits=0,
        handshake=0,
        generateEvents=False,
        terminator="",
        prefix="Serial",
        encodingNum=0,
    ):
        xonxoff = 0
        rtscts = 0
        if handshake == 1:
            xonxoff = 1
        elif handshake == 2:
            rtscts = 1

        try:
            self.serial = eg.SerialPort(
                port,
                baudrate=baudrate,
                bytesize=(5, 6, 7, 8)[bytesize],
                stopbits=(1, 2)[stopbits],
                parity=('N', 'O', 'E')[parity],
                xonxoff=xonxoff,
                rtscts=rtscts,
            )
        except:
            self.serial = None
            raise self.Exceptions.SerialOpenFailed
        self.serial.timeout = 1.0
        self.serial.setRTS()
        if generateEvents:
            self.decoder = DECODING_FUNCS[encodingNum]
            self.terminator = eg.ParseString(terminator).decode('string_escape')
            self.info.eventPrefix = prefix
            self.stopEvent = win32event.CreateEvent(None, 1, 0, None)
            self.receiveThread = threading.Thread(target=self.ReceiveThread, name="SerialThread")
            self.receiveThread.start()
        else:
            self.receiveThread = None


    def __stop__(self):
        if self.serial is not None:
            if self.receiveThread:
                win32event.SetEvent(self.stopEvent)
                self.receiveThread.join(1.0)
            self.serial.close()
            self.serial = None


    def HandleChar(self, ch):
        self.buffer += ch
        pos = self.buffer.find(self.terminator)
        if pos != -1:
            eventstring = self.buffer[:pos]
            if eventstring:
                self.TriggerEvent(self.decoder(eventstring)[0])
            self.buffer = self.buffer[pos+len(self.terminator):]


    def ReceiveThread(self):
        from win32event import (
            ResetEvent,
            MsgWaitForMultipleObjects,
            QS_ALLINPUT,
            WAIT_OBJECT_0,
            WAIT_TIMEOUT,
        )
        from win32file import ReadFile, AllocateReadBuffer, GetOverlappedResult
        from win32api import GetLastError

        continueLoop = True
        overlapped = self.serial._overlappedRead
        hComPort = self.serial.hComPort
        hEvent = overlapped.hEvent
        stopEvent = self.stopEvent
        n = 1
        waitingOnRead = False
        buf = AllocateReadBuffer(n)
        while continueLoop:
            if not waitingOnRead:
                ResetEvent(hEvent)
                hr, _ = ReadFile(hComPort, buf, overlapped)
                if hr == 997:
                    waitingOnRead = True
                elif hr == 0:
                    pass
                    #n = GetOverlappedResult(hComPort, overlapped, 1)
                    #self.HandleChar(str(buf))
                else:
                    self.PrintError("error")
                    raise

            rc = MsgWaitForMultipleObjects(
                (hEvent, stopEvent),
                0,
                1000,
                QS_ALLINPUT
            )
            if rc == WAIT_OBJECT_0:
                n = GetOverlappedResult(hComPort, overlapped, 1)
                if n:
                    self.HandleChar(str(buf))
                #else:
                #    print "WAIT_OBJECT_0", n, str(buf[:n])
                waitingOnRead = False
            elif rc == WAIT_OBJECT_0+1:
                continueLoop = False
            elif rc == WAIT_TIMEOUT:
                pass
            else:
                self.PrintError("unknown message")


    def Configure(
        self,
        port=0,
        baudrate=9600,
        bytesize=3,
        parity=0,
        stopbits=0,
        handshake=0,
        generateEvents=False,
        terminator="\\r",
        prefix="Serial",
        encodingNum=0,
    ):
        text = self.text
        panel = eg.ConfigPanel()
        portCtrl = panel.SerialPortChoice(port)

        baudrateCtrl = panel.ComboBox(
            str(baudrate),
            BAUDRATES,
            style=wx.CB_DROPDOWN,
            validator=eg.DigitOnlyValidator()
        )
        bytesizeCtrl = panel.Choice(bytesize, ['5', '6', '7', '8'])
        parityCtrl = panel.Choice(parity, text.parities)
        stopbitsCtrl = panel.Choice(stopbits, ['1', '2'])
        handshakeCtrl = panel.Choice(handshake, text.handshakes)
        generateEventsCtrl = panel.CheckBox(generateEvents, text.generateEvents)
        terminatorCtrl = panel.TextCtrl(terminator)
        terminatorCtrl.Enable(generateEvents)
        prefixCtrl = panel.TextCtrl(prefix)
        prefixCtrl.Enable(generateEvents)
        encodingCtrl = panel.Choice(encodingNum, text.codecChoices)
        encodingCtrl.Enable(generateEvents)

        def OnCheckBox(event):
            flag = generateEventsCtrl.GetValue()
            terminatorCtrl.Enable(flag)
            prefixCtrl.Enable(flag)
            encodingCtrl.Enable(flag)
            event.Skip()
        generateEventsCtrl.Bind(wx.EVT_CHECKBOX, OnCheckBox)

        panel.SetColumnFlags(1, wx.EXPAND)
        portSettingsBox = panel.BoxedGroup(
            "Port settings",
            (text.port, portCtrl),
            (text.baudrate, baudrateCtrl),
            (text.bytesize, bytesizeCtrl),
            (text.parity, parityCtrl),
            (text.stopbits, stopbitsCtrl),
            (text.flowcontrol, handshakeCtrl),
        )
        eventSettingsBox = panel.BoxedGroup(
            "Event generation",
            (generateEventsCtrl),
            (text.terminator, terminatorCtrl),
            (text.eventPrefix, prefixCtrl),
            (text.encoding, encodingCtrl),
        )
        eg.EqualizeWidths(portSettingsBox.GetColumnItems(0))
        eg.EqualizeWidths(portSettingsBox.GetColumnItems(1))
        eg.EqualizeWidths(eventSettingsBox.GetColumnItems(0)[1:])
        eg.EqualizeWidths(eventSettingsBox.GetColumnItems(1))
        panel.sizer.Add(eg.HBoxSizer(portSettingsBox, (10, 10), eventSettingsBox))
        while panel.Affirmed():
            panel.SetResult(
                portCtrl.GetValue(),
                int(baudrateCtrl.GetValue()),
                bytesizeCtrl.GetValue(),
                parityCtrl.GetValue(),
                stopbitsCtrl.GetValue(),
                handshakeCtrl.GetValue(),
                generateEventsCtrl.GetValue(),
                terminatorCtrl.GetValue(),
                prefixCtrl.GetValue(),
                encodingCtrl.GetValue(),
            )

class AddApp(eg.ActionWithStringParameter):

    def __call__(self, data, homeCode, addressCode, lightEvent):
		if lightEvent == 0:
			lightEvent = "\\x22"
		elif lightEvent == 1:
			lightEvent = "\\x23"
		elif lightEvent == 3:
			lightEvent = "\\x25"
		if homeCode == 0:
			homeCode = "\\x00"
		addressCode = "\\x0"+ str( int(addressCode) - 1)
		data = "\\x02\\x05" + str(homeCode) + addressCode + str(lightEvent) + "\\x00\\x00\\x03"
		#for testing data = "\\x02\\x05\\x55\\x00\\x22\\x00\\x00\\x03\\x02\\x05\\x55\\x00\\x22\\x00\\x00\\x03"
		print data
		data = eg.ParseString(data, self.replaceFunc)
		data = data.decode('string_escape')
		self.plugin.serial.write(str(data))

		return self.plugin.serial
		
    def Configure(self, homeCodeDesc="", homeCode="", addressCode="", lightEvent=""):
        panel = eg.ConfigPanel()
        eventSelection = ["On", "Off"]
        lightEvent = 0
        lightEventCtrl = panel.Choice(lightEvent, eventSelection)
        homeCodeSelection = ["A"]
        homecode = 0
        addressCode = panel.ComboBox(
            str(addressCode),
            ADDRESSCODE,
            style=wx.CB_DROPDOWN,
            validator=eg.DigitOnlyValidator()
        )
        homecodeCtrl = panel.Choice(homecode, homeCodeSelection)
        homeCodeTextControl = panel.TextCtrl(homeCodeDesc)
        panel.sizer.Add(panel.StaticText("Home code"))
        panel.sizer.Add(homecodeCtrl, 1, wx.EXPAND)
        #panel.sizer.Add(homeCode, 1, wx.EXPAND)
        panel.sizer.Add(panel.StaticText("User code"))
        panel.sizer.Add(addressCode, 1, wx.EXPAND)
        panel.sizer.Add(panel.StaticText("Command"))
        panel.sizer.Add(lightEventCtrl, 1, wx.EXPAND)
     
        panel.sizer.Add(panel.StaticText("Module description:"))
        panel.sizer.Add(homeCodeTextControl)  

        #sizer.Add(panel.StaticText("Module Adress: "))
        #sizer.Add(modAdressTextControl)  
        #border = wx.BoxSizer()
        #border.Add(sizer, 0, wx.ALL, 10)
        #panel.SetSizerAndFit(border)
		
        while panel.Affirmed():	
            panel.SetResult(homeCodeTextControl.GetValue(),homecodeCtrl.GetValue(),addressCode.GetValue(),lightEventCtrl.GetValue())


    def replaceFunc(self, data):
        data = data.strip()
        if data == "CR":
            return chr(13)
        elif data == "LF":
            return chr(10)
        else:
            return None
			
			
class AddLamp(eg.ActionWithStringParameter):

    def __call__(self, data, homeCode, addressCode, lightDimEvent, lightDimValue, lightDimRate):
		if lightDimEvent == 0:
			lightDimEvent = "\\x22"
		elif lightDimEvent == 1:
			lightDimEvent = "\\x23"
		elif lightDimEvent == 2:
			lightDimEvent = "\\x24"
		elif lightDimEvent == 3:
			lightDimEvent = "\\x25"
		elif lightDimEvent == 4:
			lightDimEvent = "\\x2C"
		if lightDimValue == 0:
			lightDimValue = "\\x00"
		elif lightDimValue == 1:
			lightDimValue = "\\x19"
		elif lightDimValue == 2:
			lightDimValue = "\\x32"
		elif lightDimValue == 3:
			lightDimValue = "\\x4B"
		elif lightDimValue == 4:
			lightDimValue = "\\x64"
		if lightDimRate == 0:
			lightDimRate = "\\x00"
		elif lightDimRate == 1:
			lightDimRate = "\\x01"
		elif lightDimRate == 2:
			lightDimRate = "\\x02"
		elif lightDimRate == 3:
			lightDimRate = "\\x03"
		if homeCode == 0:
			homeCode = "\\x00"
		addressCode = "\\x0"+ str( int(addressCode) - 1)
		data = "\\x02\\x05" + str(homeCode) + addressCode + str(lightDimEvent) + str(lightDimValue) + str(lightDimRate) + "\\x03"
		#data = "\\x02\\x05\\x55\\x00\\x22\\x00\\x00\\x03\\x02\\x05\\x55\\x00\\x22\\x00\\x00\\x03"
		print data
		data = eg.ParseString(data, self.replaceFunc)
		data = data.decode('string_escape')
		self.plugin.serial.write(str(data))

		return self.plugin.serial
		
    def Configure(self, homeCodeDesc="", homeCode="", addressCode="", lightDimCtrl="", lightDimValue="", lightDimRate=""):
        panel = eg.ConfigPanel()
        homeCodeSelection = ["A"]
        homecode = 0
        eventSelection = ["On", "Off", "Dim", "Bright", "Preset Dim"]
        lightDim = 0
        dimSelection = ["0", "25", "50", "75", "100"]
        dimValue = 0
        dimRateSelection = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09"]
        dimRate = 0
        #textControl = wx.TextCtrl(panel, -1, homeCodexx)
        addressCode = panel.ComboBox(
            str(addressCode),
            ADDRESSCODE,
            style=wx.CB_DROPDOWN,
            validator=eg.DigitOnlyValidator()
        )
        #lightEventCtrl = panel.Choice(lightEvent, ["On", "Off", "Dim"])
        homecodeCtrl = panel.Choice(homecode, homeCodeSelection)
        lightDimCtrl = panel.Choice(lightDim, eventSelection)
        lightDimValue = panel.Choice(dimValue, dimSelection)
        lightDimRate = panel.Choice(dimRate, dimRateSelection)
        homeCodeTextControl = panel.TextCtrl(homeCodeDesc)
        panel.sizer.Add(panel.StaticText("Home code"))
        panel.sizer.Add(homecodeCtrl, 1, wx.EXPAND)
        panel.sizer.Add(panel.StaticText("User code"))
        panel.sizer.Add(addressCode, 1, wx.EXPAND)
        panel.sizer.Add(panel.StaticText("Command"))
        panel.sizer.Add(lightDimCtrl, 1, wx.EXPAND)
        panel.sizer.Add(panel.StaticText("Dim value"))
        panel.sizer.Add(lightDimValue, 1, wx.EXPAND)
        panel.sizer.Add(panel.StaticText("Dim rate"))
        panel.sizer.Add(lightDimRate, 1, wx.EXPAND)      
        panel.sizer.Add(panel.StaticText("Module description: "))
        panel.sizer.Add(homeCodeTextControl)  

        #modAdressTextControl = panel.TextCtrl(modAdress)
        #sizer = wx.FlexGridSizer(rows=2, cols=2, hgap=10, vgap=5)
        #sizer.Add(panel.StaticText("Module Adress: "))
        #sizer.Add(modAdressTextControl)  
        #border = wx.BoxSizer()
        #border.Add(sizer, 0, wx.ALL, 10)
        #panel.SetSizerAndFit(border)
		
        while panel.Affirmed():
            panel.SetResult(homeCodeTextControl.GetValue(),homecodeCtrl.GetValue(),addressCode.GetValue(),lightDimCtrl.GetValue(),lightDimValue.GetValue(),lightDimRate.GetValue())


    def replaceFunc(self, data):
        data = data.strip()
        if data == "CR":
            return chr(13)
        elif data == "LF":
            return chr(10)
        else:
            return None

			
class Write(eg.ActionWithStringParameter):

    def __call__(self, data):
        data = eg.ParseString(data, self.replaceFunc)
        data = data.decode('string_escape')
        self.plugin.serial.write(str(data))
        return self.plugin.serial


    def replaceFunc(self, data):
        data = data.strip()
        if data == "CR":
            return chr(13)
        elif data == "LF":
            return chr(10)
        else:
            return None
	
	
class Read(eg.ActionBase):

    def __call__(self, count=None, timeout=0.0):
        serial = self.plugin.serial
        serial.timeout = timeout
        if count is None:
            count = 1024
        data = serial.read(count)
        return data


    def GetLabel(self, *args):
        return eg.ActionBase.GetLabel(self)


    def Configure(self, count=None, timeout=1.0):
        text = self.text
        panel = eg.ConfigPanel()
        if count is None:
            count = 1
            flag = False
        else:
            flag = True
        if timeout is None:
            timeout = 1.0
        rb1 = panel.RadioButton(not flag, text.read_all, style=wx.RB_GROUP)
        rb2 = panel.RadioButton(flag, text.read_some)
        countCtrl = panel.SpinIntCtrl(count, 1, 1024)
        countCtrl.Enable(flag)
        timeCtrl = panel.SpinIntCtrl(int(timeout * 1000), 0, 10000)
        timeCtrl.Enable(flag)

        def OnRadioButton(event):
            flag = rb2.GetValue()
            countCtrl.Enable(flag)
            timeCtrl.Enable(flag)
            event.Skip()
        rb1.Bind(wx.EVT_RADIOBUTTON, OnRadioButton)
        rb2.Bind(wx.EVT_RADIOBUTTON, OnRadioButton)

        Add = panel.sizer.Add
        Add(rb1)
        Add((5,5))
        Add(rb2)
        Add((5,5))
        Add(countCtrl, 0, wx.LEFT, 25)
        Add((5,5))
        Add(panel.StaticText(text.read_time), 0, wx.LEFT, 25)
        Add((5,5))
        Add(timeCtrl, 0, wx.LEFT, 25)

        while panel.Affirmed():
            if rb1.GetValue():
                panel.SetResult(None, 0.0)
            else:
                panel.SetResult(
                    countCtrl.GetValue(),
                    timeCtrl.GetValue() / 1000.0
                )
