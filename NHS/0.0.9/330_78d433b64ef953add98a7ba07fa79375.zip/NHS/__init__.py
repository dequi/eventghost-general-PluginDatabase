# -*- coding: utf-8 -*-
#
# plugins/NHS/__init__.py
#
# Copyright (C) 2009
# Walter Kraembring
#
##############################################################################
# Revision history:
#
# 2010-09-18  Added function for individual logfiles for supplementary devices
# 2010-07-29  Added summary info for dewpoint as OSD message
# 2010-05-02  Changed from telnet to socket connections
# 2010-04-22  Improved event control & reconnection of lost telnet session
#             Improved event data capturing & evaluation
#             Changed daily logging files to monthly
#             Added function to generate events for all UPM messages
# 2010-03-05  Added action to send pronto code to NetHomeServer
# 2010-02-25  Improved error handling in UPM messages
# 2010-02-14  Changed to support NetHomeManager new UPM message format
#             Fixed a bug in message repeat control function
# 2010-01-04  Replaced an eg.globals with a local variable instead
# 2009-12-30  Lenght control introduced for UPMsplit
# 2009-12-19  0.4.0 compatible GUID added
# 2009-10-06  The first stumbling version
##############################################################################

eg.RegisterPlugin(
    name = "NHS",
    guid = '{C44CA810-926F-443F-9664-3223186C6B7E}',
    author = "Walter Kraembring",
    version = "0.0.9",
    canMultiLoad = True,
    kind = "other",
    url = "http://wiki.nethome.nu/doku.php/start",
    description = (
        '<p>Plugin to receive messages from NetHomeServer</p>'
        '\n\n<p><a href="http://wiki.nethome.nu/doku.php/start">Product details...</a></p>'
        '<center><img src="nethomeserver.png" /></center>'
    ),
)

import socket, time, os, sys, winsound, re, math, random
from threading import Event, Thread


class Text:
    started = "Plugin started"
    listhl = "Currently active threads:"
    hostName = "Host name or ip:"
    portNumber = "Port number:"
    colLabels = (
        "Action Name",
        "    ",
        "    "
    )
    subscribe = "Request to Subscribe: "
    connection_etablished = "Connection established: "
    connection_error = "Connection error: "
    unsubscribe = "Request to Unsubscribe: "
    read_error = "Read error: "
    
    #Buttons
    b_abort = "Abort"
    b_abortAll = "Abort all"
    b_restartAll = "Restart All"
    b_refresh = "Refresh"

    #Threads
    n_upmThread = "upmThread"
    n_loggerThread = "loggerThread"
    thr_abort = "Thread is terminating: "
    
    class loggerAction:
        name = "Start new or control a running logger"
        description = (
            "Allows starting, stopping or resetting loggers, which "+
            "monitors events from NetHomeServer"
        )
        loggerName = "Logger name:"
        soundOnEvent = "Beep on events:"
        repeats = "Allow repeated events:"
        delay = "Delay of repeats:"
        delay_u = " s (seconds)"
        labelStart = ' "%s"'
        logToFile = "Log events to file:"
        debug = "Turn debug ON:"

    class UpmAction:
        name = "UPM monitor"
        description = "Allows starting, stopping or resetting UPM monitors"
        upmName = "UPM name:"
        txtUpmHouseCode = "Crawl space Sensor House Code:"
        txtUpmDeviceCode = "Crawl space Sensor Device Code:"
        txtUpmHouseCodeOut = "Outdoor Sensor House Code:"
        txtUpmDeviceCodeOut = "Outdoor Sensor Device Code:"
        txtUpmTempDiff = "Trig level for Difference to Dewpoint:"
        upmLabelStart = ' "%s"'
        logToFile = "Log events to file:"
        txtLogInterval = "Select the proper interval for logging (1-360 minutes):"
        #txtOnPeriod = "Select the time period you like to turn the device ON (1-720 minutes):"
        soundOnEvent = "Beep on events:"
        debug = "Turn debug ON:"
        doShowUPM = "Show all UPM events:"        
        txtCdevPoint = "Difference to dewpoint"
        txtBattLow = "Battery low"
        txt_taskObj_1 = "Lost contact with Outdoor sensor"
        txt_taskObj_2 = "Lost contact with Crawl space sensor"
        txt_signal_1_back = "Contact with Outdoor sensor recovered"
        txt_signal_2_back = "Contact with Crawl space sensor recovered"

    class prontoCmd:
        deviceName = (
            "This is a device that can be controlled via NetHomeServer "+
            "using pronto codes"
        )
        pronto = "Paste the pronto code to be transmitted for this action"



class UpmThread(Thread):
    text = Text


    def __init__(
        self,
        name,
        hostName,
        portNbr,
        upmHouseCode,
        upmDeviceCode,
        upmHouseCodeOut,
        upmDeviceCodeOut,
        upmTempDiff,
        bLogToFile,
        iLogInterval,
        iDeviceOnPeriod,
        bSound,
        bDebug,
        bDoShowUPM,
        plugin
    ):
        Thread.__init__(self, name = self.text.n_upmThread)
        self.name = name
        self.hostName = hostName
        self.portNbr = portNbr
        self.upmHouseCode = upmHouseCode
        self.upmDeviceCode = upmDeviceCode
        self.upmHouseCodeOut = upmHouseCodeOut
        self.upmDeviceCodeOut = upmDeviceCodeOut
        self.upmTempDiff = upmTempDiff
        self.bLogToFile = bLogToFile
        self.iLogInterval = iLogInterval
        self.iDeviceOnPeriod = iDeviceOnPeriod
        self.bSound = bSound
        self.bDebug = bDebug
        self.bDoShowUPM = bDoShowUPM
        self.finished = Event()
        self.abort = False
        self.bDoLog = True
        self.bDoTempLog = True
        self.plugin = plugin

   
    def run(self):
        random.jumpahead(137)
        tr = random.random()
        self.finished.wait(tr)
        storage = [0.0, 0.0, 0.0, 0.0]
        self.captured = []
        event_Old = []
        vOut = 0.0
        vGround = 0.0
        taskObj_1 = eg.scheduler.AddTask(
                        600.0,
                        eg.PrintError,
                        self.text.UpmAction.txt_taskObj_1
                    )
        taskObj_2 = eg.scheduler.AddTask(
                        600.0,
                        eg.PrintError,
                        self.text.UpmAction.txt_taskObj_2
                    )

        while (self.abort == False):
            self.finished.wait(0.2)
            self.finished.clear()

            if self.abort:
                self.finished.wait(1)
                break
            
            lst = []

            if eg.event:
                lst = self.plugin.event_NHS.split(',')
                if (
                    lst.count('UPM.HouseCode') > 0
                    and lst.count('UPM.SequenceNumber') > 0
                ):
                    lst = lst[:13]+lst[19:]

            if (
                len(lst) > 9
                and lst.count("NetHomeServer") > 0
                and lst != event_Old
            ):
                event_Old = lst
                s_lst = ""

                for X in range (4,len(lst)):
                    s_lst += str(lst[X])

                    if X < len(lst):
                        s_lst += "|"

                if (
                    s_lst.find("|UPM.HouseCode|") != -1
                    and s_lst.find("|UPM.DeviceCode|") != -1
                ):
                    # split up the event components
                    UPMsplit = s_lst.split('|')
                    
                    if not len(UPMsplit) >= 12:
                        eg.PrintError(str(UPMsplit))
                    elif len(UPMsplit) >= 12:

                        if (
                            len(UPMsplit[6]) > 0
                            and UPMsplit[6] != " "
                            and UPMsplit[6].isdigit()
                            and len(UPMsplit[10]) > 0
                            and UPMsplit[10] != " "
                            and UPMsplit[10].isdigit()
                        ):
                            upmHumidity = int(UPMsplit[6])
                            upmBattery = UPMsplit[8]
                            upmTemperature = float(UPMsplit[10])
                            upmDevice = UPMsplit[2]
                            upmHouse = UPMsplit[4]
     
                            #Heartbeat check of sensors
                            if (int(upmHouse) == int(self.upmHouseCodeOut)
                                and int(upmDevice) == int(self.upmDeviceCodeOut)
                            ):
                                try:
                                    eg.scheduler.CancelTask(taskObj_1)
                                except ValueError:
                                    print(
                                        self.text.UpmAction.txt_signal_1_back
                                    )
    
                                taskObj_1 = eg.scheduler.AddTask(
                                                600.0,
                                                eg.PrintError,
                                                self.text.UpmAction.txt_taskObj_1
                                            )
    
                            if (int(upmHouse) == int(self.upmHouseCode)
                                and int(upmDevice) == int(self.upmDeviceCode)
                            ):
                                try:
                                    eg.scheduler.CancelTask(taskObj_2)
                                except ValueError:
                                    print(
                                        self.text.UpmAction.txt_signal_2_back
                                    )
    
                                taskObj_2 = eg.scheduler.AddTask(
                                                600.0,
                                                eg.PrintError,
                                                self.text.UpmAction.txt_taskObj_2
                                            )
    
                            #Calculate values from the sensor readings
                            upmHumidity = upmHumidity / 2
                            upmTemperature = (
                                (upmTemperature * 0.0625) - 50.0
                            )
                           
                            #upmTemperature = 15.6
                            #upmHumidity = 47
                            Es=6.11*10.0**(
                                7.5 * upmTemperature/(237.7 +
                                upmTemperature)
                            )
                            E=(upmHumidity * Es)/100
                            Tdc=(
                                -430.22+237.7 * math.log(E))/(-
                                math.log(E) + 19.08
                            )
                            #print Es, E, Tdc
                            
                            s_lst = (
                                self.name+"|"+str(upmHouse)+"|"+
                                str(upmDevice)
                            )
                            
                            if upmBattery == 1:
                                # Create the eg battery low event
                                eg.TriggerEvent(
                                    s_lst+
                                    "."+self.text.UpmAction.txtBattLow
                                )
                                    
                                if self.bLogToFile:
                                    logStr = (
                                        s_lst+"|"
                                        +str(upmBattery)+"|"
                                        +self.text.UpmAction.txtBattLow
                                    )
                                    self.LogToFile(logStr)
                                        
                            if self.bDoShowUPM:
                                eg.TriggerEvent(
                                    self.name
                                    +"|"
                                    +'HCode'
                                    +"|"
                                    +str(upmHouse)
                                    +"|"
                                    +'DCode'
                                    +"|"
                                    +str(upmDevice)
                                    +"|"
                                    +'Temp Celsius (�C)'
                                    +"|"
                                    +str(upmTemperature)
                                    +"|"
                                    +'RH%'
                                    +"|"
                                    +str(upmHumidity)
                                    +"|"
                                    +'BWarn'
                                    +"|"
                                    +str(upmBattery)
                                )
                           
                            if(
                                self.bDoTempLog
                                and self.bLogToFile
                                and int(upmDevice) != int(self.upmDeviceCode)
                                and int(upmDevice) != int(self.upmDeviceCodeOut)
                                and int(upmBattery) == 0
                                and self.captured.count(str(upmHouse)+str(upmDevice)) == 0
                            ):
                                self.LogTempToFile(
                                    "  |"
                                    +'HCode'
                                    +"|"
                                    +str(upmHouse)
                                    +"|"
                                    +'DCode'
                                    +"|"
                                    +str(upmDevice)
                                    +"|"
                                    +'BWarn'
                                    +"|"
                                    +str(upmBattery)
                                    +"|"
                                    +'RH%'
                                    +"|"
                                    +str(upmHumidity)
                                    +"|"
                                    +'Temp Celsius (�C)'
                                    +"|"
                                    +str(upmTemperature)
                                    +"|"
                                    , str(upmDevice)
                                )
                                self.captured.append(str(upmHouse)+str(upmDevice))

                                eg.scheduler.AddTask(
                                    int(self.iLogInterval*19.6),
                                    self.DoLogTempStart
                                )
                                eg.scheduler.AddTask(
                                    59,
                                    self.DoLogTempStop
                                )

                            if (int(upmHouse) == int(self.upmHouseCodeOut)
                                and int(upmDevice) == int(self.upmDeviceCodeOut)
                            ):
                                # We received signal from outdoor
                                storage[0] = upmTemperature
                                storage[1] = upmHumidity
            
                            elif (int(upmHouse) == int(self.upmHouseCode)
                                and int(upmDevice) == int(self.upmDeviceCode)
                            ):
                                # We received signal from house ground
                                storage[2] = upmTemperature
                                storage[3] = upmHumidity
                          
                                # Calculate the  amount of water in the air              
                                vOut = self.V_Calculate(storage[0],storage[1])
                                vGround = self.V_Calculate(storage[2],storage[3])
            
                                # Create eventually the eg dewpoint event
                                if (self.bDoLog and vOut != 0 and vGround != 0):
                                    if (self.upmTempDiff > upmTemperature - Tdc):
                                        eg.TriggerEvent(
                                            self.name+"|"
                                            +str(storage[1])+"|"
                                            +str(storage[0])+"|"
                                            +str(upmHumidity)+"|"
                                            +str(upmTemperature)+"|"
                                            +str(vOut)+"|"
                                            +str(vGround)+"|"
                                            +self.text.UpmAction.txtCdevPoint,
                                            payload = str(upmTemperature - Tdc)
                                        )
                                    if self.bLogToFile:
                                        logStr = (
                                            "|"
                                            +self.name+"|"
                                            +str(storage[1])+"|"
                                            +str(storage[0])+"|"
                                            +str(upmHumidity)+"|"
                                            +str(upmTemperature)+"|"
                                            +str(vOut)+"|"
                                            +str(vGround)+"|"
                                            +self.text.UpmAction.txtCdevPoint+"|"
                                            +str(upmTemperature - Tdc)+"|"
                                        )
                                        self.LogToFile(logStr)
                                    print(
                                            self.name+" |"
                                            +str(storage[1])+"|"
                                            +str(storage[0])+"|"
                                            +str(upmHumidity)+"|"
                                            +str(upmTemperature)+"|"
                                            +self.text.UpmAction.txtCdevPoint+"|"
                                            +str(upmTemperature - Tdc)
                                    )
                                    self.ShowAsOSD(
                                            self.name+"|"
                                            +self.text.UpmAction.txtCdevPoint+"|"
                                            +str(upmTemperature - Tdc),
                                            1900
                                    )
                                    eg.scheduler.AddTask(
                                        int(self.iLogInterval*58.8),
                                        self.DoLogAgain
                                    )
                                    self.bDoLog = False
    
                        if self.bDebug:
                            self.debugLogToFile(
                                "|"
                                +str(s_lst)
                                +"|"
                                +str(upmHumidity)
                                +"|"
                                +str(upmTemperature)
                                +"|"
                                +str(Tdc)
                                +"|"
                                +str(upmTemperature - Tdc)
                                +"|"
                                +str(vOut)
                                +"|"
                                +str(vGround)
                            )
                    
                        if self.bSound:                        
                            winsound.Beep(1000, 200)                
        

    def V_Calculate(self, Tc, RH):
        Tk = Tc + 273.2
        Vs = (1.32 / Tk) * math.pow((1+0.02*(Tk - 273.2)), 4)
        V = 1000 * (RH * (Vs / 100))    #g/m3
        return V


    def DoLogAgain(self):
        self.bDoLog = True


    def DoLogTempStart(self):
        self.captured = []
        self.bDoTempLog = True


    def DoLogTempStop(self):
        self.bDoTempLog = False


    def AbortUpm(self):
        time.sleep(1.0)
        print self.text.thr_abort, self.text.n_upmThread
        self.abort = True
        self.finished.set()


    def ShowAsOSD(self, msg, timeout):
        txt = msg
        txt = txt.encode("utf-8")
        eg.plugins.EventGhost.ShowOSD(
            txt, # This line is the text of the ShowOSD command..
             u'0;-13;0;0;0;700;0;0;0;1;0;0;2;32;Arial',
            (255, 255, 255),
            (0, 0, 0),
            0,
            (0, 0),
            0,
            timeout,
            False
        )


    def LogToFile(self, s):
        timeStamp = str(
            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        )
        fileDate = str(
            time.strftime("%Y%m", time.localtime())
        )
        logStr = timeStamp+s+"<br\n>"
        majorVersion, minorVersion = sys.getwindowsversion()[0:2]
        fileHandle = None

        if majorVersion > 5:
            progData = os.environ['ALLUSERSPROFILE']
            if (
                not os.path.exists(progData+"/EventGhost/Log")
                and not os.path.isdir(progData+"/EventGhost/Log")
            ):
                os.makedirs(progData+"/EventGhost/Log")
            fileHandle = open (
                progData+'/EventGhost/Log/'+fileDate+'UPM_'+
                self.name+'.html', 'a'
            )
            fileHandle.write ( logStr )
            fileHandle.close ()
            
        else:
            if not os.path.exists('Log') and not os.path.isdir('Log'):
                os.mkdir('Log')
            fileHandle = open (
                'Log/'+fileDate+'UPM_'+
                self.name+'.html', 'a'
            )
            fileHandle.write ( logStr )
            fileHandle.close ()

               
    def debugLogToFile(self, s):
        timeStamp = str(
            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        )
        fileDate = str(
            time.strftime("%Y%m%d", time.localtime())
        )
        logStr = timeStamp+s+"<br\n>"
        majorVersion, minorVersion = sys.getwindowsversion()[0:2]
        fileHandle = None

        if majorVersion > 5:
            progData = os.environ['ALLUSERSPROFILE']
            if (
                not os.path.exists(progData+"/EventGhost/Log")
                and not os.path.isdir(progData+"/EventGhost/Log")
            ):
                os.makedirs(progData+"/EventGhost/Log")
            fileHandle = open (
                progData+'/EventGhost/Log/'+fileDate+'UPM_debug'+
                self.name+'.html', 'a'
            )
            fileHandle.write ( logStr )
            fileHandle.close ()
            
        else:
            if not os.path.exists('Log') and not os.path.isdir('Log'):
                os.mkdir('Log')
            fileHandle = open ( 'Log/'+fileDate+'UPM_debug'+self.name+'.html', 'a' )
            fileHandle.write ( logStr )
            fileHandle.close ()

               
    def LogTempToFile(self, s, upmDevice):
        timeStamp = str(
            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        )
        fileDate = str(
            time.strftime("%Y%m", time.localtime())
        )
        logStr = timeStamp+s+"<br>\n"
        majorVersion, minorVersion = sys.getwindowsversion()[0:2]
        fileHandle = None

        if majorVersion > 5:
            progData = os.environ['ALLUSERSPROFILE']
            if (
                not os.path.exists(progData+"/EventGhost/Log")
                and not os.path.isdir(progData+"/EventGhost/Log")
            ):
                os.makedirs(progData+"/EventGhost/Log")
            fileHandle = open (
                progData+'/EventGhost/Log/'+fileDate+'UPM_'+
                upmDevice+'_'+'.html', 'a'
            )
            fileHandle.write ( logStr )
            fileHandle.close ()
            
        else:
            if not os.path.exists('Log') and not os.path.isdir('Log'):
                os.mkdir('Log')
            fileHandle = open (
                'Log/'+fileDate+'UPM_'+
                upmDevice+'_'+'.html', 'a'
            )
            fileHandle.write ( logStr )
            fileHandle.close ()


  
class loggerThread(Thread):
    text = Text

    def __init__(
        self,
        name,
        hostName,
        portNbr,
        bSound,
        bRepeats,
        delayRepeat,
        bLogToFile,
        bDebug,
        plugin
    ):
        Thread.__init__(self, name=self.text.n_loggerThread)
        self.name = name
        self.hostName = hostName
        self.portNbr = portNbr
        self.bSound = bSound
        self.bRepeats = bRepeats
        self.delayRepeat = delayRepeat
        self.bLogToFile = bLogToFile
        self.bDebug = bDebug
        self.finished = Event()
        self.abort = False
        self.bTaskAdded = False
        self.plugin = plugin

   
    def run(self):
        event_Old = []
       
        while (self.abort == False):
            self.finished.wait(0.1)
            self.finished.clear()

            if self.abort:
                self.finished.wait(1)
                break

            lst = []
            iPronto = 0
            
            if eg.event:
                lst = self.plugin.event_NHS.split(',')
                if (
                    lst.count('UPM.HouseCode') > 0
                    and lst.count('UPM.SequenceNumber') > 0
                ):
                    lst = lst[:13]+lst[19:]

                try:
                    iPronto = lst.index('Pronto.Message')
                except ValueError:
                    iPronto = -1 # no match

            if (
                (len(lst) > 9 or iPronto > 0)
                and lst.count("NetHomeServer") > 0
                and lst.count("UPM.DeviceCode") == 0
                and lst.count("UPM.HouseCode") == 0
                and lst.count("UPM.Humidity") == 0
                and lst.count("UPM.Temp") == 0
                and (not self.bTaskAdded
                or event_Old != lst)
            ):
                event_Old = lst

                if len(lst) > 9 or iPronto > 0:
                    s_lst = ""
                    for X in range (4,len(lst)):
                        s_lst += str(lst[X])

                        if X < len(lst):
                            s_lst += "|"

                    eg.TriggerEvent(self.name+"|"+s_lst)

                    if self.bLogToFile:
                        self.LogToFile(self.name+"|"+s_lst)

                    if self.bDebug:
                        self.debugLogToFile(
                            self.name
                            +"|"
                            +str(lst)
                        )

                    if self.bSound:                        
                        winsound.Beep(1000, 200)                

                    if self.bRepeats:
                        if not self.bTaskAdded:
                            eg.scheduler.AddTask(
                                self.delayRepeat,
                                self.ClearBuffer
                            )
                            self.bTaskAdded = True

                    else:
                        self.bTaskAdded = True
                        

    def ClearBuffer(self):
        self.plugin.event_NHS = "NIL"
        self.bTaskAdded = False
        #print self.plugin.event_NHS, self.bTaskAdded


    def Abortlogger(self):
        time.sleep(1.0)
        print self.text.thr_abort, self.text.n_loggerThread
        self.abort = True
        self.finished.set()

       
    def LogToFile(self, s):
        timeStamp = str(
            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        )
        fileDate = str(
            time.strftime("%Y%m", time.localtime())
        )
        logStr = timeStamp+s+"<br\n>"
        majorVersion, minorVersion = sys.getwindowsversion()[0:2]
        fileHandle = None

        if majorVersion > 5:
            progData = os.environ['ALLUSERSPROFILE']
            if (
                not os.path.exists(progData+"/EventGhost/Log")
                and not os.path.isdir(progData+"/EventGhost/Log")
            ):
                os.makedirs(progData+"/EventGhost/Log")
            fileHandle = open (
                progData+'/EventGhost/Log/'+fileDate+'Logger_'+
                self.name+'.html', 'a'
            )
            fileHandle.write ( logStr )
            fileHandle.close ()
            
        else:
            if not os.path.exists('Log') and not os.path.isdir('Log'):
                os.mkdir('Log')
            fileHandle = open ( 'Log/'+fileDate+'Logger_'+self.name+'.html', 'a' )
            fileHandle.write ( logStr )
            fileHandle.close ()


    def debugLogToFile(self, s):
        timeStamp = str(
            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        )
        fileDate = str(
            time.strftime("%Y%m%d", time.localtime())
        )
        logStr = timeStamp+s+"<br\n>"
        majorVersion, minorVersion = sys.getwindowsversion()[0:2]
        fileHandle = None

        if majorVersion > 5:
            progData = os.environ['ALLUSERSPROFILE']
            if (
                not os.path.exists(progData+"/EventGhost/Log")
                and not os.path.isdir(progData+"/EventGhost/Log")
            ):
                os.makedirs(progData+"/EventGhost/Log")
            fileHandle = open (
                progData+'/EventGhost/Log/'+fileDate+'Logger_debug'+
                self.name+'.html', 'a'
            )
            fileHandle.write ( logStr )
            fileHandle.close ()
            
        else:
            if not os.path.exists('Log') and not os.path.isdir('Log'):
                os.mkdir('Log')
            fileHandle = open ( 'Log/'+fileDate+'Logger_debug'+self.name+'.html', 'a' )
            fileHandle.write ( logStr )
            fileHandle.close ()
               


class Upm(eg.PluginClass):
    text = Text
        
    def __init__(self):
        self.AddAction(UpmAction)
        self.AddAction(loggerAction)
        self.AddAction(prontoCmd)
        self.AllUpmNames = []
        self.AllUpmHouseCodes = []
        self.AllUpmDeviceCodes = []
        self.AllUpmHouseCodesOut = []
        self.AllUpmDeviceCodesOut = []
        self.AllUpmTempDiffs = []
        self.AllLogToFile = []
        self.AllLogIntervals = []
        self.AllDeviceOnPeriods = []
        self.AllSound = []
        self.AllDebug = []
        self.AllDoShowUPM = []
        self.lastUpmName = ""
        self.upmThreads = {}
        self.AllloggerNames = []
        self.AllSoundL = []
        self.AllRepeatsL = []
        self.AllRepeatDelayL = []
        self.AllLogToFileL = []
        self.AllDebugL = []
        self.lastloggerName = ""
        self.loggerThreads = {}
        self.counters = {}
        self.OkButtonClicked = False
        self.started = False


    def __start__(
        self,
        hostName,
        portNbr,
    ):
        print self.text.started
        self.hostName = hostName
        self.portNbr = portNbr
        self.started = True
        self.event_NHS = ""

        if self.OkButtonClicked:
            self.OkButtonClicked = False
            self.RestartAllUpms()
            self.RestartAllLoggers()

        majorVersion, minorVersion = sys.getwindowsversion()[0:2]
        if majorVersion > 5:
            progData = os.environ['ALLUSERSPROFILE']
            if (
                not os.path.exists(progData+"/EventGhost/Log")
                and not os.path.isdir(progData+"/EventGhost/Log")
            ):
                os.makedirs(progData+"/EventGhost/Log")
        else:
            if not os.path.exists('Log') and not os.path.isdir('Log'):
                os.mkdir('Log')

        self.mainThreadEvent = Event()
        mainThread = Thread(target=self.main, args=(self.mainThreadEvent,))
        mainThread.start()


    def __stop__(self):
        self.mainThreadEvent.set()
        self.AbortAllUpms()
        self.AbortAllLoggers()
        self.started = False


    def __close__(self):
        self.mainThreadEvent.set()
        self.AbortAllUpms()
        self.AbortAllLoggers()
        self.started = False


    def main(self,mainThreadEvent):
        connectionError = True
        cCount = 0
        try:
            self.skt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.skt.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.skt.settimeout(5.0)
            self.skt.connect((self.hostName, self.portNbr))
            self.skt.sendall("subscribe\r\n")
            rsp = self.skt.recv(8)
            print self.text.subscribe, rsp

            if rsp.find("ok") != -1:
                print self.text.connection_etablished, self.skt, self.hostName
                connectionError = False
            self.skt.settimeout(600.0)

        except socket.error, e:
            print self.text.connection_error, e
            connectionError = True
            time.sleep(5.0)
            self.main(mainThreadEvent)

        while not mainThreadEvent.isSet():
            tst = ''
            try:
                if cCount > 50:
                    self.skt.sendall("\r\n")
                    time.sleep(0.2)
                    p = ''
                    p = self.skt.recv(512)
                    cCount = 0
                    if p.find("ok") == -1:
                        eg.PrintError(self.text.connection_error+p)
                        connectionError = True
                else:
                    time.sleep(0.1)
                    tst = self.skt.recv(512)
                    cCount += 1
                    time.sleep(0.1)
            except EOFError:
                print self.text.read_error, EOFError
                connectionError = True
            except socket.error, e:
                print self.text.connection_error, e
                connectionError = True

            if len(tst) > 9 or tst.find('Pronto.Message') > 0:
                e_lst = []
                e_lst = tst.split("\n\r")
                myEvent = ''
            
                for myEvent in e_lst:
                    if myEvent != '':
                        #print myEvent, len(e_lst)
                        self.event_NHS = "NetHomeServer" + "," + myEvent
                        if len(e_lst)>2:
                            time.sleep(0.3)

            if connectionError:
                time.sleep(5.0)
                self.main(mainThreadEvent)

        self.skt.close()
        time.sleep(0.1)
        print self.text.unsubscribe+"Main-"+self.text.thr_abort, mainThreadEvent


    #methods to Control Upms
    def StartUpm(
        self,
        upmName,
        hostName,
        portNbr,
        upmHouseCode,
        upmDeviceCode,
        upmHouseCodeOut,
        upmDeviceCodeOut,
        upmTempDiff,
        bLogToFile,
        iLogInterval,
        iDeviceOnPeriod,
        bSound,
        bDebug,
        bDoShowUPM
    ):
        if self.upmThreads.has_key(upmName):
            t = self.upmThreads[upmName]
            if t.isAlive():
                t.AbortUpm()
            del self.upmThreads[upmName]
        t = UpmThread(
            upmName,
            self.hostName,
            self.portNbr,
            upmHouseCode,
            upmDeviceCode,
            upmHouseCodeOut,
            upmDeviceCodeOut,
            upmTempDiff,
            bLogToFile,
            iLogInterval,
            iDeviceOnPeriod,
            bSound,
            bDebug,
            bDoShowUPM,
            self
        )
        self.upmThreads[upmName] = t
        t.start()


    def AbortUpm(self, upm):
        if self.upmThreads.has_key(upm):
            t = self.upmThreads[upm]
            t.AbortUpm()
            del self.upmThreads[upm]


    def AbortAllUpms(self):
        for i, item in enumerate(self.upmThreads):
            t = self.upmThreads[item]
            t.AbortUpm()
            del t
        self.upmThreads = {}


    def RestartAllUpms(self, startNewIfNotAlive = True):
        for i, item in enumerate(self.GetAllUpmNames()):
            if startNewIfNotAlive:
                self.StartUpm(
                    self.GetAllUpmNames()[i],
                    self.hostName,
                    self.portNbr,
                    self.GetAllUpmHouseCodes()[i],
                    self.GetAllUpmDeviceCodes()[i],
                    self.GetAllUpmHouseCodesOut()[i],
                    self.GetAllUpmDeviceCodesOut()[i],
                    self.GetAllUpmTempDiffs()[i],
                    self.GetAllLogToFile()[i],
                    self.GetAllLogIntervals()[i],
                    self.GetAllDeviceOnPeriods()[i],
                    self.GetAllSound()[i],
                    self.GetAllDebug()[i],
                    self.GetAllDoShowUPM()[i]
                )


    #methods to Control loggers
    def Startlogger(
        self,
        loggerName,
        hostName,
        portNbr,
        bSound,
        bRepeats,
        repeatDelay,
        bLogToFile,
        bDebug
    ):
        if self.loggerThreads.has_key(loggerName):
            t = self.loggerThreads[loggerName]
            if t.isAlive():
                t.Abortlogger()
            del self.loggerThreads[loggerName]
        t = loggerThread(
            loggerName,
            self.hostName,
            self.portNbr,
            bSound,
            bRepeats,
            repeatDelay,
            bLogToFile,
            bDebug,
            self
        )
        self.loggerThreads[loggerName] = t
        t.start()


    def Abortlogger(self, logger):
        print logger
        if self.loggerThreads.has_key(logger):
            t = self.loggerThreads[logger]
            t.Abortlogger()
            del self.loggerThreads[logger]


    def AbortAllLoggers(self):
        for i, item in enumerate(self.loggerThreads):
            t = self.loggerThreads[item]
            t.Abortlogger()
            del t
        self.loggerThreads = {}


    def RestartAllLoggers(self, startNewIfNotAlive = True):
        for i, item in enumerate(self.GetAllLoggerNames()):
            if startNewIfNotAlive:
                self.Startlogger(
                    self.GetAllLoggerNames()[i],
                    self.hostName,
                    self.portNbr,
                    self.GetAllSoundL()[i],
                    self.GetAllRepeatsL()[i],
                    self.GetAllRepeatDelayL()[i],
                    self.GetAllLogToFileL()[i],
                    self.GetAllDebugL()[i]
                )


    def Configure(
        self,
        hostName = "192.168.10.252",
        portNbr = 8005,
        *args
    ):
        panel = eg.ConfigPanel(self, resizable=True)

        panel.sizer.Add(
            wx.StaticText(panel, -1, self.text.listhl),
            flag = wx.ALIGN_CENTER_VERTICAL
        )

        mySizer = wx.GridBagSizer(5, 5)
        mySizer.AddGrowableRow(0)
        mySizer.AddGrowableCol(1)
        mySizer.AddGrowableCol(2)
        mySizer.AddGrowableCol(3)
       
        upmListCtrl = wx.ListCtrl(
            panel,
            -1,
            style=wx.LC_REPORT | wx.VSCROLL | wx.HSCROLL
        )
       
        for i, colLabel in enumerate(self.text.colLabels):
            upmListCtrl.InsertColumn(i, colLabel)

        #setting col width to fit label
        upmListCtrl.InsertStringItem(0, "Test Upm Name                     ")
        upmListCtrl.SetStringItem(0, 1, "  ")
        upmListCtrl.SetStringItem(0, 2, "  ")

        size = 0
        for i in range(3):
            upmListCtrl.SetColumnWidth(
                i,
                wx.LIST_AUTOSIZE_USEHEADER
            ) #wx.LIST_AUTOSIZE
            size += upmListCtrl.GetColumnWidth(i)
       
        upmListCtrl.SetMinSize((size, -1))
        
        mySizer.Add(upmListCtrl, (0,0), (1, 5), flag = wx.EXPAND)

        hostNameCtrl = wx.TextCtrl(panel, -1, hostName)
        hostNameCtrl.SetInitialSize((250,-1))
        mySizer.Add(wx.StaticText(panel, -1, self.text.hostName), (1,0))
        mySizer.Add(hostNameCtrl, (1,1))
    
        portCtrl = panel.SpinIntCtrl(portNbr, 0, 9000)
        portCtrl.SetInitialSize((75,-1))
        mySizer.Add(wx.StaticText(panel, -1, self.text.portNumber), (2,0))
        mySizer.Add(portCtrl, (2,1))

        #buttons
        abortButton = wx.Button(panel, -1, self.text.b_abort)
        mySizer.Add(abortButton, (3,0))
       
        abortAllButton = wx.Button(panel, -1, self.text.b_abortAll)
        mySizer.Add(abortAllButton, (3,1), flag = wx.ALIGN_RIGHT)
       
        restartAllButton = wx.Button(panel, -1, self.text.b_restartAll)
        mySizer.Add(restartAllButton, (3,2), flag = wx.ALIGN_RIGHT)

        refreshButton = wx.Button(panel, -1, self.text.b_refresh)
        mySizer.Add(refreshButton, (3,4), flag = wx.ALIGN_RIGHT)
       
        panel.sizer.Add(mySizer, 1, flag = wx.EXPAND)

       
        def PopulateList (event):
            upmListCtrl.DeleteAllItems()
            row = 0
            for i, item in enumerate(self.upmThreads):
                t = self.upmThreads[item]
                if t.isAlive():
                    upmListCtrl.InsertStringItem(row, t.name)
                    row += 1
            for j, item in enumerate(self.loggerThreads):
                t = self.loggerThreads[item]
                if t.isAlive():
                    upmListCtrl.InsertStringItem(row, t.name)
                    row += 1
            ListSelection(wx.CommandEvent())


        def OnAbortButton(event):
            item = upmListCtrl.GetFirstSelected()
            while item != -1:
                name = upmListCtrl.GetItemText(item)
                self.AbortUpm(name)
                self.Abortlogger(name)
                item = upmListCtrl.GetNextSelected(item)
            PopulateList(wx.CommandEvent())
            event.Skip()


        def OnAbortAllButton(event):
            self.AbortAllUpms()
            self.AbortAllLoggers()
            PopulateList(wx.CommandEvent())
            event.Skip()


        def OnRestartAllButton(event):
            self.RestartAllUpms()
            self.RestartAllLoggers()
            PopulateList(wx.CommandEvent())
            event.Skip()


        def ListSelection(event):
            flag = upmListCtrl.GetFirstSelected() != -1
            abortButton.Enable(flag)
            event.Skip()

           
        def OnSize(event):
            upmListCtrl.SetColumnWidth(
                6,
                wx.LIST_AUTOSIZE_USEHEADER
            ) #wx.LIST_AUTOSIZE
            event.Skip()


        def OnApplyButton(event): 
            event.Skip()
            self.RestartAllUpms()
            self.RestartAllLoggers()
            PopulateList(wx.CommandEvent())


        def OnOkButton(event): 
            event.Skip()
            self.OkButtonClicked = True
#            if not self.started:    
#                self.RestartAllUpms()
#                self.RestartAllLoggers()
            PopulateList(wx.CommandEvent())
         
            
        PopulateList(wx.CommandEvent())
       
        abortButton.Bind(wx.EVT_BUTTON, OnAbortButton)
        abortAllButton.Bind(wx.EVT_BUTTON, OnAbortAllButton)
        restartAllButton.Bind(wx.EVT_BUTTON, OnRestartAllButton)
        refreshButton.Bind(wx.EVT_BUTTON, PopulateList)
        upmListCtrl.Bind(wx.EVT_LIST_ITEM_SELECTED, ListSelection)
        upmListCtrl.Bind(wx.EVT_LIST_ITEM_DESELECTED, ListSelection)
        panel.Bind(wx.EVT_SIZE, OnSize)
        panel.dialog.buttonRow.applyButton.Bind(wx.EVT_BUTTON, OnApplyButton)
        panel.dialog.buttonRow.okButton.Bind(wx.EVT_BUTTON, OnOkButton)

        while panel.Affirmed():
            hostName = hostNameCtrl.GetValue()
            portNbr = portCtrl.GetValue()

            panel.SetResult(
                        hostName,
                        portNbr,
                        *args
            )


    def GetAllUpmNames(self):
        return self.AllUpmNames


    def GetAllUpmHouseCodes(self):
        return self.AllUpmHouseCodes
        
        
    def GetAllUpmDeviceCodes(self):
        return self.AllUpmDeviceCodes
        
        
    def GetAllUpmHouseCodesOut(self):
        return self.AllUpmHouseCodesOut
        
        
    def GetAllUpmDeviceCodesOut(self):
        return self.AllUpmDeviceCodesOut
        
        
    def GetAllUpmTempDiffs(self):
        return self.AllUpmTempDiffs
       
        
    def GetAllLogToFile(self):
        return self.AllLogToFile


    def GetAllLogIntervals(self):
        return self.AllLogIntervals
        

    def GetAllDeviceOnPeriods(self):
        return self.AllDeviceOnPeriods
        

    def GetAllSound(self):
        return self.AllSound


    def GetAllDebug(self):
        return self.AllDebug


    def GetAllDoShowUPM(self):
        return self.AllDoShowUPM


    def GetAllLoggerNames(self):
        return self.AllloggerNames


    def GetAllSoundL(self):
        return self.AllSoundL


    def GetAllRepeatsL(self):
        return self.AllRepeatsL


    def GetAllRepeatDelayL(self):
        return self.AllRepeatDelayL


    def GetAllLogToFileL(self):
        return self.AllLogToFileL


    def GetAllDebugL(self):
        return self.AllDebugL


    def AddUpmName(self, upmName):
        if not upmName in self.AllUpmNames:
            self.AllUpmNames.append(upmName)
        return self.AllUpmNames.index(upmName)


    def AddUpmHouseCode(self, upmHouseCode, indx):
        try:
            del self.AllUpmHouseCodes[indx]
        except IndexError:
            i = -1 # no match
        self.AllUpmHouseCodes.insert(indx, upmHouseCode)

        
    def AddUpmDeviceCode(self, upmDeviceCode, indx):
        try:
            del self.AllUpmDeviceCodes[indx]
        except IndexError:
            i = -1 # no match
        self.AllUpmDeviceCodes.insert(indx, upmDeviceCode)
 
        
    def AddUpmHouseCodeOut(self, upmHouseCodeOut, indx):
        try:
            del self.AllUpmHouseCodesOut[indx]
        except IndexError:
            i = -1 # no match
        self.AllUpmHouseCodesOut.insert(indx, upmHouseCodeOut)

        
    def AddUpmDeviceCodeOut(self, upmDeviceCodeOut, indx):
        try:
            del self.AllUpmDeviceCodesOut[indx]
        except IndexError:
            i = -1 # no match
        self.AllUpmDeviceCodesOut.insert(indx, upmDeviceCodeOut)
 
        
    def AddUpmTempDiff(self, upmTempDiff, indx):
        try:
            del self.AllUpmTempDiffs[indx]
        except IndexError:
            i = -1 # no match
        self.AllUpmTempDiffs.insert(indx, upmTempDiff)


    def AddLogToFile(self, bLogToFile, indx):
        try:
            del self.AllLogToFile[indx]
        except IndexError:
            i = -1 # no match
        self.AllLogToFile.insert(indx, bLogToFile)


    def AddLogInterval(self, iLogInterval, indx):
        try:
            del self.AllLogIntervals[indx]
        except IndexError:
            i = -1 # no match
        self.AllLogIntervals.insert(indx, iLogInterval)


    def AddDeviceOnPeriod(self, iDeviceOnPeriod, indx):
        try:
            del self.AllDeviceOnPeriods[indx]
        except IndexError:
            i = -1 # no match
        self.AllDeviceOnPeriods.insert(indx, iDeviceOnPeriod)


    def AddSound(self, bSound, indx):
        try:
            del self.AllSound[indx]
        except IndexError:
            i = -1 # no match
        self.AllSound.insert(indx, bSound)


    def AddDebug(self, bDebug, indx):
        try:
            del self.AllDebug[indx]
        except IndexError:
            i = -1 # no match
        self.AllDebug.insert(indx, bDebug)


    def AddDoShowUPM(self, bDoShowUPM, indx):
        try:
            del self.AllDoShowUPM[indx]
        except IndexError:
            i = -1 # no match
        self.AllDoShowUPM.insert(indx, bDoShowUPM)


    def AddloggerName(self, loggerName):
        if not loggerName in self.AllloggerNames:
            self.AllloggerNames.append(loggerName)
        return self.AllloggerNames.index(loggerName)


    def AddSoundL(self, bSound, indx):
        try:
            del self.AllSoundL[indx]
        except IndexError:
            i = -1 # no match
        self.AllSoundL.insert(indx, bSound)


    def AddDebugL(self, bDebug, indx):
        try:
            del self.AllDebugL[indx]
        except IndexError:
            i = -1 # no match
        self.AllDebugL.insert(indx, bDebug)


    def AddLogToFileL(self, bLogToFile, indx):
        try:
            del self.AllLogToFileL[indx]
        except IndexError:
            i = -1 # no match
        self.AllLogToFileL.insert(indx, bLogToFile)


    def AddRepeatsL(self, bRepeats, indx):
        try:
            del self.AllRepeatsL[indx]
        except IndexError:
            i = -1 # no match
        self.AllRepeatsL.insert(indx, bRepeats)


    def AddRepeatDelayL(self, repeatDelay, indx):
        try:
            del self.AllRepeatDelayL[indx]
        except IndexError:
            i = -1 # no match
        self.AllRepeatDelayL.insert(indx, repeatDelay)



class UpmAction(eg.ActionClass):
    text = Text.UpmAction
    
    def __call__(
        self,
        upmName,
        hostName,
        portNbr,
        upmHouseCode,
        upmDeviceCode,
        upmHouseCodeOut,
        upmDeviceCodeOut,
        upmTempDiff,
        bLogToFile,
        iLogInterval,
        iDeviceOnPeriod,
        bSound,
        bDebug,
        bDoShowUPM
    ):
        self.plugin.StartUpm(
            upmName,
            self.plugin.hostName,
            self.plugin.portNbr,
            upmHouseCode,
            upmDeviceCode,
            upmHouseCodeOut,
            upmDeviceCodeOut,
            upmTempDiff,
            bLogToFile,
            iLogInterval,
            iDeviceOnPeriod,
            bSound,
            bDebug,
            bDoShowUPM
        )


    def GetLabel(
        self,
        upmName,
        hostName,
        portNbr,
        upmHouseCode,
        upmDeviceCode,
        upmHouseCodeOut,
        upmDeviceCodeOut,
        upmTempDiff,
        bLogToFile,
        iLogInterval,
        iDeviceOnPeriod,
        bSound,
        bDebug,
        bDoShowUPM
    ):
        indx = self.plugin.AddUpmName(upmName)
        self.plugin.AddUpmHouseCode(upmHouseCode, indx)
        self.plugin.AddUpmDeviceCode(upmDeviceCode, indx)
        self.plugin.AddUpmHouseCodeOut(upmHouseCodeOut, indx)
        self.plugin.AddUpmDeviceCodeOut(upmDeviceCodeOut, indx)
        self.plugin.AddUpmTempDiff(upmTempDiff, indx)
        self.plugin.AddLogToFile(bLogToFile, indx)
        self.plugin.AddLogInterval(iLogInterval, indx)
        self.plugin.AddDeviceOnPeriod(iDeviceOnPeriod, indx)
        self.plugin.AddSound(bSound, indx)
        self.plugin.AddDebug(bDebug, indx)
        self.plugin.AddDoShowUPM(bDoShowUPM, indx)
        
        return self.text.upmLabelStart % (upmName)


    def Configure(
        self,
        upmName = "Give this Upm a name",
        hostName = "name",
        portNbr = 0,
        upmHouseCode = 8,
        upmDeviceCode = 4,
        upmHouseCodeOut = 8,
        upmDeviceCodeOut = 1,
        upmTempDiff = 1,
        bLogToFile = False,
        iLogInterval = 30,
        iDeviceOnPeriod = 30,
        bSound = False,
        bDebug = False,
        bDoShowUPM = True
    ):
        plugin = self.plugin
        panel = eg.ConfigPanel(self)
        mySizer_1 = wx.GridBagSizer(10, 10)
        mySizer_2 = wx.GridBagSizer(10, 10)
        mySizer_3 = wx.GridBagSizer(10, 10)

        #name
        upmNameCtrl = wx.TextCtrl(panel, -1, upmName)
        upmNameCtrl.SetInitialSize((250,-1))
        mySizer_1.Add(wx.StaticText(panel, -1, self.text.upmName), (0,0))
        mySizer_1.Add(upmNameCtrl, (0,1))

        upmHouseCodeCtrl = panel.SpinIntCtrl(int(upmHouseCode), 1, 16)
        upmHouseCodeCtrl.SetInitialSize((40,-1))
        mySizer_2.Add(
            wx.StaticText(panel, -1, self.text.txtUpmHouseCode),
            (1,0)
        )
        mySizer_2.Add(upmHouseCodeCtrl, (1,1))

        upmDeviceCodeCtrl = panel.SpinIntCtrl(int(upmDeviceCode), 1, 4)
        upmDeviceCodeCtrl.SetInitialSize((40,-1))
        mySizer_2.Add(
            wx.StaticText(panel, -1, self.text.txtUpmDeviceCode),
            (2,0)
        )
        mySizer_2.Add(upmDeviceCodeCtrl, (2,1))

        upmHouseCodeOutCtrl = panel.SpinIntCtrl(int(upmHouseCodeOut), 1, 16)
        upmHouseCodeOutCtrl.SetInitialSize((40,-1))
        mySizer_2.Add(
            wx.StaticText(panel, -1, self.text.txtUpmHouseCodeOut),
            (3,0)
        )
        mySizer_2.Add(upmHouseCodeOutCtrl, (3,1))

        upmDeviceCodeOutCtrl = panel.SpinIntCtrl(int(upmDeviceCodeOut), 1, 4)
        upmDeviceCodeOutCtrl.SetInitialSize((40,-1))
        mySizer_2.Add(
            wx.StaticText(panel, -1, self.text.txtUpmDeviceCodeOut),
            (4,0)
        )
        mySizer_2.Add(upmDeviceCodeOutCtrl, (4,1))

        upmTempDiffCtrl = panel.SpinIntCtrl(int(upmTempDiff), 0, 15)
        upmTempDiffCtrl.SetInitialSize((50,-1))
        mySizer_3.Add(
            wx.StaticText(panel, -1, self.text.txtUpmTempDiff),
            (2,0)
        )
        mySizer_3.Add(upmTempDiffCtrl, (2,1))

        iLogIntervalCtrl = panel.SpinIntCtrl(int(iLogInterval), 1, 360)
        iLogIntervalCtrl.SetInitialSize((50,-1))
        mySizer_3.Add(
            wx.StaticText(panel, -1, self.text.txtLogInterval),
            (3,0)
        )
        mySizer_3.Add(iLogIntervalCtrl, (3,1))

        """
        iDeviceOnPeriodCtrl = panel.SpinIntCtrl(int(iDeviceOnPeriod), 1, 360)
        iDeviceOnPeriodCtrl.SetInitialSize((50,-1))
        mySizer_3.Add(
            wx.StaticText(panel, -1, self.text.txtOnPeriod),
            (4,0)
        )
        mySizer_3.Add(iDeviceOnPeriodCtrl, (4,1))

        """

        bLogToFileCtrl = wx.CheckBox(panel, -1, "")
        bLogToFileCtrl.SetValue(bLogToFile)
        mySizer_3.Add(wx.StaticText(panel, -1, self.text.logToFile), (5,0))
        mySizer_3.Add(bLogToFileCtrl, (5,1))

        bSoundCtrl = wx.CheckBox(panel, -1, "")
        bSoundCtrl.SetValue(bSound)
        mySizer_3.Add(wx.StaticText(panel, -1, self.text.soundOnEvent), (6,0))
        mySizer_3.Add(bSoundCtrl, (6,1))

        bDebugCtrl = wx.CheckBox(panel, -1, "")
        bDebugCtrl.SetValue(bDebug)
        mySizer_3.Add(wx.StaticText(panel, -1, self.text.debug), (7,0))
        mySizer_3.Add(bDebugCtrl, (7,1))

        bDoShowUPMCtrl = wx.CheckBox(panel, -1, "")
        bDoShowUPMCtrl.SetValue(bDoShowUPM)
        mySizer_3.Add(wx.StaticText(panel, -1, self.text.doShowUPM), (8,0))
        mySizer_3.Add(bDoShowUPMCtrl, (8,1))

        panel.sizer.Add(mySizer_1, 0, flag = wx.EXPAND)
        panel.sizer.Add(mySizer_2, 0, flag = wx.EXPAND)
        panel.sizer.Add(mySizer_3, 0, flag = wx.EXPAND)


        def OnButton(event): 
            # re-assign the OK button
            event.Skip()
            
            upmName = upmNameCtrl.GetValue()
            plugin.lastUpmName = upmName
            indx = plugin.AddUpmName(upmName)
            hostName = self.plugin.hostName
            portNbr = self.plugin.portNbr
            upmHouseCode = upmHouseCodeCtrl.GetValue()
            plugin.AddUpmHouseCode(upmHouseCode, indx)
            upmDeviceCode = upmDeviceCodeCtrl.GetValue()
            plugin.AddUpmDeviceCode(upmDeviceCode, indx)
            upmHouseCodeOut = upmHouseCodeOutCtrl.GetValue()
            plugin.AddUpmHouseCodeOut(upmHouseCodeOut, indx)
            upmDeviceCodeOut = upmDeviceCodeOutCtrl.GetValue()
            plugin.AddUpmDeviceCodeOut(upmDeviceCodeOut, indx)
            upmTempDiff = upmTempDiffCtrl.GetValue()
            plugin.AddUpmTempDiff(upmTempDiff, indx)
            bLogToFile = bLogToFileCtrl.GetValue()
            plugin.AddLogToFile(bLogToFile, indx)
            iLogInterval = iLogIntervalCtrl.GetValue()
            plugin.AddLogInterval(iLogInterval, indx)
            #iDeviceOnPeriod = iDeviceOnPeriodCtrl.GetValue()
            iDeviceOnPeriod = 30
            plugin.AddDeviceOnPeriod(iDeviceOnPeriod, indx)
            bSound = bSoundCtrl.GetValue()
            plugin.AddSound(bSound, indx)
            bDebug = bDebugCtrl.GetValue()
            plugin.AddDebug(bDebug, indx)
            bDoShowUPM = bDoShowUPMCtrl.GetValue()
            plugin.AddDoShowUPM(bDoShowUPM, indx)
            
            self.plugin.RestartAllUpms()

        panel.dialog.buttonRow.okButton.Bind(wx.EVT_BUTTON, OnButton)

        while panel.Affirmed():
            upmName = upmNameCtrl.GetValue()
            plugin.lastUpmName = upmName
            indx = plugin.AddUpmName(upmName)
            hostName = self.plugin.hostName
            portNbr = self.plugin.portNbr
            upmHouseCode = upmHouseCodeCtrl.GetValue()
            plugin.AddUpmHouseCode(upmHouseCode, indx)
            upmDeviceCode = upmDeviceCodeCtrl.GetValue()
            plugin.AddUpmDeviceCode(upmDeviceCode, indx)
            upmHouseCodeOut = upmHouseCodeOutCtrl.GetValue()
            plugin.AddUpmHouseCodeOut(upmHouseCodeOut, indx)
            upmDeviceCodeOut = upmDeviceCodeOutCtrl.GetValue()
            plugin.AddUpmDeviceCodeOut(upmDeviceCodeOut, indx)
            upmTempDiff = upmTempDiffCtrl.GetValue()
            plugin.AddUpmTempDiff(upmTempDiff, indx)
            bLogToFile = bLogToFileCtrl.GetValue()
            plugin.AddLogToFile(bLogToFile, indx)
            iLogInterval = iLogIntervalCtrl.GetValue()
            plugin.AddLogInterval(iLogInterval, indx)
            #iDeviceOnPeriod = iDeviceOnPeriodCtrl.GetValue()
            iDeviceOnPeriod = 30
            plugin.AddDeviceOnPeriod(iDeviceOnPeriod, indx)
            bSound = bSoundCtrl.GetValue()
            plugin.AddSound(bSound, indx)
            bDebug = bDebugCtrl.GetValue()
            plugin.AddDebug(bDebug, indx)
            bDoShowUPM = bDoShowUPMCtrl.GetValue()
            plugin.AddDoShowUPM(bDoShowUPM, indx)

            panel.SetResult(
                upmName,
                hostName,
                portNbr,
                upmHouseCode,
                upmDeviceCode,
                upmHouseCodeOut,
                upmDeviceCodeOut,
                upmTempDiff,
                bLogToFile,
                iLogInterval,
                iDeviceOnPeriod,
                bSound,
                bDebug,
                bDoShowUPM
            )


             
class loggerAction(eg.ActionClass):
    text = Text.loggerAction
    
    def __call__(
        self,
        loggerName,
        hostName,
        portNbr,
        bSound,
        bRepeats,
        repeatDelay,
        bLogToFile,
        bDebug
    ):
        self.plugin.Startlogger(
            loggerName,
            hostName,
            portNbr,
            bSound,
            bRepeats,
            repeatDelay,
            bLogToFile,
            bDebug
        )


    def GetLabel(
        self,
        loggerName,
        hostName,
        portNbr,
        bSound,
        bRepeats,
        repeatDelay,
        bLogToFile,
        bDebug
    ):
        indx = self.plugin.AddloggerName(loggerName)
        self.plugin.AddSoundL(bSound, indx)
        self.plugin.AddRepeatDelayL(repeatDelay, indx)
        self.plugin.AddRepeatsL(bRepeats, indx)
        self.plugin.AddLogToFileL(bLogToFile, indx)
        self.plugin.AddDebugL(bDebug, indx)
        
        return self.text.labelStart % (loggerName)


    def Configure(
        self,
        loggerName = "Give this logger a name",
        hostName = "name",
        portNbr = 0,
        bSound = False,
        bRepeats = True,
        repeatDelay = 5.0,
        bLogToFile = True,
        bDebug = False
    ):
        plugin = self.plugin
        panel = eg.ConfigPanel(self)
        mySizer_1 = wx.GridBagSizer(10, 10)
        mySizer_2 = wx.GridBagSizer(5, 5)
        mySizer_3 = wx.GridBagSizer(10, 10)

        #name
        loggerNameCtrl = wx.TextCtrl(panel, -1, loggerName)
        loggerNameCtrl.SetInitialSize((250,-1))
        mySizer_1.Add(wx.StaticText(panel, -1, self.text.loggerName), (0,0))
        mySizer_1.Add(loggerNameCtrl, (0,1))

        bRepeatsCtrl = wx.CheckBox(panel, -1, "")
        bRepeatsCtrl.SetValue(bRepeats)
        mySizer_1.Add(wx.StaticText(panel, -1, self.text.repeats), (1,0))
        mySizer_1.Add(bRepeatsCtrl, (1,1))

        repeatDelayCtrl = panel.SpinNumCtrl(
            repeatDelay,
            decimalChar = '.', # by default, use '.' for decimal point
            groupChar = ',',   # by default, use ',' for grouping
            fractionWidth = 1,
            integerWidth = 3,
            min = 0.0,
            max = 999.9,
            increment = 0.5
        )
        repeatDelayCtrl.SetInitialSize((60,-1))
        mySizer_2.Add(wx.StaticText(panel, -1, self.text.delay), (2,1))
        mySizer_2.Add(repeatDelayCtrl, (2,2))
        mySizer_2.Add(wx.StaticText(panel, -1, self.text.delay_u), (2,3))

        bLogToFileCtrl = wx.CheckBox(panel, -1, "")
        bLogToFileCtrl.SetValue(bLogToFile)
        mySizer_3.Add(wx.StaticText(panel, -1, self.text.logToFile), (3,0))
        mySizer_3.Add(bLogToFileCtrl, (3,1))

        bSoundCtrl = wx.CheckBox(panel, -1, "")
        bSoundCtrl.SetValue(bSound)
        mySizer_3.Add(wx.StaticText(panel, -1, self.text.soundOnEvent), (4,0))
        mySizer_3.Add(bSoundCtrl, (4,1))

        bDebugCtrl = wx.CheckBox(panel, -1, "")
        bDebugCtrl.SetValue(bDebug)
        mySizer_3.Add(wx.StaticText(panel, -1, self.text.debug), (5,0))
        mySizer_3.Add(bDebugCtrl, (5,1))

        panel.sizer.Add(mySizer_1, 0, flag = wx.EXPAND)
        panel.sizer.Add(mySizer_2, 0, flag = wx.EXPAND)
        panel.sizer.Add(mySizer_3, 0, flag = wx.EXPAND)


        def OnButton(event): 
            # re-assign the OK button
            event.Skip()
            
            loggerName = loggerNameCtrl.GetValue()
            plugin.lastloggerName = loggerName
            indx = plugin.AddloggerName(loggerName)
            hostName = self.plugin.hostName
            portNbr = self.plugin.portNbr
            bSound = bSoundCtrl.GetValue()
            plugin.AddSoundL(bSound, indx)
            bRepeats = bRepeatsCtrl.GetValue()
            plugin.AddRepeatsL(bRepeats, indx)
            repeatDelay = repeatDelayCtrl.GetValue()
            plugin.AddRepeatDelayL(repeatDelay, indx)
            bLogToFile = bLogToFileCtrl.GetValue()
            plugin.AddLogToFileL(bLogToFile, indx)
            bDebug = bDebugCtrl.GetValue()
            plugin.AddDebugL(bDebug, indx)

            self.plugin.RestartAllLoggers()

        panel.dialog.buttonRow.okButton.Bind(wx.EVT_BUTTON, OnButton)

        while panel.Affirmed():
            loggerName = loggerNameCtrl.GetValue()
            plugin.lastloggerName = loggerName
            indx = plugin.AddloggerName(loggerName)
            hostName = self.plugin.hostName
            portNbr = self.plugin.portNbr
            bSound = bSoundCtrl.GetValue()
            plugin.AddSoundL(bSound, indx)
            bRepeats = bRepeatsCtrl.GetValue()
            plugin.AddRepeatsL(bRepeats, indx)
            repeatDelay = repeatDelayCtrl.GetValue()
            plugin.AddRepeatDelayL(repeatDelay, indx)
            bLogToFile = bLogToFileCtrl.GetValue()
            plugin.AddLogToFileL(bLogToFile, indx)
            bDebug = bDebugCtrl.GetValue()
            plugin.AddDebugL(bDebug, indx)
            
            panel.SetResult(
                loggerName,
                hostName,
                portNbr,
                bSound,
                bRepeats,
                repeatDelay,
                bLogToFile,
                bDebug
            )


   
class prontoCmd(eg.ActionClass):
    text = Text.prontoCmd
    
    def __call__(
        self,
        deviceName,
        pronto
    ):
    	header = "event,Pronto_Message,Direction,Out,Pronto.Message,"
        connectionError = True
        try:
            self.skt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.skt.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.skt.settimeout(5.0)
            self.skt.connect((self.plugin.hostName, self.plugin.portNbr))
            self.skt.sendall("\r\n")
            rsp = self.skt.recv(512)
            if rsp.find("ok") != -1:
                connectionError = False
        except socket.error, e:
            print self.plugin.text.connection_error, e
            connectionError = True
            
        s = header+str(pronto)+"\r\n"
        time.sleep(0.05)
        self.skt.sendall(s)
        time.sleep(0.1)
        self.skt.sendall("quit\r\n")
        self.skt.close()


    def Configure(
        self,
        deviceName = "Give the device a name",
        pronto = (
            "0000 0073 0000 0019 000e 002a 000e 002a 000e 002a 000e "+
            "002a 000e 002a 000e 002a 000e 002a 000e 002a 000e 002a "+
            "000e 002a 000e 002a 000e 002a 000e 002a 000e 002a 000e "+
            "002a 000e 002a 000e 002a 000e 002a 000e 002a 002a 000e "+
            "000e 002a 002a 000e 000e 002a 002a 000e 000e 0199"
        )
    ):
        plugin = self.plugin
        panel = eg.ConfigPanel(self)
        mySizer_1 = wx.GridBagSizer(10, 10)
        mySizer_2 = wx.GridBagSizer(10, 10)

        #name
        deviceNameCtrl = wx.TextCtrl(panel, -1, deviceName)
        deviceNameCtrl.SetInitialSize((250,-1))
        mySizer_1.Add(wx.StaticText(panel, -1, self.text.deviceName), (0,0))
        mySizer_1.Add(deviceNameCtrl, (1,0))

        #pronto
        prontoCtrl = wx.TextCtrl(panel, -1, pronto, style=wx.TE_MULTILINE)
        prontoCtrl.SetInitialSize((400,-1))
        mySizer_2.Add(wx.StaticText(panel, -1, self.text.pronto), (1,0))
        mySizer_2.Add(prontoCtrl, (2,0))

        panel.sizer.Add(mySizer_1, 0, flag = wx.EXPAND)
        panel.sizer.Add(mySizer_2, 0, flag = wx.EXPAND)

        while panel.Affirmed():
            deviceName = deviceNameCtrl.GetValue()
            pronto = prontoCtrl.GetValue()
            panel.SetResult(
                deviceName,
                pronto
            )


